def test_good():
    raise AssertionError("collect-only must never execute this")
