"""Task-local monitored diagnostic; collection is never scientific acceptance."""
import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2];task=Path(__file__).parent
stage,suffix=sys.argv[1:3];assert stage in ('collect','admin','offline','comparison','checks','committed')
retained_engine=sys.argv[3:]==['--retained-engine'];assert sys.argv[3:] in ([],['--retained-engine'])
attempt=task/(stage+'-'+suffix);attempt.mkdir(exist_ok=False)
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available()>policy['available_reserve_bytes']+512*1024**2
for name in ('run.py','worker.py'):
 source=task/name
 if stage=='offline' and suffix=='pm-fs' and name=='worker.py':source=task/'offline-normal/frozen-worker.py'
 shutil.copyfile(source,attempt/('frozen-'+name))
if stage=='offline' and suffix=='pm-fs':assert json.loads((task/'offline-normal/resource-outcome.json').read_text())['outcome']=='PASS'
registration={'stage':stage,'policy':policy,'initial_available_bytes':available(),'estimated_group_rss_bytes':512*1024**2,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Collection/import and offline administrative diagnostics only; no scientific/native execution or installed gate PASS'}
registration['retained_engine']=retained_engine
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy();env.update(DMT_COLLECTION_ROOT=str(root),DMT_COLLECTION_TASK=str(task),DMT_COLLECTION_ATTEMPT=str(attempt),DMT_COLLECTION_STAGE=stage,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(attempt/'tmp'),XDG_CACHE_HOME=str(attempt/'cache'),MPLCONFIGDIR=str(attempt/'mpl'),MAKEFLAGS='-j1',CMAKE_BUILD_PARALLEL_LEVEL='1')
if retained_engine:
 engine=root/'.molsyssuite/e5-timed-replay-20261107/layouts-admission-01/producer/engine'
 env['DMT_COLLECTION_ENGINE']=str(engine)
 env['LD_LIBRARY_PATH']=str(engine/'lib')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
for name in ['tmp','cache','mpl']:(attempt/name).mkdir()
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:env[key]='1'
py=root/'.molsyssuite/record-wheel-inputs-20261109/receiver/bin/python'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
 process=subprocess.Popen([str(py),'-I','-B',str(attempt/'frozen-worker.py')],cwd=attempt,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
 outcome=monitor(process,policy)
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
if (attempt/'receipt.json').exists():print((attempt/'receipt.json').read_text()[:1300])
if outcome['outcome']!='PASS':print((attempt/'stderr.log').read_text()[-1300:]);raise SystemExit(1)
