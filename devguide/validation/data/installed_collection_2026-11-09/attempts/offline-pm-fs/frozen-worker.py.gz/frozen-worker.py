"""Receive all test-module imports without executing a test or fixture."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tomllib

root=Path(os.environ['DMT_COLLECTION_ROOT']);task=Path(os.environ['DMT_COLLECTION_TASK']);attempt=Path(os.environ['DMT_COLLECTION_ATTEMPT']);stage=os.environ['DMT_COLLECTION_STAGE']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
sdk=root/'.molsyssuite/publication-sdk'
assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45'
assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
artifact=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/artifact.json').read_text());assert sha(artifact['wheel'])==artifact['wheel_sha256']
installation=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/installation.json').read_text());site=Path(installation['site'])
for group in ['consumer_sha256','tool_sha256','unit_sha256']:
 for name,digest in installation[group].items():assert sha(site/name)==digest
if stage=='admin':
 sys.path.insert(0,str(root))
 import pytest
 import xml.etree.ElementTree as ET
 selected=['devtools/tests/test_test_support_boundaries.py','devtools/tests/test_installed_support.py']
 status=int(pytest.main(['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'pytest-cache')]+[str(root/n) for n in selected]))
 counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
 save(attempt/'receipt.json',{'stage':stage,'pytest_exit_code':status,'counts':counts})
 raise SystemExit(status)
def cohort():
 return {name:{'commit':subprocess.check_output(['git','-C',str(root.parent/name),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(root.parent/name),'status','--porcelain'],text=True),'python_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.py')},'native_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.so')}} for name in ['molsysmt','molsysviewer','argdigest','smonitor','depdigest','pyunitwizard']}
before=cohort();save(attempt/'cohort.json',before)
engine=None
if os.environ.get('DMT_COLLECTION_ENGINE'):
 engine=Path(os.environ['DMT_COLLECTION_ENGINE']);engine_receipt=root/'.molsyssuite/e1-public-composition-20261106/final_engine_byte_receipt.json'
 engine_hashes=json.loads(engine_receipt.read_text())['paths'];assert len(engine_hashes)==103
 assert all(sha(engine/n)==digest for n,digest in engine_hashes.items())
 shutil.copyfile(engine_receipt,attempt/'frozen-engine-byte-receipt.json');sys.path.insert(0,str(engine/'lib/python3.14/site-packages'))
sys.path.insert(0,str(sdk))
from devtools.scripts.installed_imports import check_installed_imports
from devtools.scripts.installed_test_support import staged_support
roots=('dockingmt','molsysviewer_dockingmt')
harness=attempt/'harness';harness.mkdir()
with (attempt/'source.tar').open('wb') as stream:subprocess.run(['git','archive','HEAD'],cwd=root,stdout=stream,check=True)
with tarfile.open(attempt/'source.tar') as stream:stream.extractall(harness,filter='data')
(attempt/'source.tar').unlink()
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','tests','dmt_test_support','devtools/tests'],cwd=root,text=True).splitlines()
for name in set(changed+untracked):
 if name.startswith(('tests/','dmt_test_support/','devtools/tests/')) or name=='devtools/conda-build/resources.toml':
  destination=harness/name
  if (root/name).is_file():destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,destination)
  elif destination.exists():destination.unlink()
for name in roots:shutil.rmtree(harness/name)
input_files={str(p.relative_to(harness)):sha(p) for folder in ['tests','dmt_test_support'] for p in (harness/folder).rglob('*') if p.is_file()}
save(attempt/'qualification-inputs.json',input_files)
inventory=tomllib.loads((harness/'devtools/conda-build/resources.toml').read_text());shutil.copyfile(harness/'devtools/conda-build/resources.toml',attempt/'frozen-resources.toml')
assert root not in [Path(p).resolve() for p in sys.path if p] and harness not in [Path(p).resolve() for p in sys.path if p]
origins=check_installed_imports(roots,Path(sys.prefix),harness)
blocked_calls=[]
def forbid(*args,**kwargs):blocked_calls.append('molecular/engine operation');raise AssertionError('Collection attempted a molecular/engine operation')
import molsysmt as msm
import molsysviewer as msv
for name in ['get','set','select','convert','extract','copy','append_structures']:setattr(msm,name,forbid)
msv.MolSysView=forbid
if engine is not None:
 import vina
 assert Path(vina.__file__).resolve().is_relative_to(engine/'lib/python3.14/site-packages/vina')
 vina.Vina.__init__=forbid
import pytest
if stage=='offline':
 import importlib.abc
 import xml.etree.ElementTree as ET
 import pyunitwizard as puw
 from devtools.scripts.installed_noarch import run_tests
 class BlockEngines(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['vina','rdkit','openmm']:blocked_calls.append(fullname);raise AssertionError('Offline receiving imported an optional engine')
 sys.meta_path.insert(0,BlockEngines())
 selection=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/selection.json').read_text());save(attempt/'selection.json',selection)
 inventory['import_name']='dockingmt';inventory['installed_tests']['paths']=[n for n in selection if n.startswith('tests/')]
 inventory['installed_tests']['pytest_args']=['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'pytest-cache')]+[n for n in selection if n.startswith('--deselect=')]
 profile=attempt.name.removeprefix('offline-');assert profile in ('normal','pm-fs')
 units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if profile=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
 with puw.context(default_form='pint',standard_units=units):
  caller=puw.configure.report();status=run_tests(harness,inventory,support_output=attempt/'support-sidecar.json',support_context={'sha256':artifact['wheel_sha256'],'provider_sha':'95f693be10c9205ab9b912cb53453710a207bf45'})
  for key in ['default_form','default_parser','standard_units']:assert caller[key]==puw.configure.report()[key]
 counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
 from pytest_receptor import read_artifact
 events=read_artifact(attempt/'events.jsonl');assert events.complete and not blocked_calls and cohort()==before
 for group in ['consumer_sha256','tool_sha256','unit_sha256']:
  for name,digest in installation[group].items():assert sha(site/name)==digest
 assert all(sha(harness/n)==digest for n,digest in input_files.items())
 save(attempt/'receipt.json',{'stage':stage,'profile':profile,'pytest_exit_code':int(status),'counts':counts,'receptor_final':events.final.data,'wheel_sha256':artifact['wheel_sha256'],'support_inputs':len(inventory['installed_tests']['support']['files']),'blocked_calls':blocked_calls,'cohort_unchanged':True,'caller_policy':caller,'installed_origins':check_installed_imports(roots,Path(sys.prefix),harness)})
 raise SystemExit(status)
class CollectionGuard:
 executed=0
 def pytest_runtest_setup(self,item):raise AssertionError('Collection diagnostic attempted test execution')
 def pytest_runtest_logreport(self,report):self.executed+=1
 def pytest_collection_finish(self,session):save(attempt/'collected.json',[item.nodeid for item in session.items])
guard=CollectionGuard();support=None
with staged_support(harness,inventory['installed_tests']['support'],roots,context={'sha256':artifact['wheel_sha256'],'provider_sha':'95f693be10c9205ab9b912cb53453710a207bf45'}) as support:
 support.check();origins=check_installed_imports(roots,Path(sys.prefix),harness)
 status=int(pytest.main(['--collect-only','--import-mode=importlib','--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'-o','pythonpath=','-o','cache_dir='+str(attempt/'pytest-cache'),str(harness/'tests')],plugins=[guard]))
 support.check();check_installed_imports(roots,Path(sys.prefix),harness)
save(attempt/'support-sidecar.json',support.receipt)
from pytest_receptor import read_artifact
events=read_artifact(attempt/'events.jsonl');assert events.complete and guard.executed==0
assert all(sha(harness/n)==digest for n,digest in input_files.items())
assert not blocked_calls and cohort()==before
if engine is not None:assert all(sha(engine/n)==digest for n,digest in engine_hashes.items())
for group in ['consumer_sha256','tool_sha256','unit_sha256']:
 for name,digest in installation[group].items():assert sha(site/name)==digest
save(attempt/'receipt.json',{'stage':stage,'scope':'collection only; zero tests and fixtures executed','pytest_exit_code':status,'collected':len(json.loads((attempt/'collected.json').read_text())),'executed':guard.executed,'blocked_calls':blocked_calls,'receptor_final':events.final.data,'wheel_sha256':artifact['wheel_sha256'],'installed_origins':origins,'support_inputs':len(inventory['installed_tests']['support']['files']),'retained_engine':str(engine) if engine else None,'retained_engine_paths':len(engine_hashes) if engine else 0,'cohort_unchanged':True})
raise SystemExit(status)
