"""Receive all test-module imports without executing a test or fixture."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tomllib

root=Path(os.environ['DMT_COLLECTION_ROOT']);task=Path(os.environ['DMT_COLLECTION_TASK']);attempt=Path(os.environ['DMT_COLLECTION_ATTEMPT']);stage=os.environ['DMT_COLLECTION_STAGE']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
sdk=root/'.molsyssuite/publication-sdk'
assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45'
assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
artifact=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/artifact.json').read_text());assert sha(artifact['wheel'])==artifact['wheel_sha256']
installation=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/installation.json').read_text());site=Path(installation['site'])
for group in ['consumer_sha256','tool_sha256','unit_sha256']:
 for name,digest in installation[group].items():assert sha(site/name)==digest
sys.path.insert(0,str(sdk))
from devtools.scripts.installed_imports import check_installed_imports
from devtools.scripts.installed_test_support import staged_support
roots=('dockingmt','molsysviewer_dockingmt')
harness=attempt/'harness';harness.mkdir()
with (attempt/'source.tar').open('wb') as stream:subprocess.run(['git','archive','HEAD'],cwd=root,stdout=stream,check=True)
with tarfile.open(attempt/'source.tar') as stream:stream.extractall(harness,filter='data')
(attempt/'source.tar').unlink()
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','tests','dmt_test_support','devtools/tests'],cwd=root,text=True).splitlines()
for name in set(changed+untracked):
 if name.startswith(('tests/','dmt_test_support/','devtools/tests/')) or name=='devtools/conda-build/resources.toml':
  destination=harness/name
  if (root/name).is_file():destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,destination)
  elif destination.exists():destination.unlink()
for name in roots:shutil.rmtree(harness/name)
input_files={str(p.relative_to(harness)):sha(p) for folder in ['tests','dmt_test_support'] for p in (harness/folder).rglob('*') if p.is_file()}
save(attempt/'qualification-inputs.json',input_files)
inventory=tomllib.loads((harness/'devtools/conda-build/resources.toml').read_text());shutil.copyfile(harness/'devtools/conda-build/resources.toml',attempt/'frozen-resources.toml')
assert root not in [Path(p).resolve() for p in sys.path if p] and harness not in [Path(p).resolve() for p in sys.path if p]
origins=check_installed_imports(roots,Path(sys.prefix),harness)
import pytest
class CollectionGuard:
 executed=0
 def pytest_runtest_setup(self,item):raise AssertionError('Collection diagnostic attempted test execution')
 def pytest_runtest_logreport(self,report):self.executed+=1
 def pytest_collection_finish(self,session):save(attempt/'collected.json',[item.nodeid for item in session.items])
guard=CollectionGuard();support=None
with staged_support(harness,inventory['installed_tests']['support'],roots,context={'sha256':artifact['wheel_sha256'],'provider_sha':'95f693be10c9205ab9b912cb53453710a207bf45'}) as support:
 support.check();origins=check_installed_imports(roots,Path(sys.prefix),harness)
 status=int(pytest.main(['--collect-only','--import-mode=importlib','--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'-o','pythonpath=','-o','cache_dir='+str(attempt/'pytest-cache'),str(harness/'tests')],plugins=[guard]))
 support.check();check_installed_imports(roots,Path(sys.prefix),harness)
save(attempt/'support-sidecar.json',support.receipt)
from pytest_receptor import read_artifact
events=read_artifact(attempt/'events.jsonl');assert events.complete and guard.executed==0
assert all(sha(harness/n)==digest for n,digest in input_files.items())
save(attempt/'receipt.json',{'stage':stage,'scope':'collection only; zero tests and fixtures executed','pytest_exit_code':status,'collected':len(json.loads((attempt/'collected.json').read_text())),'executed':guard.executed,'receptor_final':events.final.data,'wheel_sha256':artifact['wheel_sha256'],'installed_origins':origins,'support_inputs':len(inventory['installed_tests']['support']['files'])})
raise SystemExit(status)
