# Isolated installed collection receiving — 2026-11-09

Owner: [DockingMT #102](https://github.com/uibcdf/dockingmt/issues/102), within
installed qualification #47 and functional delivery #73.

Starting source: `9375f3a8b96a651f8944c48105d56d33a0cf4c68`.
Use the retained, normally installed wheel from runtime producer9a40e385,
SHA256 `0ed16b5a607a684be611b964b1996f56cc3273f7fcf012e6f86403551f3e91dd`.
No runtime or wheel change is authorized by this test-support increment.

The diagnostic uses shared publication SDK95f693be staging, both installed
runtime origin checks, an exported qualification harness with core/addon source
removed, importlib mode and empty pytest pythonpath. `--collect-only` and a
runtest refusal hook ensure zero executed tests/fixtures. Whole-suite collection
is an import prerequisite; it is never called a scientific installed gate PASS.

Each cell uses CPU0/nice10, one native/build worker, 13GiB available-RAM reserve,
1GiB group RSS,2GiB address space,45CPU/60wall seconds. Initial estimate512MiB;
monitor owned descendants and retain every interrupted/failed attempt. No Slurm
allocation is present; the prior scheduler probe was inconclusive.

Initial `collect-01`: exit2,1,996 collected,47 collection failures,zero runtest
reports,595 support inputs checked/retired,21.096s,368,603,136B peak group RSS,
55,859,073,024B minimum available RAM, no resource interruption. Missing optional
Vina and sibling-test imports are separate causes. Pytest Receptor1.2.2 retains
exit2/COLLECTION_ERROR but conflates collection failures with executed counts;
the existing provider owner is pytest-receptor#46. Native hooks govern scope.

Acceptance: move the shared finite factories/declarations once into unshipped
support; preserve all scientific test/function bodies and data/producers, with
only explicit helper-path/import routing changes. Keep original595 declarations
exact, register added helper SHA256 inputs and receive guards plus isolated
collection. Optional missing tools and full execution remain separate evidence.
