"""Observe saved-protocol coercion without molecular or native execution."""
from copy import deepcopy
import importlib.metadata
import json
import os
from pathlib import Path
import sys

import dockingmt as dmt
import pyunitwizard as puw

attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
rows = []
def observe(function):
    try:
        result = function()
        return {'accepted': True, 'value': puw.get_value(result.energy_range, to_unit='kcal/mol', value_type=float)}
    except Exception as error:
        return {'accepted': False, 'error_type': type(error).__name__, 'code': getattr(error, 'code', None), 'argument': getattr(error, 'extra', {}).get('arg_name')}
for label, value in [('boolean_true', True), ('boolean_false', False), ('numeric_text', '3'), ('integer', 3), ('float', 3.0), ('vector', [3]), ('complex', 3 + 0j)]:
    record = {'parameters': {'energy_range': {'value': value, 'unit': 'kcal/mol'}}}
    before = deepcopy(record)
    rows.append({'case': label, 'constructor': observe(lambda: dmt.VinaProtocol(energy_range=puw.quantity(value, 'kcal/mol'))), 'reader': observe(lambda: dmt.VinaProtocol.from_dict(record)), 'source_preserved': record == before})
assert all(row['source_preserved'] for row in rows)
assert rows[0]['reader']['accepted'] and not rows[0]['constructor']['accepted']
assert rows[1]['reader']['accepted'] and not rows[1]['constructor']['accepted']
assert rows[2]['reader']['accepted']
result = {'observations': rows, 'versions': {name: importlib.metadata.version(name) for name in ['dockingmt', 'argdigest', 'smonitor', 'pyunitwizard', 'numpy']}, 'consumer_origin': dmt.__file__, 'molecular_operations': 0, 'native_searches': 0, 'scope': 'Confirmed saved-protocol Boolean coercion; diagnosis only, not correction acceptance'}
(attempt / 'observations.json').write_text(json.dumps(result, indent=2) + '\n')
assert not any(name.split('.')[0] in {'vina', 'molsysviewer', 'rdkit', 'openmm'} for name in sys.modules)
print(json.dumps({'bug_confirmed': True, 'observed_rows': len(rows)}))
