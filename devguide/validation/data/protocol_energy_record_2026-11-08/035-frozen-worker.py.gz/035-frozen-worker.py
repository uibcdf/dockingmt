"""Preserve complete red/green offline selections and their raw pytest evidence."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
stage = attempt.name.split('-')[0]
plan = json.loads((task / 'plan.json').read_text())
profiles = ['normal'] if stage == 'red' else ['normal', 'pm-fs']
inputs = ['dockingmt/core/protocol.py', 'tests/test_protocol.py', 'tests/test_argument_contracts.py', 'tests/test_serialization_contracts.py']
before = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in inputs}
if stage == 'red':
    assert before['dockingmt/core/protocol.py'] == plan['original_protocol_sha256']
for name in inputs:
    shutil.copyfile(root / name, attempt / ('frozen-' + name.replace('/', '__')))
shutil.copyfile(task / 'test_child.py', attempt / 'frozen-test_child.py')
observations = []
for profile in profiles:
    with (attempt / (profile + '.log')).open('xb') as stream:
        result = subprocess.run([sys.executable, '-B', '-I', str(attempt / 'frozen-test_child.py'), profile], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    parsed = ET.parse(attempt / (profile + '.xml'))
    counts = {key: sum(int(row.get(key, '0')) for row in parsed.getroot().iter('testsuite')) for key in ['tests', 'failures', 'errors', 'skipped']}
    receipt = json.loads((attempt / (profile + '-receipt.json')).read_text())
    assert result.returncode == receipt['pytest_exit_code'] and counts['errors'] == counts['skipped'] == 0
    assert result.returncode == (1 if stage == 'red' else 0)
    assert counts['failures'] > 0 if stage == 'red' else counts['failures'] == 0
    observations.append({'profile': profile, 'exit_code': result.returncode, **counts})
after = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in inputs}
assert before == after
receipt = {'stage': stage, 'source_commit': plan['source_commit'], 'outcome': 'FAIL' if stage == 'red' else 'PASS', 'qualification_complete': True, 'observations': observations, 'inputs_sha256': before, 'molecular_operations': 0, 'native_builds': 0, 'package_installs': 0, 'scope': 'Original bug reproduction retained as FAIL' if stage == 'red' else 'Complete affected offline source record/argument/schema cases under both caller policies; no installed/public/scientific admission'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
