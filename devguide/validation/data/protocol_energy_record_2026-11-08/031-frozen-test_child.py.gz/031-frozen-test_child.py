"""Run pure protocol/argument/schema cases under one explicit caller policy."""
from datetime import datetime, timezone
import importlib.abc
import importlib.metadata
import json
import os
from pathlib import Path
import sys

import pytest
import pyunitwizard as puw

attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
profile = sys.argv[1]
stage = attempt.name.split('-')[0]
units = ['nm', 'ps', 'K', 'mole', 'dalton', 'e', 'kJ/mol', 'radians'] if profile == 'normal' else ['pm', 'fs', 'K', 'mole', 'dalton', 'coulomb', 'J/mol', 'radians']
with puw.context(default_form='pint', standard_units=units):
    before = puw.configure.report()
    import dockingmt as dmt
    import molsysmt as msm
    forbidden_calls = []
    def forbidden(*args, **kwargs):
        forbidden_calls.append('molecular')
        raise AssertionError('Pure record tests requested a molecular operation')
    for name in ['get', 'select', 'extract', 'convert', 'copy', 'set']:
        setattr(msm, name, forbidden)
    class BlockOptional(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname.split('.')[0] in {'vina', 'molsysviewer', 'rdkit', 'openmm'}:
                raise AssertionError('Pure record tests imported an optional engine')
    sys.meta_path.insert(0, BlockOptional())
    arguments = ['--receptor=llm', '--junitxml=' + str(attempt / (profile + '.xml')), 'tests/test_protocol.py']
    if stage == 'red':
        arguments.extend(['-k', 'protocol_reader'])
    else:
        arguments.extend(['tests/test_argument_contracts.py', 'tests/test_serialization_contracts.py'])
    code = int(pytest.main(arguments))
    after = puw.configure.report()
    for key in ['default_form', 'default_parser', 'standard_units']:
        assert before[key] == after[key], key
    assert not forbidden_calls
    assert not any(name.split('.')[0] in {'vina', 'molsysviewer', 'rdkit', 'openmm'} for name in sys.modules)
    record = {'at_utc': datetime.now(timezone.utc).isoformat(), 'profile': profile, 'pytest_exit_code': code, 'consumer_origin': dmt.__file__, 'versions': {name: importlib.metadata.version(name) for name in ['dockingmt', 'argdigest', 'smonitor', 'pyunitwizard', 'numpy', 'pytest', 'pytest-receptor']}, 'caller_policy_before': before, 'caller_policy_after': after, 'molecular_calls_attempted': forbidden_calls, 'optional_engines_loaded': [], 'arguments': arguments}
    (attempt / (profile + '-receipt.json')).write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(code)
