"""Run one bounded protocol-record diagnostic in the actual routine Python."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
plan = json.loads((task / 'plan.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == plan['source_commit']
assert hashlib.sha256((root / 'dockingmt/core/protocol.py').read_bytes()).hexdigest() == plan['original_protocol_sha256']
shutil.copyfile(task / 'probe_child.py', attempt / 'frozen-probe_child.py')
result = subprocess.run([sys.executable, '-B', '-I', str(attempt / 'frozen-probe_child.py')], cwd=root, check=False)
assert result.returncode == 0
receipt = {'stage': 'probe', 'source_commit': plan['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'bug_confirmed': True, 'observed_rows': 7, 'molecular_operations': 0, 'native_builds': 0, 'scope': 'Task diagnosis complete; old protocol reader remains defective'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
