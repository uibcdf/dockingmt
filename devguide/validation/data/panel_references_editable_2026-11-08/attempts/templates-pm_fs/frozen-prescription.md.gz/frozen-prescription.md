# Coordinate-free reference receiving on the development workspace — 2026-11-08

Owners: [DockingMT #33](../pending_proposals/validate_native_molsysmt_formats.md)
and [#49](../pending_proposals/retire_general_molecular_operations.md).
Registered before execution; current outcome: **unexecuted**.

## Preserved selection and source route

Resume the entire original [six-chain reference selection](scientific_panel_receptor_models_2026-11-08.md),
including both original cases, declared fixed hypotheses, all six coordinate-free
references, native storage/comparison/history checks, both typed invalid-input
controls and final live source/reference/caller checks. No partial reference or
passing source test substitutes for the full selection. The three earlier
failed whole selections and their unattempted members remain failed/unattempted.

Use the maintainer-refreshed editable composition: DockingMT
`c238513a1e76715a56abffb6528ba31bf913e226`, MolSysMT
`2325038e8c68157f5c730693ffbb8535f0b45540`, native SHA-256
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`.
Capture actual support/Viewer origins, versions, Python-source inventories and
native identity; refuse relevant source/native drift. A separate wheel or public
package is not required. The historical prepared receptor worker is recovered
from the authenticated 156-member archive, root SHA-256
`8111abe7233e7b21920959c53a8e8407273cbd5f35a822c3875c7bb8faf0d847`;
its decoded SHA-256 is
`c926c23d6b0dfb23cb9457ca7061b7f8cbd12b900638f4eef4bc5384abd822f1`.
The frozen hypothesis is unchanged, SHA-256
`a11e4d5f04d1af83eb7afc15e5397870e0c72fe73483d4e73935271ab751d6d2`.

Only import/custody and honest development-receipt fields change. Preserve the
literal original reference-construction/persistence/comparison/refusal assertion
block, including the accepted provider-owned canonical text-storage contract.
No local table normalization, comparator, molecular parser or template application
is introduced. Stage the unchanged declared unshipped `dmt_test_support` through
SDK `95f693be10c9205ab9b912cb53453710a207bf45`; source/qualification hashes are
caller context, and the absent artifact SHA-256 stays absent. Runtime imports
remain actual editables, and helpers stay outside the runtime payload.

## Complete execution and limits

Authenticate both original PDB inputs against their retained identities and
freeze the actual worker/controller, hypotheses, declaration, source composition,
inputs and resources before launching. Execute one complete normal process;
only its whole PASS admits an identical pm/fs/coulomb process. Every failure
terminates the complete selection, preserving returned artifacts and all
unattempted members. No chemistry fallback, relaxed assertion, smaller case or
outcome-selected retry follows.

Per-policy direct caps remain: PDB conversions 2, assemblies 2, chain selectors
2, group queries 6, factory attempts 8, summaries 6, formal-charge reads 6,
hydrogen inventories 6, history reads 12, H5 writes 6, H5 reads 6 and component
comparisons 6. All six references must pass with absent structural domains,
zero indexed H, declared stored inventories, complete links, field/history
preservation and unchanged source/caller states. The two unsupported-input
controls must refuse with the provider's public error. This receives software
reference construction and persistence, not a prepared receptor or chemical
validity of a bound experiment.

Bound-source modification, template application, terminal/heavy/H coordinate
generation, charge/type assignment, energies, RMSD, detection, docking/search
and View/browser/kernel creation remain outside this selection. Keep the
existing snapshot scope and explicit unassessed scientific checks. Original
water/other-occupant decisions, MolSysMT #558 generation/maps/history, the separate
ligand-reference control and E3 #604 retain their own requirements.

Use CPU 0/nice 10/one native/build worker, a monitored 13 GiB available reserve,
1 GiB group RSS, 2 GiB address space and 45 CPU/60 wall seconds per process.
Estimate at most 512 MiB group RSS from the previous approximately 215 MiB
partial reference observation. Inspect memory/load/swap/pressure before launch.
Slurm binaries are present without an allocation; prior bounded applicability
query was inconclusive/socket-denied, so keep direct work small and serial.
Do not restart automatically after a resource/headroom interruption. Retain all
owned process-group outcomes and preserve other users' processes.

Keep `.molsyssuite/panel-references-editable-20261108` under #50/review 2026-11-14.
Seal exact records and receive them with a standard-library reader without
molecular replay, then update owning reports and current checkpoints. No build,
install, runtime/helper/data/pin change or remote CI is selected. Original
installed/private/public qualification keeps its separate identities; the full
Core/Extended/scientific/public objective remains incomplete.
