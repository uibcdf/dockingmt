"""Running the original ligand reference question, serially and without preparation."""
import ast
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2]
task=Path(__file__).parent
profile=sys.argv[1]
assert profile in ['normal','pm_fs'] and not (task/'ligand-terminal.json').exists()
attempt=task/('ligand-'+profile)
attempt.mkdir(exist_ok=False)
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
assert len(nodes)==6
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available()>policy['available_reserve_bytes']+512*1024**2
composition=json.loads((task/'composition.json').read_text())
for path,expected in composition['python_sources_sha256'].items():
    assert sha(path)==expected
for directory,expected in composition['source_revisions'].items():
    assert subprocess.check_output(['git','-C',directory,'rev-parse','HEAD'],text=True).strip()==expected
assert sha(composition['native_path'])==composition['provider_native_sha256']
old_plan=json.loads((task/'original-ligand-plan.json').read_text())
plan={key:old_plan[key] for key in ['owner','hypothesis_sha256','direct_caps','provider_caps','negative_controls','scope']}
frozen={}
for path,name in [(guard,'guard.py'),(task/'ligand-worker.py','worker.py'),(Path(__file__),'controller.py'),(task/'ligand-hypothesis.json','hypothesis.json'),(task/'ligand-route-change.json','route-change.json'),(task/'composition.json','composition.json'),(root/'devguide/validation/panel_references_editable_2026-11-08.md','prescription.md')]:
    target=attempt/('frozen-'+name)
    shutil.copyfile(path,target)
    frozen[target.name]=sha(target)
(attempt/'frozen-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
frozen['frozen-plan.json']=sha(attempt/'frozen-plan.json')
hypothesis=json.loads((task/'ligand-hypothesis.json').read_text())
assert sha(hypothesis['input']['path'])==hypothesis['input']['sha256']
shutil.copyfile(hypothesis['input']['path'],attempt/'input-BTN.cif')
if profile=='pm_fs':
    previous=task/'ligand-normal'
    assert json.loads((previous/'resource-outcome.json').read_text())['outcome']=='PASS'
    assert frozen==json.loads((previous/'registration.json').read_text())['frozen_sha256']
registration={'source_commit':'c238513a1e76715a56abffb6528ba31bf913e226','stage':'ligand','profile':profile,'owner':'uibcdf/dockingmt#33','registered_at_utc':datetime.now(timezone.utc).isoformat(),'policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':512*1024**2,'frozen_sha256':frozen,'composition_sha256':sha(attempt/'frozen-composition.json'),'input_sha256':hypothesis['input']['sha256']}
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy()
env.update(DMT_MODEL_ROOT=str(root),DMT_MODEL_TASK=str(task),DMT_MODEL_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
for name,key in [('tmp','TMPDIR'),('cache','XDG_CACHE_HOME'),('numba','NUMBA_CACHE_DIR'),('mpl','MPLCONFIGDIR')]:
    folder=attempt/name
    folder.mkdir()
    env[key]=str(folder)
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:
    env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen(['/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python','-B','-I',str(attempt/'frozen-worker.py')],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
    outcome=monitor(process,policy)
try:
    receipt=json.loads((attempt/'receipt.json').read_text())
    semantic=receipt['outcome']=='PASS' and receipt['qualification_complete'] and receipt['profile']==profile and receipt['typed_refusals']==2 and receipt['native_roundtrip_received']
except Exception as error:
    semantic=False
    outcome['qualification_diagnostic']=type(error).__name__+': '+str(error)
outcome['outcome']='PASS' if semantic and outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome),flush=True)
if outcome['outcome']!='PASS':
    (task/'ligand-terminal.json').write_text(json.dumps({'outcome':'FAIL','failed_attempt':attempt.name,'further_molecular_work_permitted':False,'unattempted':['pm_fs'] if profile=='normal' else []},indent=2)+'\n')
    print((attempt/'stderr.log').read_text()[-6000:])
    raise SystemExit(1)
print(json.dumps({'profile':profile,'typed_refusals':receipt['typed_refusals'],'native_roundtrip_received':True,'direct_counts':receipt['direct_counts'],'provider_counts':receipt['provider_counts'],'admitted_docking_cases':0}))
if profile=='pm_fs':
    (task/'ligand-terminal.json').write_text(json.dumps({'outcome':'PASS','accepted_profiles':['normal','pm_fs'],'further_molecular_work_permitted':False,'admitted_docking_cases':0},indent=2)+'\n')
