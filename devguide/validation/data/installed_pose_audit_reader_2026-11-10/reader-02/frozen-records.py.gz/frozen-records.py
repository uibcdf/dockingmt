"""Authenticate finite installed pose-audit records without molecular replay."""
import ast
import base64
import gzip
import hashlib
import importlib.abc
import json
import os
from pathlib import Path
import sys
import tempfile
import tomllib
import xml.etree.ElementTree as ET

root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT'])
task=root/'.molsyssuite/installed-pose-audit-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/installed_pose_audit_2026-11-10'
companion=root/'devguide/validation/data/installed_pose_audit_reader_2026-11-10'
qualified=json.loads((task/'qualified-files.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0)
  dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob)
  rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_pose_audit@1','owner':'uibcdf/dockingmt#47','co_owners':['uibcdf/dockingmt#73','uibcdf/dockingmt#50'],'qualification_base':'03ed7676b2177440cbceea00574a437889a4d6f9','runtime_producer':'37a61e61db40f386a4ad031ecd14d578441f61ce','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256']
  raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256']
  assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
blocked=[]
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:
   blocked.append(fullname);raise AssertionError('Stored reader attempted molecular import')
sys.meta_path.insert(0,Block())
receipt={'stage':stage,'outcome':'PASS','scope':'Stored records only; no molecular, test, native, score or audit replay'}
if stage=='seal':
 paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']]
 for label in ['audit-normal-01','audit-pm-fs-01']:
  folder=task/label
  paths.extend((p,'attempts/'+label+'/'+p.name) for p in sorted(folder.iterdir()) if p.is_file())
  for sub in ['inputs','outputs','pytest-work']:
   if (folder/sub).is_dir():paths.extend((p,'attempts/'+label+'/'+sub+'/'+str(p.relative_to(folder/sub))) for p in sorted((folder/sub).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 paths.extend((root/name,'qualified/'+name) for name in qualified)
 for name in ['dmt_test_support/pdbqt_fixtures.py','devguide/validation/data/audit/minimal_scored_pose.json']:
  paths.append((root/name,'reference/'+name))
 receipt.update(seal(primary,paths));save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 artifact=d('producer/artifact.json');installed=d('producer/installation.json');cohort=d('producer/expected-cohort.json')
 assert artifact['source_commit']=='37a61e61db40f386a4ad031ecd14d578441f61ce' and artifact['version']=='0.0.0+359.g37a61e6' and artifact['wheel_sha256']=='ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d'
 assert cohort['molsysmt']['commit']=='9df62445e49a1e268cf4c13d1ebbdd06b2088674'
 native_sha=cohort['molsysmt']['native_sha256']['molsysmt/_rust.abi3.so'];assert native_sha=='2dbcf13d148cb3ae13a5908707fcdd61c75a2de5027e50c566ce07de81bdb038'
 for folder,ref in d('producer/prior-receiving.json').items():
  assert sha(root/'devguide/validation/data'/folder/'manifest.json')==ref['manifest_sha256']
 for name in qualified:
  raw=data['qualified/'+name];assert (root/name).read_bytes()==raw
  if name in artifact['source_sha256']:assert hashlib.sha256(raw).hexdigest()==artifact['payload_sha256'][name]
 assert len(qualified)==68 and data['qualified/tests/test_pose_audit.py']==data['producer/source-qualified-test.py.txt']
 assert hashlib.sha256(data['qualified/tests/test_pose_audit.py']).hexdigest()==d('producer/source-reference.json')['test_sha256']
 literals={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(data['reference/dmt_test_support/pdbqt_fixtures.py']).body if isinstance(n,ast.Assign)}
 expected_inputs={'receptor':literals['MINIMAL_REC_PDBQT'].encode(),'partner':literals['MINIMAL_LIG_PDBQT'].encode()}
 populations={}
 for label,unit in [('audit-normal-01','nanometer'),('audit-pm-fs-01','picometer')]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');resource=d(prefix+'resource-outcome.json');collection=d(prefix+'collection.json')
  assert row['counts']=={'tests':48,'failures':0,'errors':0,'skipped':0} and row['pytest_exit_code']==0 and row['warnings']==0 and row['receptor_final']['counts']['deselected']==0
  assert len(collection['selected'])==48 and not collection['deselected'] and collection['selected']==row['selected_nodes']
  assert resource['outcome']=='PASS' and resource['group_terminal'] and resource['resource_interruption'] is None and not resource['remaining_live_owned_pids'] and resource['minimum_available_bytes']>13*1024**3
  assert row['native_sha256']==native_sha and row['native_build_provenance']=='unassessed' and row['wheel_sha256']==artifact['wheel_sha256'] and not row['forbidden_operations'] and row['cohort_unchanged'] and d(prefix+'cohort.json')==cohort
  assert row['engine_call_counts']=={'__init__':2,'set_receptor':2,'set_ligand_from_string':2,'compute_vina_maps':2,'score':2} and row['provider_call_counts']=={'convert':2,'get':6}
  native=d(prefix+'native-calls.json');assert native==row['native_calls'] and len(native)==2
  for call in native:assert call['n_atoms']==2 and call['pairs']==[] and call['pairs_shape']==[0,2] and call['pairs_dtype']==call['result_dtype']=='int64' and call['result']==[0,1] and call['outcome']=='PASS'
  engine=d(prefix+'engine-calls.json');assert engine==row['engine_calls'] and len(engine)==10
  outputs=[d(prefix+'outputs/exports/'+str(i)+'.json') for i in range(3)]
  assert len(outputs[0]['scores'])==8 and len(outputs[1]['scores'])==16 and outputs[1]['coordinates']['unit']==unit
  report=outputs[2];assert report['status']=='consistent' and report['scope']=='saved_pose_internal_consistency' and len(report['checks'])==404 and all(c['status']=='consistent' for c in report['checks'])
  for i,method in [(1,'vina'),(2,'vinardo')]:
   calls=[c for c in engine if c['run']==i];assert [c['call'] for c in calls]==['__init__','set_receptor','set_ligand_from_string','compute_vina_maps','score'] and all(c['outcome']=='PASS' for c in calls)
   assert calls[0]['parameters']['sf_name']==method and calls[0]['parameters']['cpu']==1 and calls[0]['parameters']['seed']==17
   assert calls[3]['parameters']['center']==[0.,0.,0.] and calls[3]['parameters']['box_size']==[10.,10.,10.] and calls[4]['native_unit']=='kcal/mol' and calls[4]['result_shape']==[8]
   for role in ['receptor','partner']:
    blob=data[prefix+'inputs/backend/'+str(i)+'/'+role+'.pdbqt'];assert blob==expected_inputs[role]
    call=calls[1 if role=='receptor' else 2];assert call[role]['sha256']==hashlib.sha256(blob).hexdigest() and call[role]['atom_records']==(4 if role=='receptor' else 2)
   keys=['', '.lig_inter','.flex_inter','.other_inter','.flex_intra','.lig_intra','.torsions','.lig_intra_best_pose']
   assert [outputs[1]['scores'][method+k] for k in keys]==calls[4]['native_components']
   for key in [method+k for k in keys]:
    definition=outputs[1]['metadata']['score_definitions'][key];assert definition['unit']=='kilocalorie / mole' and definition['method']=='AutoDock Vina/'+method and definition['method_version']==row['actual_engine_version']
   history=outputs[1]['metadata']['scoring_history'][i-1]
   for role in ['receptor','partner']:
    b=history['backend_artifacts'][role];assert base64.b64decode(b['content_base64'],validate=True)==expected_inputs[role]
  for export in row['exports']:assert hashlib.sha256(data[prefix+export['file']]).hexdigest()==export['sha256']
  support=d(prefix+'support-sidecar.json');decl=tomllib.loads(data[prefix+'frozen-resources.toml'].decode())['installed_tests']['support']['files']
  assert len(support['files'])==len(decl)==606 and support['executed_tests']==48 and support['imports_retired'] and support['resources_retired']
  assert {r['source']:r['sha256'] for r in support['files']}=={r['source']:r['sha256'] for r in decl}
  for k in ['default_form','default_parser','standard_units']:assert row['caller_policy'][k]==row['caller_policy_after'][k]
  origins=row['installed_origins']
  assert origins['roots']==['dockingmt','molsysviewer_dockingmt'] and 'dockingmt' in origins['loaded']
  assert 'molsysviewer_dockingmt' not in origins['loaded']
  maps=d(prefix+'native-maps.json');assert maps[str(root.parent/'molsysmt/molsysmt/_rust.abi3.so')]==native_sha
  engine_receipt=d(prefix+'frozen-engine-receipt.json');assert len(engine_receipt['paths'])==103
  populations[label]={'cases':48,'native_scores':2,'topology_calls':2,'audit_checks':404,'outcome':'PASS'}
 a='attempts/audit-normal-01/';b='attempts/audit-pm-fs-01/'
 for name in ['run.py','worker.py','audit.json','expected-cohort.json','artifact.json','installation.json','qualification-inputs.json','selection-review.json','source-reference.json','prior-receiving.json']:
  assert data[a+'frozen-'+name]==data[b+'frozen-'+name]
 assert d(a+'collection.json')==d(b+'collection.json') and d(a+'support-sidecar.json')['files']==d(b+'support-sidecar.json')['files']
 assert d(a+'outputs/exports/1.json')['scores']==d(b+'outputs/exports/1.json')['scores']
 receipt.update(members=len(data),primary_manifest_sha256=expected['manifest_sha256'],qualified_sources=68,populations=populations,molecular_import_attempts=blocked,native_compile_provenance='unassessed',reference_4ffb82e4_received=False,addon_runtime_loaded=False,addon_payload_authenticated=True,full_scientific_public_platform_gate=False)
elif stage=='audit':
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site))
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for label in ['audit-normal-01','audit-pm-fs-01']:
   prefix='attempts/'+label+'/';path=Path(tmp)/'events.jsonl';path.write_bytes(data[prefix+'events.jsonl']);events=read_artifact(path);row=json.loads(data[prefix+'receipt.json'])
   counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']}
   assert events.complete and row['receptor_final']==events.final.data and row['counts']==counts and events.final.data['counts']['executed']==counts['tests']==48 and events.final.data['exitstatus']==row['pytest_exit_code']==0
   resource=json.loads(data[prefix+'resource-outcome.json']);assert resource['exit_code']==0 and resource['outcome']=='PASS'
   crosschecked[label]={'junit':counts,'pytest_exit':0,'qualification_exit':0,'receptor_outcome':events.final.data['outcome']}
 assert not blocked
 receipt.update(crosschecked=crosschecked,event_inputs_retired=not Path(tmp).exists(),scientific_imports=blocked)
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','reader-02','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()]
 receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1800])
