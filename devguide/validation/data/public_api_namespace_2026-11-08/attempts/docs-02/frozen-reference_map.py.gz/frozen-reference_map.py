"""Render the inspected declarations into the maintained reference."""

def source_map(inventory):
    exports=inventory['exports']; lines=[]
    lines+=['### Root functions and values','', '| Name | Declaration / owner |', '| --- | --- |']
    for name,row in exports.items():
        if row['kind'] in ['class','module']:continue
        source='../'+row['source'] if row.get('source') else ''
        if row['kind']=='generated value':description='Generated version value; created by the build/version machinery.'
        elif row['kind']=='external module':description='Provider module; follow PyUnitWizard documentation.'
        elif 'alias_of' in row:description='Exact alias of `'+row['alias_of']+'`.'
        else:description='`'+name+row['signature']+'`'
        label='['+name+']('+source+')' if source and row['kind']!='generated value' else '`'+name+'`'
        lines+=['| '+label+' | '+description+' |']
    lines+=['','### Model and extension classes','']
    for name,row in exports.items():
        if row['kind']!='class':continue
        lines+=['#### '+name,'','Source: ['+row['source']+'](../'+row['source']+'). Bases: '+', '.join('`'+n+'`' for n in row['bases'])+'.' if row['bases'] else 'Source: ['+row['source']+'](../'+row['source']+').','', '| Member | Declaration |', '| --- | --- |']
        for member in row['members']:
            label=member['name'];signature=member['signature']
            if member['kind']=='property':
                description='Property'+(' `'+signature.split(' -> ',1)[1]+'`' if ' -> ' in signature else '')
            else:description='`'+label+signature+'`'
            lines+=['| `'+label+'` | '+description+' |']
        lines+=['']
    lines+=['### exceptions','', 'Source: [dockingmt/exceptions.py](../dockingmt/exceptions.py). Each name aliases its existing implementation class.','', '| Public alias | Existing bases |','| --- | --- |']
    for name,row in exports['exceptions']['exports'].items():
        lines+=['| `'+name+'` | '+', '.join('`'+n+'`' for n in row['bases'])+' |']
    return '\n'.join(line.replace('|', '\\|') if not line.startswith('|') else '|'+line[1:-1].replace(' | ', '\x00').replace('|','\\|').replace('\x00',' | ')+'|' for line in lines)+'\n'
