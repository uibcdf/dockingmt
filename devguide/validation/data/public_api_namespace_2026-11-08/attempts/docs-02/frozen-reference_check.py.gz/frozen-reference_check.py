"""Check the source map and execute its exact offline snippets on synthetic data."""
import ast
import contextlib
import hashlib
import importlib.abc
import importlib.machinery
import io
import json
import os
from pathlib import Path
import re
import sys


def verify_reference(root, attempt, smoke=True):
    inventory = json.loads((attempt / 'frozen-inventory.json').read_text())
    for name, digest in inventory['source_sha256'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
    namespace = {}
    renderer = attempt / 'frozen-reference_map.py'
    exec(compile(renderer.read_text(), str(renderer), 'exec'), namespace)
    document = root / 'devguide/PUBLIC_API.md'
    text = document.read_text()
    mapped = text.split('<!-- SOURCE_MAP:START -->\n\n')[1].split('\n<!-- SOURCE_MAP:END -->')[0]
    assert mapped == namespace['source_map'](inventory)
    links = re.findall(r'\[[^\]]*\]\(([^)]+)\)', text)
    local_links = [x.split('#')[0] for x in links if '://' not in x]
    assert all((document.parent / name).exists() for name in local_links), [name for name in local_links if not (document.parent / name).exists()]
    snippets = re.findall(r'```python\n(.*?)\n```', text, re.S)
    assert len(snippets) == 2
    for source in snippets:
        ast.parse(source)
    receipt = {'root_exports': len(inventory['exports']), 'model_classes': sum(row['kind'] == 'class' for row in inventory['exports'].values()), 'exception_aliases': len(inventory['exports']['exceptions']['exports']), 'local_links_checked': len(local_links), 'compiled_snippets': len(snippets), 'reference_sha256': hashlib.sha256(document.read_bytes()).hexdigest(), 'smoke_profiles': []}
    if not smoke:
        return receipt
    attempted = []
    class RejectImport(importlib.abc.Loader):
        def create_module(self, spec):
            attempted.append(spec.name)
            raise AssertionError('Reference smoke imported an engine')
        def exec_module(self, module):
            raise AssertionError('Unreachable engine execution')
    class EngineGuard(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname.split('.')[0] in {'vina', 'rdkit', 'openmm'}:
                spec = importlib.machinery.PathFinder.find_spec(fullname, path)
                if spec is not None:
                    spec.loader = RejectImport()
                return spec
    sys.meta_path.insert(0, EngineGuard())
    import pyunitwizard as puw
    for label, units in [('normal', ['nm', 'ps', 'K', 'mole', 'dalton', 'e', 'kJ/mol', 'radians']), ('pm_fs', ['pm', 'fs', 'K', 'mole', 'dalton', 'coulomb', 'J/mol', 'radians'])]:
        with puw.context(default_form='pint', standard_units=units):
            before = puw.configure.report()
            import dockingmt as dmt
            import molsysmt as msm
            import molsysviewer as msv
            assert Path(dmt.__file__).resolve() == root / 'dockingmt/__init__.py'
            def reject(*args, **kwargs):
                attempted.append('molecular operation/viewer construction')
                raise AssertionError(attempted[-1])
            for name in ['get', 'select', 'extract', 'convert', 'copy', 'set']:
                setattr(msm, name, reject)
            msv.MolSysView = reject
            errors = dmt.exceptions
            implementation = sys.modules[errors.ArgumentError.__module__]
            assert errors.__all__ == list(inventory['exports']['exceptions']['exports'])
            assert all(getattr(errors, name) is getattr(implementation, name) for name in errors.__all__)
            result = dmt.DockingResult([
                dmt.DockingPose(puw.quantity([[0, 0, 0]], 'angstrom'), rank=2, pose_id='first'),
                dmt.DockingPose(puw.quantity([[1, 0, 0]], 'angstrom'), rank=1, pose_id='second'),
            ])
            folder = attempt / ('example-' + label)
            folder.mkdir()
            saved = folder / 'saved-result.json'
            saved.write_text(json.dumps(result.to_dict()), encoding='utf-8')
            digest = hashlib.sha256(saved.read_bytes()).hexdigest()
            old_cwd = Path.cwd()
            try:
                os.chdir(folder)
                output = io.StringIO()
                with contextlib.redirect_stdout(output):
                    scope = {}
                    exec(compile(snippets[0], str(document), 'exec'), scope)
                    assert scope['report']['status'] == 'incomplete'
                    assert len(scope['result']) == 2
                    assert scope['result'].top_pose.pose_id == 'second'
                    exec(compile(snippets[1], str(document), 'exec'), scope)
                    protocol = scope['protocol']
                    assert protocol.cpu == 1 and protocol.seed == 17 and protocol.capture_backend_inputs
            finally:
                os.chdir(old_cwd)
            assert output.getvalue() == 'Poses: 2\nEvidence: incomplete\nSelected pose: second\n'
            assert hashlib.sha256(saved.read_bytes()).hexdigest() == digest
            assert {p.name for p in folder.iterdir()} == {'saved-result.json'}
            after = puw.configure.report()
            for name in ['default_form', 'default_parser', 'standard_units']:
                assert before[name] == after[name]
            receipt['smoke_profiles'].append({'profile': label, 'caller_policy_before': before, 'caller_policy_after': after, 'input_sha256': digest, 'input_unchanged': True, 'output': output.getvalue(), 'exact_alias_identities': len(errors.__all__)})
    assert not attempted
    assert not any(name.split('.')[0] in {'vina', 'rdkit', 'openmm'} for name in sys.modules)
    receipt.update(molecular_calls_attempted=attempted, native_searches=0)
    return receipt
