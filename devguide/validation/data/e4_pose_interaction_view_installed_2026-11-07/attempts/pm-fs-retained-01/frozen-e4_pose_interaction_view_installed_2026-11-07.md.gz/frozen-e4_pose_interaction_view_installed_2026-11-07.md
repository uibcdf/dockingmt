# Installed interaction-view receiving — 2026-11-07

Owner: [DockingMT #80](../pending_proposals/receive_docking_interaction_analysis.md)
and [#60](../pending_proposals/qualify_saved_result_addon.md).
Registered before execution. Outcome at registration: **unexecuted**.

## Candidate and custody

Receive the new `dmt.view(PoseInteractions)` route from exact source
`2ef82d25e34266d1b504464dc238e8863a9dade0`. Its
[186-case source/23-case DOM qualification](pose_interaction_view.md) is separate;
the older `cfff386` wheel cannot receive this new code. Build once in a detached
exact-source worktree, without a version override, index/dependency access or
build isolation, and install that exact wheel into a task-local consumer prefix.
Record wheel bytes/digest, version, all RECORD entries, exact tracked source and
installed payload bytes. No editable finder or source root may supply runtime code.

Transport the byte-exact 3794-file provider composition from the retained
E1 installation, excluding all 73 historical consumer/addon/dist-info files.
Anchor the installation receipt to its immutable saved-carrier archive copy.
MolSysMT stays `9e1f1b1ad8bf09446374ab6f04ca7208e2717936`; use the 641-file
qualified Viewer overlay `78ede79e2e345593db5bfe80d246d3f6c70bd005`, wheel SHA-256
`3d31a4d9edb7ed0e72fadcd81b3952196795218f55776478a7625b79e47e9e2a`.
Keep provider checkouts, pins and routine Conda prefix unchanged. Publication SDK
is the clean exact `95f693be10c9205ab9b912cb53453710a207bf45` snapshot.

Task `.molsyssuite/e4-view-installed-20261107`, #50 custody, review 2026-11-14,
retains the worktree/wheel/prefix, frozen code/inputs, all failures, raw logs,
module/native origins, semantic completion and terminal resource receipts.
The original migration directory remains untouched/untracked. Use a separately
registered receiving attempt after any failure; never rewrite old observations.

## Finite receiving population

The scientific inputs and original producer remain
`5952053328aac6f737e22906e984c0f9eb938dd7`, the full five-pose result and the
original 3238-atom/one-frame saved retained/translated carriers. Resolve exact
stored/decoded input bytes through the immutable prior saved-carrier manifest
SHA-256 `73c8114368f0d7011d2e27d229662bf29be1f99bea27c0e0a24065f077e04b4d`.
Historical wire position 1 is one-based; the atom correspondence has two columns.
Declare the same ordered 13 pose atoms at carrier indices 3220–3232, 18-atom
ligand domain, known partner/receptor state IDs and common Cartesian frame.

Complete all four normal-policy cells before starting any fresh pm/fs cell.
Each cell is a fresh isolated process, not a resumed partial computation.

1. **Retained original:** bind original result index 0 and receive the actual
   public view. All five original records, scores/ranks/provenance stay exact;
   `hbonds`/`hydrophobic` retain 3/2 observations and evaluated frame 0.
2. **Explicit reordered control:** reorder the same five complete pose records
   by permutation `[1, 2, 3, 0, 4]`, with a separate provenance annotation and
   no new scientific producer/pose. Bind the original retained geometry at
   collection index 3. The view must select position 4 while local frame stays
   0 and the original scientific rank/ID remain unchanged. Verify every pose
   record against its original permutation and preserve the untouched original
   result separately. This is a client ordering control, not a new docking case.
3. **Empty/unevaluated control:** use the original translated saved carrier and
   a separately identified coordinate snapshot control pose, with no original
   score/rank and explicit source-file derivation. Public MolSysMT invalidation
   on its already evaluated-empty `hbonds` yields zero evaluated frames while
   `hydrophobic` stays evaluated-empty. No positive-source invalidation, label
   stripping or fabricated observation. Keep original and derived source state
   distinct; this is not a sixth original pose.
4. **Existing native regression:** execute exactly
   `tests/test_viewer_state.py::test_public_resolved_widgets_keep_separate_reactive_state_and_owned_cleanup`
   against installed core/addon origins, with `pytest --receptor=llm`, native
   completion/JUnit and explicit source-pythonpath removal. Its real provider
   fixture, duplicate-frame extraction, widgets, callbacks and cleanup are part
   of this registered native cell, not relabelled source-only tests.

## Required observations

For each view cell, require real addon discovery/public per-view namespace,
provider-created interaction visuals for both stored analyses and actual
Explorer/Search Domain widgets resolved/mounted through the provider. Verify
their Python-side public widget states, full pose table, selected position/ID/
scientific rank, explicit geometry availability and live coverage/occurrence
counts. Read provider visual metadata/filters and complete typed analyses,
including unit-bearing query pages, before and after controls.

Exercise Python, context and panel actions at the bound position; reject a
foreign original position before player movement. Preserve native failure
types and source nonmutation. Check summary/export's complete result and
association. A duplicate frame-0 selection must not invent another pose or
extra frame. One-frame views have no valid different-frame transition; the
separate two-frame native regression provides actual callback-transition evidence.

Retain a foreign provider visual, clear DockingMT through the public lifecycle
and verify that owned visuals disappear while foreign/scientific data survives.
Re-enable and render the same binding into that same View through the public
entry point, without assigning private or runtime association fields. Before
final cleanup, replace the molecular system through public provider
loading and require the old binding's geometry to become unavailable even
with equal counts. Close every owned widget/View in `finally`; verify source
native domains/analysis payloads and the complete original result afterwards.
Do not manufacture provider callback events or claim browser rendering.

Use the already qualified native snapshot/diagnostic helpers frozen in the old
saved-carrier notebook, SHA-256
`a6a8561e4aa7d9d2b5967fd43b9c2fdf8793ba13bbbb3c3a5d524e3d53e7d113`.
They produce inspection witnesses, not a molecular codec. Coordinates/box use
explicit angstrom output and finite shape/dtype/value checks; caller unit
policy is entered before sibling imports, preserved and restored. All source
and installed prefix/SDK bytes, loaded module/native-library origins and shared
Conda metadata are checked before/after.

No preparation, H/charge/type assignment, detector, RMSD, alignment, geometry
transformation, energy, scoring or search is allowed. Viewer rendering may use
provider-owned coordinate/participant-center projection in explicit units; this
is presentation of saved observations, not new interaction detection/scientific
measurement. No public package compatibility, real browser/comm/canvas, visual
C6, independent molecular reproduction or whole E4 follows from Python Views.

## Resource and call policy

Run cells serially on CPU0/nice10, one native/build worker, with 8 GiB available
RAM reserve, 1 GiB owned-group RSS, 2 GiB address space, 45 CPU seconds and
60 wall seconds per cell. Reuse frozen guard functions SHA-256
`3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d`
under MolSysSuite #173; monitor owned descendants, preserve interruptions and
never automatically restart after a headroom stop. Exit zero without complete
semantic receipts is not a pass. Fresh pm/fs requires the entire normal matrix
passing on identical worker/controller/candidate/SDK bytes.

Per view-cell receiver caps: one accepted binding, three public view attempts
(two renders in the same View and one conflict refusal), four native snapshots plus two additional for the empty
derivation, 32 typed exports, two explicit analysis queries/pages, three mounted
widgets at most, one explicit system replacement, one foreign visual, four
navigation attempts per action route, and bounded cleanup/close operations.
Provider-entry caps: convert128, copy40, get640, has_attribute256, select64,
extract16, merge4, append4, set16 for provider-owned loading/copying, H5 reads2/writes0, analysis copy128/remap16/
invalidation1, typed exports128, participant-center64. Other geometry/scientific
operations stay forbidden. Native-regression caps use the same maxima and allow
its explicit duplicate-frame extraction. Viewer-entry caps: loads4, new Views2,
analysis metadata128, visual add6/get512/delete16/info16, queries128, complete
analysis access256 and player navigation32. Count direct and nested calls.

Normal units are nm/ps; nondefault units pm/fs, with the complete previously
declared suite unit list and explicit caller authority. Every attempt freezes
the prescription, worker/controller, candidate receipt, exact inputs and SDK.
Seal passing and failed records separately from earlier immutable archives and
verify them with a detached standard-library reader without molecular replay.

MolSysMT #642 stays a separate failed positive-invalidation persistence route;
owner triage does not deliver a fix. E3 #604, other-carrier projection, actual
canvas #52/#60, public/minor/platform qualification and full #73 remain open.
No manual CI is dispatched; exact-head hosted evidence remains missing under
#28 and the authorized `[skip ci]` route.

## Candidate and initial instrumentation correction

`candidate-01` passes in 6.283 s/140,062,720 sampled group-RSS bytes. Exact source
`2ef82d2` produces `0.0.0+310.g2ef82d2`, wheel SHA-256
`6db76835f4f3f9c41d06a163cb3a4fbc9e780597bfd89d2fc6a75d29cff31133`,
154,750 bytes. The new consumer has 75 installed files; provider transport has
3794, with the historical consumer excluded. No source/provider/shared-prefix
change or public closure claim follows from this build.

`normal-retained-01` fails before any carrier read, binding or View creation:
the instrumentation attaches visual-method observers to the scientific base
manager, while public `view.interactions` uses the `InteractionsManager`
subclass that actually owns `add/get/info`. This is a receiver setup error,
not a provider or product defect. The terminal attempt remains failed, 4.706 s/
226,394,112 bytes, without resource interruption. Before retry, observe the
combined public manager's unchanged methods. Keep all inputs, requirements,
candidate and resource/call limits intact. The pm/fs prerequisite uses an
explicit frozen normal-case-to-passing-attempt matrix, so a failed `-01` cannot
silently count as completion or require overwriting its record.

## Native test-tool amendment before retry

The three normal View cells pass, including actual nonfirst selection and native
unevaluated coverage. `normal-native-regression-01` fails before test collection:
the isolated no-site interpreter cannot import `pytest_receptor` from the routine
environment's editable installation. Native pytest exits 3 with no completed
test. Preserve that 5.426 s/241,475,584-byte attempt without reclassifying it as
a scientific failure or a provider defect. An earlier invalid underscore in the
launcher label is recorded separately before any attempt/process was created.

Before retry, transport only the Python payload/metadata of the cached Conda
`pytest-receptor` 1.2.2 `py_0` archive into a separate reporting-tool prefix.
Its archive SHA-256 is
`c0b075286f45e8fce5ab5852947611bfba82b7d509115fc5dadf1a9572b9dd74`,
matching the retained `uibcdf/noarch` repodata record. Verify every selected
archive member against `info/paths.json`, refuse traversal/links and retain the
original index/repodata record. This is a byte transport of a cached declared
published tool, not a fresh public-channel availability/closure claim. No solve,
network download, source import fallback or shared Conda change is needed.

Only the native worker adds this explicit prefix, freezes its receipt and checks
all tool bytes and loaded reporting-module origins before/after. Keep the
consumer, scientific providers, common View worker, resources and all assertions
unchanged. The three successful normal View cells retain their exact bytes;
the native retry and fresh pm/fs use the same corrected native worker and tool.
Require full native events/JUnit/exit completion; the receptor version does not
convert the earlier uncollected attempt to a pass.
