"""Task-specific immutable evidence publication and independent receipt reading."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

root=Path(os.environ['DMT_COLLECTION_ROOT']);task=Path(os.environ['DMT_COLLECTION_TASK']);attempt=Path(os.environ['DMT_COLLECTION_ATTEMPT']);stage=os.environ['DMT_COLLECTION_STAGE']
primary=root/'devguide/validation/data/installed_collection_2026-11-09'
reader=root/'devguide/validation/data/installed_collection_reader_2026-11-09'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);destination=folder/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(blob)
  rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_collection@1','source_commit':'9375f3a8b96a651f8944c48105d56d33a0cf4c68','runtime_producer':'9a40e385d951b0521f6509de6b127083b78be61c','owner':'uibcdf/dockingmt#102','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 manifest=json.loads((folder/'manifest.json').read_text());decoded={}
 for row in manifest['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  path=folder/row['path'];assert path.resolve()==path.resolve(strict=True) and not path.is_symlink()
  blob=path.read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256']
  raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in decoded;decoded[row['original_path']]=raw
 return manifest,decoded
receipt={'stage':stage,'scope':'Read retained software receipts; no scientific replay','outcome':'PASS'}
if stage=='seal':
 names=['run.py','worker.py','records.py','move_support.py','verify_relocation.py','relocation.json','relocation-proof.json','prescription-initial.md','provider-status.json','custody.json','wheel.json']
 paths=[(task/name,'producer/'+name+('.txt' if name.endswith('.py') else '')) for name in names]
 for label in ['collect-01','admin-red','admin-green','collect-02','collect-03','offline-normal','offline-pm-fs','comparison-01','admin-final']:
  directory=task/label
  paths.extend((p,'attempts/'+label+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  if (directory/'inputs').is_dir():paths.extend((p,'attempts/'+label+'/inputs/'+str(p.relative_to(directory/'inputs'))) for p in sorted((directory/'inputs').rglob('*')) if p.is_file())
 proof=json.loads((task/'relocation-proof.json').read_text());qualified=set(proof['test_modules'])|set(proof['helpers'])|{'tests/molecular_fixtures.py'}
 for name in sorted(qualified):
  path=task/'collect-03/harness'/name;assert path.read_bytes()==(root/name).read_bytes();paths.append((path,'qualified/'+name))
 source='9375f3a8b96a651f8944c48105d56d33a0cf4c68';original=task/'original-sources';original.mkdir()
 for name in sorted(set(proof['test_modules'])|set(json.loads((task/'relocation.json').read_text())['modules'])):
  path=original/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=root));paths.append((path,'original/'+name))
 receipt.update(seal(primary,paths));save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];manifest,data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 for label,count,exit_code in [('collect-01',1996,2),('collect-02',2116,2),('collect-03',2593,0)]:
  row=d('attempts/'+label+'/receipt.json');assert row['pytest_exit_code']==exit_code and row['collected']==count and row['executed']==0
  support=d('attempts/'+label+'/support-sidecar.json');assert support['resources_retired'] and support['imports_retired']
 final=d('attempts/collect-03/receipt.json');assert final['blocked_calls']==[] and final['retained_engine_paths']==103 and final['cohort_unchanged']
 for label in ['offline-normal','offline-pm-fs']:
  row=d('attempts/'+label+'/receipt.json');assert row['counts']=={'tests':1267,'failures':0,'errors':0,'skipped':0} and row['pytest_exit_code']==0 and row['support_inputs']==606 and row['blocked_calls']==[] and row['cohort_unchanged']
  counts=row['receptor_final']['counts'];assert counts['deselected']==4 and counts['warnings']==0 and counts['executed']==1267
  support=d('attempts/'+label+'/support-sidecar.json');assert len(support['files'])==606 and support['executed_tests']==1267 and support['resources_retired'] and support['imports_retired']
 assert data['attempts/offline-normal/frozen-worker.py']==data['attempts/offline-pm-fs/frozen-worker.py']
 admin=d('attempts/admin-final/receipt.json');assert admin['counts']=={'tests':130,'failures':0,'errors':0,'skipped':0} and admin['forbidden_imports']==[] and admin['receptor_final']['counts']['passed']==104
 comparison=d('attempts/comparison-01/receipt.json');assert all(v=={'exit_code':2,'runtest_reports':[]} for v in comparison['native'].values()) and comparison['receptor_final']['counts']['executed']==1
 for label in ['collect-01','admin-red','admin-green','collect-02','collect-03','offline-normal','offline-pm-fs','comparison-01','admin-final']:
  outcome=d('attempts/'+label+'/resource-outcome.json');assert outcome['resource_interruption'] is None and outcome['group_terminal'] and outcome['remaining_live_owned_pids']==[] and outcome['minimum_available_bytes']>13*1024**3
 for prefix in ['attempts/offline-normal','attempts/offline-pm-fs']:
  for name,digest in d(prefix+'/qualification-inputs.json').items():
   if 'qualified/'+name in data:assert hashlib.sha256(data['qualified/'+name]).hexdigest()==digest
 proof=d('producer/relocation-proof.json');assert proof['support_inputs']==606 and proof['original_support_records_preserved']==595 and proof['runtime_paths_unchanged']==67
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),collection=2593,executed_offline_per_profile=1267,admin_tests=104,admin_subtests=26,old_support_preserved=595,new_support_total=606,full_scientific_gate=False,source_context_accepted=False)
elif stage=='reader-seal':
 paths=[(p,'reader-01/'+p.name) for p in sorted((task/'reader-01').iterdir()) if p.is_file()]
 receipt.update(seal(reader,paths));save(task/'reader-receipt.json',receipt)
elif stage in ['checks','committed']:
 py='/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python';suite=root/'.molsyssuite/sdk';publication=root/'.molsyssuite/publication-sdk'
 assert subprocess.check_output(['git','-C',str(suite),'rev-parse','HEAD'],text=True).strip()=='738fe8dd731abb99dac421b0bb2acc8564110180'
 for folder,expected_path in [(primary,task/'primary-receipt.json'),(reader,task/'reader-receipt.json')]:assert sha(folder/'manifest.json')==json.loads(expected_path.read_text())['manifest_sha256']
 def validate(target):
  env=os.environ.copy();env['DOCKINGMT_SUITE_ROOT']=str(suite)
  commands=[('ruff-check',[str(Path(py).parent/'ruff'),'check','.', '--extend-exclude','dockingmt-migration-2026-11-06']),('ruff-format',[str(Path(py).parent/'ruff'),'format','--check','.', '--extend-exclude','dockingmt-migration-2026-11-06']),('index',[py,'devtools/devguide_index.py','--check']),('resources',[py,str(publication/'devtools/scripts/noarch_conda.py'),'--root',str(target),'--plan','devtools/conda-build/release_plan.example.toml']),('contract',[py,str(publication/'devtools/scripts/conda_release_contract.py'),str(target)])]
  if stage=='checks':commands.append(('diff',['git','diff','--check']))
  results=[]
  for name,args in commands:
   with (attempt/(name+'.log')).open('xb') as stream:result=subprocess.run(args,cwd=target,env=env,stdout=stream,stderr=subprocess.STDOUT)
   assert result.returncode==0,(name,result.returncode);results.append(name)
  _,data=read(target/'devguide/validation/data/installed_collection_2026-11-09');read(target/'devguide/validation/data/installed_collection_reader_2026-11-09')
  for name,raw in data.items():
   if name.startswith('qualified/'):assert (target/name.removeprefix('qualified/')).read_bytes()==raw,name
  results.append('archive-and-qualified-bytes');return results
 if stage=='committed':
  commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root)
  with tempfile.TemporaryDirectory(prefix='dmt-collection-committed-',dir='/tmp') as temporary:
   export=Path(temporary)/'source';export.mkdir();tar=Path(temporary)/'source.tar'
   with tar.open('wb') as stream:subprocess.run(['git','archive','HEAD'],cwd=root,stdout=stream,check=True)
   with tarfile.open(tar) as stream:stream.extractall(export,filter='data')
   receipt.update(source_commit=commit,checks=validate(export))
  receipt['committed_export_retired']=not Path(temporary).exists()
 else:receipt['checks']=validate(root)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt))
