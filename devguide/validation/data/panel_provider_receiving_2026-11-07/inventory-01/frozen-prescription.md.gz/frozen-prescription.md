# Scientific-panel provider and artifact admission — 2026-11-07

Owner: [DockingMT #33](../pending_proposals/validate_native_molsysmt_formats.md),
with [#49](../pending_proposals/retire_general_molecular_operations.md) retaining
molecular ownership. Starting checkpoint: `9977317bfdbff60ee783043c5445f5b3e9719920`.
The previous goal turn made progress: complete bounded E5 receiving and #83
resolution, with the complete product objective still active.

## Preserved question and source cases

Retain the original [two-candidate panel design](scientific_panel_design_2026-11-04.md),
all four original downloaded files and the unadmitted 1HSG terminal-control output.
Do not replace a blocked candidate with an easier one, infer missing chemistry,
or treat E5's repeated 1IEP as a new independent molecular case. The proposed
24-search matrix remains unregistered and unexecuted. Terminal, catalytic/ligand
states, waters, other ligand copies and truncation decisions retain their
case-specific admission obligations.

## Refreshed provider state before molecular work

MolSysMT #556 is source-resolved at06c065d3 for CIF primary occupancy/model-local
observations. #557 is source-resolved atfaab727c for experimental public
`physchem.get_chemical_template` and strict `topology.get_atom_name_correspondence`.
#558 remains open for public native terminal-completion correspondence/history.
Source closure is separate from installed consumer receiving.

The actual qualified9e1f1b1 provider payload lacks both new #557 modules. Its
CIF converter SHA differs from the correction and later source. No new source
or binary is therefore relabelled as received. Public `add_terminal_atoms`
requires caller-supplied coordinates and does not generate missing terminal
geometry; it does not replace #558 without a provider-supported composition.
Do not implement a CCD parser, chemistry transfer, atom matcher, OXT placer,
private map extraction or an ad hoc provider module overlay in DockingMT.

A bounded central `suite_status.py` refresh inspects DockingMT and MolSysMT.
DockingMT is synchronized, preserving the untracked original migration; MolSysMT
is clean at9e1f1b1 and120 commits behind fetched main. Preserve both worktrees,
all pinned/private prefixes and prior build interruptions. No merge, source
installation, source-module replacement or native construction is part of this
selection. The #642 construction hold after owned-memory interruption remains.

## Current finite selection

Inspect exact source contracts and available complete artifacts before calling
any molecular API. Read-only public registry acquisition may inspect the uibcdf
Conda MolSysMT package metadata, including actual filenames, platform/Python/
build identities and covering source evidence where supplied. Bound each HTTP
request to25 seconds and16 MiB; record exact bytes/digests and any unavailable
route. No environment solve/install, workflow dispatch, molecular import or
scientific operation is authorized by this inventory.

Metadata/source inventory runs at CPU0/nice10, one worker,45 CPU/60 wall seconds,
2 GiB AS/1 GiB owned RSS, with8 GiB available reserve checked before and during
reads. Preserve interrupted attempts and do not automatically restart owned
heavy work after a headroom stop. The exact original provider/native/source
identities remain separate from current upstream source and advertised files.

If a complete covering artifact is available, register its exact acquisition and
isolated whole-provider admission before execution. If unavailable, publish the
bounded evidence to the existing provider issues/artifact handoff and advance
another independent complete-plan boundary; do not manufacture an installed
PASS from source closure or partial Python replacement. A genuine new provider
defect or missing reusable tool remains the provider's issue.

Task `.molsyssuite/panel-receiving-20261107` retains issue/source/status/registry
snapshots, scripts and receipts under #50, review2026-11-14. Keep #33/#49 partial,
all panel cases unadmitted until their actual criteria pass, and the full Core/
Extended/scientific/public/stabilization objective active. No manual CI; skipped
hosted evidence remains missing.
