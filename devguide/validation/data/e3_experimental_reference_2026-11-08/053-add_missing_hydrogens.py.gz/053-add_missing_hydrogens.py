from molsysmt._private.argdigest import arg_digest


@arg_digest()
def add_missing_hydrogens(
    molecular_system,
    pH=7.4,
    engine="OpenMM",
    skip_digestion=False,
    *,
    mode="pH",
    chemical_state="reference",
    structure_indices="all",
    return_report=False,
    attribute_policy="intersection",
):
    """
    Adding missing hydrogen atoms to a molecular system.

    This function adds hydrogen atoms that are missing from a molecular system,
    based on its topology, standard chemical templates, and a selected pH. The
    added atoms are positioned using predefined rules for protonation states and
    geometry constraints.


    Parameters
    ----------
    molecular_system : molecular system
        Molecular system in any supported MolSysMT format.
    pH : float or None, default=7.4
        pH passed to the legacy engine. Fixed-state mode requires None: it
        materializes a prepared inventory without choosing a protonation state.
    engine : str, default='OpenMM'
        Legacy engines are OpenMM, PDBFixer and MolSysMT. Explicit RDKit is
        required for fixed-state mode; missing RDKit never selects a fallback.
    skip_digestion : bool, default=False
        Whether to skip MolSysMT's internal argument digestion mechanism.
    mode : {'pH', 'fixed_chemical_state'}, default='pH'
        Keyword-only choice between existing residue/pH behavior and adding H
        to one isolated prepared component with one chemical state and one
        structure.
    chemical_state : str or int, default='reference'
        State selected in fixed-state mode; 'structure' resolves the structure link.
    structure_indices : int, list, tuple or numpy.ndarray, default='all'
        Selected structure in fixed-state mode. Extract multiple source
        structures first.
    return_report : bool, default=False
        In fixed-state mode, return a dictionary containing molecular_system
        and a detached versioned preparation report instead of just the system.
        Successful reports are retained in the output's preparation history
        regardless of this option.
    attribute_policy : {'intersection', 'strict'}, default='intersection'
        Fixed-state handling of attributes that cannot cover added atoms:
        intersection drops them with a diagnostic; strict rejects the input.

    Returns
    -------
    molecular system or dict
        Legacy mode returns the input form. Fixed-state mode returns a new
        native MolSys, or that system and hydrogen_addition@1 report when
        return_report=True. Existing atom indices and coordinate values are
        retained; appended H have deterministic string IDs and parent maps.


    Raises
    ------
    NotSupportedFormError
        Raised if the input molecular system is not in a supported form.

    ArgumentError
        Raised if an input argument does not meet the expected format or conditions.

    StructuralInconsistencyError
        If fixed-state chemistry, geometry or atom-domain preservation is invalid.

    ImportError
        If an explicitly requested optional engine is unavailable.


    Notes
    -----
    Checked historical and Amber construction state layouts can spell H names
    differently. Existing H names select the compatible layout; group naming
    alone does not force atom naming. Declared Amber caps similarly retain the
    supported observed methyl-H layout rather than gaining alias duplicates.

    Native pH preparation reads stored per-group naming declarations. Ambiguous
    names without context fail before native component reconstruction. Explicit
    Amber state labels use atom/bond variants checked against bundled Meeko-derived
    heavy connectivity and per-parent hydrogen counts; their named side-chain H
    inventory is preserved across pH choices. Modified heavy-only references,
    named-state terminal completion and incompatible atom layouts remain unassessed
    and emit UnassessedResidueWarning. The existing placement heuristic and standard
    pH approximation are unchanged; this does not certify energy, stereochemistry,
    bond orders or stored chemical assignments. OpenMM/PDBFixer wrappers refuse
    reviewed contextual labels until naming adapters are implemented. Fixed-state
    RDKit mode uses ChemicalStates and does not interpret group labels chemically.

    Fixed-state mode requires explicit elements, complete covalent connectivity,
    atom/bond aromaticity, formal charges, closed-shell assignments and virtual
    H counts. Nonaromatic bonds require declared integer orders of 1, 2 or 3;
    explicitly aromatic bonds may retain fractional order 1.5 without an integer
    bond_order column. No alternating Kekule orders are invented. The optional
    RDKit AddHs(addCoords=True) primitive generates local
    H coordinates on the supplied pose. Backend reinterpretation of the declared
    inventory fails. Source inputs remain unchanged on success and failure.
    Missing H are appended; existing H are never removed or repositioned.
    No receptor refinement, minimization or heavy-atom conformer generation runs.
    Supply compact periodic coordinates; split molecules are rejected rather than
    reconstructed implicitly. Named interactions become unevaluated on an expanded
    output; no-addition outputs retain their analyses. Multiple states/structures,
    metals, radicals, query atoms and virtual isotopic additions are unsupported.
    Successful fixed-state operations retain both terminal-attachment and
    hydrogen-generation evidence in ChemicalStates preparation history, including
    no-addition results. H5MSM preserves original operation indices, structure
    counts, units and producer versions without storing another coordinate array.
    The embedded readiness audit uses scalar lists for nullable/mixed values
    and typed arrays for indices and coverage. History is not a live index map
    or a certificate after later edits. Import a component's historical records
    explicitly with ChemicalStates.append_preparation_history when reinserting H.
    See :ref:`Tutorial_Fixed_State_Hydrogens` for the experimental contract.

    In legacy pH mode, hydrogen atoms are added based on standard residue templates and general
    rules for protonation. Ionizable side chains (e.g., ASP, GLU, HIS) and both
    chain termini are adjusted according to the provided pH.

    .. warning::

       `pH` is applied through **fixed pKa thresholds** taken from free-amino-acid
       values, not through a calculation of each residue's own pKa in its
       environment. A buried or electrostatically shifted residue can titrate more
       than a pH unit away from its threshold, and this function will not reflect
       that. Where the assignment matters — a residue near a threshold, or a
       pH-dependent result — verify it rather than assuming it, or obtain the
       protonation from a dedicated pKa predictor. Environment-dependent pKa
       prediction, comparable to PROPKA, is not implemented in any of the engines
       offered here.

    This function only **adds** hydrogens. A hydrogen already present that the pH
    rules would not have placed is left untouched.

    The list of supported molecular systems' forms is available at:
    :ref:`User Guide > Introduction > Molecular systems > Forms <Introduction_Forms>`


    See Also
    --------
    :func:`molsysmt.build.has_hydrogens`
        Check whether a molecular system contains hydrogen atoms.

    :func:`molsysmt.build.add_missing_heavy_atoms`
        Add missing non-hydrogen atoms to a molecular system.

    :func:`molsysmt.basic.contains`
        Check for the presence of specific atoms or molecules.


    Examples
    --------
    >>> import molsysmt as msm
    >>> from rdkit import Chem
    >>> molsys = Chem.MolFromSmiles('C')
    >>> conf = Chem.Conformer(1)
    >>> _ = molsys.AddConformer(conf)
    >>> result = msm.build.add_missing_hydrogens(molsys, mode='fixed_chemical_state',
    ...     pH=None, engine='RDKit', return_report=True)
    >>> result['molecular_system'].get_n_atoms()
    5
    >>> result['report']['n_added_hydrogens']
    4


    .. admonition:: User guide

       Follow this link for a tutorial on how to work with this function:
       :ref:`User Guide > Tools > Build > Add missing hydrogens <Tutorial_Add_missing_hydrogens>`

    .. versionadded:: 1.0.0
    """

    if not isinstance(skip_digestion, bool):
        from molsysmt._private.argdigest.argument.skip_digestion import (
            digest_skip_digestion,
        )

        digest_skip_digestion(
            skip_digestion, caller=__name__ + ".add_missing_hydrogens"
        )
    from molsysmt._private.smonitor import ArgumentError
    from molsysmt._private.variables import is_all

    caller = "molsysmt.build.add_missing_hydrogens"
    if mode == "fixed_chemical_state":
        if pH is not None:
            raise ArgumentError(
                "pH",
                value=pH,
                caller=caller,
                message="Fixed-state mode requires pH=None.",
            )
        if engine != "RDKit":
            raise ArgumentError(
                "engine",
                value=engine,
                caller=caller,
                message="Fixed-state mode requires the explicit RDKit engine.",
            )
        from molsysmt._private.fixed_hydrogens import add

        result = add(
            molecular_system, chemical_state, structure_indices, attribute_policy
        )
        return result if return_report else result["molecular_system"]
    if mode != "pH" or pH is None or engine == "RDKit":
        raise ArgumentError(
            "mode",
            value=mode,
            caller=caller,
            message="RDKit and pH=None require explicit fixed_chemical_state mode.",
        )
    if (
        chemical_state != "reference"
        or not is_all(structure_indices)
        or return_report
        or attribute_policy != "intersection"
    ):
        raise ArgumentError(
            "mode",
            value=mode,
            caller=caller,
            message="State, structure, report and attribute-policy options require fixed-state mode.",
        )

    from molsysmt.basic import convert, get, get_form

    output_molecular_system = None
    form_in = get_form(molecular_system)
    form_out = form_in

    if engine in ("OpenMM", "PDBFixer"):
        from molsysmt._private.amino_acid_templates import check_external_preparation

        check_external_preparation(molecular_system, engine, caller)

    if engine == "OpenMM":
        from molsysmt.basic import set

        atts_from_components = get(
            molecular_system,
            element="component",
            component_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )
        atts_from_molecules = get(
            molecular_system,
            element="molecule",
            molecule_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )
        atts_from_chains = get(
            molecular_system,
            element="chain",
            chain_id=True,
            chain_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )
        atts_from_entities = get(
            molecular_system,
            element="entity",
            entity_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )

        temp_molecular_system = convert(
            molecular_system, to_form="openmm.Modeller", skip_digestion=True
        )
        temp_molecular_system.addHydrogens(pH=pH)
        output_molecular_system = convert(
            temp_molecular_system, to_form=form_out, skip_digestion=True
        )

        _n_comp = get(
            output_molecular_system,
            element="component",
            n_components=True,
            skip_digestion=True,
        )
        if _n_comp == len(next(iter(atts_from_components.values()))):
            set(
                output_molecular_system,
                element="component",
                **atts_from_components,
                skip_digestion=True,
            )
        _n_mol = get(
            output_molecular_system,
            element="molecule",
            n_molecules=True,
            skip_digestion=True,
        )
        if _n_mol == len(next(iter(atts_from_molecules.values()))):
            set(
                output_molecular_system,
                element="molecule",
                **atts_from_molecules,
                skip_digestion=True,
            )
        _n_chain = get(
            output_molecular_system, element="chain", n_chains=True, skip_digestion=True
        )
        if _n_chain == len(next(iter(atts_from_chains.values()))):
            set(
                output_molecular_system,
                element="chain",
                **atts_from_chains,
                skip_digestion=True,
            )
        if form_out == "molsysmt.MolSys":
            output_molecular_system.topology.rebuild_entities(
                redefine_indices=True,
                redefine_ids=True,
                redefine_names=True,
                redefine_types=True,
            )
            _n_ent = get(
                output_molecular_system,
                element="entity",
                n_entities=True,
                skip_digestion=True,
            )
            if _n_ent == len(next(iter(atts_from_entities.values()))):
                set(
                    output_molecular_system,
                    element="entity",
                    **atts_from_entities,
                    skip_digestion=True,
                )
        elif form_out == "molsysmt.Topology":
            output_molecular_system.rebuild_entities(
                redefine_indices=True,
                redefine_ids=True,
                redefine_names=True,
                redefine_types=True,
            )
            _n_ent = get(
                output_molecular_system,
                element="entity",
                n_entities=True,
                skip_digestion=True,
            )
            if _n_ent == len(next(iter(atts_from_entities.values()))):
                set(
                    output_molecular_system,
                    element="entity",
                    **atts_from_entities,
                    skip_digestion=True,
                )

        del (
            atts_from_components,
            atts_from_molecules,
            atts_from_chains,
            atts_from_entities,
        )

        del temp_molecular_system

    elif engine == "PDBFixer":
        from molsysmt.basic import set

        atts_from_components = get(
            molecular_system,
            element="component",
            component_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )
        atts_from_molecules = get(
            molecular_system,
            element="molecule",
            molecule_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )
        atts_from_chains = get(
            molecular_system,
            element="chain",
            chain_id=True,
            chain_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )
        atts_from_entities = get(
            molecular_system,
            element="entity",
            entity_name=True,
            output_type="dictionary",
            skip_digestion=True,
        )

        temp_molecular_system = convert(
            molecular_system, to_form="pdbfixer.PDBFixer", skip_digestion=True
        )
        temp_molecular_system.addMissingHydrogens(pH=pH)
        output_molecular_system = convert(
            temp_molecular_system, to_form=form_out, skip_digestion=True
        )

        _n_comp = get(
            output_molecular_system,
            element="component",
            n_components=True,
            skip_digestion=True,
        )
        if _n_comp == len(next(iter(atts_from_components.values()))):
            set(
                output_molecular_system,
                element="component",
                **atts_from_components,
                skip_digestion=True,
            )
        _n_mol = get(
            output_molecular_system,
            element="molecule",
            n_molecules=True,
            skip_digestion=True,
        )
        if _n_mol == len(next(iter(atts_from_molecules.values()))):
            set(
                output_molecular_system,
                element="molecule",
                **atts_from_molecules,
                skip_digestion=True,
            )
        _n_chain = get(
            output_molecular_system, element="chain", n_chains=True, skip_digestion=True
        )
        if _n_chain == len(next(iter(atts_from_chains.values()))):
            set(
                output_molecular_system,
                element="chain",
                **atts_from_chains,
                skip_digestion=True,
            )
        if form_out == "molsysmt.MolSys":
            output_molecular_system.topology.rebuild_entities(
                redefine_indices=True,
                redefine_ids=True,
                redefine_names=True,
                redefine_types=True,
            )
            _n_ent = get(
                output_molecular_system,
                element="entity",
                n_entities=True,
                skip_digestion=True,
            )
            if _n_ent == len(next(iter(atts_from_entities.values()))):
                set(
                    output_molecular_system,
                    element="entity",
                    **atts_from_entities,
                    skip_digestion=True,
                )
        elif form_out == "molsysmt.Topology":
            output_molecular_system.rebuild_entities(
                redefine_indices=True,
                redefine_ids=True,
                redefine_names=True,
                redefine_types=True,
            )
            _n_ent = get(
                output_molecular_system,
                element="entity",
                n_entities=True,
                skip_digestion=True,
            )
            if _n_ent == len(next(iter(atts_from_entities.values()))):
                set(
                    output_molecular_system,
                    element="entity",
                    **atts_from_entities,
                    skip_digestion=True,
                )

        del (
            atts_from_components,
            atts_from_molecules,
            atts_from_chains,
            atts_from_entities,
        )

        del temp_molecular_system

    elif engine == "MolSysMT":
        from molsysmt import pyunitwizard as puw
        from molsysmt.basic import convert, get
        from molsysmt.build._native_placers import (
            _infer_hybridization,
            append_atoms_to_molsys,
            h_bond_length,
            load_residue_template,
            place_hydrogens_on_parent,
        )
        from molsysmt.element.group.amino_acid import (
            get_expected_hydrogens,
        )

        if form_in != "molsysmt.MolSys":
            native_ms = convert(
                molecular_system, to_form="molsysmt.MolSys", skip_digestion=True
            )
        else:
            native_ms = molecular_system

        from molsysmt._private.amino_acid_templates import (
            choose_variant,
            family,
            variants,
        )

        topo = native_ms.topology
        schemes = topo.group_naming_schemes
        for index, name in enumerate(topo.groups["group_name"]):
            family(name, schemes[index], caller=caller)
        all_coords = puw.get_value(native_ms.structures.coordinates, to_unit="nm")
        n_structures = all_coords.shape[0]

        # For each group determine terminal status
        # Rebuild components to ensure component_type is derived from bonds
        native_ms.rebuild_components(
            redefine_indices=True,
            redefine_ids=False,
            redefine_types=True,
            redefine_names=False,
        )

        # Group-level metadata
        n_groups = topo.n_groups

        # Determine first/last group of each component (peptide/protein)
        comp_first = {}  # comp_idx -> first group_idx
        comp_last = {}  # comp_idx -> last group_idx
        for g in range(n_groups):
            g_atoms = topo.atoms[topo.atoms["group_index"] == g]
            if g_atoms.empty:
                continue
            c_idx = int(
                native_ms.chemical_states._get_component_indices().loc[g_atoms.index[0]]
            )
            if c_idx not in comp_first:
                comp_first[c_idx] = g
            comp_last[c_idx] = g

        # Detect disulfide bonds: CYS–CYS SG–SG bonds
        disulfide_groups = {}  # used as a set (keys only)
        bonds = native_ms.chemical_states._get_chemical_state_bonds()
        if bonds is not None and len(bonds) > 0:
            for _, brow in bonds.iterrows():
                a1 = int(brow["atom1_index"])
                a2 = int(brow["atom2_index"])
                row1 = topo.atoms.loc[a1]
                row2 = topo.atoms.loc[a2]
                if row1["atom_name"] == "SG" and row2["atom_name"] == "SG":
                    disulfide_groups[int(row1["group_index"])] = True
                    disulfide_groups[int(row2["group_index"])] = True

        # Collect all atom_name→atom_index mappings per group (for bond neighbor lookup)
        group_name_to_idx = {}  # group_idx -> {atom_name: atom_idx}
        for g in range(n_groups):
            g_atoms = topo.atoms[topo.atoms["group_index"] == g]
            group_name_to_idx[g] = dict(
                zip(g_atoms["atom_name"], g_atoms.index.tolist())
            )

        # This function only adds. Reporting what it will not touch is the whole of its
        # answer to uibcdf/molsysmt#178: the silence was the defect, not the inaction.
        from warnings import warn as _warn

        from molsysmt._private.smonitor import UnexpectedProtonationWarning
        from molsysmt.build._protonation import unexpected_hydrogens

        _unexpected = unexpected_hydrogens(native_ms, pH=pH)
        if _unexpected:
            _examples = ", ".join(
                f"{name} in {group_name} {group_index}"
                for _, name, group_index, group_name in _unexpected[:3]
            )
            if len(_unexpected) > 3:
                _examples += f", and {len(_unexpected) - 3} more"
            _warn(
                UnexpectedProtonationWarning(
                    count=len(_unexpected),
                    pH=pH,
                    examples=_examples,
                    caller="molsysmt.build.add_missing_hydrogens",
                ),
                stacklevel=2,
            )

        new_atom_info = []  # (group_idx, atom_name, coords(n_s,3))
        new_bonds_info = []  # (new_idx1, new_idx2) or (existing_idx, new_idx)

        n_atoms_so_far = topo.n_atoms  # running counter for new atom indices

        for g in range(n_groups):
            g_atoms = topo.atoms[topo.atoms["group_index"] == g]
            if g_atoms.empty:
                continue

            gname = topo.groups.loc[g, "group_name"] if g < len(topo.groups) else None

            lookup = gname

            if gname in ("ACE", "NME"):
                # Place missing H atoms on pre-existing capping groups via template bonds.
                template = load_residue_template(gname)
                if template is None:
                    continue
                if schemes[g] == "amber":
                    from molsysmt._private.peptide_builder_data import atom_variant

                    # A group convention does not declare an atom convention.
                    # Match observed H names across the two known cap layouts.
                    construction = atom_variant(gname)
                    if construction is not None:
                        legacy = dict(template)
                        legacy["atoms"] = list(
                            dict.fromkeys(
                                list(template["atoms"])
                                + [name for pair in template["bonds"] for name in pair]
                            )
                        )
                        template = choose_variant(
                            [legacy, construction], g_atoms["atom_name"].tolist()
                        )
                        if template is None:
                            continue
                        if template is construction:
                            from molsysmt import _ackredit
                            from molsysmt._private.peptide_builder_data import reference

                            with _ackredit.scope(caller) as provider:
                                _ackredit.credit(
                                    provider, [reference()], caller, contextual=True
                                )
                present_hs = {
                    a
                    for a in g_atoms["atom_name"]
                    if a.startswith("H")
                    or (len(a) >= 2 and a[0].isdigit() and a[1] == "H")
                }
                name_to_idx = group_name_to_idx[g]
                # Build parent → [H, ...] map from template bonds
                capping_parent_to_hs = {}
                for b1, b2 in template["bonds"]:
                    b1h = b1.startswith("H") or (
                        len(b1) >= 2 and b1[0].isdigit() and b1[1] == "H"
                    )
                    b2h = b2.startswith("H") or (
                        len(b2) >= 2 and b2[0].isdigit() and b2[1] == "H"
                    )
                    if b1h and not b2h:
                        capping_parent_to_hs.setdefault(b2, []).append(b1)
                    elif b2h and not b1h:
                        capping_parent_to_hs.setdefault(b1, []).append(b2)
                for par_name, h_names in capping_parent_to_hs.items():
                    missing_hs_here = [h for h in h_names if h not in present_hs]
                    if not missing_hs_here:
                        continue
                    par_idx = name_to_idx.get(par_name)
                    if par_idx is None:
                        continue
                    par_pos = all_coords[:, int(par_idx), :]
                    # Heavy neighbors of par_name within the template
                    neigh_positions = []
                    for b1, b2 in template["bonds"]:
                        b1h = b1.startswith("H") or (
                            len(b1) >= 2 and b1[0].isdigit() and b1[1] == "H"
                        )
                        b2h = b2.startswith("H") or (
                            len(b2) >= 2 and b2[0].isdigit() and b2[1] == "H"
                        )
                        if not b1h and not b2h:
                            nb = (
                                b2
                                if b1 == par_name
                                else (b1 if b2 == par_name else None)
                            )
                            if nb is not None:
                                nb_idx = name_to_idx.get(nb)
                                if nb_idx is not None:
                                    neigh_positions.append(
                                        all_coords[:, int(nb_idx), :]
                                    )
                    # For NME N: also add C from the preceding residue (peptide bond)
                    if gname == "NME" and par_name == "N":
                        n_atom_idx = name_to_idx.get("N")
                        if (
                            n_atom_idx is not None
                            and bonds is not None
                            and len(bonds) > 0
                        ):
                            for _, brow in bonds.iterrows():
                                a1, a2 = (
                                    int(brow["atom1_index"]),
                                    int(brow["atom2_index"]),
                                )
                                other = (
                                    a2
                                    if a1 == n_atom_idx
                                    else (a1 if a2 == n_atom_idx else None)
                                )
                                if other is not None:
                                    if int(topo.atoms.loc[other, "group_index"]) != g:
                                        neigh_positions.append(all_coords[:, other, :])
                    # CH3 (ACE) and C (NME methyl) are sp3; N is sp3 for amide H placement
                    bond_len = (
                        h_bond_length("C")
                        if par_name in ("CH3", "C")
                        else h_bond_length(par_name[0])
                    )
                    placed = place_hydrogens_on_parent(
                        par_pos,
                        neigh_positions,
                        len(missing_hs_here),
                        "sp3",
                        bond_len,
                        n_structures,
                    )
                    for h_name, h_coords in zip(missing_hs_here, placed):
                        new_atom_info.append((g, h_name, h_coords))
                        h_new_idx = n_atoms_so_far + len(new_atom_info) - 1
                        new_bonds_info.append((int(par_idx), h_new_idx))
                continue

            candidates = variants(gname, schemes[g], caller=caller)
            if candidates is None:
                from molsysmt._private.name_resolution import assessed
                from molsysmt._private.residue_templates import (
                    CURATED_MODIFIED_RESIDUES,
                )
                from molsysmt._private.smonitor import UnassessedResidueWarning

                interpretation = assessed(gname, schemes[g], caller=caller)
                if gname in CURATED_MODIFIED_RESIDUES or (
                    interpretation is not None
                    and interpretation.group_type == "amino acid"
                ):
                    _warn(
                        UnassessedResidueWarning(
                            group_name=gname,
                            group_index=g,
                            reason="no supported exact hydrogen reference for this naming interpretation",
                        ),
                        stacklevel=2,
                    )
                continue

            # Terminal status
            c_idx = int(
                native_ms.chemical_states._get_component_indices().loc[g_atoms.index[0]]
            )
            is_n_term = comp_first.get(c_idx) == g
            is_c_term = comp_last.get(c_idx) == g
            is_disulfide = g in disulfide_groups

            present_names = g_atoms["atom_name"].tolist()
            present_hs = {
                a
                for a in present_names
                if a.startswith("H") or (len(a) >= 2 and a[0].isdigit() and a[1] == "H")
            }

            expected_hs = get_expected_hydrogens(
                gname,
                naming_scheme=schemes[g],
                present_atom_names=present_names,
                pH=pH,
                is_n_terminal=is_n_term,
                is_c_terminal=is_c_term,
                is_disulfide=is_disulfide,
            )
            if expected_hs is None:
                from molsysmt._private.smonitor import UnassessedResidueWarning

                _warn(
                    UnassessedResidueWarning(
                        group_name=gname,
                        group_index=g,
                        reason="terminal-state completion or the observed atom layout is not supported by the exact hydrogen reference",
                    ),
                    stacklevel=2,
                )
                continue

            missing_hs = [h for h in expected_hs if h not in present_hs]
            if not missing_hs:
                continue

            # Use exactly the same atom-name matching as the expectation tool.
            best_variant = choose_variant(candidates, present_names)
            if best_variant is None:
                continue

            # Build parent→Hs map from variant bonds
            parent_to_hs = {}  # atom_name -> [h_name, ...]
            for b1, b2 in best_variant["bonds"]:
                h, par = None, None
                b1_is_h = b1.startswith("H") or (
                    len(b1) >= 2 and b1[0].isdigit() and b1[1] == "H"
                )
                b2_is_h = b2.startswith("H") or (
                    len(b2) >= 2 and b2[0].isdigit() and b2[1] == "H"
                )
                if b1_is_h and not b2_is_h:
                    h, par = b1, b2
                elif b2_is_h and not b1_is_h:
                    h, par = b2, b1
                if h is not None and h in missing_hs:
                    parent_to_hs.setdefault(par, []).append(h)

            # For each parent, place its missing Hs
            name_to_idx = group_name_to_idx[g]  # existing atoms in this group

            # Also include neighbour atom indices from adjacent groups for backbone N
            # N-H placement needs C(i-1) — bond partner from bonds DataFrame
            def _get_pos(aname, name_to_idx=name_to_idx):
                """Coords (n_s,3) for atom_name in this group, or None."""
                idx = name_to_idx.get(aname)
                if idx is None:
                    return None
                return all_coords[:, int(idx), :]

            for par_name, h_names in parent_to_hs.items():
                par_pos = _get_pos(par_name)
                if par_pos is None:
                    continue  # parent not present — skip

                # Find heavy-atom neighbors of parent in the variant
                variant_heavy_neigh = []
                for b1, b2 in best_variant["bonds"]:
                    b1_is_h = b1.startswith("H") or (
                        len(b1) >= 2 and b1[0].isdigit() and b1[1] == "H"
                    )
                    b2_is_h = b2.startswith("H") or (
                        len(b2) >= 2 and b2[0].isdigit() and b2[1] == "H"
                    )
                    if not b1_is_h and not b2_is_h:
                        if b1 == par_name:
                            variant_heavy_neigh.append(b2)
                        elif b2 == par_name:
                            variant_heavy_neigh.append(b1)

                # Positions of existing heavy neighbors within the group
                neigh_positions = []
                for nb_name in variant_heavy_neigh:
                    pos = _get_pos(nb_name)
                    if pos is not None:
                        neigh_positions.append(pos)

                # For backbone N: add C from previous residue via bonds table
                if par_name == "N" and len(neigh_positions) < 2:
                    n_atom_idx = name_to_idx.get("N")
                    if n_atom_idx is not None:
                        for _, brow in bonds.iterrows():
                            a1 = int(brow["atom1_index"])
                            a2 = int(brow["atom2_index"])
                            other = None
                            if a1 == n_atom_idx:
                                other = a2
                            elif a2 == n_atom_idx:
                                other = a1
                            if other is not None:
                                other_gidx = int(topo.atoms.loc[other, "group_index"])
                                if other_gidx != g:
                                    neigh_positions.append(all_coords[:, other, :])

                par_element = par_name[0] if par_name else "C"
                bond_len = h_bond_length(par_element)
                hybridization = _infer_hybridization(
                    par_name, variant_heavy_neigh, lookup
                )

                n_hs = len(h_names)
                placed = place_hydrogens_on_parent(
                    par_pos,
                    neigh_positions,
                    n_hs,
                    hybridization,
                    bond_len,
                    n_structures,
                )

                for h_name, h_coords in zip(h_names, placed):
                    new_atom_info.append((g, h_name, h_coords))
                    h_new_idx = n_atoms_so_far + len(new_atom_info) - 1
                    par_existing_idx = name_to_idx[par_name]
                    new_bonds_info.append((par_existing_idx, h_new_idx))

        if new_atom_info:
            native_out = append_atoms_to_molsys(
                native_ms, new_atom_info, new_bonds_info
            )
        else:
            native_out = native_ms

        output_molecular_system = (
            convert(native_out, to_form=form_in, skip_digestion=True)
            if form_in != "molsysmt.MolSys"
            else native_out
        )

    else:
        raise NotImplementedError

    return output_molecular_system
