"""Prospective, bounded E3 experimental-reference chemistry receiving."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tomllib
import traceback
from dataclasses import asdict

root = Path(os.environ['DMT_E3_ROOT'])
task = Path(os.environ['DMT_E3_TASK'])
attempt = Path(os.environ['DMT_E3_ATTEMPT'])
registration = json.loads((attempt / 'registration.json').read_text())
candidate = json.loads((attempt / 'frozen-candidate.json').read_text())
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')
prefix = Path(candidate['prefix'])
sdk = root / '.molsyssuite/publication-sdk/devtools/scripts'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def files(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}

def write(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

assert sys.flags.isolated and sys.flags.no_site
assert os.sched_getaffinity(0) == {0} and os.getpriority(os.PRIO_PROCESS, 0) >= 10
sys.path[:0] = [str(prefix), candidate['consumer_prefix'], candidate['viewer_prefix'], str(routine / 'lib/python3.14/site-packages'), str(sdk)]
blocked, allowed_subprocesses = [], []
declaration = tomllib.loads((attempt / 'frozen-resources.toml').read_text())['installed_tests']['support']
git_files = {str(root): (registration['source_commit'], {r['source'] for r in declaration['files']}), str(sdk.parents[1]): ('95f693be10c9205ab9b912cb53453710a207bf45', {'devtools/scripts/installed_test_support.py', 'devtools/scripts/installed_noarch.py', 'devtools/scripts/installed_imports.py', 'devtools/scripts/installed_test_dependencies.py'})}
git_read_count = 0
def audit(event, args):
    global git_read_count
    if event == 'subprocess.Popen':
        executable, argv = os.fsdecode(args[0]), args[1]
        if shutil.which(executable) == json.loads((attempt / 'frozen-plan.json').read_text())['git_executable'] and isinstance(argv, list) and len(argv) >= 4 and argv[:2] == ['git', '-C'] and argv[2] in git_files:
            commit, paths = git_files[argv[2]]
            if argv[3:] == ['rev-parse', 'HEAD'] or any(argv[3:] in (['rev-parse', commit + ':' + path], ['hash-object', '--no-filters', str(Path(argv[2]) / path)]) for path in paths):
                git_read_count += 1
                return
        if shutil.which(executable) == '/usr/bin/uname' and argv == ['uname', '-p']:
            allowed_subprocesses.append({'executable': '/usr/bin/uname', 'arguments': ['-p'], 'purpose': 'stdlib platform.processor during h5py import'})
            return
    if event == 'socket.connect' or event == 'subprocess.Popen' or event == 'import' and args[0].split('.')[0] == 'vina':
        blocked.append(event)
        raise AssertionError('Network, native search and non-platform subprocesses forbidden')
sys.addaudithook(audit)
from installed_test_support import staged_support
import numpy as np
import pyunitwizard as puw

def policy():
    return {k: puw.configure.report()[k] for k in ['default_form', 'default_parser', 'standard_units', 'provenance']}

counts = dict.fromkeys(registration['direct_caps'], 0)
stage = 'custody'
def call(key, function, *args, **kwargs):
    global stage
    stage = key
    counts[key] += 1
    assert counts[key] <= registration['direct_caps'][key], key
    with (attempt / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps({'operation': key, 'direct_counts': counts}) + '\n')
    return function(*args, **kwargs)

support = None
try:
    assert files(prefix) == candidate['provider_files_sha256']
    assert files(Path(candidate['consumer_prefix'])) == candidate['consumer_files_sha256']
    assert files(Path(candidate['viewer_prefix'])) == candidate['viewer_files_sha256']
    assert {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')} == candidate['routine_metadata_sha256']
    context = {'candidate_sha': registration['source_commit'], 'qualification_sha': registration['source_commit'], 'provider_sha': '95f693be10c9205ab9b912cb53453710a207bf45', 'sha256': candidate['consumer_wheel_sha256']}
    previous = policy()
    units = ['nm', 'ps', 'kelvin', 'mole', 'dalton', 'elementary_charge', 'kJ/mol', 'kJ/(mol*nm)', 'kJ/(mol*nm**2)', 'radians'] if registration['profile'] == 'normal' else ['pm', 'fs', 'kelvin', 'mole', 'dalton', 'coulomb', 'kJ/mol', 'kJ/(mol*pm)', 'kJ/(mol*pm**2)', 'radians']
    with puw.context(standard_units=units), staged_support(root, declaration, ('dockingmt', 'molsysviewer_dockingmt'), context=context) as support:
        caller = policy()
        import molsysmt as msm
        import dockingmt as dmt
        from dmt_test_support.qualify_chemical_templates import detached_record, snapshot
        assert policy() == caller and msm.__version__ == candidate['wheel']['version']
        origins = {}
        for name, module in tuple(sys.modules.items()):
            if name.split('.')[0] in {'molsysmt', 'dockingmt', 'pyunitwizard', 'argdigest', 'smonitor', 'depdigest'}:
                path = getattr(module, '__file__', None)
                if path:
                    expected = Path(candidate['consumer_prefix']) if name.split('.')[0] == 'dockingmt' else prefix
                    assert Path(path).resolve().is_relative_to(expected)
                    origins[name] = {'path': path, 'sha256': sha(path)}
        write('installed-origins.json', origins)
        immutable = []
        def keep(name, system):
            value = snapshot(system)
            write(name + '-snapshot.json', value)
            immutable.append((name, system, value))
        authorities = {}
        for role, basename in [('source', '5x72_ligand_p59H.sdf'), ('experimental', '5x72_ligand_p59.sdf')]:
            native, report = call('sdf_native', msm.convert, str(attempt / basename), to_form='molsysmt.MolSys', stereo_engine='rdkit', discard_properties=True, return_report=True)
            write(role + '-sdf-report.json', detached_record(asdict(report)))
            keep(role + '-parsed', native)
            toolkit, report = call('native_to_rdkit', msm.convert, native, to_form='rdkit.Mol', return_report=True)
            write(role + '-native-to-rdkit-report.json', detached_record(asdict(report)))
            authority, report = call('rdkit_to_native', msm.convert, toolkit, to_form='molsysmt.MolSys', return_report=True)
            write(role + '-rdkit-to-native-report.json', detached_record(asdict(report)))
            keep(role + '-authority', authority)
            xyz = call('coordinates', msm.get, authority, coordinates=True)
            parsed_xyz = call('coordinates', msm.get, native, coordinates=True)
            np.testing.assert_allclose(puw.get_value(xyz, to_unit='angstrom'), puw.get_value(parsed_xyz, to_unit='angstrom'), rtol=0, atol=1e-12)
            authorities[role] = authority
        heavy_before = call('coordinates', msm.get, authorities['experimental'], coordinates=True)
        addition = call('hydrogen_addition', msm.build.add_missing_hydrogens, authorities['experimental'], mode='fixed_chemical_state', pH=None, engine='RDKit', structure_indices=0, chemical_state='structure', return_report=True)
        generated = addition['molecular_system']
        write('hydrogen-addition-report.json', detached_record(addition['report']))
        keep('experimental-generated', generated)
        assert addition['report']['n_added_hydrogens'] == 15
        generated_xyz = call('coordinates', msm.get, generated, coordinates=True)
        np.testing.assert_allclose(puw.get_value(generated_xyz, to_unit='angstrom')[:, :24], puw.get_value(heavy_before, to_unit='angstrom'), rtol=0, atol=1e-12)
        heavy = call('heavy_selections', msm.select, authorities['source'], selection="atom_type!='H'")
        generated_heavy = call('heavy_selections', msm.select, generated, selection="atom_type!='H'")
        np.testing.assert_array_equal(heavy, np.arange(24))
        np.testing.assert_array_equal(generated_heavy, np.arange(24))
        witness = call('graph_witnesses', msm.chemical_states.get_atom_correspondences, authorities['source'], selection=heavy, reference_molecular_system=generated, reference_selection=generated_heavy, max_matches=4096)
        write('full39-correspondences.json', detached_record(witness))
        assert witness['search_complete'] and witness['search_scope'] == 'all_chemical_correspondences'
        assert witness['atom_correspondences'].shape[1:] == (24, 2) and witness['context_atom_correspondences'].shape[1:] == (39, 2)
        assert len(witness['atom_correspondences']) >= 1
        prepared_native = {}
        for role, system in [('source', authorities['source']), ('experimental', generated)]:
            cip = call('cip', msm.physchem.get_cip_stereochemistry, system, engine='rdkit', from_coordinates=False, structure_indices=0, chemical_state='structure')
            write(role + '-cip.json', detached_record(cip))
            assert cip['atom_stereochemistry'][7] == 'R'
            charged = call('charges', msm.build.assign_partial_charges, system, method='gasteiger_marsili', expected_total_charge=puw.quantity(0, 'elementary_charge'), structure_indices=0, chemical_state='structure', return_report=True)
            write(role + '-charge-report.json', detached_record(charged['report']))
            keep(role + '-charged', charged['molecular_system'])
            typed = call('types', msm.build.assign_autodock_atom_types, charged['molecular_system'], typing_scheme='autodock4', method='chemical_environment', structure_indices=0, chemical_state='structure', return_report=True)
            write(role + '-type-report.json', detached_record(typed['report']))
            keep(role + '-typed', typed['molecular_system'])
            prepared = call('prepare', dmt.prepare_ligand, typed['molecular_system'], selection='all', active_torsion_bonds=[], state_id='e2-5x72-p59' if role == 'source' else 'e3-5x72-p59-experimental-generated-H')
            write(role + '-prepared-declaration.json', detached_record(prepared.to_dict()))
            text = call('pdbqt', prepared.to_pdbqt)
            (attempt / (role + '-prepared.pdbqt')).write_text(text)
            if role == 'source':
                assert hashlib.sha256(text.encode()).hexdigest() == 'ae0e9d3beb4d14363ea6edb1bff591c56d53b02295082bae8c281d9284d84b9e'
            native = call('prepared_native', prepared.to_molecular_system)
            keep(role + '-prepared25', native)
            inventory = call('hydrogen_inventory', msm.physchem.get_hydrogen_inventory, native, structure_indices=0, chemical_state='structure')
            write(role + '-hydrogen-inventory.json', detached_record(inventory))
            assert len(inventory['atom_indices']) == 25 and sum(inventory['total_hydrogen_counts']) == 15
            prepared_native[role] = native
        reduced = call('graph_witnesses', msm.chemical_states.get_atom_correspondences, prepared_native['source'], reference_molecular_system=prepared_native['experimental'], max_matches=4096)
        write('prepared25-correspondences.json', detached_record(reduced))
        assert reduced['search_complete'] and len(reduced['atom_correspondences']) >= 1 and reduced['atom_correspondences'].shape[1:] == (25, 2)
        for name, system in [('experimental-heavy24', authorities['experimental']), ('experimental-generated39', generated), ('source-prepared25', prepared_native['source']), ('experimental-prepared25', prepared_native['experimental'])]:
            call('h5_write', msm.convert, system, to_form=str(attempt / (name + '.h5msm')))
        for name, system in [('experimental-generated39', generated), ('experimental-prepared25', prepared_native['experimental'])]:
            restored = call('h5_read', msm.convert, str(attempt / (name + '.h5msm')), to_form='molsysmt.MolSys')
            assert snapshot(restored) == snapshot(system), name
        stage = 'final-nonmutation-and-custody'
        for name, system, before in immutable:
            assert snapshot(system) == before, name
        support.check()
        assert policy() == caller
    assert policy() == previous and not blocked
    assert files(prefix) == candidate['provider_files_sha256']
    assert files(Path(candidate['consumer_prefix'])) == candidate['consumer_files_sha256']
    assert files(Path(candidate['viewer_prefix'])) == candidate['viewer_files_sha256']
    assert {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')} == candidate['routine_metadata_sha256']
    for basename, expected in registration['input_sha256'].items():
        assert sha(attempt / basename) == expected
    assert counts == registration['direct_caps']
    write('receipt.json', {'source_commit': registration['source_commit'], 'stage': 'reference', 'profile': registration['profile'], 'outcome': 'PASS', 'qualification_complete': True, 'direct_counts': counts, 'full39_heavy_maps': len(witness['atom_correspondences']), 'full39_context_candidates': witness['n_candidate_matches'], 'prepared25_maps': len(reduced['atom_correspondences']), 'generated_hydrogens': 15, 'heavy_preservation_atol_angstrom': 1e-12, 'matched_original_source_pdbqt': True, 'source_and_caller_preserved': True, 'common_receptor_frame_admitted': False, 'rmsd_calls': 0, 'clustering_calls': 0, 'native_searches': 0, 'new_independent_complexes': 0, 'e3_accepted': False, 'blocked': blocked, 'allowed_subprocesses': allowed_subprocesses, 'support_binding_git_reads': git_read_count})
except BaseException as error:
    write('failure.json', {'stage': stage, 'exception_type': type(error).__name__, 'exception_module': type(error).__module__, 'message': str(error), 'direct_counts': counts, 'reference_accepted': False, 'e3_accepted': False})
    traceback.print_exc()
    raise
finally:
    if support is not None:
        write('support-receipt.json', support.receipt)
