# E3 experimental-reference chemistry receiving — 2026-11-08

Owner: [DockingMT #79](https://github.com/uibcdf/dockingmt/issues/79).
Consumer checkpoint: `dc060579b097643546cf38655aa262c596f4b68c`.
Status: **prospectively registered; not executed or accepted**.

## Question and preserved scope

Can supported public provider operations admit the experimental P59 reference
to the indexed/virtual-H representation of the three existing rigid25 poses?
This independently useful prerequisite advances the complete E3 workflow while
[MolSysMT #604](https://github.com/uibcdf/molsysmt/issues/604) owns the supported
pairwise/clustering contract. It does not replace the experimental reference,
controls, common-frame admission, clustering or the full Core/Extended plan.

The exact original 24-heavy SDF is SHA-256
`a476b0d62652664596801fc88024fbd756294e9e2faf9234c8d90c2288aaa373`;
the original hydrogenated source is
`ef26c05a198a16972efcf8baae644f6b38fd953561f130ee230626088766b08a`.
Both remain immutable, with attribution in the existing
[input inventory](../../tests/data/vina_torsions/README.md). The earlier
[E2 source/preparation receiving](e2_preparation_receiving_2026-11-07.md)
and [E3 population inspection](e3_provider_admission_2026-11-07.md) keep their
original producers and outcomes. No new independent molecular case is proposed.

## Prospective selection and failure policy

Two fresh serial processes, normal units then pm/fs/coulomb. Run the second
only after the whole first selection passes. A failed molecular or resource
gate terminates the selection; retain partial returns and unattempted members.
No retry, chemistry fallback, alternate reference or relaxed assertion follows.

1. Read both original SDFs with public native conversion, explicit
   `stereo_engine='rdkit'` and `discard_properties=True`, retaining raw source
   properties. Public native→RDKit→native interpretation is a separately
   reported transformation, matching the original E2 recipe. Check coordinates
   against the parsed authority within 1e-12 angstrom, with zero relative tolerance.
2. On the experimental authority only, add fixed-state H using public
   `add_missing_hydrogens(mode='fixed_chemical_state', pH=None, engine='RDKit')`.
   Expect fifteen appended H from the historical hypothesis; preserve the 24
   heavy coordinates within the same tolerance. Generated H orientation remains
   a model assumption. No pH-state choice, heavy refinement or optimization.
3. Request provider-owned complete-graph correspondence for the 24 selected
   heavy atoms with the complete 39-atom H context and `max_matches=4096`.
   Retain every returned heavy map, full-context witness and search scope.
   Do not assume source order, names or historical H-parent order is a map.
4. Require explicit stored R stereo at original source index 7. Prepare both
   authorities with named Gasteiger-Marsili charges, explicit neutral total,
   AutoDock4 chemical-environment typing and `active_torsion_bonds=[]`.
   Require the source PDBQT to reproduce the originally admitted exact SHA-256
   `ae0e9d3beb4d14363ea6edb1bff591c56d53b02295082bae8c281d9284d84b9e`.
   Check the resulting 25-atom inventory and fifteen represented H. Request a
   second complete-graph correspondence on the two actual prepared systems.
5. Retain native H5MSM heavy24/generated39/source25/reference25 outputs. Publicly
   reopen generated39/reference25 in-process and compare public snapshots;
   verify all live input/intermediate snapshots and caller policy stay unchanged.

Per process direct caps: SDF/native 2, native/RDKit 2, RDKit/native 2, coordinate
reads 6, H addition 1, heavy selections 2, graph witnesses 2, explicit CIP 2,
charge assignments 2, type assignments 2, preparations 2, PDBQT exports 2,
prepared/native 2, hydrogen inventories 2, H5 writes 4 and H5 reads 2.
Snapshot and provider-internal dispatches are separate from these direct caps.
No RMSD, matrix, clustering, docking, energy evaluation or interaction detection.

## Exact composition and execution bounds

Reuse the preserved complete private provider faab727ca5b5c9078e2f2e505971fc0ea1cf1a8d
wheel, SHA-256 `c603fbde78a58fcec43d6d0fb8a6b27dabcbef706c19c35b4f5033c8a8dae9c6`.
Its qualified native/build inputs remain those of 9e1f1b1; this is neither an
exact current-main native build nor a public provider delivery. The candidate
manifest SHA-256 is
`c7061d409bf59f8598027588f7dd8589edea16c36a58812436fad0c2adb5e76a`.
Consumer source 2ef82d25e34266d1b504464dc238e8863a9dade0 and whole installed wheel
`6db76835f4f3f9c41d06a163cb3a4fbc9e780597bfd89d2fc6a75d29cff31133`
are unchanged; no runtime implementation changes are being received.
Use Python 3.14.10, isolated/no-site imports, exact immutable private payloads,
declared staged test support and SDK 95f693be10c9205ab9b912cb53453710a207bf45.

One logical CPU0, nice10, one native/build worker, group RSS ≤1 GiB, address
space ≤2 GiB, CPU45 s and wall60 s per process. Estimate ≤512 MiB group RSS from
the previous small-molecule provider cells. Preserve at least 20% physical RAM,
rounded up to a GiB (13 GiB on this host), and require another 1 GiB before
launch. Sample availability/group RSS while executing and stop only owned work.
The installed Slurm commands have no active allocation; the bounded scheduler
query's actual outcome is retained before launch. Direct execution is limited
to this small, finite molecular inspection/preparation, with no compilation,
campaign or search. Availability is not a resource reservation.

The actual worker, controller, prescription, candidate, exact inputs and resource
declaration are frozen before each execution. Network/native searches and
subprocesses are denied except the known stdlib `uname -p` platform query and
SDK read-only Git verification of the exact selected support/provider files.
Retain failures, resource outcomes and records; exact public dependency closure,
visible acceptance, common receptor-frame validation and whole E3 stay separate.

## Fresh selection amendment, before receiving-02

The first normal attempt terminates in SDK support binding: the task audit
allowed `/usr/bin/git` while PATH selects the existing Conda Git. All molecular
counters are zero; no source is read and the second policy is unattempted.
That qualification remains FAIL, with terminal owned processes, no resource
interruption, 2.453 s and sampled group RSS 63,275,008 bytes.

A separately registered whole selection `receiving-02` preserves the same two
policies, inputs, scientific checks, caps and stop-on-failure rule. Its single
task correction allows the actual Conda Git executable, SHA-256
`5f6c0e64b125f4089fdfb581f46fb5aeea4555814840217c65ff9061d6ed3658`,
for the already declared bounded read-only support/provider verification.
The original failed selection is not overwritten or promoted to a pass.
