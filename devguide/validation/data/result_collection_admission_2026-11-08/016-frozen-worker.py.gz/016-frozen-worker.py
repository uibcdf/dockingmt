"""Read one public registry response with existing task limits and no imports."""
import hashlib
import json
import os
from pathlib import Path
import urllib.request

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
plan = json.loads((task / 'plan.json').read_text())
request = plan['registry_request']
with urllib.request.urlopen(request['url'], timeout=request['timeout_seconds']) as response:
    raw = response.read(request['maximum_bytes'] + 1)
    assert response.status == 200 and len(raw) <= request['maximum_bytes']
(attempt / 'registry-response.json').write_bytes(raw)
data = json.loads(raw)
prior_path = root / '.molsyssuite/provider-fix-artifacts-20261108/inventory-01/registry-inventory.json'
prior_raw = prior_path.read_bytes()
(task / 'prior-registry-inventory.json').write_bytes(prior_raw)
prior = json.loads(prior_raw)
fields = ['basename', 'version', 'sha256', 'size', 'upload_time']
def identities(rows):
    return sorted(tuple(str(row.get(k)) for k in fields) for row in rows)
old = identities(prior['files'])
current = identities(data['files'])
observation = {'status': 'AVAILABLE', 'response_bytes': len(raw), 'response_sha256': hashlib.sha256(raw).hexdigest(), 'advertised_files': len(current), 'unchanged_identities': current == old, 'newly_advertised_identities': sorted(set(current) - set(old)), 'identity_fields': fields, 'prior_inventory_sha256': hashlib.sha256(prior_raw).hexdigest(), 'scope': 'One dated public metadata observation only; no package payload, private artifact or complete dependency qualification'}
(attempt / 'registry-observation.json').write_text(json.dumps(observation, indent=2) + '\n')
receipt = {'stage': 'registry', 'source_commit': plan['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'advertised_files': len(current), 'new_advertised_files': len(observation['newly_advertised_identities']), 'molecular_operations': 0, 'native_builds': 0, 'package_installs': 0}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
