"""Run one record-only probe and bounded public registry observation."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.request

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
plan = json.loads((task / 'plan.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == plan['source_commit']
for name, field in [('dockingmt/core/results.py', 'original_runtime_sha256'), ('dockingmt/_private/argdigest/registry.py', 'original_registry_sha256')]:
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == plan[field]
shutil.copyfile(task / 'probe_child.py', attempt / 'frozen-probe_child.py')
subprocess.run([sys.executable, '-B', '-I', str(attempt / 'frozen-probe_child.py')], cwd=root, check=True)
observation = {'status': 'UNAVAILABLE', 'scope': 'One bounded metadata observation only; no package payload or absence qualification'}
request = plan['registry_request']
try:
    with urllib.request.urlopen(request['url'], timeout=request['timeout_seconds']) as response:
        raw = response.read(request['maximum_bytes'] + 1)
        assert len(raw) <= request['maximum_bytes']
        assert response.status == 200
    data = json.loads(raw)
    (attempt / 'registry-response.json').write_bytes(raw)
    prior = json.loads((root / '.molsyssuite/provider-fix-artifacts-20261108/inventory-01/registry-inventory.json').read_text())
    fields = ['basename', 'version', 'sha256', 'size', 'upload_time']
    def identities(rows):
        return sorted(tuple(str(row.get(k)) for k in fields) for row in rows)
    old = identities(prior['files'])
    current = identities(data['files'])
    observation.update(status='AVAILABLE', response_bytes=len(raw), response_sha256=hashlib.sha256(raw).hexdigest(), advertised_files=len(current), unchanged_identities=current == old, newly_advertised_identities=sorted(set(current) - set(old)), identity_fields=fields)
except Exception as error:
    observation.update(error_type=type(error).__name__, error=str(error))
(attempt / 'registry-observation.json').write_text(json.dumps(observation, indent=2) + '\n')
receipt = {'stage': 'probe', 'source_commit': plan['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'saved_observations': 9, 'live_observations': 3, 'registry_status': observation['status'], 'molecular_operations': 0, 'scope': 'Confirms source collection bugs and records bounded registry outcome; not corrected-reader or artifact receiving'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
