"""Observe saved result collection interpretation and live ordering only."""
from copy import deepcopy
import json
import os
from pathlib import Path

import dockingmt as dmt
import pyunitwizard as puw

attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
pose = dmt.DockingPose(puw.quantity([[1, 2, 3]], 'nm'), pose_id='control')
valid = dmt.DockingResult([pose]).to_dict()
rows = []
for label, record in [
    ('missing_legacy_axis', {}),
    ('valid_empty_list', {'poses': []}),
    ('valid_empty_tuple', {'poses': ()}),
    ('invalid_empty_mapping', {'poses': {}}),
    ('invalid_empty_text', {'poses': ''}),
    ('invalid_empty_set', {'poses': set()}),
    ('invalid_null', {'poses': None}),
    ('invalid_member', {'poses': [None]}),
    ('valid_pose_list', valid),
]:
    before = deepcopy(record)
    try:
        restored = dmt.DockingResult.from_dict(record)
        observed = {'accepted': True, 'n_poses': len(restored), 'pose_ids': [p.pose_id for p in restored]}
    except Exception as error:
        observed = {'accepted': False, 'error': type(error).__name__, 'code': getattr(error, 'code', None), 'field': getattr(error, 'extra', {}).get('arg_name')}
    assert record == before
    rows.append({'case': label, 'reader': observed, 'caller_preserved': True})
live = []
for label, values in [('empty_set', set()), ('pose_set', {pose}), ('pose_list', [pose])]:
    restored = dmt.DockingResult(values)
    live.append({'case': label, 'accepted': True, 'n_poses': len(restored)})
assert all(rows[i]['reader']['accepted'] and rows[i]['reader']['n_poses'] == 0 for i in [3, 4, 5])
assert live[0]['accepted'] and live[1]['accepted']
(attempt / 'observations.json').write_text(json.dumps({'rows': rows, 'live_collections': live, 'molecular_operations': 0, 'scope': 'Malformed saved axes can be interpreted as empty results; unordered live sets admitted'}, indent=2) + '\n')
print(json.dumps({'diagnosis_complete': True, 'saved_cases': len(rows), 'live_cases': len(live)}))
