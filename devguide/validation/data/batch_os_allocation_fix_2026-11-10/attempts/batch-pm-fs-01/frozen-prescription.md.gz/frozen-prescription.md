# Recorded-batch OS allocation errors — 2026-11-10

Owner: [DockingMT #106](https://github.com/uibcdf/dockingmt/issues/106),
functional/resource owners #73/#50. Source base85d91c1. Status: red/green registered.

The original ordinary installed aeae47d diagnostic raises pre-created errors,
not a real allocation failure. MemoryError propagates as the same object after
first/bad; OSError(errno.ENOMEM) records failure and visits third. ENOENT records
and continues as intended. Preserve that observation and original wheel; it is
not receiving of the source correction.

Add two policy cases for OS allocation failure, preserving exact exception
identity, first outcome, unconsumed next item and caller-owned source. Add two
recording controls for ordinary ENOENT/ENOSPC errors. Receive an expected failing
record-policy case before changing runtime code, then correct only ENOMEM
classification. No string matching, generic OSError passthrough, schema or
dependency change is admitted.

Run the entire updated45-case batch module normal then pm/fs, with all41 original
cases and assertions retained. Native work remains ten tiny searches per policy,
the same four/two-record PDBQT, seed123, CPU1, exhaustiveness1 and10-angstrom box.
Use the unchanged retained engine and six-provider cohort. Source origins and
overlay hashes are explicit; no new wheel/install/public artifact is claimed.

Each cell is serial CPU0/nice10/one worker,13GiB available-RAM reserve,1GiB group
RSS,2GiB address space,60/65 CPU seconds and180 wall seconds. Expected native
peak768MiB, red control256MiB; prior whole-module peak is below452MiB. The
registered monitor checks RAM before launch and during execution, supervises
owned descendants and preserves every interruption. No automatic headroom
restart or native build. Slurm has no allocation; earlier applicability check
was inconclusive. Retain original programs, overlays, outcomes and original
diagnostic under `.molsyssuite/batch-os-allocation-fix-20261110`, owners#106/#50,
review2026-11-14. Original runtime artifacts and scientific fixtures stay intact.

Full/public/platform/hosted/interactive and SSH-source-context gates retain their
separate scope. No remote CI, shared environment or provider changes are needed.
