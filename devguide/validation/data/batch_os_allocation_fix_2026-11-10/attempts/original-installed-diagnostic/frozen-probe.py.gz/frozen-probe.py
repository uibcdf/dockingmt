"""Controlled exception classification; no allocation failure or native work."""
import errno
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path(os.environ['DMT_GATE_ROOT'])
attempt = Path(os.environ['DMT_GATE_ATTEMPT'])
installation = json.loads((root / '.molsyssuite/installed-reconstruction-20261109/installation.json').read_text())
site = Path(installation['site'])
assert Path(sys.prefix) == Path(installation['prefix'])
def verify():
    for group in ['consumer_sha256', 'tool_sha256', 'unit_sha256']:
        for name, digest in installation[group].items():
            assert hashlib.sha256((site / name).read_bytes()).hexdigest() == digest
verify()
import dockingmt as dmt
import pyunitwizard as puw
assert Path(dmt.__file__).resolve().is_relative_to(site)
assert dmt.__version__ == '0.0.0+351.gaeae47d'

class Controlled(dmt.DockingBackend):
    name = 'controlled-error-only'
    capabilities = set()
    is_available = True
    def __init__(self, error):
        self.error = error
        self.calls = []
    def dock(self, problem, protocol=None):
        label = problem.metadata['label']
        self.calls.append(label)
        if label == 'bad':
            raise self.error
        return dmt.DockingResult([])

rows = []
for error in [MemoryError('controlled'), OSError(errno.ENOMEM, 'controlled'), FileNotFoundError(errno.ENOENT, 'controlled')]:
    backend = Controlled(error)
    items = [dmt.DockingProblem('unused_receptor.pdbqt', 'unused_partner.pdbqt',
        dmt.BoxRegion(puw.quantity([0, 0, 0], 'angstrom'), puw.quantity([10, 10, 10], 'angstrom')),
        metadata={'label': label}) for label in ['first', 'bad', 'third']]
    statuses = []
    propagated = False
    same_exception = False
    stream = dmt.dock_many(items, backend=backend, on_error='record')
    try:
        for outcome in stream:
            statuses.append(outcome.status)
    except BaseException as caught:
        propagated = True
        same_exception = caught is error
    finally:
        stream.close()
    rows.append({'type': type(error).__name__, 'errno': getattr(error, 'errno', None),
        'statuses': statuses, 'calls': backend.calls, 'propagated': propagated,
        'same_exception': same_exception})
assert rows[0]['propagated'] and rows[0]['same_exception'] and rows[0]['calls'] == ['first', 'bad']
assert not rows[1]['propagated'] and rows[1]['statuses'] == ['success', 'failure', 'success']
assert not rows[2]['propagated'] and rows[2]['statuses'] == ['success', 'failure', 'success']
verify()
assert 'vina' not in sys.modules and 'molsysviewer' not in sys.modules
receipt = {'diagnostic_completed': True, 'runtime_version': dmt.__version__,
    'ordinary_installed_origin': str(Path(dmt.__file__).resolve()),
    'controlled_exceptions_only': True, 'actual_memory_exhaustion': False,
    'native_execution': False, 'rows': rows}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
