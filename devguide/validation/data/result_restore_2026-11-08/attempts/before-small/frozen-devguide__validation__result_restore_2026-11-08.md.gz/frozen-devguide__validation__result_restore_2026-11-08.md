# Bounded result restoration profile — 2026-11-08

Owner: [DockingMT #28](../pending_proposals/review_extensibility_and_performance.md).
Execution base: `cadb16b146555faae0e0c87e1221e787797f2306`.
Registered before execution; **unexecuted**. Existing export timings and scientific
producers retain their original identities; this measures another operation.

## Question and fixed selection

Does `DockingResult.from_dict` spend material time/memory copying complete pose
records twice, once through its whole-result snapshot and once through each
pose reader? First measure the unchanged runtime. Reuse the existing unshipped
`dmt_test_support.benchmark_result_export._synthetic_result` builder without
changing its helper, data or molecular definitions. These are deterministic
serialization fixtures, not molecular systems or scientific cases.

Start with its mapped 9-pose × 64-atom fixture. After a complete safe pilot,
measure one fixed mapped 64-pose × 256-atom fixture. Each fresh process receives
five uninstrumented restoration samples and separate single cProfile and
tracemalloc calls. Keep the exact worker/helper/case/profile/method bytes and
fixture strict-JSON digest fixed before/after. Require full canonical restored
export equality and source nonmutation; never change a payload to improve timing.
Run one unmeasured restoration warm-up first. Eight restoration calls per cell
are permitted in total. Freeze the builder's ordinary JSON snapshot in the before
cell; after cells receive those same authenticated bytes rather than regenerate
different inputs. The builder and input construction remain outside measurement.

Use normal nm/ps caller policy for comparable timing; final source correctness
receiving must also use pm/fs. Record build/distribution labels separately from
actual mutable source SHA inventories. All scientific/molecular/engine/viewer
operations remain forbidden; no new docking, scoring, RMSD or preparation.

## Measurement and conditional implementation

Elapsed samples time only `DockingResult.from_dict(record)` with perf_counter.
Imports, fixture construction, source hashing, GC between trials, canonical
export/hash and snapshot disposal are excluded. Record every raw sample and
median, process load observations and environment. OS caches remain warm;
background work is uncontrolled on the shared host. No portable speed guarantee.

Tracemalloc records peak Python allocations during one separate restoration,
excluding pre-existing input storage. It is not RSS or a complete memory budget.
The worker owns and stops only its own tracing. A separate cProfile records
function-call counts and cumulative/self time; cumulative values overlap.
The external guard independently records sampled owned-group RSS and headroom.

Only if measured costs justify it, remove the redundant whole-pose traversal
while leaving each pose reader responsible for its own independent snapshot.
Detach all declared result-context fields together so their existing internal
aliases survive. Preserve order, duplicates, inherited factories, NumPy/tuple/set
metadata, nondefault units, schema/member checks before copying, and native
resource exceptions. No cache, schema migration or new public API. Verify with
existing complete affected model/record/audit/snapshot guards and meaningful
ownership regressions, without wall-clock thresholds.

## Resources and stop rule

Serial CPU 0, nice 10, one native/build worker; 13 GiB monitored available-memory
reserve, 1 GiB group RSS, 2 GiB address space, CPU 45/wall 60 seconds per cell.
Estimated pilot peak 256 MiB, fixed medium case 512 MiB. Inspect RAM, CPU/load,
swap and memory pressure first; the earlier Slurm applicability probe remains
inconclusive and no allocation exists. Availability is not a reservation.
Proceed to the fixed medium cell only after a safe pilot and fresh headroom
check. Preserve failures/interruptions and never automatically restart a
headroom stop or increase limits. Stop without optimizing if the evidence does
not justify a change; report the measured limit honestly.

Retain `.molsyssuite/result-restore-20261108` under #28/#50, review 2026-11-14.
Seal original/final producers, input hashes, logs, metrics, exact source/method
and resource outcomes; independently read records without benchmarking again.
Update roadmap/plan/handoff and run applicable source/resource/publication checks
including a fresh committed export. No remote CI or provider polling/building.
Full scientific/installed/public/platform/canvas acceptance remains separate.
