# Declaration ownership and file-I/O receiving

Owners: [#97](https://github.com/uibcdf/dockingmt/issues/97),
[#98](https://github.com/uibcdf/dockingmt/issues/98), broader #19/#28/#73.
Prospective registration 2026-11-09; baseline
`9b077fabf41e19ffdfb945bc7aa3fb6c53265e0f`.

## Accepted concrete boundaries

Retaining a prepared-input/problem declaration must not allow later editing of
that exported observation to change the live scientific input. Source inspection
finds live list/metadata aliases in both preparation exports and the problem
export/reader. This complements #25's earlier pose/result isolation. Detach those
existing Python record boundaries, preserving exact fields/schema/values, rich
metadata types/cycles/aliases within each snapshot and subtype behavior. Keep
explicit live receptor/partner sources borrowed and outside serialized/copied
payloads. Ordinary constructor borrowing stays unchanged. No chemistry validator,
molecular codec, generic model framework or JSON encoder is introduced.

Separately, an already identified regular file whose open/read fails must not
fall through to hashing its path as literal molecular text. Propagate the exact
original I/O exception, preserving MemoryError/process-control semantics, stream
chunking and successful hashes. Existing literal/nonfile detection stays within
its original scope; ambiguous failed stat/typed Path behavior is not expanded.
No retry, polling or input-format inference follows.

## Prospective receiving

Freeze/run the complete two new guard modules on the old implementation first;
retain failing cases and positive controls without relabeling them. Apply the
smallest consumer-owned changes, then run both complete affected selections in
fresh normal and pm/fs processes with identical test/code inputs. The final union
is the two new modules plus whole serialization, model/prepared-view argument,
input-resource, batch/outcome and result-record modules named in registration.
Only offline public operations and explicit provider stand-ins are admitted.
Real molecular conversion/geometry/search, Viewer construction and optional engine
imports are actively blocked. Source/file errors use tiny task-owned PDBQT bytes;
one 1 MiB+1 byte case verifies the existing chunk boundary, not a benchmark.

Preserve caller policies, schema-before-payload admission, exact source/module/
helper/tool bytes, original inputs and scientific producers. Verify executed
Pytest Receptor1.2.2/JUnit agreement and complete outcomes independently without
replaying tests. The existing verified private test-only unit/reporting prefixes
are reused; no shared install or build. No new installed/public/platform/canvas/
hosted acceptance is inferred. Prior wheels retain their original byte identity.

Private task `.molsyssuite/plan-push-20261109`, owners #97/#98/#50, review
2026-11-14. Serial CPU0/nice10, native/build workers1; check available RAM before
each cell and monitor **13 GiB available reserve**, 1 GiB group RSS, 2 GiB address
space,45 CPU/60 wall seconds. Expected RSS below256MiB. Slurm binaries exist,
no allocation; original bounded inconclusive applicability observation retained.
Do not automatically restart after headroom loss or increase limits to force a
pass. Preserve all failed/interrupted attempts and unreached gates. Final shared
resource/documentation checks repeat on fresh actual committed source; use
`[skip ci]`, with #28/#21 hosted evidence explicitly missing.
