"""Seal and independently read complete installed offline software controls."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/installed-offline-union-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/installed_offline_union_2026-11-10';companion=root/'devguide/validation/data/installed_offline_union_reader_2026-11-10'
qualified=json.loads((task/'qualified-files.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_offline_union@1','owner':'uibcdf/dockingmt#47','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'qualification_base':'e7149cf7d72defa252bcb8e85ef03395838b5019','runtime_producer':'37a61e61db40f386a4ad031ecd14d578441f61ce','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored offline installed evidence; zero test/native/molecular replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 for name in qualified:paths.append((root/name,'qualified/'+name))
 paths.append((task/'baseline-junit.xml','producer/baseline-junit.xml'));paths.extend((p,'baseline/'+str(p.relative_to(task/'baseline-inputs'))) for p in sorted((task/'baseline-inputs').rglob('*')) if p.is_file())
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 import ast
 from collections import Counter
 import xml.etree.ElementTree as ET
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 artifact=d('producer/artifact.json');installed=d('producer/installation.json');review=d('producer/selection-review.json')
 assert artifact['source_commit']=='37a61e61db40f386a4ad031ecd14d578441f61ce' and artifact['version']=='0.0.0+359.g37a61e6' and artifact['wheel_sha256']=='ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d' and artifact['wheel_bytes']==157933
 refs=d('producer/prior-receiving.json');parents={}
 for folder,ref in refs['manifests'].items():
  path=root/'devguide/validation/data'/folder;assert sha(path/'manifest.json')==ref['manifest_sha256'];parents[folder]=read(path);assert len(parents[folder])==ref['members']
 previous=parents['installed_allocation_fixes_2026-11-10'];assert json.loads(previous['producer/artifact.json'])==artifact and json.loads(previous['producer/installation.json'])==installed
 assert data['producer/installed-version.py.txt']==previous['producer/installed-version.py.txt'] and d('producer/installed-direct-url.json')==json.loads(previous['producer/installed-direct-url.json'])
 assert hashlib.sha256(data['producer/installed-version.py.txt']).hexdigest()==artifact['payload_sha256']['dockingmt/_version.py']
 assert d('producer/installed-direct-url.json')['archive_info']['hashes']['sha256']==artifact['wheel_sha256']
 baseline_support=json.loads(previous['attempts/pilot-normal-01/support-sidecar.json'])['files'];assert len(baseline_support)==606
 old=root/'devguide/validation/data/ci_installed_inputs_2026-11-09';assert sha(old/'manifest.json')==review['baseline_manifest_sha256'];old_manifest=json.loads((old/'manifest.json').read_text());old_row=next(r for r in old_manifest['files'] if r['original_path']==review['baseline_junit_original_path']);old_blob=(old/old_row['path']).read_bytes();assert hashlib.sha256(old_blob).hexdigest()==old_row['sha256']
 baseline_xml=data['producer/baseline-junit.xml'];assert gzip.decompress(old_blob)==baseline_xml and hashlib.sha256(baseline_xml).hexdigest()==review['baseline_junit_sha256']
 baseline_cases={(c.get('classname'),c.get('name')) for c in ET.fromstring(baseline_xml).iter('testcase')};assert len(baseline_cases)==1267
 preserved=0
 for name,digest in review['baseline_module_hashes'].items():
  raw=data['baseline/'+name];assert hashlib.sha256(raw).hexdigest()==digest
  a={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};b={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(data['qualified/'+name]).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
  allowed={review['excluded_changed_function']} if name=='tests/test_pose_audit.py' else set();assert all(b.get(n)==v for n,v in a.items() if n not in allowed);preserved+=len(a)-len(allowed)
  assert [n for n in b if n not in a]==review['added_function_names'][name]
 assert preserved==320 and len(review['modules'])==26 and len(review['deselection_prefixes'])==3
 cohort=d('producer/expected-cohort.json');measured={};whole_nodes=None
 for label,count,excluded in [('pilot-normal-01',12,0),('pilot-normal-02',12,0),('whole-normal-01',1287,4),('whole-pm-fs-01',1287,4)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['pytest_exit_code']==0 and row['counts']=={'tests':count,'failures':0,'errors':0,'skipped':0} and row['warnings']==0
  assert row['wheel_sha256']==artifact['wheel_sha256'] and row['runtime_version']==artifact['version'] and row['qualification_source']==artifact['source_commit'] and row['cohort_unchanged'] and d(prefix+'cohort.json')==cohort
  assert not row['forbidden_operations'] and row['actual_molecular_native_viewer_calls']==0 and row['optional_engines_loaded']==[] and row['public_exception_aliases']==13
  final=row['receptor_final'];assert final['outcome']=='PASS' and final['exitstatus']==0 and final['counts']['passed']==count and final['counts']['executed']==count and final['counts']['deselected']==excluded and not final['counts']['warnings']
  collected=d(prefix+'collection.json');assert collected['selected']==row['selected_nodes'] and collected['deselected']==row['deselected_nodes'];assert len(collected['selected'])==count and len(collected['deselected'])==excluded
  xml=ET.fromstring(data[prefix+'junit.xml']);counts={k:sum(int(n.get(k,'0')) for n in xml.iter('testsuite')) for k in ['tests','failures','errors','skipped']};assert counts==row['counts']
  support=d(prefix+'support-sidecar.json');assert support['files']==baseline_support and support['executed_tests']==count and support['imports_retired'] and support['resources_retired']
  for key in ['default_form','default_parser','standard_units']:assert row['caller_policy_before'][key]==row['caller_policy_after'][key]
  for origin_key in ['installed_origins_before','installed_origins_after']:
   origins=row[origin_key];assert origins['state']=='verified-loaded-imports' and origins['roots']==['dockingmt','molsysviewer_dockingmt']
  if label.startswith('pilot-'):
   assert row['positive_roundtrip'] and len(row['refusals'])==4 and all(r['refused'] for r in row['refusals'])
   witness=next(r['reason'] for r in row['refusals'] if r['mode']=='source_addon');assert ('dockingmt._version' if label.endswith('01') else 'molsysviewer_dockingmt') in witness
   assert not row['installed_origins_before']['loaded']
  else:
   assert not row['positive_roundtrip'] and not row['refusals'] and collected['module_counts']==review['expected_module_counts']
   assert all(any(n==p or n.startswith(p+'[') for p in review['deselection_prefixes']) for n in collected['deselected'])
   origins=row['installed_origins_at_admission'];assert {'dockingmt','molsysviewer_dockingmt'}<=set(origins['loaded'])
   assert all(Path(row['runtime_paths_at_admission'][n]).is_relative_to(installed['site']) for n in ['dockingmt','molsysviewer_dockingmt'])
   assert {'dockingmt','molsysviewer_dockingmt'}<=set(row['installed_origins_after']['loaded'])
   current_cases={(c.get('classname'),c.get('name')) for c in xml.iter('testcase')};assert len(current_cases)==1287 and baseline_cases<=current_cases
   added=current_cases-baseline_cases;assert Counter(name.split('[')[0] for cls,name in added)=={'test_scoring_geometry_preserves_resource_errors_and_cleans_staging':16,'test_os_allocation_failure_stops_without_consuming_next_item':2,'test_ordinary_os_failure_remains_recordable':2}
   if whole_nodes is None:whole_nodes=collected
   else:assert whole_nodes==collected
  measured[label]={'cases':count,'deselected':excluded,'actual_native_molecular_viewer_calls':0}
 a='attempts/whole-normal-01/';b='attempts/whole-pm-fs-01/'
 for name in ['worker.py','whole.json','artifact.json','installation.json','qualification-inputs.json','selection-review.json','expected-cohort.json']:assert data[a+'frozen-'+name]==data[b+'frozen-'+name]
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   x=json.loads(raw);assert x['outcome']=='PASS' and x['resource_interruption'] is None and x['group_terminal'] and not x['remaining_live_owned_pids'] and x['minimum_available_bytes']>13*1024**3
 inputs=d('producer/qualification-inputs.json')
 for name in qualified:
  raw=data['qualified/'+name];assert raw==(root/name).read_bytes()
  if name=='devtools/conda-build/resources.toml':assert raw==data[a+'frozen-resources.toml']==data[b+'frozen-resources.toml']
  else:assert hashlib.sha256(raw).hexdigest()==(artifact['payload_sha256'][name] if name in artifact['source_sha256'] else inputs[name])
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),populations=measured,qualified_sources=len(qualified),preserved_original_functions_or_classes=preserved,support_records=606,runtime_version=artifact['version'],new_installed_offline_union_received=True,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json']);path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete and row['counts']==counts and row['receptor_final']==events.final.data
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':row['pytest_exit_code'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==4 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1600])
