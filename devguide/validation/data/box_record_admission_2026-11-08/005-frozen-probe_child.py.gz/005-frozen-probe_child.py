"""Observe saved-box scalar coercion, not molecular geometry construction."""
from copy import deepcopy
import json
import os
from pathlib import Path
import warnings

import dockingmt as dmt
import pyunitwizard as puw

attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
rows = []
for field in ['center', 'lengths']:
    for label, value in [('boolean', [True, 1, 1]), ('text', ['3', 1, 1]), ('complex', [3 + 2j, 1, 1]), ('valid', [3, 1, 1])]:
        record = {'center': {'value': [0, 0, 0], 'unit': 'nm'}, 'lengths': {'value': [2, 2, 2], 'unit': 'nm'}}
        record[field]['value'] = value
        before = deepcopy(record)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                result = dmt.BoxRegion.from_dict(record)
                observed = {'accepted': True, 'value': puw.get_value(getattr(result, field), to_unit='nm', value_type=list)}
            except Exception as error:
                observed = {'accepted': False, 'error': type(error).__name__, 'code': getattr(error, 'code', None), 'field': getattr(error, 'extra', {}).get('arg_name')}
        rows.append({'field': field, 'case': label, 'reader': observed, 'warnings': [type(item.message).__name__ for item in caught], 'caller_record_preserved': record == before})
assert all(row['caller_record_preserved'] for row in rows)
assert all(row['reader']['accepted'] for row in rows if row['case'] in ['boolean', 'text', 'valid'])
(attempt / 'observations.json').write_text(json.dumps({'rows': rows, 'molecular_operations': 0, 'native_builds': 0, 'scope': 'Pure numeric box-record diagnosis only'}, indent=2) + '\n')
print(json.dumps({'coercion_confirmed': True, 'rows': len(rows)}))
