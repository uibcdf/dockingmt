"""Seal completed routine dependency receiving, including the failed harness."""
import gzip
import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
objects = root / '.molsyssuite/provider-fix-artifacts-20261108/source-objects.git'
source_contexts = {}
env = os.environ.copy()
env['GIT_NO_LAZY_FETCH'] = '1'
for name, revision in [('rust_wheels', 'fbb09782c3f66735762bd4a507314db692927f97'), ('public_argdigest', 'bd40d70591c2ada8d2fa2e7e2ce65d7420e60b33'), ('corrections642644646', 'ad67e0e915ba23d90cb9d6331c063c342852d67a')]:
    command = ['git', '--git-dir=' + str(objects), 'rev-parse', revision + ':rust']
    digest = subprocess.check_output(command, env=env, text=True, timeout=5).strip()
    source_contexts[name] = {'source': revision, 'command': command, 'rust_tree': digest}
assert source_contexts['rust_wheels']['rust_tree'] == source_contexts['public_argdigest']['rust_tree'] == '32cfb07b9c26ae9ad3ed379c1b76fab85669cf67'
assert source_contexts['corrections642644646']['rust_tree'] == 'fb25b2eac60b6e706c712e788119b3dad94329fe'
(task / 'artifact-source-review.json').write_text(json.dumps({'observations': source_contexts, 'scope': 'Read-only exact Git input triage; native binary not downloaded/qualified and645 source compatibility unassessed'}, indent=2) + '\n')
output = root / 'devguide/validation/data/box_record_admission_2026-11-08'
output.mkdir(exist_ok=False)
sources = [task / name for name in ['plan.json', 'owner-evidence.json', 'artifact-triage.json', 'artifact-source-review.json']]
for label in ['probe-01', 'red-01', 'green-01']:
    sources.extend(path for path in sorted((task / label).iterdir()) if path.is_file())
sources.append(Path(__file__))
rows = []
for index, path in enumerate(sources):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    relative = f'{index:03d}-{path.name}.gz'
    (output / relative).write_bytes(stored)
    rows.append({'original_path': str(path.relative_to(task)), 'path': relative, 'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(), 'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'schema': 'dockingmt.box_record_admission_fix@1', 'owner': 'uibcdf/dockingmt#85', 'source_commit': '8e6a8fd58165f5fa6adfd98787b146da8ef64318', 'scope': 'Saved-box vector defect diagnosis, original red and complete green source guards under two caller policies plus bounded existing-artifact triage; no molecular/backend work, build, installation or public/installed qualification', 'files': rows}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {'stage': 'seal', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members': len(rows), 'manifest_sha256': hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest(), 'stored_bytes': sum(row['bytes'] for row in rows), 'molecular_operations': 0}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
