"""Execute one bounded record-only diagnostic with the routine interpreter."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
plan = json.loads((task / 'plan.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == plan['source_commit']
assert hashlib.sha256((root / 'dockingmt/core/search_domain.py').read_bytes()).hexdigest() == plan['original_runtime_sha256']
shutil.copyfile(task / 'probe_child.py', attempt / 'frozen-probe_child.py')
subprocess.run([sys.executable, '-B', '-I', str(attempt / 'frozen-probe_child.py')], cwd=root, check=True)
receipt = {'stage': 'probe', 'source_commit': plan['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'diagnosis_complete': True, 'rows': 8, 'molecular_operations': 0, 'scope': 'Confirms saved-box Boolean/text coercion; not corrected-reader acceptance'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
