"""Actual installed one-pose binding receiving; no detection/preparation/native work."""
import ast
from copy import deepcopy
from contextlib import ExitStack
import subprocess
from functools import wraps
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import traceback

root = Path(os.environ['DMT_INSTALLED_ROOT'])
task = Path(os.environ['DMT_INSTALLED_TASK'])
attempt = Path(os.environ['DMT_INSTALLED_ATTEMPT'])
profile = os.environ['DMT_INSTALLED_PROFILE']
case = os.environ['DMT_VIEW_CASE']
registration = json.loads((attempt / 'registration.json').read_text())
composition=json.loads((attempt/'frozen-composition.json').read_text())
candidate={'source_commit':registration['source_commit'],'version':composition['consumer_build_stamp'],'distribution_version':composition['packages']['dockingmt']['version']}
providers=Path(composition['packages']['molsysmt']['path']).parent
routine=Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')
sdk=root/'.molsyssuite/publication-sdk'
assert sys.flags.isolated and not sys.flags.no_site
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
output = attempt / 'output'
output.mkdir(exist_ok=False)
completed = []
forbidden_attempts = []
refusals = []
origins = []
counts = {}
budgets = {'binding_calls':1,'public_views':3,'native_snapshots':6,'typed_exports':32,'analysis_queries':2,'analysis_pages':2,'derive_copy':1,'invalidation':1,'explicit_load':1,'foreign_visual':1,'python_navigation':4,'context_navigation':4,'panel_navigation':4}
counts.update({name:0 for name in budgets})
provider_caps = {'convert':128,'copy':40,'get':640,'has_attribute':256,'select':64,'extract':16,'merge':4,'append_structures':4,'set':16,'h5_read':2,'h5_write':0,'analysis_copy':128,'analysis_remap':16,'analysis_invalidate':1,'typed_exports':128,'center':64}
provider_counts = {name:0 for name in provider_caps}
viewer_caps = {'loads':4,'new_views':2,'metadata':128,'visual_add':6,'visual_get':512,'visual_delete':16,'visual_info':16,'analysis_query':128,'analysis_get':256,'navigation':32,'view_close':2}
viewer_counts = {name:0 for name in viewer_caps}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, allow_nan=False, separators=(',', ':'))
        stream.write('\n')

def journal(stage, **values):
    with (attempt / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps({'stage': stage, **values, 'receiver_counts': dict(counts), 'provider_counts': dict(provider_counts)}, allow_nan=False) + '\n')

def direct(name, function, *args, **kwargs):
    assert counts[name] < budgets[name], ('receiver cap', name)
    counts[name] += 1
    journal('called', operation=name)
    value = function(*args, **kwargs)
    journal('returned', operation=name)
    return value

def payload_hashes(directory):
    return {str(p.relative_to(directory)): sha(p) for p in directory.rglob('*') if p.is_file()}

def custody(label):
    current = {}
    for package in composition['packages'].values():
        for path in Path(package['path']).rglob('*.py'):
            current[str(path)] = sha(path)
    assert current == composition['python_sources_sha256'], 'Python source inventory drift'
    for directory, expected in composition['source_revisions'].items():
        assert subprocess.check_output(['git', '-C', directory, 'rev-parse', 'HEAD'], text=True).strip() == expected
    assert sha(composition['native_path']) == composition['provider_native_sha256']
    modules = []
    for name, module in tuple(sys.modules.items()):
        families = [p for p in composition['packages'] if name == p or name.startswith(p + '.')]
        if not families:
            continue
        expected = Path(composition['packages'][max(families, key=len)]['path']).resolve()
        locations = list(getattr(module, '__path__', ()))
        if getattr(module, '__file__', None):
            locations.append(module.__file__)
        if not locations:
            assert name == 'pyunitwizard.main'
            initializer = sys.modules['pyunitwizard']
            for function in (module.__getattr__, module.__dir__):
                assert function.__globals__ is vars(initializer)
                assert Path(function.__code__.co_filename).resolve() == expected / '__init__.py'
            locations = [str(expected / '__init__.py')]
        rows = []
        for value in sorted(set(locations)):
            path = Path(value).resolve()
            assert path.is_relative_to(expected), (name, str(path), str(expected))
            rows.append({'path': str(path), 'sha256': sha(path) if path.is_file() else None})
        modules.append({'module': name, 'locations': rows})
    natives = set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        fields = line.split(None, 5)
        if len(fields) == 6 and fields[5].startswith('/') and ('.so' in fields[5]) and Path(fields[5]).is_file():
            natives.add(Path(fields[5]).resolve())
    origins.append({'label': label, 'route': 'editable-development', 'runtime_origins': modules, 'native_libraries': [{'path': str(p), 'sha256': sha(p)} for p in sorted(natives)]})
    for entry in entries.values():
        assert sha(Path(entry['path']))==entry['decoded_sha256']
    for relative,digest in registration['sdk_source_sha256'].items():
        assert sha(sdk/relative)==digest

def observe_aliases(owner, name, label):
    original = getattr(owner, name)
    @wraps(original)
    def wrapped(*args, **kwargs):
        assert provider_counts[label] < provider_caps[label], ('provider cap', label)
        provider_counts[label] += 1
        if label == 'convert' and kwargs.get('to_form') in ('molsysmt.TopologyDict', 'molsysmt.ChemicalStatesDict', 'molsysmt.InteractionsDict'):
            assert provider_counts['typed_exports'] < provider_caps['typed_exports']
            provider_counts['typed_exports'] += 1
        return original(*args, **kwargs)
    for module_name, module in tuple(sys.modules.items()):
        if not (module_name == 'molsysmt' or module_name.startswith('molsysmt.')):
            continue
        for attribute, value in tuple(vars(module).items()):
            if value is original:
                setattr(module, attribute, wrapped)
    setattr(owner, name, wrapped)

def prohibit_aliases(owner, name):
    original = getattr(owner, name)
    @wraps(original)
    def denied(*args, **kwargs):
        forbidden_attempts.append(name)
        journal('forbidden', operation=name)
        raise AssertionError('Forbidden installed binding operation: ' + name)
    for module_name, module in tuple(sys.modules.items()):
        if not (module_name == 'dockingmt' or module_name.startswith('dockingmt.') or module_name == 'molsysmt' or module_name.startswith('molsysmt.')):
            continue
        for attribute, value in tuple(vars(module).items()):
            if value is original:
                setattr(module, attribute, denied)
    setattr(owner, name, denied)

def expect(label, function, *args, expected=None, **kwargs):
    journal('refusal-started', label=label)
    try:
        function(*args, **kwargs)
    except expected as exc:
        if expected is ArgumentError:
            assert exc.code == 'DMT-E002'
        refusals.append({'label': label, 'type': type(exc).__name__, 'module': type(exc).__module__, 'code': getattr(exc, 'code', None), 'reason': str(exc)})
        journal('refused', label=label)
    else:
        raise AssertionError('Expected refusal was accepted: ' + label)

def assert_native_roundtrip(actual, expected):
    actual_fields, expected_fields = dict(actual), dict(expected)
    for field in ('coordinates', 'box', 'time'):
        observed = actual_fields.pop(field)
        original = expected_fields.pop(field)
        if original is None or observed is None:
            assert observed is original is None, field
            continue
        assert observed['unit'] == original['unit'], field
        a, b = dict(observed['value']), dict(original['value'])
        values_a, values_b = a.pop('array'), b.pop('array')
        assert a == b, (field, 'physical shape/dtype')
        np.testing.assert_allclose(values_a, values_b, rtol=0, atol=1e-12)
    assert actual_fields == expected_fields

class NoVina:
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'vina' or fullname.startswith('vina.'):
            forbidden_attempts.append('vina import')
            raise AssertionError('Vina import is forbidden')

sys.meta_path.insert(0, NoVina())
def audit(event,args):
    if event=='subprocess.Popen':
        executable,argv=os.fsdecode(args[0]),args[1]
        if isinstance(argv,list) and len(argv)==5 and argv[:2]==['git','-C'] and argv[2] in composition['source_revisions'] and argv[3:]==['rev-parse','HEAD']:
            return
        if isinstance(argv,list) and argv==['uname','-p'] and __import__('shutil').which(executable)=='/usr/bin/uname':
            return
    if event in ['subprocess.Popen','socket.connect','socket.bind']:
        forbidden_attempts.append(event)
        raise AssertionError('Network/server/non-custody subprocess forbidden: '+event)
sys.addaudithook(audit)

metadata_before = {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')}
inputs_path = attempt / 'inputs.json'
assert sha(inputs_path) == registration['inputs_sha256']
inputs = json.loads(inputs_path.read_text())
assert inputs['profile'] == profile == registration['profile']
entries = inputs['inputs']
import numpy as np
import pyunitwizard as puw

def authority():
    return {key: puw.configure.report()[key] for key in ('default_form', 'default_parser', 'standard_units', 'provenance')}


previous_policy=authority()
units=['pm','fs','kelvin','mole','dalton','coulomb','kJ/mol','kJ/(mol*pm)','kJ/(mol*pm**2)','radians'] if profile=='pm_fs' else ['nm','ps','kelvin','mole','dalton','elementary_charge','kJ/mol','kJ/(mol*nm)','kJ/(mol*nm**2)','radians']
context=ExitStack();context.__enter__();context.enter_context(puw.context(standard_units=units));caller_policy=authority()

def observe_view(owner,name,label):
    original=getattr(owner,name)
    @wraps(original)
    def wrapped(*args,**kwargs):
        assert viewer_counts[label]<viewer_caps[label],('Viewer cap',label)
        viewer_counts[label]+=1
        return original(*args,**kwargs)
    setattr(owner,name,wrapped)

def initialize():
    global dmt,msm,msv,ArgumentError,ViewerStateError,diagnostic,payload,native_state,provider_policy_before
    import dockingmt as dmt
    import molsysmt as msm
    import molsysviewer as msv
    from dockingmt._private.smonitor import ArgumentError,ViewerStateError
    assert dmt.__version__==candidate['version'] and authority()==caller_policy
    save(attempt/'build-identity.json',{'package_local_build_stamp':dmt.__version__,'distribution_metadata_version':candidate['distribution_version'],'actual_source_commit':candidate['source_commit'],'stamp_source_sha256':composition['python_sources_sha256'][str(root/'dockingmt/_version.py')],'route':'editable; build labels are not a live source fingerprint'})
    provider_policy_before={name:getattr(msm.configure,name) for name in ['parallel_mode','num_threads']}
    context.enter_context(msm.configure.context(parallel_mode=False,num_threads=1))
    custody('before-receiving')
    notebook_path=root/'devguide/validation/e4_saved_carrier_receiving.ipynb'
    data=notebook_path.read_bytes();assert hashlib.sha256(data).hexdigest()=='a6a8561e4aa7d9d2b5967fd43b9c2fdf8793ba13bbbb3c3a5d524e3d53e7d113'
    (attempt/'frozen-diagnostic-helpers.ipynb').write_bytes(data)
    cell=next(c for c in json.loads(data)['cells'] if c.get('id')=='e4-carrier-public-tools')
    names={'diagnostic','payload','native_state'}
    functions=[n for n in ast.parse(''.join(cell['source'])).body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert {n.name for n in functions}==names
    exec(compile(ast.Module(body=functions,type_ignores=[]),'frozen-old-native-helpers','exec'),globals())
    for owner,name in [(dmt,'dock'),(dmt,'dock_many'),(dmt,'score'),(dmt,'prepare_ligand'),(dmt,'prepare_receptor'),(dmt,'evaluate_redocking'),(dmt,'compare_scores'),(msm.build,'add_missing_hydrogens'),(msm.build,'assign_partial_charges'),(msm.build,'assign_autodock_atom_types'),(msm.interactions.hbonds,'get_hbonds'),(msm.interactions.hydrophobic,'get_hydrophobic_interactions')]:prohibit_aliases(owner,name)
    for name in ['get_rmsd','get_symmetry_corrected_rmsd','get_pairwise_rmsd','get_distance_clusters','get_distances','get_dihedral_angles','align','superpose','get_superposition']:
        if hasattr(msm.structure,name):prohibit_aliases(msm.structure,name)
    for name in ['convert','copy','get','has_attribute','select','extract','merge','append_structures','set']:observe_aliases(msm,name,name)
    observe_aliases(msm.h5msm,'read','h5_read');observe_aliases(msm.h5msm,'write','h5_write')
    for name,label in [('copy','analysis_copy'),('remap','analysis_remap'),('invalidate_structures','analysis_invalidate')]:observe_aliases(msm.Interactions,name,label)
    observe_aliases(msm.structure,'get_center','center')
    from molsysviewer.interactions import InteractionsManager as ScientificInteractionsManager,InteractionSet
    from molsysviewer.player import PlayerManager
    for owner,name,label in [(msv.MolSysView,'__init__','new_views'),(msv.MolSysView,'load','loads'),(msv.MolSysView,'close','view_close'),(PlayerManager,'go_to_structure','navigation'),(ScientificInteractionsManager,'analyses','metadata'),(ScientificInteractionsManager,'add','visual_add'),(ScientificInteractionsManager,'get','visual_get'),(ScientificInteractionsManager,'query','analysis_query'),(ScientificInteractionsManager,'get_analysis','analysis_get'),(ScientificInteractionsManager,'info','visual_info'),(InteractionSet,'delete','visual_delete')]:observe_view(owner,name,label)

def finish():
    assert forbidden_attempts==[] and authority()==caller_policy
    custody('after-receiving')
    after={p.name:sha(p) for p in (routine/'conda-meta').glob('*.json')};assert after==metadata_before
    save(attempt/'runtime-origins.json',origins)
    save(attempt/'routine-metadata-before.json',metadata_before);save(attempt/'routine-metadata-after.json',after)
