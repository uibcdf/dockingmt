"""Independent standard-library verification of saved records, without replay."""
import copy
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

source='204f5f6c342368e1e2530bd663594b62018cb599'
def sha(blob):return hashlib.sha256(blob).hexdigest()
def same(a,b):return json.dumps(a,sort_keys=True,allow_nan=False)==json.dumps(b,sort_keys=True,allow_nan=False)
def numbers(a,b,tol):
 if isinstance(a,list):
  assert isinstance(b,list) and len(a)==len(b)
  for aa,bb in zip(a,b):numbers(aa,bb,tol)
 else:
  assert type(a) in (int,float) and type(b) in (int,float)
  assert math.isfinite(a) and math.isfinite(b) and abs(a-b)<=tol
def native(a,b):
 aa,bb=dict(a),dict(b)
 for name in ['coordinates','box','time']:
  x,y=aa.pop(name),bb.pop(name)
  if x is None or y is None:assert x is y is None;continue
  assert x['unit']==y['unit']=='angstrom'
  xx,yy=dict(x['value']),dict(y['value']);xa,ya=xx.pop('array'),yy.pop('array')
  assert same(xx,yy);numbers(xa,ya,1e-12)
 assert same(aa,bb)
def analysis(a,b):
 aa,bb=dict(a),dict(b);ma,mb=aa.pop('measurements'),bb.pop('measurements')
 assert same(aa,bb) and set(ma)==set(mb)
 for name in ma:
  x,y=dict(ma[name]),dict(mb[name]);xa,ya=x.pop('array'),y.pop('array')
  assert same(x,y) and a['measure_units'][name] in ('nm','radians')
  numbers(xa,ya,1e-13 if a['measure_units'][name]=='nm' else 1e-12)

def verify_records(records):
 root=Path(os.environ['DMT_RECORD_ROOT'])
 def raw(name):return records[name]
 def record(name):return json.loads(raw(name))
 manifest=record('producer/archive-context.json')
 composition=record('producer/composition.json')
 tool=record('producer/reporting-tools-receipt.json')
 assert tool['version']=='1.2.2' and len(tool['files_sha256'])==15 and tool['routine_metadata_unchanged']
 assert tool['archive_sha256']=='c0b075286f45e8fce5ab5852947611bfba82b7d509115fc5dadf1a9572b9dd74'
 assert sha(raw('producer/reporting-tools-receipt.json'))=='6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
 assert sha(raw('producer/original-view_worker.py'))=='b8eca9894ced90739497c82e0eed92e60ba9b9ed979393c5228212646772a659'
 assert sha(raw('producer/original-native_worker.py'))=='5a9f46ee1ad9a8df095365428751f6e95ccca3f33b2320d6c92a88c4a4537d7f'
 original,received=raw('producer/original-view_worker.py'),raw('producer/view_worker.py')
 assert original[original.index(b'    initialize()'):original.index(b'    receipt=')]==received[received.index(b'    initialize()'):received.index(b'    receipt=')]
 original,received=raw('producer/original-native_worker.py'),raw('producer/native_worker.py')
 assert original[original.index(b'    test=attempt/'):original.index(b'    finish()')]==received[received.index(b'    test=attempt/'):received.index(b'    finish()')]
 assert composition['source_revisions'][str(root)]==source
 assert composition['source_revisions'][str(root.parent/'molsysmt')]=='fab8cbccf570a60205a3863aad19dd4b7cfb8d3a'
 assert composition['source_revisions'][str(root.parent/'molsysviewer')]=='1187fc187247aa2d20d01791856a541d50562bcb'
 assert composition['provider_native_sha256']=='5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
 route=record('producer/route-change.json')
 assert route['receiving_03_common_sha256']==sha(raw('producer/common.py'))
 for name in ['view_worker.py','native_worker.py']:assert route[name]==sha(raw('producer/'+name))
 old=root/'devguide/validation/data/e4_saved_carrier_receiving_2026-11-07'
 assert sha((old/'manifest.json').read_bytes())=='73c8114368f0d7011d2e27d229662bf29be1f99bea27c0e0a24065f077e04b4d'
 oldrows={r['path']:r for r in json.loads((old/'manifest.json').read_text())['files']}
 def original_analysis(profile,case):
  name='attempts/'+('normal-02' if profile=='normal' else 'pm-fs-01')+'/output/'+('translated_geometry_control' if case=='empty' else 'retained_pose')+'/original_full_analyses.json.gz'
  blob=(old/name).read_bytes();assert sha(blob)==oldrows[name]['sha256']
  decoded=gzip.decompress(blob);assert sha(decoded)==oldrows[name]['decoded_sha256']
  return json.loads(decoded)
 controls={};binding_counts={};native_counts={}
 for profile,cases in manifest['profiles'].items():
  assert set(cases)=={'retained','reordered','empty','native_regression'}
  binding_counts[profile]=0;native_counts[profile]=0
  for case,name in cases.items():
   prefix='attempts/'+name+'/'
   resource=record(prefix+'resource-outcome.json');worker=record(prefix+'worker-receipt.json');receipt=record(prefix+'output/receipt.json');reg=record(prefix+'registration.json')
   assert resource['outcome']==worker['outcome']==receipt['outcome']=='PASS'
   assert resource['group_terminal'] and resource['remaining_live_owned_pids']==[] and resource['resource_interruption'] is None
   assert resource['exit_code']==0 and resource['sampled_peak_group_rss_bytes']<1024**3
   assert resource['minimum_available_bytes']>=13*1024**3 and resource['elapsed_seconds']<=60
   assert worker['profile']==reg['profile']==profile and worker['case']==reg['case']==case
   assert worker['source_commit']==source and worker['route']=='editable-development' and worker['provider_commit']=='fab8cbccf570a60205a3863aad19dd4b7cfb8d3a'
   assert worker['qualification_complete'] and worker['caller_policy_restored'] and worker['caller_policy_preserved'] and worker['forbidden_attempts']==[]
   assert same({k:v for k,v in worker.items() if k!='caller_policy_restored'},receipt)
   assert worker['caller_policy']['standard_units'][:2]==(['nm','ps'] if profile=='normal' else ['pm','fs'])
   for field in ['canvas_received','public_delivery_received','whole_e4_received']:assert worker[field] is False
   for family in ['provider','viewer']+([] if case=='native_regression' else ['receiver']):
    counts,caps=worker[family+'_counts'],worker[family+'_caps']
    assert set(counts)==set(caps) and all(type(v)is int and 0<=v<=caps[k] for k,v in counts.items())
   assert same(record(prefix+'routine-metadata-before.json'),record(prefix+'routine-metadata-after.json'))
   assert same(record(prefix+'frozen-composition.json'),composition)
   for name,row in reg['frozen'].items():
    assert sha(raw(prefix+row['path']))==row['sha256']
   assert sha(raw(prefix+'inputs.json'))==reg['inputs_sha256']
   assert sha(raw(prefix+'frozen-composition.json'))==reg['composition_sha256']
   policy=reg['policy']
   assert policy==resource['policy'] and policy['cpu']==0 and policy['nice']==10 and policy['workers']==1
   assert policy['available_reserve_bytes']==13*1024**3 and policy['group_rss_limit_bytes']==1024**3
   identity=record(prefix+'build-identity.json')
   assert identity['actual_source_commit']==source and identity['package_local_build_stamp']==composition['consumer_build_stamp']
   assert identity['distribution_metadata_version']==composition['packages']['dockingmt']['version']
   origins=record(prefix+'runtime-origins.json')
   assert [row['label'] for row in origins]==['before-receiving','after-receiving']
   for snapshot in origins:
    assert snapshot['route']=='editable-development'
    for module in snapshot['runtime_origins']:
     family=max((p for p in composition['packages'] if module['module']==p or module['module'].startswith(p+'.')),key=len)
     directory=Path(composition['packages'][family]['path'])
     for location in module['locations']:
      path=Path(location['path']);assert path.is_relative_to(directory)
      if location['sha256'] is not None:
       if path.suffix=='.py':assert composition['python_sources_sha256'][str(path)]==location['sha256']
       elif path.name=='_rust.abi3.so':assert location['sha256']==composition['provider_native_sha256']
    native_origin=next(row for row in snapshot['native_libraries'] if row['path']==composition['native_path'])
    assert native_origin['sha256']==composition['provider_native_sha256']
   descriptors=record(prefix+'inputs.json')['inputs']
   for row in descriptors.values():
    relative=Path(row['repository_path']);assert not relative.is_absolute() and '..' not in relative.parts
    blob=(root/relative).read_bytes();assert len(blob)==row['stored_bytes'] and sha(blob)==row['stored_sha256']
    decoded=gzip.decompress(blob);assert len(decoded)==row['decoded_bytes'] and sha(decoded)==row['decoded_sha256']
   if case=='native_regression':
    assert worker['native_cases']==worker['native_passed']==1 and worker['pytest_exit_code']==0
    assert worker['pytest_receptor_version']=='1.2.2' and worker['reporting_tools_receipt_sha256']==sha(raw('producer/reporting-tools-receipt.json'))
    session=record(prefix+'pytest-session.json');assert session['session_finished'] and session['exit_status']==0
    assert len(session['collected'])==len(session['reports'])==1
    assert next(iter(session['reports'].values()))=={'setup':'passed','call':'passed','teardown':'passed'}
    tree=ET.fromstring(raw(prefix+'junit.xml'));testcases=tree.findall('.//testcase')
    assert len(testcases)==1 and not any(tree.findall('.//'+k) for k in ['failure','error','skipped'])
    test=record(prefix+'output/test-source.json')
    assert test['sha256']==test['original_source_sha256']==sha(raw(prefix+'qualified-tests/test_viewer_state.py'))
    fixture=record(prefix+'output/fixture.json')
    assert fixture['provider_source_verified'] and fixture['sha256']=='92ec5f1d3e2b2e753891488c7e984631609819ab07b1b046b2c7b312bed47069'
    assert Path(fixture['path']).is_relative_to(Path(composition['packages']['molsysmt']['path']))
    origins=record(prefix+'output/reporting-origins.json');assert origins['version']=='1.2.2'
    for origin in origins['before']+origins['after']:
     relative=str(Path(origin['path']).relative_to(tool['prefix']))
     assert origin['sha256']==tool['files_sha256'][relative]
    native_counts[profile]+=1;continue
   assert worker['completed_steps']==['custody_and_inputs','actual_view_and_controls','source_nonmutation_and_cleanup','final_receipt_and_origins']
   assert worker['accepted_bindings']==worker['views_closed']==1 and worker['widgets_closed']==2
   assert worker['actual_view_route_received'] and worker['public_renders_in_same_view']==2
   assert worker['refusals']==len(worker['refusal_records'])==4
   assert {r['label'] for r in worker['refusal_records']}=={'unavailable_python_position','unavailable_context_position','unavailable_panel_position','binding_conflicting_result'}
   binding_counts[profile]+=1
   output=prefix+'output/'
   original=json.loads(gzip.decompress((root/descriptors['result']['repository_path']).read_bytes()))
   assert len(original['poses'])==worker['original_population']==5
   assert same(record(output+'original-result.json'),original)
   result=record(output+'result.json');assert len(result['poses'])==worker['result_population']
   bound=worker['bound_position'];association=record(output+'association.json')
   assert association['pose_index']==bound and association['pose_id']==result['poses'][bound]['pose_id']
   assert association['pose_atom_indices']==list(range(3220,3233)) and association['structure_index']==0
   assert association['carrier_n_atoms']==3238 and association['carrier_n_structures']==1
   assert association['original_pose_count']==len(result['poses']) and association['analysis_evaluated']==worker['analysis_coverage']
   assert association['chemical_equivalence_validated'] is False and association['analysis_producer_authenticated'] is False
   if case=='retained':assert same(result,original) and bound==0 and worker['derivation'] is None
   elif case=='reordered':
    expected=copy.deepcopy(original);expected['poses']=[original['poses'][i] for i in [1,2,3,0,4]]
    expected['provenance']['receiving_order_control']=worker['derivation']
    assert same(result,expected) and bound==3
   else:
    assert len(result['poses'])==1 and bound==0
    pose=result['poses'][0];assert pose['pose_id']=='control:translated-saved-carrier' and pose['scores']=={} and pose['rank'] is None
    assert pose['pose_id'] not in [p['pose_id'] for p in original['poses']]
    derivation=pose['metadata']['control_derivation']
    assert derivation['source']==descriptors['translated_geometry_control']['decoded_sha256'] and derivation['original_pose'] is False
    assert derivation['source_producer']==manifest['original_scientific_producer'] and derivation['original_pose_id']==original['poses'][0]['pose_id']
   before=record(output+'original-native-before.json');assert same(before,record(output+'original-native-after.json'))
   carrier=record(output+'carrier-native-before.json');assert same(carrier,record(output+'carrier-native-after.json'))
   native(record(output+'loaded-native.json'),carrier)
   original_payload=record(output+'original-analyses-before.json')
   assert same(original_payload,record(output+'original-analyses-after.json')) and same(original_payload,original_analysis(profile,case))
   payload=record(output+'carrier-analyses-before.json');assert same(payload,record(output+'carrier-analyses-after.json'))
   expected=copy.deepcopy(original_payload)
   if case=='empty':
    expected['hbonds']['evaluated_structure_indices']['array']=[];expected['hbonds']['evaluated_structure_indices']['shape']=[0]
    expected['hbonds']['execution_records']=[]
   assert same(payload,expected)
   initial=record(output+'initial-widget-state.json');replaced=record(output+'replaced-widget-state.json')
   assert initial['n_poses']==len(result['poses']) and initial['active_index']==bound and initial['active_rank']==bound+1
   for i,row in enumerate(initial['poses']):
    pose=result['poses'][i]
    assert row['index']==i and row['position']==i+1 and row['pose_id']==pose['pose_id'] and row['rank']==pose['rank']
    assert row['geometry_available']==(i==bound) and {s['name']:s['value'] for s in row['scores']}==pose['scores']
    assert all(s['unit'] and s['definition'] for s in row['scores'])
   assert initial['interaction_geometry_available'] and not replaced['interaction_geometry_available']
   assert all(not row['geometry_available'] for row in replaced['poses']) and replaced['interaction_analyses']==[]
   expected_counts={'hbonds':0,'hydrophobic':0} if case=='empty' else {'hbonds':3,'hydrophobic':2}
   expected_coverage={'hbonds':case!='empty','hydrophobic':True}
   assert worker['observation_counts']==expected_counts and worker['analysis_coverage']==expected_coverage
   visuals=record(output+'visual-info.json');assert len(visuals)==2
   for visual in visuals:
    family=visual['analysis_name']
    assert visual['frame']==0 and visual['filter']['structure_indices']==[0] and not visual['broken']
    assert visual['n_observations']==visual['n_supported']==visual['n_segments']==expected_counts[family] and visual['n_skipped']==0
    assert visual['status']==('evaluated' if expected_coverage[family] else 'unevaluated') and visual['style']['radius_unit']=='nm'
   for family in expected_counts:
    meta=next(row for row in initial['interaction_analyses'] if row['name']==family)
    assert meta['available'] and meta['evaluated']==expected_coverage[family] and meta['n_occurrences']==expected_counts[family]
    page=record(output+family+'-page.json')
    assert page['evaluated_structure_indices']['array']==([0] if expected_coverage[family] else [])
    assert len(page['occurrence_indices']['array'])==expected_counts[family]
   export=record(output+'export.json');summary=record(output+'summary.json')
   assert same(export['result'],result) and same(export['interaction_association'],association) and same(summary['interaction_association'],association)
   assert export['selected_pose']['index']==summary['active_pose_index']==bound
   controls[profile,case]={'result':result,'payload':payload,'carrier':carrier,'association':association}
 for case in ['retained','reordered','empty']:
  a,b=controls['normal',case],controls['pm_fs',case]
  assert same(a['association'],b['association'])
  if case!='empty':assert same(a['result'],b['result'])
  else:
   pa,pb=copy.deepcopy(a['result']['poses'][0]),copy.deepcopy(b['result']['poses'][0])
   ca,cb=pa.pop('coordinates'),pb.pop('coordinates');assert ca['unit']==cb['unit']=='nanometer';numbers(ca['value'],cb['value'],1e-13)
   pa['metadata']['control_derivation'].pop('source');pb['metadata']['control_derivation'].pop('source');assert same(pa,pb)
  native(a['carrier'],b['carrier'])
  for family in ['hbonds','hydrophobic']:analysis(a['payload'][family],b['payload'][family])
 for name in manifest['failed_setup_attempts']:
  prefix='attempts/'+name+'/';resource=record(prefix+'resource-outcome.json');failure=record(prefix+'failure.json')
  assert resource['outcome']=='FAIL' and resource['group_terminal'] and resource['resource_interruption'] is None
  assert not resource['remaining_live_owned_pids'] and not any(failure['provider_counts'].values()) and not any(failure['viewer_counts'].values())
  assert not any(failure['receiver_counts'].values()) and failure['completed_steps']==[]
  assert failure['exception_type']==('AssertionError' if name.startswith('receiving-01') else 'AttributeError')
 scientific=[n for n in sys.modules if any(n==p or n.startswith(p+'.') for p in ['numpy','pyunitwizard','molsysmt','molsysviewer','dockingmt','vina','rdkit'])]
 assert scientific==[]
 receipt={'stage':'reader','source_commit':source,'outcome':'PASS','qualification_complete':True,'accepted_bindings_per_profile':binding_counts,'native_regressions_per_profile':native_counts,'scientific_imports':scientific,'molecular_operations':0,'whole_original_result_preserved':True,'saved_typed_analyses_agree':True,'native_loading_atol_angstrom':1e-12,'cross_profile_measurement_atol':{'nm':1e-13,'radians':1e-12},'relative_tolerance':0,'canvas_received':False,'public_delivery_received':False,'whole_e4_received':False,'scope':'Standard-library identity, saved records and numeric witnesses only; no molecular restoration/calculation, producer authentication, browser/canvas or whole-workflow acceptance'}
 return receipt
