import os
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

_attempt=Path(os.environ['DMT_INSTALLED_ATTEMPT']);_registration=json.loads((_attempt/'registration.json').read_text());_common=_attempt/'frozen-common.py'
assert hashlib.sha256(_common.read_bytes()).hexdigest()==_registration['frozen']['common.py']['sha256']
exec(compile(_common.read_bytes(),str(_common),'exec'),globals())
_tool_receipt=task/'reporting-tools-receipt.json'
assert sha(_tool_receipt)=='6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
(attempt/'frozen-reporting-tools-receipt.json').write_bytes(_tool_receipt.read_bytes())
reporting=json.loads(_tool_receipt.read_text());reporting_prefix=Path(reporting['prefix'])
sys.path.insert(0,str(reporting_prefix))
def tool_custody():
    assert payload_hashes(reporting_prefix)==reporting['files_sha256']
    locations=[]
    for name,module in tuple(sys.modules.items()):
        if name=='pytest_receptor' or name.startswith('pytest_receptor.'):
            path=Path(module.__file__).resolve();assert path.is_relative_to(reporting_prefix)
            locations.append({'module':name,'path':str(path),'sha256':sha(path)})
    return locations
import importlib.metadata
import pytest_receptor
assert importlib.metadata.version('pytest-receptor')=='1.2.2'
tool_before=tool_custody()
try:
    initialize()
    import pytest
    fixture=Path(msm.systems['alanine dipeptide']['alanine_dipeptide.h5msm']).resolve();assert fixture.is_relative_to(providers)
    assert sha(fixture)=='92ec5f1d3e2b2e753891488c7e984631609819ab07b1b046b2c7b312bed47069'
    save(output/'fixture.json',{'path':str(fixture),'sha256':sha(fixture),'provider_source_verified':True,'scope':'Existing native regression fixture, not a new independent molecular case'})
    test=attempt/'qualified-tests/test_viewer_state.py';original=root/'tests/test_viewer_state.py'
    assert test.read_bytes()==original.read_bytes()
    save(output/'test-source.json',{'path':str(test),'sha256':sha(test),'original_source_sha256':sha(original)})
    node=str(test)+'::test_public_resolved_widgets_keep_separate_reactive_state_and_owned_cleanup'
    state={'collected':[],'reports':{},'session_finished':False}
    class Completion:
        def pytest_collection_finish(self,session):state['collected']=[item.nodeid for item in session.items]
        def pytest_runtest_logreport(self,report):state['reports'].setdefault(report.nodeid,{})[report.when]=report.outcome
        def pytest_sessionfinish(self,session,exitstatus):state.update(session_finished=True,exit_status=int(exitstatus))
    args=[node,'--receptor=llm','--import-mode=importlib','--confcutdir='+str(test.parent),'-o','pythonpath=','-o','cache_dir='+str(attempt/'pytest-cache'),'--junitxml='+str(attempt/'junit.xml')]
    save(attempt/'pytest-command.json',args)
    exit_code=int(pytest.main(args,plugins=[Completion()]));save(attempt/'pytest-session.json',state)
    complete=exit_code==0 and state['session_finished'] and len(state['collected'])==1 and len(state['reports'])==1 and all(state['reports'][n]=={'setup':'passed','call':'passed','teardown':'passed'} for n in state['collected'])
    assert complete,(exit_code,state)
    xml=ET.parse(attempt/'junit.xml').getroot();suites=[xml] if xml.tag=='testsuite' else list(xml.findall('testsuite'))
    assert sum(int(s.attrib['tests']) for s in suites)==1 and sum(int(s.attrib.get(k,0)) for s in suites for k in ['failures','errors','skipped'])==0
    assert sha(fixture)==json.loads((output/'fixture.json').read_text())['sha256']
    finish()
    tool_after=tool_custody()
    save(output/'reporting-origins.json',{'before':tool_before,'after':tool_after,'receipt_sha256':sha(_tool_receipt),'version':'1.2.2'})
    receipt={'schema':'dockingmt.editable_view_native_regression@1','outcome':'PASS','qualification_complete':True,'profile':profile,'case':case,'source_commit':candidate['source_commit'],'route':'editable-development','provider_commit':composition['source_revisions'][str(root.parent/'molsysmt')],'native_cases':1,'native_passed':1,'pytest_receptor_version':'1.2.2','reporting_tools_receipt_sha256':sha(_tool_receipt),'pytest_exit_code':exit_code,'completed_steps':['pytest_native_regression','final_receipt_and_origins'],'forbidden_attempts':forbidden_attempts,'provider_counts':provider_counts,'provider_caps':provider_caps,'viewer_counts':viewer_counts,'viewer_caps':viewer_caps,'caller_policy':diagnostic(caller_policy),'caller_policy_preserved':True,'canvas_received':False,'public_delivery_received':False,'whole_e4_received':False}
    save(output/'receipt.json',receipt)
except Exception as exc:
    save(attempt/'failure.json',{'exception_type':type(exc).__name__,'message':str(exc),'provider_counts':provider_counts,'viewer_counts':viewer_counts,'forbidden_attempts':forbidden_attempts});traceback.print_exc();raise
finally:context.__exit__(None,None,None)
assert authority()==previous_policy
assert {name:getattr(msm.configure,name) for name in provider_policy_before}==provider_policy_before
save(attempt/'worker-receipt.json',{**receipt,'caller_policy_restored':True})
print(json.dumps({'outcome':'PASS','profile':profile,'case':case,'native_cases':1,'provider_counts':provider_counts,'viewer_counts':viewer_counts}),flush=True)
