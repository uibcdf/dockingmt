# Receiving the original interaction-view workflow on editable sources — 2026-11-08

Owners: [DockingMT #80](../pending_proposals/receive_docking_interaction_analysis.md)
and [#60](../pending_proposals/qualify_saved_result_addon.md).
Registered before execution; outcome **unexecuted**.

## Initial setup failure and receiving-02 amendment

The first retained/normal attempt fails before every molecular/View operation:
the old installed-wheel identity check compares package-local build stamp
`0.0.0+297.g3b1853a` with editable distribution metadata
`0.0.0+295.g2fda623`. Both actual labels and the source origin are retained;
neither labels the current mutable source. This is a receiver setup error,
not a demonstrated product/provider defect. The whole attempt remains FAIL,
0.917 s / 58,998,784 sampled group RSS bytes, no resource interruption and all
owned groups terminal; every provider/receiver/Viewer count is zero.

Register a fresh task `.molsyssuite/e4-view-editable-02-20261108`. Freeze the
actual package-local stamp bytes as part of the full Python-source inventory,
parse its literal build label before execution, require the imported package
to match that stamp and retain distribution metadata as a separate observation.
Actual source/native/import custody remains mandatory. No version is overridden,
build/reinstall or source overlay performed. The complete original scientific
and action assertions remain unchanged. Preserve the first terminal campaign
and its frozen registration; no resource interruption is restarted.

Receiving-02 also stops during setup, at the first native-binary custody hash:
the reused helper accepts `Path` objects but the frozen composition records
the native path as a string. All operation counters remain zero; 1.227 s /
61,689,856 sampled group RSS bytes, no resource interruption, owned groups
terminal. Preserve that failed campaign. Register receiving-03 prospectively
with `Path(path)` at the private hash helper boundary; no molecular, view,
action, tolerance or native-test assertion changes.

## Independent workflow and preserved holds

While MolSysMT #256 is being developed, receive the complete original
[eight-cell Python interaction-view selection](e4_pose_interaction_view_installed_2026-11-07.md)
on the current editable cohort. Original actual-View evidence used older private
MolSysMT/Viewer artifacts; #642's catalog correction, the new provider cohort
and #89's local admission changes have not received this whole composition.
This is an integration question, not a repeat molecular/docking calculation.
Keep earlier installed/source/DOM/scientific producers and failures unchanged.

Use consumer `204f5f6c342368e1e2530bd663594b62018cb599`, MolSysMT
`fab8cbccf570a60205a3863aad19dd4b7cfb8d3a`, MolSysViewer
`1187fc187247aa2d20d01791856a541d50562bcb`, native SHA-256
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`.
Freeze participating Python-source inventories, actual imports/native origins,
provider/consumer revisions and observed build labels. No wheel/build/reinstall,
runtime module overlay, package wait, provider checkout change or source pin change.

## Same original complete matrix

Authenticate the 342-member original archive, manifest SHA-256
`a6b92821b8c5af375fcadbb8e64f6e2cf01015283b95e33ea47af53a3e692606`.
Original view worker SHA-256 is
`b8eca9894ced90739497c82e0eed92e60ba9b9ed979393c5228212646772a659`;
native worker is `5a9f46ee1ad9a8df095365428751f6e95ccca3f33b2320d6c92a88c4a4537d7f`.
Preserve the complete original scientific/action/assertion blocks. Amend only
installation/tool-prefix/custody setup and completion metadata for the actual
editable route. Never label this composition as the old installed artifact.

Complete retained original, explicit five-record permutation `[1,2,3,0,4]`,
evaluated-empty/unevaluated translated control, and the existing native two-frame
widget/callback regression under normal policy before any pm/fs cell. Each cell
is a fresh process. Preserve original result/pose/state/source/frame identities,
13 mapped pose atoms, 18-atom ligand domain and retained carrier's 3/2 original
observations. Receive public binding, addon discovery, real Python visuals and
mounted widgets, metadata/filter/query pages, selection/context/panel actions,
four refusals, full result/association export, foreign-visual ownership, clearing,
re-enable, same-count system-replacement invalidation and complete cleanup.
Keep full original native/typed/snapshot/result equality and unit tolerances.
No new detector, preparation, score, RMSD, geometry transformation or search.

Original source data are authenticated through saved-carrier manifest
`73c8114368f0d7011d2e27d229662bf29be1f99bea27c0e0a24065f077e04b4d`.
The native test is byte-identical, SHA-256
`7ef11e6690153d9b61771af08b2a4d252642fc93dfabc500f3c2d3e42280ce84`;
its existing provider fixture is also unchanged, SHA-256
`92ec5f1d3e2b2e753891488c7e984631609819ab07b1b046b2c7b312bed47069`.
The existing diagnostic notebook/helper SHA-256 remains
`a6a8561e4aa7d9d2b5967fd43b9c2fdf8793ba13bbbb3c3a5d524e3d53e7d113`.
Inspection snapshots are not molecular restoration codecs.

## Resources, tooling and completion

Keep every original receiver/provider/Viewer entry cap, scientific refusal and
finite matrix. Add the newly available pairwise/clustering operations to the
forbidden scientific guard. The routine environment currently exposes editable Pytest Receptor 1.2.0,
while this original gate requires 1.2.2. Reuse the previously authenticated
15-file published 1.2.2 tool prefix under its unchanged receipt SHA-256
`6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1`.
Verify its exact bytes, actual tool imports/version and native pytest/JUnit
completion with `--receptor=llm`. This is a separate test-tool identity, not
an old molecular runtime or a source fallback; the shared environment is untouched.

Run serially on CPU 0/nice 10, one native/build worker, 13 GiB monitored available
reserve, 1 GiB group RSS, 2 GiB address space and 45 CPU/60 wall seconds per cell.
Initial estimated peak is 768 MiB; start with one retained cell and inspect its
measured outcome before proceeding. Check RAM/load/swap/pressure first. Slurm
has no allocation; retain the prior bounded inconclusive applicability probe.
Stop after any failed gate and preserve failed/unattempted members. Never
automatically restart a resource/headroom interruption or raise limits silently.

The parent verifies relevant source/native/data drift, and all owned groups must
terminate. Preserve all exact producers, registrations, original input identities,
logs/warnings/counters and outcomes under
`.molsyssuite/e4-view-editable-20261108`, #50/review 2026-11-14. Seal/independently
read records without molecular replay and run final local/fresh committed-export
resource checks. Audit all five original #80 criteria against received evidence.

These are real Python-side widgets/callbacks, not browser/comm/canvas acceptance.
Do not start a browser/server/kernel, dispatch CI, wait/poll #256, re-evaluate
unmeasured poses or weaken the experimental-reference/native-persistence gate.
Full E4/Core/Extended/science, visible #52/#60, public/installed/minor/platform
and the original E3 reference/saved-pose/common-frame criteria remain separate.
