"""Serial, frozen current-source receiving of the original Python view matrix."""
import ast
from datetime import datetime,timezone
import gzip
import hashlib
import importlib.metadata as md
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
import traceback

root=Path(__file__).resolve().parents[2]
task=Path(__file__).parent
profile,case=sys.argv[1:3]
cases=['retained','reordered','empty','native_regression']
assert profile in ['normal','pm_fs'] and case in cases
assert not (task/'campaign-terminal.json').exists()
attempt=task/(profile+'-'+case)
attempt.mkdir(exist_ok=False)
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
try:
    guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
    assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
    nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
    policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
    assert available()>policy['available_reserve_bytes']+1024**3
    collector=root/'.molsyssuite/e4-evidence-editable-20261108/run_receiving.py'
    s=collector.read_text();block=s[s.index("native=root.parent/'molsysmt/molsysmt/_rust.abi3.so'"):s.index('composition_bytes=')]
    block=block.replace('542c5c5853a64ed9472a3317449e900f33f9b952','204f5f6c342368e1e2530bd663594b62018cb599').replace('2325038e8c68157f5c730693ffbb8535f0b45540','fab8cbccf570a60205a3863aad19dd4b7cfb8d3a')
    exec(compile(block,str(collector)+'#composition','exec'),globals())
    assert composition['source_revisions'][str(root.parent/'molsysviewer')]=='1187fc187247aa2d20d01791856a541d50562bcb'
    raw=(json.dumps(composition,indent=2)+'\n').encode()
    if profile=='normal' and case=='retained':
        (task/'composition.json').write_bytes(raw)
    else:
        assert (task/'composition.json').read_bytes()==raw
    worker='native_worker.py' if case=='native_regression' else 'view_worker.py'
    sdk=root/'.molsyssuite/publication-sdk'
    assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45'
    assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
    sdk_hashes={str(p.relative_to(sdk)):sha(p) for p in (sdk/'devtools/scripts').glob('*.py')}
    frozen={}
    for original,name in [(task/worker,worker),(task/'common.py','common.py'),(Path(__file__),'run.py'),(task/'route-change.json','route-change.json'),(guard,'guard.py'),(root/'devguide/validation/e4_view_editable_2026-11-08.md','prescription.md'),(collector,'composition-producer.py')]:
        destination=attempt/('frozen-'+name);shutil.copyfile(original,destination)
        frozen[name]={'sha256':sha(destination),'path':destination.name}
    (attempt/'frozen-composition.json').write_bytes(raw)
    predecessors=cases[:cases.index(case)] if profile=='normal' else cases
    for previous_case in predecessors:
        previous=task/('normal-'+previous_case)
        reg=json.loads((previous/'registration.json').read_text())
        assert json.loads((previous/'resource-outcome.json').read_text())['outcome']=='PASS'
        assert json.loads((previous/'worker-receipt.json').read_text())['outcome']=='PASS'
        for name in ['common.py','run.py','prescription.md','route-change.json']:
            assert reg['frozen'][name]['sha256']==frozen[name]['sha256']
    if profile=='pm_fs':
        for previous_case in cases[:cases.index(case)]:
            assert json.loads((task/('pm_fs-'+previous_case)/'resource-outcome.json').read_text())['outcome']=='PASS'
    archive=root/'devguide/validation/data/e4_saved_carrier_receiving_2026-11-07'
    assert sha(archive/'manifest.json')=='73c8114368f0d7011d2e27d229662bf29be1f99bea27c0e0a24065f077e04b4d'
    rows=json.loads((archive/'manifest.json').read_text())['files']
    relative='attempts/'+('normal-02' if profile=='normal' else 'pm-fs-01')+'/inputs.json.gz'
    row=next(r for r in rows if r['path']==relative);blob=(archive/relative).read_bytes()
    assert hashlib.sha256(blob).hexdigest()==row['sha256'];decoded=gzip.decompress(blob);assert hashlib.sha256(decoded).hexdigest()==row['decoded_sha256']
    original=json.loads(decoded);entries={};directory=attempt/'inputs';directory.mkdir()
    for key,entry in original['inputs'].items():
        source=root/entry['repository_path'];blob=source.read_bytes();assert len(blob)==entry['stored_bytes'] and hashlib.sha256(blob).hexdigest()==entry['stored_sha256']
        data=gzip.decompress(blob);assert len(data)==entry['decoded_bytes'] and hashlib.sha256(data).hexdigest()==entry['decoded_sha256']
        destination=directory/(key+('.json' if key in ['result','association'] else '.h5msm'));destination.write_bytes(data);destination.chmod(0o444)
        entries[key]={**entry,'path':str(destination)}
    (attempt/'inputs.json').write_text(json.dumps({'profile':profile,'inputs':entries,'original_source':original['original_source']},indent=2)+'\n')
    if case=='native_regression':
        tests=attempt/'qualified-tests';tests.mkdir();shutil.copyfile(root/'tests/test_viewer_state.py',tests/'test_viewer_state.py')
        assert sha(tests/'test_viewer_state.py')=='7ef11e6690153d9b61771af08b2a4d252642fc93dfabc500f3c2d3e42280ce84'
    registration={'owner':'uibcdf/dockingmt#80','source_commit':'204f5f6c342368e1e2530bd663594b62018cb599','profile':profile,'case':case,'registered_at_utc':datetime.now(timezone.utc).isoformat(),'frozen':frozen,'sdk_source_sha256':sdk_hashes,'inputs_sha256':sha(attempt/'inputs.json'),'composition_sha256':sha(attempt/'frozen-composition.json'),'policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':768*1024**2,'scope':'Original complete Python view/widget/action/native-test selection on actual editable sources; no browser/comm/canvas or scientific recalculation'}
    (attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
    env=os.environ.copy();env.update(DMT_INSTALLED_ROOT=str(root),DMT_INSTALLED_TASK=str(task),DMT_INSTALLED_ATTEMPT=str(attempt),DMT_INSTALLED_PROFILE=profile,DMT_VIEW_CASE=case,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
    for name,key in [('tmp','TMPDIR'),('cache','XDG_CACHE_HOME'),('numba','NUMBA_CACHE_DIR'),('mpl','MPLCONFIGDIR')]:
        p=attempt/name;p.mkdir();env[key]=str(p)
    for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:
        env[key]='1'
    with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
        process=subprocess.Popen([sys.executable,'-B','-I',str(attempt/('frozen-'+worker))],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
        outcome=monitor(process,policy)
    try:
        receipt=json.loads((attempt/'worker-receipt.json').read_text())
        complete=receipt['outcome']=='PASS' and receipt['qualification_complete'] and receipt['caller_policy_restored'] and receipt['profile']==profile and receipt['case']==case
    except Exception as error:
        complete=False;outcome['qualification_diagnostic']=type(error).__name__+': '+str(error)
    outcome['outcome']='PASS' if complete and outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
    (attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
    if outcome['outcome']!='PASS':
        (task/'campaign-terminal.json').write_text(json.dumps({'outcome':'FAIL','failed_attempt':attempt.name,'further_execution_permitted':False},indent=2)+'\n')
        print((attempt/'stderr.log').read_text()[-5000:]);raise SystemExit(1)
    print(json.dumps({'profile':profile,'case':case,'view_received':receipt.get('actual_view_route_received'),'native_cases':receipt.get('native_cases'),'whole_e4_received':False}),flush=True)
    if profile=='pm_fs' and case=='native_regression':
        (task/'campaign-terminal.json').write_text(json.dumps({'outcome':'PASS','complete_cells':8,'further_execution_permitted':False,'canvas_received':False,'whole_e4_received':False},indent=2)+'\n')
except Exception as error:
    (attempt/'controller-failure.json').write_text(json.dumps({'outcome':'FAIL','exception_type':type(error).__name__,'message':str(error),'further_execution_permitted':False},indent=2)+'\n')
    if not (task/'campaign-terminal.json').exists():
        (task/'campaign-terminal.json').write_text(json.dumps({'outcome':'FAIL','failed_attempt':attempt.name,'further_execution_permitted':False},indent=2)+'\n')
    raise
