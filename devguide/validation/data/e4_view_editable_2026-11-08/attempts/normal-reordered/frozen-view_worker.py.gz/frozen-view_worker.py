import os
from pathlib import Path
import hashlib
import json

_attempt=Path(os.environ['DMT_INSTALLED_ATTEMPT']);_registration=json.loads((_attempt/'registration.json').read_text());_common=_attempt/'frozen-common.py'
assert hashlib.sha256(_common.read_bytes()).hexdigest()==_registration['frozen']['common.py']['sha256']
exec(compile(_common.read_bytes(),str(_common),'exec'),globals())
view=None;widgets=[];closed_widgets=0;closed_views=0
try:
    initialize()
    from molsysviewer_dockingmt import set_active_pose,on_context_action,clear_docking
    from molsysviewer_dockingmt.runtime import ensure_runtime
    from molsysviewer_dockingmt.export import build_docking_export_payload
    from molsysviewer_dockingmt.workbench import get_docking_summary_section
    original_record=json.loads(Path(entries['result']['path']).read_text());original=dmt.DockingResult.from_dict(original_record)
    assert original.to_dict()==original_record and len(original)==5
    association=json.loads(Path(entries['association']['path']).read_text());assert association['selected_original_position']==1
    pose=original[0];assert pose.pose_id==association['pose_id'] and pose.metadata['source_atom_keys']==association['pose_atom_keys']
    ligand=association['merged_ligand_atom_indices']['retained_pose'];assert ligand==list(range(3220,3238))
    correspondence=association['existing_ligand_atom_correspondence'];assert correspondence==[[i,i] for i in range(13)]
    indices=[ligand[target] for source,target in correspondence];assert indices==list(range(3220,3233));receptor=list(range(3220))
    input_case='translated_geometry_control' if case=='empty' else 'retained_pose'
    source=msm.h5msm.read(entries[input_case]['path']);source_before=native_state(source)
    source_analyses={name:diagnostic(payload(analysis)) for name,analysis in source.interactions.items()}
    save(output/'original-native-before.json',source_before);save(output/'original-analyses-before.json',source_analyses)
    model=source;result=original;position=0;derivation=None
    if case=='reordered':
        permutation=[1,2,3,0,4];record=deepcopy(original_record);record['poses']=[deepcopy(original_record['poses'][i]) for i in permutation]
        record['provenance']['receiving_order_control']={'permutation':permutation,'original_result_decoded_sha256':entries['result']['decoded_sha256'],'operation':'Collection reordering only; no new pose, score or docking'}
        result=dmt.DockingResult.from_dict(record);position=3
        assert result[position].to_dict()==original[0].to_dict()
        assert [p.to_dict() for p in result]==[original_record['poses'][i] for i in permutation]
        derivation=record['provenance']['receiving_order_control']
    elif case=='empty':
        model=direct('derive_copy',msm.copy,source)
        invalidated=direct('invalidation',source.interactions['hbonds'].invalidate_structures,[0]);assert invalidated.evaluated_structure_indices.tolist()==[]
        model.interactions={**model.interactions,'hbonds':invalidated}
        xyz=puw.get_value(msm.get(model,element='atom',coordinates=True),to_unit='angstrom')[0,indices,:]
        derivation={'source':entries[input_case]['decoded_sha256'],'source_producer':'5952053328aac6f737e22906e984c0f9eb938dd7','original_pose_id':pose.pose_id,'original_pose':False,'operation':'Indexed saved coordinate snapshot and public empty-family invalidation; no geometry transformation, new observation or docking'}
        control=dmt.DockingPose(puw.quantity(xyz,'angstrom'),pose_id='control:translated-saved-carrier',partner_state_id=pose.partner_state_id,receptor_state_id=pose.receptor_state_id,metadata={'pose_atom_order':pose.metadata['pose_atom_order'],'source_atom_keys':deepcopy(pose.metadata['source_atom_keys']),'control_derivation':derivation})
        result=dmt.DockingResult([control],provenance={'derived_control':True,'original_scientific_producer':derivation['source_producer']});assert control.scores=={} and control.rank is None
    else:assert case=='retained'
    result_record=result.to_dict();selected=result[position]
    expected={name:diagnostic(payload(analysis)) for name,analysis in model.interactions.items()}
    model_before=native_state(model) if case=='empty' else source_before
    save(output/'carrier-native-before.json',model_before);save(output/'carrier-analyses-before.json',expected)
    binding=direct('binding_calls',dmt.bind_interactions,result,model,pose_index=position,pose_atom_indices=indices,partner_state_id=selected.partner_state_id,receptor_state_id=selected.receptor_state_id,assume_aligned=True)
    expected_coverage={'hbonds':case!='empty','hydrophobic':True};expected_counts={'hbonds':0,'hydrophobic':0} if case=='empty' else {'hbonds':3,'hydrophobic':2}
    assert binding.result.to_dict()==result_record and binding.association['analysis_evaluated']==expected_coverage
    completed.append('custody_and_inputs');journal('step-completed',step=completed[-1])
    view=direct('public_views',dmt.view,binding)
    assert view.addons.is_enabled('dockingmt')
    runtime=ensure_runtime(view);assert view.addons.dockingmt is runtime and runtime.interaction_binding is binding
    assert runtime.result.to_dict()==result_record and runtime.active_pose_index==position and view.player.index==0
    loaded=native_state(view.molsys);assert_native_roundtrip(loaded,model_before);save(output/'loaded-native.json',loaded)
    for panel_id in ['explorer','domain']:
        widget=view.addons.resolve_panel_widget('dockingmt',panel_id);widgets.append(widget);widget.on_mount(view)
    explorer,domain=widgets
    def widget_state():
        state=view.widget.addon_states['dockingmt']['explorer']
        assert state['n_poses']==len(result) and state['active_index']==position
        assert [row['geometry_available'] for row in state['poses']]==[i==position for i in range(len(result))]
        assert {row['name']:row['evaluated'] for row in state['interaction_analyses']}==expected_coverage
        assert {row['name']:row['n_occurrences'] for row in state['interaction_analyses']}==expected_counts
        return diagnostic(state)
    state=widget_state();save(output/'initial-widget-state.json',state)
    visual=view.interactions.info();assert len(visual)==2
    for row in visual:
        name=row['analysis_name'];assert row['filter']['structure_indices']==[0] and row['frame']==0
        assert row['status']==('evaluated' if expected_coverage[name] else 'unevaluated')
        assert row['n_observations']==expected_counts[name] and row['n_skipped']==0
        assert row['n_supported']==expected_counts[name]
    save(output/'visual-info.json',diagnostic(visual))
    for family in binding.analysis_names:
        assert diagnostic(payload(view.interactions.get_analysis(family)))==expected[family]
        query=direct('analysis_queries',view.interactions.query,family,selection=ligand,selection_2=receptor,mode='between_selections',exclusive=True,structure_indices=[0])
        assert query.n_interactions==expected_counts[family]
        page=diagnostic(direct('analysis_pages',query.to_page,offset=0,limit=20,max_participant_atoms=512));assert page['evaluated_structure_indices']['array']==([0] if expected_coverage[family] else [])
        save(output/(family+'-page.json'),page)
    for name,function in [('python_navigation',lambda:set_active_pose(view,position+1)),('context_navigation',lambda:on_context_action(view,'set-pose',{'rank':position+1})),('panel_navigation',lambda:explorer.handle_action(view,'set_pose',{'index':position}))]:
        direct(name,function);assert view.player.index==0;widget_state()
    foreign_position=0 if position!=0 else 1
    if len(result)==1:
        foreign_position=1
        expected_error=__import__('dockingmt._private.smonitor',fromlist=['ViewerPosePositionError']).ViewerPosePositionError
    else:expected_error=ViewerStateError
    expect('unavailable_python_position',direct,'python_navigation',set_active_pose,view,foreign_position+1,expected=expected_error)
    expect('unavailable_context_position',direct,'context_navigation',on_context_action,view,'set-pose',{'rank':foreign_position+1},expected=expected_error)
    direct('panel_navigation',explorer.handle_action,view,'set_pose',{'index':foreign_position});assert explorer._last_state['status']=='error' and view.player.index==0
    refusals.append({'label':'unavailable_panel_position','type':explorer._last_state['error_code']})
    direct('panel_navigation',explorer.handle_action,view,'refresh',{});widget_state()
    expect('binding_conflicting_result',direct,'public_views',dmt.view,binding,result=binding.result,view=view,expected=ArgumentError)
    summary=get_docking_summary_section(view);export=build_docking_export_payload(view)
    assert export['result']==result_record and summary['selected_pose']['pose_id']==selected.pose_id
    assert export['interaction_association']==summary['interaction_association']==binding.association
    assert export['interaction_geometry_available'] and summary['interaction_geometry_available']
    save(output/'summary.json',diagnostic(summary));save(output/'export.json',diagnostic(export));save(output/'association.json',binding.association)
    save(output/'result.json',result_record);save(output/'original-result.json',original_record)
    completed.append('actual_view_and_controls');journal('step-completed',step=completed[-1])
    foreign=direct('foreign_visual',view.interactions.add,'hydrophobic',tag='receiving:foreign-visual',structure_indices=[0])
    view.addons.disable('dockingmt')
    assert ensure_runtime(view).result is None and ensure_runtime(view).interaction_binding is None
    assert view.interactions.get(foreign.tag) is foreign
    assert all(view.interactions.get(row['tag']) is None for row in visual)
    assert set(view.molsys.interactions)==set(binding.analysis_names)
    assert {name:diagnostic(payload(analysis)) for name,analysis in view.molsys.interactions.items()}==expected
    # Re-enable is a supported lifecycle call. Reloading the same snapshot is
    # intentionally a new system identity, never permission to reuse a binding.
    view.addons.enable('dockingmt')
    direct('public_views',dmt.view,binding,view=view)
    runtime=ensure_runtime(view);assert runtime.interaction_binding is binding and runtime.active_pose_index==position and runtime.result.to_dict()==result_record
    widget_state()
    replacement=msm.copy(model)
    direct('explicit_load',view.load,replacement,label='replaced-same-counts',mode='replace')
    explorer.handle_action(view,'refresh',{});state=diagnostic(explorer._last_state)
    assert state['interaction_geometry_available'] is False and not any(row['geometry_available'] for row in state['poses'])
    save(output/'replaced-widget-state.json',state)
    assert original.to_dict()==original_record and result.to_dict()==result_record
    after=native_state(source);assert after==source_before;save(output/'original-native-after.json',after)
    assert {name:diagnostic(payload(analysis)) for name,analysis in source.interactions.items()}==source_analyses
    save(output/'original-analyses-after.json',source_analyses)
    model_after=native_state(model) if case=='empty' else after;assert model_after==model_before
    assert {name:diagnostic(payload(analysis)) for name,analysis in model.interactions.items()}==expected
    save(output/'carrier-native-after.json',model_after);save(output/'carrier-analyses-after.json',expected)
    for widget in widgets:widget.close();closed_widgets+=1
    widgets.clear();view.close();closed_views+=1;view=None
    completed.append('source_nonmutation_and_cleanup');journal('step-completed',step=completed[-1])
    finish();completed.append('final_receipt_and_origins')
    receipt={'schema':'dockingmt.editable_interaction_view@1','outcome':'PASS','qualification_complete':True,'profile':profile,'case':case,'source_commit':candidate['source_commit'],'version':candidate['version'],'route':'editable-development','provider_commit':composition['source_revisions'][str(root.parent/'molsysmt')],'completed_steps':completed,'accepted_bindings':1,'refusals':len(refusals),'refusal_records':refusals,'views_closed':closed_views,'widgets_closed':closed_widgets,'actual_view_route_received':True,'public_renders_in_same_view':2,'result_population':len(result),'original_population':5,'bound_position':position,'derivation':derivation,'analysis_coverage':expected_coverage,'observation_counts':expected_counts,'receiver_counts':counts,'receiver_caps':budgets,'provider_counts':provider_counts,'provider_caps':provider_caps,'viewer_counts':viewer_counts,'viewer_caps':viewer_caps,'caller_policy':diagnostic(caller_policy),'forbidden_attempts':forbidden_attempts,'caller_policy_preserved':True,'canvas_received':False,'public_delivery_received':False,'whole_e4_received':False}
    save(output/'receipt.json',receipt)
except Exception as exc:
    save(attempt/'failure.json',{'exception_type':type(exc).__name__,'message':str(exc),'completed_steps':completed,'receiver_counts':counts,'provider_counts':provider_counts,'viewer_counts':viewer_counts,'forbidden_attempts':forbidden_attempts});traceback.print_exc();raise
finally:
    for widget in widgets:widget.close();closed_widgets+=1
    if view is not None:view.close();closed_views+=1
    context.__exit__(None,None,None)
assert authority()==previous_policy
assert {name:getattr(msm.configure,name) for name in provider_policy_before}==provider_policy_before
save(attempt/'worker-receipt.json',{**receipt,'caller_policy_restored':True})
print(json.dumps({'outcome':'PASS','profile':profile,'case':case,'source_commit':candidate['source_commit'],'receiver_counts':counts,'provider_counts':provider_counts,'viewer_counts':viewer_counts}),flush=True)
