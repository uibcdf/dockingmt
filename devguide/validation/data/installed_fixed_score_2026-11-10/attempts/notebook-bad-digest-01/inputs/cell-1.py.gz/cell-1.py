import base64
import gzip
import hashlib
import json
import os
import platform
from pathlib import Path

import numpy as np
import pyunitwizard as puw
from smonitor.integrations import CatalogException

import dockingmt as dmt

input_path = Path(os.environ['DOCKINGMT_RESULT_PATH']).expanduser().resolve()
expected_sha256 = os.environ['DOCKINGMT_RESULT_SHA256'].lower()
if len(expected_sha256) != 64 or any(
    char not in '0123456789abcdef' for char in expected_sha256
):
    raise ValueError('Supply an externally expected file SHA-256 digest.')
input_bytes = input_path.read_bytes()
if hashlib.sha256(input_bytes).hexdigest() != expected_sha256:
    raise ValueError('Input file SHA-256 does not match the trusted expectation.')
decoded = gzip.decompress(input_bytes) if input_path.suffix == '.gz' else input_bytes
record = json.loads(decoded)
audit = dmt.audit_result(record)
if audit['status'] == 'inconsistent':
    raise ValueError('Resolve inconsistent saved-input evidence before scoring.')
saved_input = dmt.DockingResult.from_dict(record)
artifacts = record.get('provenance', {}).get('backend_artifacts', {})
captured_sizes = dmt.verify_captured_inputs(artifacts)
if any(artifacts[role].get('format') != 'pdbqt' for role in ('receptor', 'partner')):
    raise ValueError('This example requires captured prepared PDBQT inputs.')
problem = dmt.DockingProblem(
    receptor=base64.b64decode(
        artifacts['receptor']['content_base64'], validate=True
    ).decode(),
    partner=base64.b64decode(
        artifacts['partner']['content_base64'], validate=True
    ).decode(),
    search_domain=dmt.BoxRegion.from_dict(saved_input.problem_info['search_domain']),
)
print(
    {
        'python': platform.python_version(),
        'reader': dmt.__version__,
        'recorded_input_producer': record.get('provenance', {}).get(
            'dockingmt_version'
        ),
        'input_file_sha256': expected_sha256,
        'input_audit': audit['status'],
        'captured_sizes_bytes': captured_sizes,
        'geometry': 'captured submitted partner; no saved output pose selected',
    }
)