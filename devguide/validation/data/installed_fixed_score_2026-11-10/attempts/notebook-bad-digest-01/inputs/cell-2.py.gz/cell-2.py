first = dmt.score(
    problem,
    dmt.VinaProtocol(cpu=1, seed=17, capture_backend_inputs=True),
    score_name='vina',
)
before = first.to_dict()
second = dmt.score(
    problem,
    dmt.VinaProtocol(cpu=1, seed=17, scoring='vinardo'),
    pose=first,
    score_name='vinardo',
)
assert first.to_dict() == before
np.testing.assert_array_equal(
    puw.get_value(first.coordinates), puw.get_value(second.coordinates)
)
assert len(second.scores) == 16
assert second.rank is None
for name, value in second.scores.items():
    definition = second.score_definitions[name]
    print(f'{name:30s} {value:10.3f} {definition["unit"]} ({definition["kind"]})')