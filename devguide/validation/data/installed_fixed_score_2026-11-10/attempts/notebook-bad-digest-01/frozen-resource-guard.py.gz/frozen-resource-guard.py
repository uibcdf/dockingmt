"""Finite serial resource guard for the new saved-carrier receiving selection."""

import ast
import gzip
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

attempt_owned = False
_guard_stage = 'preflight'
try:
    root = Path('/fast_data/home/liliana/repos@uibcdf/dockingmt')
    task = root / '.molsyssuite/e4-saved-carrier-20261107'
    label, profile = sys.argv[1:]
    assert profile in ('normal', 'pm_fs')
    attempt = task / label
    attempt.mkdir(exist_ok=False)
    attempt_owned = True
    (attempt / 'stdout.log').touch(exist_ok=False)
    (attempt / 'stderr.log').touch(exist_ok=False)
    output = attempt / 'output'
    input_dir = attempt / 'inputs'
    input_dir.mkdir()
    owned_tmp = attempt / 'owned-tmp'
    owned_tmp.mkdir()
    reserve = 8 * 1024**3
    rss_limit = 1024**3
    policy = {
        'cpu': 0,
        'nice': 10,
        'workers': 1,
        'available_reserve_bytes': reserve,
        'group_rss_limit_bytes': rss_limit,
        'address_space_bytes': 2 * 1024**3,
        'cpu_seconds': 45,
        'wall_seconds': 60,
    }

    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def write(name, value):
        with (attempt / name).open('x') as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write('\n')

    def available():
        return (
            int(
                next(
                    line.split()[1]
                    for line in Path('/proc/meminfo').read_text().splitlines()
                    if line.startswith('MemAvailable:')
                )
            )
            * 1024
        )

    def memory(group):
        total = 0
        for directory in Path('/proc').iterdir():
            if not directory.name.isdigit():
                continue
            try:
                fields = (directory / 'stat').read_text().rsplit(') ', 1)[1].split()
                if int(fields[2]) != group:
                    continue
                for line in (directory / 'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        total += int(line.split()[1]) * 1024
            except (OSError, ProcessLookupError):
                continue
        return total

    def limits():
        os.sched_setaffinity(0, {0})
        os.setpriority(os.PRIO_PROCESS, 0, 10)
        resource.setrlimit(
            resource.RLIMIT_AS,
            (policy['address_space_bytes'], policy['address_space_bytes']),
        )
        resource.setrlimit(resource.RLIMIT_CPU, (45, 45))

    receipt_path = (
        root / 'devguide/validation/data/interaction_hosted_success_2026-11-06.json'
    )
    assert receipt_path.read_bytes() == subprocess.check_output(
        [
            'git',
            'show',
            'HEAD:devguide/validation/data/interaction_hosted_success_2026-11-06.json',
        ],
        cwd=root,
    )
    old = json.loads(receipt_path.read_text())
    sdk = root / '.molsyssuite/publication-sdk'
    assert (
        subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=sdk, text=True
        ).strip()
        == '95f693be10c9205ab9b912cb53453710a207bf45'
    )
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=sdk) == b''
    sdk_source_sha256 = {
        str(path.relative_to(sdk)): sha(path)
        for path in (sdk / 'devtools/scripts').rglob('*.py')
    }
    assert sdk_source_sha256

    installation_path = (
        root / '.molsyssuite/e1-score-comparison-20261107/installation-02.json'
    )
    source_manifest_path = (
        root / 'devguide/validation/data/e2_source_admission_2026-11-07/manifest.json'
    )
    assert (
        sha(source_manifest_path)
        == 'a5a60b65715b466bd04dc5e2bdb41a73489fdf9a13254552870628d387221b8d'
    )
    source_manifest = json.loads(source_manifest_path.read_text())
    installation_row = next(
        row
        for row in source_manifest['files']
        if row['original_path'] == 'attempts/source-01/frozen-installation-02.json'
    )
    assert sha(installation_path) == installation_row['decoded_sha256']
    entries = {}
    for key, old_key in [
        ('association', f'{profile}/interactions/association.json'),
        ('retained_pose', f'{profile}/interactions/retained_pose.h5msm'),
        (
            'translated_geometry_control',
            f'{profile}/interactions/translated_geometry_control.h5msm',
        ),
    ]:
        row = old['selected_original_exports'][old_key]
        path = root / row['repository_path']
        data = path.read_bytes()
        assert (
            len(data) == row['compressed_bytes']
            and hashlib.sha256(data).hexdigest() == row['compressed_sha256']
        )
        raw = gzip.decompress(data)
        assert (
            len(raw) == row['original_bytes']
            and hashlib.sha256(raw).hexdigest() == row['original_sha256']
        )
        destination = input_dir / Path(old_key).name
        destination.write_bytes(raw)
        destination.chmod(0o444)
        entries[key] = {
            'path': str(destination),
            'repository_path': row['repository_path'],
            'stored_sha256': row['compressed_sha256'],
            'stored_bytes': row['compressed_bytes'],
            'decoded_sha256': row['original_sha256'],
            'decoded_bytes': row['original_bytes'],
        }
    row = old['inputs']['result']
    data = (root / row['repository_path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    raw = gzip.decompress(data)
    association = json.loads((input_dir / 'association.json').read_text())
    assert (
        hashlib.sha256(raw).hexdigest() == association['original_decoded_result_sha256']
    )
    destination = input_dir / 'original_result.json'
    destination.write_bytes(raw)
    destination.chmod(0o444)
    entries['result'] = {
        'path': str(destination),
        'repository_path': row['repository_path'],
        'stored_sha256': row['sha256'],
        'stored_bytes': len(data),
        'decoded_sha256': hashlib.sha256(raw).hexdigest(),
        'decoded_bytes': len(raw),
    }
    inputs = {
        'schema': 'dockingmt.e4_saved_carrier_inputs@1',
        'owner': 'uibcdf/dockingmt#80',
        'profile': profile,
        'original_source': old['source'],
        'inputs': entries,
    }
    write('inputs.json', inputs)
    paths = [
        root / 'devguide/validation/e4_saved_carrier_receiving.ipynb',
        root / 'devguide/validation/e4_saved_carrier_receiving_2026-11-07.md',
        root / 'devguide/validation/e4_saved_analysis_admission_2026-11-07.md',
        root / 'devtools/conda-build/resources.toml',
        root / '.molsyssuite/e1-score-comparison-20261107/installation-02.json',
        task / 'viewer-overlay-receipt.json',
        receipt_path,
        Path('/tmp/e4_saved_carrier_worker.py'),
        Path(__file__),
    ]
    frozen = {}
    for path in paths:
        destination = attempt / ('frozen-' + path.name)
        shutil.copyfile(path, destination)
        frozen[path.name] = {'sha256': sha(path), 'frozen_name': destination.name}
    notebook = json.loads(
        (attempt / 'frozen-e4_saved_carrier_receiving.ipynb').read_text()
    )
    cells = []
    for cell in notebook['cells']:
        if cell['cell_type'] != 'code':
            continue
        body = ''.join(cell['source'])
        ast.parse(body)
        assert cell['outputs'] == [] and cell['execution_count'] is None
        cells.append(
            {'id': cell['id'], 'sha256': hashlib.sha256(body.encode()).hexdigest()}
        )
    if profile == 'pm_fs':
        normal = Path(os.environ.get('DMT_E4_NORMAL_ATTEMPT', str(task / 'normal-01')))
        assert normal.resolve().is_relative_to(task.resolve())
        for path in [
            normal / 'output/receipt.json',
            normal / 'worker-receipt.json',
            normal / 'resource-outcome.json',
        ]:
            assert json.loads(path.read_text())['outcome'] == 'PASS', str(path)
        previous_registration = json.loads((normal / 'registration.json').read_text())
        assert previous_registration['profile'] == 'normal'
        assert (
            json.loads((normal / 'worker-receipt.json').read_text())['profile']
            == 'normal'
        )
        assert previous_registration['sdk_source_sha256'] == sdk_source_sha256
        for identity in ['installation-02.json', 'viewer-overlay-receipt.json']:
            assert (
                previous_registration['frozen'][identity]['sha256']
                == frozen[identity]['sha256']
            )

        for name in [
            'e4_saved_carrier_receiving.ipynb',
            'e4_saved_carrier_worker.py',
            Path(__file__).name,
        ]:
            assert (
                previous_registration['frozen'][name]['sha256']
                == frozen[name]['sha256']
            ), name
        command_dependency = {
            'normal_attempt': str(normal),
            'worker_receipt_sha256': sha(normal / 'worker-receipt.json'),
            'resource_receipt_sha256': sha(normal / 'resource-outcome.json'),
        }
    else:
        command_dependency = None
    py = '/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python'
    command = [py, '-B', '-I', '-S', str(attempt / 'frozen-e4_saved_carrier_worker.py')]
    source_paths = list((root / 'dockingmt').rglob('*.py')) + list(
        (root / 'molsysviewer_dockingmt').rglob('*.py')
    )
    registration = {
        'schema': 'dockingmt.e4_saved_carrier_registration@1',
        'registered_at_utc': datetime.now(timezone.utc).isoformat(),
        'owner': 'uibcdf/dockingmt#80',
        'profile': profile,
        'command': command,
        'git_head': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=root, text=True
        ).strip(),
        'source_sha256': {
            str(p.relative_to(root)): sha(p) for p in sorted(source_paths)
        },
        'policy': policy,
        'initial_available_bytes': available(),
        'hardware_model': next(
            (
                line.split(':', 1)[1].strip()
                for line in Path('/proc/cpuinfo').read_text().splitlines()
                if line.startswith('model name')
            ),
            None,
        ),
        'guard_sha256': sha(Path(__file__)),
        'frozen': frozen,
        'sdk_source_sha256': sdk_source_sha256,
        'code_cells': cells,
        'inputs_manifest_sha256': sha(attempt / 'inputs.json'),
        'sequential_dependency': command_dependency,
        'scope': 'New saved-carrier/headless receiving; no restart of interrupted preparation/detector selection and no canvas/remote CI. No native search or new detection is allowed.',
    }
    write('registration.json', registration)
    if registration['initial_available_bytes'] < reserve + rss_limit:
        write(
            'resource-outcome.json',
            {
                'outcome': 'FAIL',
                'process_started': False,
                'resource_interruption': 'pre_launch_headroom',
                'initial_available_bytes': registration['initial_available_bytes'],
                'policy': policy,
            },
        )
        raise SystemExit(1)
    env = os.environ.copy()
    env.update(
        PYTHONDONTWRITEBYTECODE='1',
        DMT_E4_ROOT=str(root),
        DMT_E4_OUTPUT=str(output),
        DMT_E4_PROFILE=profile,
        DMT_E4_INPUTS=str(attempt / 'inputs.json'),
        TMPDIR=str(owned_tmp),
        XDG_CACHE_HOME=str(attempt / 'cache'),
        LD_LIBRARY_PATH='/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/lib',
    )
    for key in [
        'OMP_NUM_THREADS',
        'OMP_THREAD_LIMIT',
        'OPENBLAS_NUM_THREADS',
        'MKL_NUM_THREADS',
        'NUMEXPR_NUM_THREADS',
        'BLIS_NUM_THREADS',
        'RAYON_NUM_THREADS',
        'CARGO_BUILD_JOBS',
        'MAX_JOBS',
    ]:
        env[key] = '1'

    def group_members(group):
        members = []
        for directory in Path('/proc').iterdir():
            if not directory.name.isdigit():
                continue
            try:
                fields = (directory / 'stat').read_text().rsplit(') ', 1)[1].split()
                if int(fields[2]) == group and fields[0] not in ('Z', 'X'):
                    members.append(int(directory.name))
            except (OSError, ProcessLookupError):
                continue
        return members

    def stop_owned_group(process):
        for sig in (signal.SIGTERM, signal.SIGKILL):
            if process.poll() is not None and not group_members(process.pid):
                break
            try:
                os.killpg(process.pid, sig)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + 2
            while time.monotonic() < deadline:
                process.poll()
                if process.returncode is not None and not group_members(process.pid):
                    break
                time.sleep(0.05)
        process.poll()
        return group_members(process.pid)

    def monitor(process, execution_policy):
        start = time.monotonic()
        minimum = available()
        peak = samples = 0
        interruption = None
        remaining = []
        while True:
            code = process.poll()
            members = group_members(process.pid)
            if code is not None and not members:
                break
            minimum = min(minimum, available())
            resident = memory(process.pid)
            peak = max(peak, resident)
            samples += 1
            if minimum < execution_policy['available_reserve_bytes']:
                interruption = 'available_RAM_reserve_threatened'
            elif resident > execution_policy['group_rss_limit_bytes']:
                interruption = 'owned_group_RSS_limit'
            elif time.monotonic() - start > execution_policy['wall_seconds']:
                interruption = 'wall_limit'
            elif code is not None and members:
                interruption = 'owned_descendants_after_leader_exit'
            if interruption:
                remaining = stop_owned_group(process)
                break
            time.sleep(0.1)
        code = process.poll()
        return dict(
            process_started=True,
            exit_code=code,
            resource_interruption=interruption,
            termination_signal=-code if code is not None and code < 0 else None,
            elapsed_seconds=time.monotonic() - start,
            minimum_available_bytes=minimum,
            sampled_peak_group_rss_bytes=peak,
            samples=samples,
            policy=execution_policy,
            remaining_live_owned_pids=remaining,
            group_terminal=code is not None and not remaining,
        )

    def qualification(directory, code_cells, expected_profile):
        try:
            assert not (directory / 'failure.json').exists()
            worker = json.loads((directory / 'worker-receipt.json').read_text())
            selection = json.loads((directory / 'output/receipt.json').read_text())
            assert worker['outcome'] == selection['outcome'] == 'PASS'
            assert worker['qualification_complete'] is True
            assert worker['profile'] == selection['profile'] == expected_profile
            assert worker['completed_cells'] == [row['id'] for row in code_cells]
            assert (
                selection['views_closed'] is True
                and not selection['forbidden_attempts']
            )
            return True, None
        except (OSError, ValueError, KeyError, AssertionError, TypeError) as error:
            return False, type(error).__name__ + ': ' + str(error)

    _guard_stage = 'execution'
    with (
        (attempt / 'stdout.log').open('ab') as stdout,
        (attempt / 'stderr.log').open('ab') as stderr,
    ):
        process = subprocess.Popen(
            command,
            cwd=root,
            env=env,
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
            preexec_fn=limits,
        )
        result = monitor(process, policy)
    _guard_stage = 'qualification'
    valid, diagnostic = qualification(attempt, cells, profile)
    resource_pass = (
        result['exit_code'] == 0
        and not result['resource_interruption']
        and result['group_terminal']
    )
    result.update(
        resource_outcome='PASS' if resource_pass else 'FAIL',
        qualification_outcome='PASS' if valid else 'FAIL',
        qualification_diagnostic=diagnostic,
        outcome='PASS' if resource_pass and valid else 'FAIL',
    )
    assert all(
        sha(root / name) == digest
        for name, digest in registration['source_sha256'].items()
    )
    assert all(
        sha(Path(row['path'])) == row['decoded_sha256'] for row in entries.values()
    )
    write('resource-outcome.json', result)
    print(json.dumps(result), flush=True)
    for name in ['stdout.log', 'stderr.log']:
        content = (attempt / name).read_text()
        print(json.dumps({'log': name, 'tail': content[-4000:]}), flush=True)
    raise SystemExit(0 if result['outcome'] == 'PASS' else 1)
except BaseException as error:
    expected_exit = (
        isinstance(error, SystemExit)
        and 'result' in globals()
        and (attempt / 'resource-outcome.json').is_file()
    )
    if expected_exit and error.code == (0 if result['outcome'] == 'PASS' else 1):
        raise
    if attempt_owned:
        remaining = []
        if 'process' in globals() and 'stop_owned_group' in globals():
            remaining = stop_owned_group(process)
        diagnostic = dict(
            outcome='FAIL',
            stage=_guard_stage,
            exception_type=type(error).__name__,
            message=str(error),
            process_started='process' in globals(),
            resource_metrics=globals().get('result'),
            remaining_live_owned_pids=remaining,
        )
        (attempt / 'guard-failure.json').write_text(
            json.dumps(diagnostic, indent=2, allow_nan=False) + '\n'
        )
        with (attempt / 'stderr.log').open('a') as stream:
            stream.write(traceback.format_exc())
        if not (attempt / 'stdout.log').exists():
            (attempt / 'stdout.log').touch()
        if not (attempt / 'resource-outcome.json').exists():
            (attempt / 'resource-outcome.json').write_text(
                json.dumps(
                    dict(
                        outcome='FAIL',
                        process_started='process' in globals(),
                        stage=_guard_stage,
                        resource_interruption=None,
                        exception_type=type(error).__name__,
                    ),
                    indent=2,
                )
                + '\n'
            )
    raise SystemExit(1) from error
