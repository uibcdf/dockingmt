# Installed fixed-pose scoring controls — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with public
scoring/evidence #76 and complete functional plan #73. Status: actual direct/API pilot passes; complete small-input and record receiving active. Execution base `4e30da511afa4181bbdbb63a3f53c31a19b4e5fa`.

## Question and immutable composition

Receive the existing fixed-conformation scoring boundary through the actual
installed consumer and retained native Vina/Vinardo engine. Check direct-native
component equality, explicit units/methods/reference policy, detached metadata,
state/geometry validation, original failure cleanup and record-only interpretation.
This is finite synthetic software integration, not an affinity/accuracy/ranking
study. Preserve original fixture bodies, seeds, assertions and producer identities.

Reuse the genuine aeae47d wheel, version `0.0.0+351.gaeae47d`,157821B, SHA256
`0b303ae371466a6736e8d194a89a54048f8bc51de3cd293cdc68c06050ae042b`. The normally
installed receiver, independently anchored source-free test root,67-path runtime,
private unit/reporting tools and606 support declarations remain unchanged in
`installed-reconstruction-20261109`. Shared SDKs stay738fe8dd/95f693be; do not alter
the verifier, user remotes or source-context profile to force acceptance.

Freeze the received MolSysMT0c6f9c7/Viewer1187fc18/ArgDigest07126411/
PyUnitWizardf82b618e/SMonitorc1b6ce29/DepDigest032d345b source/native cohort,
with stale distribution labels separate. Reuse the original103-file engine prefix
at `e5-timed-replay-20261107/layouts-admission-01/producer/engine`, verify every
byte before/after and record actual origins/version/final loaded extension hashes.
The prior administrative receipt does not recover failed historical native maps.
No source/test/helper/data change, provider refresh, install, build or remote CI.

## Small actual scoring and deliberate adverse controls

The original synthetic receptor is four records/317B, SHA256
`fdf890083d54bf740b9ca1eab96069840bffbbf6cea4a8dfdbfa9651ba79d80b`.
The partner is two records/181B, SHA256
`e195e663227eb6b77c2fe7b71efbc906ef6b5e72860261f0c18b8b37a43bf884`, or the original
prepared/provisional two-atom variant. Each backend input is at most64KiB;
submit at most four receptor and two partner records, grid center at the origin
and at most10 angstrom per side. Native constructors must explicitly request
CPU1 and method vina/vinardo. Do not override a default CPU0 to make a test pass.

Instrument actual constructor/input/map/score methods with signature-preserving
wrappers that delegate unchanged. Capture test-node association, native eight-value
vectors with the API's kcal/mol declaration, inputs, parameters and loaded binary.
Direct score uses its original `unbound_energy=None` current-conformation policy.
Forbid actual dock/optimize/randomize/poses/energies and viewer operations. Native
scoring and original deliberate fake/absent-engine controls remain distinct: stubs
must not count as actual engine execution, and each designated live cell requires
real native construction/scoring. Preserve all malformed-input/unsupported-method/
resource/failure checks and all original tolerances; no substitute native result.

## Ordered module selections

1. Pilot: real `test_scoring.py` module plus explicit deselections of31 frozen
   collected nodes, selecting only
   `test_native_scoring_matches_direct_engine_and_preserves_pose[vina]`.
   Expected one case and two actual constructors/maps/scores (direct/API).
2. If measured admission permits, receive `test_scoring.py` with the single
   original larger-input `test_flexible_external_input_retains_tree_and_record_order`
   explicitly deselected. Expected31 cases and seven actual constructor/map/score
   calls per caller policy: direct/API Vina/Vinardo comparisons, successive
   evaluations and provisional two-atom preparation. The four original failure
   and two fixed-component stubs stay intentional software controls; invalid or
   absent-backend requests must not touch the real native constructor. The larger
   receptor/30-angstrom case is not executed, modified or counted as passed.
3. Whole `test_scoring_reference.py`, `test_score_semantics.py` and
   `test_scored_result_audit.py`: expected25+45+19=89 cases, no exclusions. Require
   zero actual native and molecular operations. Preserve the historical minimal
   scored-pose/result files, their original producer labels, absent reference
   interpretation and the frozen legacy audit digest. A synthetic test declaration
   is not a new producer or recovered missing evidence.

Run each complete admitted selection normal then pm/fs, keeping worker/source/
helper/fixture bytes fixed for each pair. Counts are software coverage, not
independent scientific observations. The pilot overlaps the later module. Passing
pytest inside a failed/incomplete process is unqualified; preserve every attempt.

## Shared-resource bounds and custody

Host:64,978,440,192B physical RAM,20 logical CPUs; initial available60,134,215,680B,
load2.25/1.96/2.39,77% interval CPU idle, no active swap I/O and zero memory PSI.
Slurm commands exist, but no allocation and no confirmed scheduler applicability;
free resources are not reserved. Cells stay serial on CPU0,nice10,one worker with
13GiB available reserve,60 soft/65 hard CPU seconds and180 wall seconds. The direct
comparison intentionally holds two real engines at once. Allow1.5GiB group RSS /
3GiB address space with conservative1GiB expected peak (record-only256MiB), based
on prior single-engine peak below553MiB and possible overlapping native caches.
This is a bounded memory allowance for two small engines, not wider parallelism.
Monitor only owned descendants; stop only owned work if reserve/caps are threatened.
Never restart automatically after a headroom stop; no native build is restarted.

Retain programs, registrations, exact input/output/native identities, native calls,
original outcomes and independent stored-evidence reading under
`.molsyssuite/installed-fixed-score-20261110`, owners#47/#50/#76, review2026-11-14.
Retain original receiver/harness/engine/SDK inputs; shared support retires per cell.
Full #47/#30/#73, public Conda/closure/eight OS-minor cells, SSH #100 under
MolSysSuite#178, hosted #21/#28 and actual browser/canvas/comm/kernel evidence stay
separate. The #49/#33 partial/reference reader exception under MolSysMT#521 is not
resolved by scoring. CI pins, fixed candidates and historical producers stay intact.


## Pilot admission

Pilot-normal-01 passes one selected case with31 explicit module deselections,
zero errors/skips/warnings, two real constructors/maps/scores and no search or
optimization. The native eight-component vectors agree exactly between direct
and public API routes, with the original zero-tolerance comparison unchanged.
Wall19.188 seconds, measured child CPU17.813 seconds, peak686768128B; available
memory stays above58488885248B. This fits the declared two-engine memory allowance.
Receive the complete31-case small-input module selection under both caller
policies, then89 whole record-only cases per policy with zero native operations.
No source/test/fixture/assertion or resource-limit change is needed.
