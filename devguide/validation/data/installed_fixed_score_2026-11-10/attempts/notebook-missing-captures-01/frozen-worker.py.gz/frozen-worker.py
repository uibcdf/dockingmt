"""Execute declared installed small-fixture tests through the shared runner."""
from collections import Counter
from functools import wraps
import inspect
import ast
from contextlib import redirect_stdout
import tempfile
import traceback
import time
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib
import xml.etree.ElementTree as ET

root=Path(os.environ['DMT_SMALL_ROOT']);task=Path(os.environ['DMT_SMALL_TASK']);attempt=Path(os.environ['DMT_SMALL_ATTEMPT']);reg=json.loads((attempt/'registration.json').read_text())
def sha(p):
 with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
sdk=root/'.molsyssuite/publication-sdk';assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45';assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
old=root/'.molsyssuite/installed-small-fixtures-20261109';artifact=json.loads((attempt/'frozen-artifact.json').read_text());installation=json.loads((attempt/'frozen-installation.json').read_text());site=Path(installation['site']);assert sha(artifact['wheel'])==artifact['wheel_sha256']
assert artifact['source_commit']=='aeae47d50c5e90687c2558437cb22cf8f271ce85'
assert Path(sys.prefix)==Path(installation['prefix'])
def verify_receiver():
 for group in ['consumer_sha256','tool_sha256','unit_sha256']:
  for name,digest in installation[group].items():assert sha(site/name)==digest
verify_receiver();save(attempt/'wheel.json',artifact)
harness=Path(installation['harness'])
def cohort():
 return {name:{'commit':subprocess.check_output(['git','-C',str(root.parent/name),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(root.parent/name),'status','--porcelain'],text=True),'python_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.py')},'native_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.so')},'distribution_version':metadata.version(name)} for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']}
before=cohort();assert before==json.loads((attempt/'frozen-expected-cohort.json').read_text());save(attempt/'cohort.json',before)
engine=root/'.molsyssuite/e5-timed-replay-20261107/layouts-admission-01/producer/engine';engine_receipt=root/'.molsyssuite/e1-public-composition-20261106/final_engine_byte_receipt.json';engine_hashes=json.loads(engine_receipt.read_text())['paths'];assert len(engine_hashes)==103 and all(sha(engine/n)==digest for n,digest in engine_hashes.items());shutil.copyfile(engine_receipt,attempt/'frozen-engine-receipt.json')
sys.path.insert(0,str(engine/'lib/python3.14/site-packages'));assert root not in [Path(n).resolve() for n in sys.path if n] and harness not in [Path(n).resolve() for n in sys.path if n]
import pyunitwizard as puw
units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if reg['profile']=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
forbidden_operations=[];engine_calls=[];engine_call_counts=Counter();run_ids={};provider_calls=Counter()
def forbidden(*args,**kwargs):forbidden_operations.append('Unregistered native search/optimization/viewer work');raise AssertionError(forbidden_operations[-1])
config=json.loads((attempt/('frozen-'+reg['selection']+'.json')).read_text());notebook=Path(config['notebook']);assert sha(notebook)==config['notebook_sha256'];cells=[''.join(c['source']) for c in json.loads(notebook.read_text())['cells'] if c['cell_type']=='code'];assert len(cells)==4
inputs=attempt/'inputs';inputs.mkdir();shutil.copyfile(notebook,inputs/'fixed_pose_scoring.ipynb');source_record=Path(config['input']);assert sha(source_record)==config['input_sha256'];shutil.copyfile(source_record,inputs/'record.json');initial_input=source_record.read_bytes()
for i,source in enumerate(cells,1):(inputs/('cell-'+str(i)+'.py')).write_text(source)
completed=[];refusal=None;result_records={}
with puw.context(default_form='pint',default_parser='pint',standard_units=units):
 caller=puw.configure.report()
 import dockingmt as dmt
 import molsysmt as msm
 import vina
 assert dmt.__version__==artifact['version']==metadata.version('dockingmt')
 assert json.loads(metadata.distribution('dockingmt').read_text('direct_url.json'))['archive_info']['hashes']['sha256']==artifact['wheel_sha256']
 assert Path(vina.__file__).resolve().is_relative_to(engine/'lib/python3.14/site-packages/vina')
 for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']:assert Path(__import__(name).__file__).resolve().is_relative_to(root.parent/name/name)
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 for name in ['dock','optimize','randomize','poses','energies']:setattr(vina.Vina,name,forbidden)
 def native_observed(name,operation):
  signature=inspect.signature(operation)
  @wraps(operation)
  def call(self,*args,**kwargs):
   bound=signature.bind(self,*args,**kwargs);bound.apply_defaults();values={k:v for k,v in bound.arguments.items() if k!='self'}
   if name=='__init__':
    assert values['cpu']==1 and values['sf_name'] in ['vina','vinardo'];run_ids[id(self)]=engine_call_counts[name]+1
   elif name=='compute_vina_maps':
    assert len(values['center'])==len(values['box_size'])==3 and all(float(x)==0 for x in values['center']) and all(0<float(x)<=10 for x in values['box_size'])
   elif name=='score':assert values['unbound_energy'] is None
   elif name in ['poses','energies']:assert 1<=values['n_poses']<=2
   engine_call_counts[name]+=1;event={'call':name,'run':run_ids[id(self)],'outcome':'started','test_node':os.environ.get('PYTEST_CURRENT_TEST'),'parameters':{}};engine_calls.append(event)
   for key,value in values.items():
    if key in ['pdbqt_string']:continue
    if isinstance(value,(str,int,float,bool)) or value is None:event['parameters'][key]=value
    elif isinstance(value,(list,tuple)):event['parameters'][key]=[float(x) for x in value]
    elif hasattr(value,'tolist'):event['parameters'][key]=value.tolist()
   submissions=[]
   if name=='set_receptor':
    assert values.get('flex_pdbqt_filename') is None
    submissions=[('receptor',Path(values['rigid_pdbqt_filename']).read_bytes(),4)]
   elif name=='set_ligand_from_string':
    assert isinstance(values['pdbqt_string'],str);submissions=[('partner',values['pdbqt_string'].encode(),2)]
   elif name=='set_ligand_from_file':
    assert isinstance(values['pdbqt_filename'],str);submissions=[('partner',Path(values['pdbqt_filename']).read_bytes(),2)]
   for role,blob,maximum in submissions:
    atom_records=sum(line.startswith((b'ATOM  ',b'HETATM')) for line in blob.splitlines());assert 0<atom_records<=maximum and len(blob)<=65536
    target=attempt/'inputs/backend'/str(event['run'])/(role+'.pdbqt');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blob);event[role]={'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'atom_records':atom_records}
   start=time.perf_counter()
   try:result=operation(self,*args,**kwargs)
   except BaseException as error:event.update(outcome='raised',exception_type=type(error).__name__);raise
   else:
    event['outcome']='PASS'
    if isinstance(result,str):
     event['result_sha256']=hashlib.sha256(result.encode()).hexdigest()
     if name=='poses':
      target=attempt/'outputs/backend'/str(event['run'])/('poses-'+str(engine_call_counts[name])+'.pdbqt');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(result)
    elif getattr(result,'shape',None) is not None:
     event['result_shape']=list(result.shape)
     if name=='score':event['native_components']=result.tolist();event['native_unit']='kcal/mol'
    return result
   finally:event['elapsed_seconds']=time.perf_counter()-start;save(attempt/'engine-calls.json',engine_calls)
  return call
 for name in ['__init__','set_receptor','set_ligand_from_string','set_ligand_from_file','compute_vina_maps','score']:setattr(vina.Vina,name,native_observed(name,getattr(vina.Vina,name)))
 if reg['selection']=='records':
  vina.Vina=forbidden
 def observed(name,operation):
  def call(*args,**kwargs):provider_calls[name]+=1;return operation(*args,**kwargs)
  return call
 for name in ['convert','get','set','copy','select','extract','merge','append_structures','concatenate_structures','permute_atoms']:setattr(msm,name,observed(name,getattr(msm,name)))
 for name in ['assign_partial_charges','assign_autodock_atom_types','add_missing_hydrogens','merge_nonpolar_hydrogens']:setattr(msm.build,name,observed('build.'+name,getattr(msm.build,name)))
 assert Path(dmt.__file__).resolve().is_relative_to(site/'dockingmt')
 with tempfile.TemporaryDirectory(prefix='dmt-score-notebook-',dir='/tmp') as tmp:
  work=Path(tmp);record=work/'supplied_result.json';record.write_bytes(initial_input);os.environ['DOCKINGMT_RESULT_PATH']=str(record);os.environ['DOCKINGMT_RESULT_SHA256']=config.get('supplied_expected_sha256',config['input_sha256']);cwd=Path.cwd();namespace={'__name__':'__main__'}
  try:
   os.chdir(work)
   for i,source in enumerate(cells,1):
    try:
     with (attempt/('cell-'+str(i)+'.stdout.log')).open('x') as stream,redirect_stdout(stream):exec(compile(source,'fixed_pose_scoring.ipynb:cell-'+str(i),'exec'),namespace)
    except BaseException as error:
     with (attempt/'cell-refusal.log').open('x') as stream:traceback.print_exc(file=stream)
     refusal={'cell':i,'type':type(error).__name__,'message':str(error),'code':getattr(error,'code',None)};break
    else:completed.append({'cell':i,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'outcome':'PASS'})
  finally:os.chdir(cwd)
  assert record.read_bytes()==initial_input
  if config['mode']=='original-refusal':assert refusal and refusal['type']=='AssertionError' and refusal['cell']==1 and not engine_calls
  elif config['mode']=='bad-digest':assert refusal and refusal['type']=='ValueError' and refusal['cell']==1 and not engine_calls
  elif config['mode']=='missing-captures':assert refusal and refusal['cell']==1 and refusal['code']=='DMT-E002' and not engine_calls
  else:
   assert refusal is None and len(completed)==4 and engine_call_counts['score']==engine_call_counts['__init__']==2
   for name in ['first','second','restored']:result_records[name]=namespace[name].to_dict()
   assert len(result_records['first']['scores'])==8 and len(result_records['second']['scores'])==16 and len(result_records['restored']['scores'])==17
   assert len(result_records['second']['metadata']['scoring_history'])==len(result_records['restored']['metadata']['scoring_history'])==2
   save(attempt/'scoring-records.json',result_records)
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 assert not forbidden_operations
verify_receiver();assert cohort()==before and sha(notebook)==config['notebook_sha256'] and source_record.read_bytes()==initial_input and all(sha(engine/n)==digest for n,digest in engine_hashes.items())
native_maps={}
for line in Path('/proc/self/maps').read_text().splitlines():
 fields=line.split(None,5)
 if len(fields)==6 and fields[5].startswith('/') and '.so' in fields[5] and Path(fields[5]).is_file():native_maps[fields[5]]=sha(fields[5])
save(attempt/'native-maps.json',native_maps)
save(attempt/'receipt.json',{'profile':reg['profile'],'selection':reg['selection'],'mode':config['mode'],'completed_cells':len(completed),'cells':completed,'refusal':refusal,'expected_refusal_received':config['mode']!='revised','engine_call_counts':dict(engine_call_counts),'engine_calls':engine_calls,'forbidden_operations':forbidden_operations,'provider_call_counts':dict(provider_calls),'wheel_sha256':artifact['wheel_sha256'],'runtime_version':artifact['version'],'runtime_producer':artifact['source_commit'],'notebook_sha256':config['notebook_sha256'],'input_sha256':config['input_sha256'],'caller_policy_preserved':True,'original_producer':json.loads(initial_input).get('provenance',{}).get('dockingmt_version'),'cohort_unchanged':True,'outside_source_execution_root_retired':not Path(tmp).exists(),'no_sdk_harness_source_injection':True,'headless_not_actual_kernel':True,'new_accuracy_case':False,'full_public_platform_gate':False})
print(json.dumps({'mode':config['mode'],'completed_cells':len(completed),'refusal':refusal,'real_score_calls':engine_call_counts['score']}))
