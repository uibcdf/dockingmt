for evaluation in second.metadata['scoring_history']:
    report = {
        key: evaluation[key]
        for key in (
            'operation',
            'backend_version',
            'applied_parameters',
            'unused_search_parameters',
            'geometry_check',
        )
    }
    report['input_hashes'] = {
        role: record['sha256']
        for role, record in evaluation['backend_artifacts'].items()
    }
    report['preparation_assessment'] = {
        role: record['assessment_report']['assessment']
        for role, record in evaluation['preparation'].items()
    }
    print(json.dumps(report, indent=2))