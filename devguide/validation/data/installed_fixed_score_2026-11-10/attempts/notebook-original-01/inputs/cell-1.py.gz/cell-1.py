import base64
import json
import platform
import sys
from pathlib import Path
import numpy as np
import pyunitwizard as puw
import molsysmt as msm
import vina
import dockingmt as dmt

assert sys.version_info[:2] == (3, 14)
assert 'molsyssuite@uibcdf_3.14' in sys.executable
root = next(path for path in (Path.cwd(), *Path.cwd().parents) if (path / 'dockingmt').is_dir())
manifest = json.loads((root / 'devguide/validation/data/audit/minimal_vina_result.json').read_text())
artifacts = manifest['provenance']['backend_artifacts']
problem = dmt.DockingProblem(
    receptor=base64.b64decode(artifacts['receptor']['content_base64']).decode(),
    partner=base64.b64decode(artifacts['partner']['content_base64']).decode(),
    search_domain=dmt.BoxRegion.from_dict(manifest['problem_info']['search_domain']),
)
print(json.dumps({'python': platform.python_version(), 'interpreter': sys.executable,
                 'dockingmt': dmt.__version__, 'molsysmt': msm.__version__,
                 'vina': vina.__version__, 'molsysmt_source': str(Path(msm.__file__).parent)}, indent=2))
