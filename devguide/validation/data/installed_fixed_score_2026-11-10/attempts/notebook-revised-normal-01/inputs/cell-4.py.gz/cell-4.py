annotated = second.with_scores({'manual_review': 0.75})
assert 'manual_review' not in second.scores
assert 'manual_review' not in annotated.score_definitions  # Meaning remains undeclared.
restored = dmt.DockingPose.from_dict(
    json.loads(json.dumps(annotated.to_dict(), allow_nan=False))
)
assert restored.to_dict() == annotated.to_dict()
try:
    second.with_scores({'vina': 0.0})
except CatalogException as error:
    if error.code != 'DMT-E002':
        raise
    print(type(error).__name__ + ': an existing score cannot be replaced')
else:
    raise AssertionError('Existing scores were overwritten')
print(
    'Independent roundtrip:',
    len(restored.scores),
    'scores;',
    len(restored.metadata['scoring_history']),
    'native evaluations',
)