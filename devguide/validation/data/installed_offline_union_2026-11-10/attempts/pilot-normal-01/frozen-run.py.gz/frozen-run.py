"""Finite serial installed receiving with explicit resource and artifact binding."""
import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
root=Path(__file__).resolve().parents[2];task=Path(__file__).parent
label,selection,profile=sys.argv[1:];assert profile in ['normal','pm_fs']
attempt=task/label;attempt.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py';assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','group_members','stop_owned_group','monitor'}];assert len(nodes)==5
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':60,'cpu_hard_seconds':65,'wall_seconds':180}
def limits():
 os.sched_setaffinity(0,{policy['cpu']});os.setpriority(os.PRIO_PROCESS,0,policy['nice'])
 resource.setrlimit(resource.RLIMIT_AS,(policy['address_space_bytes'],policy['address_space_bytes']))
 resource.setrlimit(resource.RLIMIT_CPU,(policy['cpu_seconds'],policy['cpu_hard_seconds']))
estimate=(256 if selection=='pilot' else 512)*1024**2
assert available()>policy['available_reserve_bytes']+estimate
for name in ['run.py','worker.py',selection+'.json','expected-cohort.json','artifact.json','installation.json','qualification-inputs.json','selection-review.json','prior-receiving.json']:shutil.copyfile(task/name,attempt/('frozen-'+name))
shutil.copyfile(root/'devguide/validation/installed_offline_union_2026-11-10.md',attempt/'frozen-prescription.md');shutil.copyfile(guard,attempt/'frozen-resource-guard.py')
artifact=json.loads((attempt/'frozen-artifact.json').read_text());installation=json.loads((attempt/'frozen-installation.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
reg={'owner':'uibcdf/dockingmt#47','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'scope':'Complete original 26-module offline installed union; actual retained new wheel, zero actual molecular/native/viewer work','policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':estimate,'profile':profile,'selection':selection,'qualification_source':artifact['source_commit'],'runtime_source':artifact['source_commit'],'runtime_wheel_sha256':artifact['wheel_sha256'],'consumer_checkpoint_base':head,'frozen_sha256':{p.name:sha(p) for p in attempt.iterdir() if p.is_file()}}
(attempt/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
env=os.environ.copy();env.update(DMT_SMALL_ROOT=str(root),DMT_SMALL_TASK=str(task),DMT_SMALL_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(attempt/'tmp'),XDG_CACHE_HOME=str(attempt/'cache'),MPLCONFIGDIR=str(attempt/'mpl'),MAKEFLAGS='-j1',CMAKE_BUILD_PARALLEL_LEVEL='1')
env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
for name in ['tmp','cache','mpl']:(attempt/name).mkdir()
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:env[key]='1'
py=Path(installation['prefix'])/'bin/python'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
 usage_before=resource.getrusage(resource.RUSAGE_CHILDREN)
 process=subprocess.Popen([str(py),'-I','-B',str(attempt/'frozen-worker.py')],cwd=attempt,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);outcome=monitor(process,policy)
usage_after=resource.getrusage(resource.RUSAGE_CHILDREN);outcome['child_user_cpu_seconds']=usage_after.ru_utime-usage_before.ru_utime;outcome['child_system_cpu_seconds']=usage_after.ru_stime-usage_before.ru_stime
if outcome['termination_signal']==signal.SIGXCPU and outcome['resource_interruption'] is None:outcome['resource_interruption']='cpu_limit'
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
if (attempt/'receipt.json').exists():
 receipt=json.loads((attempt/'receipt.json').read_text());print(json.dumps({k:receipt[k] for k in ['counts','pytest_exit_code','engine_attempts','provider_call_counts','warnings','engine_call_counts'] if k in receipt}))
if outcome['outcome']!='PASS':print((attempt/'stdout.log').read_text()[-2400:]);print((attempt/'stderr.log').read_text()[-1400:]);raise SystemExit(1)
