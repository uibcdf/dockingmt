# Complete private installed offline union — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with
#30/#73 qualification and #50 custody. Status: registered; execution pending.
Documentation base `e7149cf7d72defa252bcb8e85ef03395838b5019`; runtime and
qualification-input producer `37a61e61db40f386a4ad031ecd14d578441f61ce`.

## Artifact and receiving boundary

Reuse the actual normally installed private wheel
`dockingmt-0.0.0+359.g37a61e6-py3-none-any.whl`, 157,933 B, SHA-256
`ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d`.
The [prior genuine build/install and native receiving](installed_allocation_fixes_2026-11-10.md)
keeps its immutable 419/14-member records and producer identity. Do not rebuild,
reinstall, relabel the earlier aeae47d file or transfer old evidence to this wheel.

Use the existing private receiver and independent Git-anchored qualification
harness at the runtime producer, with both runtime source directories removed.
Authenticate all 67 installed consumer files, reporting/unit files, actual
generated/metadata/imported version and PEP 610 wheel identity before/after each
cell. Check all 305 qualification inputs in both the harness and current source.
Clear inherited PYTHONPATH/PYTHONHOME; the shared SDK is the only added import
path. Use the shared multi-root installed-import validator and installed test
runner at `95f693be10c9205ab9b912cb53453710a207bf45`. No local staging replacement.

Keep the exact previously received MolSysMT 0c6f9c7, Viewer 1187fc18, ArgDigest
07126411, PyUnitWizard f82b618e, SMonitor c1b6ce29 and DepDigest 032d345b source/
Python/native cohort. Distribution labels remain separate from actual sources.
Original engine prefixes and previous build interruptions retain their custody;
this offline selection does not load or execute an optional engine.

## Original union, preservation and admission

Use the same 26 modules and three deselection prefixes as the original
[1,267-case union](record_wheel_inputs_2026-11-09.md), with its four actual native
cases explicitly deselected. The parametrized batch equivalence control accounts
for two cases, the intervening-file native batch control for one, and the fresh
native score/audit control for one. Their earlier live qualification remains a
separate population; these exclusions do not become new passing native evidence.

The new union expects **1,287 executed cases per unit policy**: the original 1,267,
sixteen #107 geometry-resource/ordinary-diagnostic controls and four #106 batch
allocation/ordinary-I/O controls. Module counts must equal the original counts
plus those exact increments. Preserve all original selected function/class ASTs;
the changed fresh-native function remains explicitly outside this selection.
Retain the original baseline files and authenticated old final JUnit record.
Controlled fakes retain their original assertions and are not actual provider or
native work. Test counts are software coverage, not scientific observations.

First run the complete twelve-case public exception module under the normal
policy, plus an actual installed roundtrip, thirteen alias identities and four
shared-validator refusals in fresh child processes. Then run the complete union
normal followed by pm/fs, on identical worker/selection/artifact/test/cohort bytes.
Observe actual collection before execution: require every module count, all
1,287 selected node identities and precisely four native deselections. Retain
complete JUnit/Receptor/exit-code streams; require unchanged caller unit policy.

Forbid actual MolSysMT geometry/preparation/reader operations, Viewer construction
and Vina/RDKit/OpenMM imports. The saved-audit child keeps its original explicit
optional-provider refusal and assertions. No search, score, preparation, geometry,
canvas, notebook replay or new scientific case is admitted. Use the shared
606-input support declaration and verify complete staging/retirement per cell.

## Shared resources, stop policy and custody

Preflight: 64,978,440,192 B physical/60,555,644,928 B available RAM, 20 logical
CPUs, load 1.39/1.08/0.94, about 94.7% sampled idle and zero memory PSI averages.
The one-second swap interval has two pages in/zero out; allocated swap alone is
not active memory pressure. Disk free is 38,934,986,752 B. Slurm exists without an
allocation; earlier applicability was inconclusive. Capacity is not reserved.

Run cells serially on CPU 0/nice 10, with one native/build worker and the same
affinity on heavy descendants. Estimate 256 MiB pilot/512 MiB whole-cell RSS;
bound group RSS at 1 GiB and address space at 2 GiB. Preserve a 13 GiB available
RAM reserve, monitor owned descendants, limit CPU to 60/65 seconds and wall time
to 180 seconds per test cell. Administrative readers use 45 CPU/60 wall seconds.
Preserve every interrupted attempt; stop only owned work and never automatically
restart after a headroom interruption. No native/provider rebuild or shared install.

Retain `.molsyssuite/installed-offline-union-20261110` under #47/#50, review
2026-11-14; preserve the reused wheel/receiver/source-free harness and original
engine/SDK resources. Managed reader/export scratch retires. Preserve human
migration files and all original observations/producers. Seal the actual results
and independently authenticate stored evidence without replay. Update maintained
checkpoints, run applicable local/fresh committed-export checks and publish a
direct `[skip ci]` checkpoint. No remote CI or package publication is dispatched.

Full #47/#30/#73, public Conda/same-byte closure/eight OS-minor lanes, hosted/SSH
source-context, original panel/provider and real kernel/comm/browser/canvas gates
remain separate. This qualification creates no release or distribution route.


## Pilot witness amendment before the whole union

The first pilot passes all twelve public cases and the four original refusal
probes, with zero failures/errors/skips/warnings. Its source-addon probe also
imports a foreign core; the shared validator correctly refuses that core first.
This is an original passing mixed-origin refusal, not an isolated addon witness.
Preserve the complete pilot-01 population and its exact reason.

For pilot-02, first import the installed core and assert that the addon is absent,
then expose the source addon. Require the actual validator diagnostic to name
`molsysviewer_dockingmt`. Keep all original public cases and the other three
refusals unchanged. Require this stronger pilot before either whole profile;
the paired whole workers remain byte-identical. No shared validator or runtime
change is needed. The first measured peak is 273,944,576 B, slightly above the
256 MiB estimate and far below the 1 GiB cap; refine the next pilot estimate to
384 MiB without raising any hard bound. No resource interruption occurred.
