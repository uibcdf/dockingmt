"""Receive the original offline union through the shared installed runner."""
import functools
import hashlib
import importlib.abc
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib
import xml.etree.ElementTree as ET
from collections import Counter

root = Path(os.environ['DMT_SMALL_ROOT'])
task = Path(os.environ['DMT_SMALL_TASK'])
attempt = Path(os.environ['DMT_SMALL_ATTEMPT'])
reg = json.loads((attempt / 'registration.json').read_text())

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

assert os.sched_getaffinity(0) == {0}
assert os.getpriority(os.PRIO_PROCESS, 0) >= 10
sdk = root / '.molsyssuite/publication-sdk'
assert subprocess.check_output(['git', '-C', str(sdk), 'rev-parse', 'HEAD'], text=True).strip() == '95f693be10c9205ab9b912cb53453710a207bf45'
assert not subprocess.check_output(['git', '-C', str(sdk), 'status', '--porcelain'])
artifact = json.loads((attempt / 'frozen-artifact.json').read_text())
installed = json.loads((attempt / 'frozen-installation.json').read_text())
site = Path(installed['site'])
harness = Path(installed['harness'])
inputs = json.loads((attempt / 'frozen-qualification-inputs.json').read_text())
selection = json.loads((attempt / ('frozen-' + reg['selection'] + '.json')).read_text())
review = json.loads((attempt / 'frozen-selection-review.json').read_text())
assert artifact['source_commit'] == '37a61e61db40f386a4ad031ecd14d578441f61ce'
assert artifact['version'] == '0.0.0+359.g37a61e6'
assert sha(artifact['wheel']) == artifact['wheel_sha256'] == 'ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d'
assert Path(sys.prefix) == Path(installed['prefix'])
assert not any((harness / name).exists() for name in ['dockingmt', 'molsysviewer_dockingmt'])

def verify():
    for group in ['consumer_sha256', 'tool_sha256', 'unit_sha256']:
        for name, digest in installed[group].items():
            assert sha(site / name) == digest, name
    for name, digest in inputs.items():
        assert sha(harness / name) == digest == sha(root / name), name

def cohort():
    return {name: {
        'commit': subprocess.check_output(['git', '-C', str(root.parent / name), 'rev-parse', 'HEAD'], text=True).strip(),
        'status': subprocess.check_output(['git', '-C', str(root.parent / name), 'status', '--porcelain'], text=True),
        'python_sha256': {str(p.relative_to(root.parent / name)): sha(p) for p in (root.parent / name / name).rglob('*.py')},
        'native_sha256': {str(p.relative_to(root.parent / name)): sha(p) for p in (root.parent / name / name).rglob('*.so')},
        'distribution_version': metadata.version(name),
    } for name in ['molsysmt', 'molsysviewer', 'argdigest', 'pyunitwizard', 'smonitor', 'depdigest']}

verify()
before = cohort()
assert before == json.loads((attempt / 'frozen-expected-cohort.json').read_text())
save(attempt / 'cohort.json', before)
inventory = tomllib.loads((harness / 'devtools/conda-build/resources.toml').read_text())
assert len(inventory['installed_tests']['support']['files']) == 606
shutil.copyfile(harness / 'devtools/conda-build/resources.toml', attempt / 'frozen-resources.toml')
sys.path.insert(0, str(sdk))
assert root not in [Path(p).resolve() for p in sys.path if p]
assert harness not in [Path(p).resolve() for p in sys.path if p]
from devtools.scripts.installed_imports import check_installed_imports, runtime_import_roots
from devtools.scripts.installed_noarch import run_tests
import pyunitwizard as puw

units = ['nm', 'ps', 'K', 'mole', 'dalton', 'e', 'kJ/mol', 'radians'] if reg['profile'] == 'normal' else ['pm', 'fs', 'K', 'mole', 'dalton', 'coulomb', 'J/mol', 'radians']
forbidden = []
optional = ['vina', 'rdkit', 'openmm']

class BlockEngines(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in optional:
            forbidden.append(fullname)
            raise AssertionError('Offline installed receiving imported an optional engine: ' + fullname)

assert not set(optional).intersection(sys.modules)
sys.meta_path.insert(0, BlockEngines())

def blocked(name, operation):
    @functools.wraps(operation)
    def call(*args, **kwargs):
        forbidden.append(name)
        raise AssertionError('Offline installed receiving attempted actual molecular/viewer work: ' + name)
    return call

with puw.context(default_form='pint', default_parser='pint', standard_units=units):
    caller = puw.configure.report()
    roots = runtime_import_roots(inventory, 'dockingmt')
    assert roots == ('dockingmt', 'molsysviewer_dockingmt') or list(roots) == ['dockingmt', 'molsysviewer_dockingmt']
    origins_before = check_installed_imports(roots, Path(sys.prefix), harness)
    import dockingmt as dmt
    import molsysmt as msm
    import molsysviewer as msv
    assert dmt.__version__ == artifact['version'] == metadata.version('dockingmt')
    assert json.loads(metadata.distribution('dockingmt').read_text('direct_url.json'))['archive_info']['hashes']['sha256'] == artifact['wheel_sha256']
    for name in before:
        assert Path(__import__(name).__file__).resolve().is_relative_to(root.parent / name / name)
    for name in ['convert', 'get', 'set', 'copy', 'select', 'extract', 'merge', 'append_structures', 'concatenate_structures', 'permute_atoms']:
        setattr(msm, name, blocked('molsysmt.' + name, getattr(msm, name)))
    for name in ['assign_partial_charges', 'assign_autodock_atom_types', 'add_missing_hydrogens', 'merge_nonpolar_hydrogens']:
        setattr(msm.build, name, blocked('molsysmt.build.' + name, getattr(msm.build, name)))
    for namespace, name in [(msm.structure, 'get_rmsd'), (msm.form.string_pdbqt_text, 'read_poses'), (msm.form.file_pdbqt, 'read_poses')]:
        setattr(namespace, name, blocked(namespace.__name__ + '.' + name, getattr(namespace, name)))
    msv.MolSysView = blocked('molsysviewer.MolSysView', msv.MolSysView)
    aliases = dmt.exceptions
    implementation = sys.modules[aliases.ArgumentError.__module__]
    assert len(aliases.__all__) == 13
    assert all(getattr(aliases, n) is getattr(implementation, n) for n in aliases.__all__)
    refusals = []
    if reg['selection'] == 'pilot':
        pose = dmt.DockingPose(puw.quantity([[0, 0, 0]], 'angstrom'))
        result = dmt.DockingResult([pose])
        assert dmt.DockingResult.from_dict(result.to_dict()).to_dict() == result.to_dict()
        code = '''import json,sys,tomllib
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from devtools.scripts.installed_imports import check_installed_imports,runtime_import_roots
from devtools.scripts.noarch_conda import ContractError
mode=sys.argv[2];source=Path(sys.argv[3]);harness=Path(sys.argv[4]);inventory=tomllib.loads((harness/'devtools/conda-build/resources.toml').read_text());inventory['import_name']='dockingmt'
if mode=='source_addon':
 import dockingmt
 assert 'molsysviewer_dockingmt' not in sys.modules
try:
 if mode=='omitted_addon':
  inventory['import_roots']=['dockingmt'];runtime_import_roots(inventory,'dockingmt')
 else:
  if mode in ['source_core','source_addon']:sys.path.insert(0,str(source))
  if mode=='source_addon':import molsysviewer_dockingmt
  else:
   import dockingmt
   if mode=='package_path':dockingmt.__path__.append(str(source/'dockingmt'))
  check_installed_imports(('dockingmt','molsysviewer_dockingmt'),Path(sys.prefix),harness)
except ContractError as exc:print(json.dumps({'mode':mode,'refused':True,'reason':str(exc)}))
else:raise AssertionError('Expected shared validator refusal')
'''
        for mode in ['source_core', 'source_addon', 'package_path', 'omitted_addon']:
            child = subprocess.run([sys.executable, '-I', '-B', '-c', code, str(sdk), mode, str(root), str(harness)], cwd=attempt, capture_output=True, text=True)
            (attempt / (mode + '.stdout')).write_text(child.stdout)
            (attempt / (mode + '.stderr')).write_text(child.stderr)
            assert child.returncode == 0, (mode, child.stderr[-1200:])
            witness = json.loads(child.stdout)
            if mode == 'source_addon':
                assert 'molsysviewer_dockingmt' in witness['reason']
            refusals.append(witness)
    elif reg['profile'] == 'normal':
        assert json.loads((task / 'pilot-normal-02/resource-outcome.json').read_text())['outcome'] == 'PASS'
    else:
        previous = task / 'whole-normal-01'
        assert json.loads((previous / 'resource-outcome.json').read_text())['outcome'] == 'PASS'
        for name in ['worker.py', 'whole.json', 'qualification-inputs.json', 'expected-cohort.json', 'artifact.json', 'installation.json', 'selection-review.json']:
            assert (previous / ('frozen-' + name)).read_bytes() == (attempt / ('frozen-' + name)).read_bytes()

    import pytest
    selected_nodes = []
    deselected_nodes = []
    def normalized(item):
        return str(Path(item.path).relative_to(harness)) + '::' + item.nodeid.split('::', 1)[1]
    class ObserveCollection:
        def pytest_deselected(self, items):
            deselected_nodes.extend(normalized(item) for item in items)

        @pytest.hookimpl(trylast=True)
        def pytest_collection_finish(self, session):
            selected_nodes.extend(normalized(item) for item in session.items)
            module_counts = dict(Counter(n.split('::')[0].removesuffix('.py').replace('/', '.') for n in selected_nodes))
            save(attempt / 'collection.json', {'selected': selected_nodes, 'deselected': deselected_nodes, 'module_counts': module_counts})
            if reg['selection'] == 'whole':
                assert len(selected_nodes) == review['expected_cases'] == 1287
                assert len(deselected_nodes) == review['expected_deselected'] == 4
                assert module_counts == review['expected_module_counts']
                assert all(any(n == p or n.startswith(p + '[') for p in review['deselection_prefixes']) for n in deselected_nodes)
            else:
                assert len(selected_nodes) == 12 and not deselected_nodes

    original_main = pytest.main
    @functools.wraps(original_main)
    def observed_main(*args, **kwargs):
        kwargs['plugins'] = [*kwargs.get('plugins', []), ObserveCollection()]
        return original_main(*args, **kwargs)
    pytest.main = observed_main
    inventory['import_name'] = 'dockingmt'
    inventory['installed_tests']['paths'] = [n for n in selection if not n.startswith('--')]
    inventory['installed_tests']['pytest_args'] = ['--receptor=llm', '--receptor-events=' + str(attempt / 'events.jsonl'), '--junitxml=' + str(attempt / 'junit.xml'), '-o', 'cache_dir=' + str(attempt / 'pytest-cache'), '--basetemp=' + str(attempt / 'pytest-work')] + [n for n in selection if n.startswith('--')]
    try:
        status = int(run_tests(harness, inventory, support_output=attempt / 'support-sidecar.json', support_context={'sha256': artifact['wheel_sha256'], 'provider_sha': '95f693be10c9205ab9b912cb53453710a207bf45', 'candidate_sha': artifact['source_commit']}))
    finally:
        pytest.main = original_main
    caller_after = puw.configure.report()
    for key in ['default_form', 'default_parser', 'standard_units']:
        assert caller[key] == caller_after[key]
    origins_after = check_installed_imports(roots, Path(sys.prefix), harness)

counts = {k: sum(int(row.get(k, '0')) for row in ET.parse(attempt / 'junit.xml').getroot().iter('testsuite')) for k in ['tests', 'failures', 'errors', 'skipped']}
from pytest_receptor import read_artifact
events = read_artifact(attempt / 'events.jsonl')
assert events.complete
verify()
assert cohort() == before and not forbidden and not set(optional).intersection(sys.modules)
support = json.loads((attempt / 'support-sidecar.json').read_text())
assert len(support['files']) == 606 and support['imports_retired'] and support['resources_retired']
save(attempt / 'receipt.json', {'profile': reg['profile'], 'selection': selection, 'pytest_exit_code': status, 'counts': counts, 'receptor_final': events.final.data, 'warnings': events.final.data['counts']['warnings'], 'selected_nodes': selected_nodes, 'deselected_nodes': deselected_nodes, 'forbidden_operations': forbidden, 'actual_molecular_native_viewer_calls': 0, 'optional_engines_loaded': [], 'wheel_sha256': artifact['wheel_sha256'], 'runtime_version': dmt.__version__, 'qualification_source': artifact['source_commit'], 'installed_origins_before': origins_before, 'installed_origins_after': origins_after, 'cohort_unchanged': True, 'caller_policy_before': caller, 'caller_policy_after': caller_after, 'support_inputs': 606, 'public_exception_aliases': 13, 'refusals': refusals, 'positive_roundtrip': reg['selection'] == 'pilot', 'full_scientific_public_platform_gate': False})
raise SystemExit(status)
