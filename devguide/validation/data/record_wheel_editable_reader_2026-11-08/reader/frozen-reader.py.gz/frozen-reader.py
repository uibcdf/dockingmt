"""Read private installed records through published native reporting, without replay."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import tomllib
import xml.etree.ElementTree as ET

_tool_path=Path(__file__).resolve().parents[1]/'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_path.read_bytes()).hexdigest()=='6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool=json.loads(_tool_path.read_text());_prefix=Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()}==_tool['files_sha256']
sys.path.insert(0,str(_prefix))
from pytest_receptor import read_artifact


def verify_records(records):
 def obj(name):return json.loads(records[name])
 def prefix(label):return 'attempts/'+label+'/'
 wheel='13169bd91cc90a16bd3b8f60329856ee2cb1921a0dd69ebb598230f543e6fa92'
 expected={'build-01':False,'red_admin-01':False,'red_admin-02':False,'green_admin-01':True,'inspect-01':True,'setup-01':True,'pilot-01':True,'normal-01':True,'pm_fs-01':True}
 for label,passed in expected.items():
  p=prefix(label);r=obj(p+'resource-outcome.json');reg=obj(p+'registration.json')
  assert r['outcome']==('PASS' if passed else 'FAIL') and r['exit_code']==(0 if passed else 1)
  assert r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids']
  assert r['minimum_available_bytes']>=13*1024**3 and r['sampled_peak_group_rss_bytes']<1024**3 and r['elapsed_seconds']<=60
  assert r['policy']==reg['policy'] and r['policy']['cpu']==0 and r['policy']['nice']==10 and r['policy']['workers']==1
  for name,digest in reg['frozen_sha256'].items():assert hashlib.sha256(records[p+name]).hexdigest()==digest
  if label!='build-01':
   receipt=obj(p+'receipt.json');assert receipt['outcome']==r['outcome'] and receipt['qualification_complete']
 assert wheel.encode() in records[prefix('build-01')+'build.log']
 assert b'AssertionError' in records[prefix('build-01')+'stderr.log']
 old=tomllib.loads(records['producer/original-resources.toml'].decode());new=tomllib.loads(records[prefix('inspect-01')+'frozen-resources.toml'].decode())
 assert len(old['required_paths'])==65 and len(new['required_paths'])==66
 assert set(new['required_paths'])-set(old['required_paths'])=={'site-packages/dockingmt/interactions.py'}
 altered=dict(new);altered['required_paths']=old['required_paths'];assert altered==old
 artifact=obj('producer/artifact.json');installation=obj('producer/installation.json')
 assert artifact['wheel_sha256']==wheel and artifact['version']=='0.0.0+339.g6310a97' and artifact['source_commit']=='6310a97b7a900f31d37f84a476bc355a899282de'
 runtime={x.removeprefix('site-packages/') for x in new['required_paths']}
 assert runtime==set(installation['consumer_sha256'])
 for name in runtime:assert installation['consumer_sha256'][name]==artifact['payload_sha256'][name]
 for name,digest in artifact['source_sha256'].items():assert artifact['payload_sha256'][name]==digest
 for name,digest in installation['tests_sha256'].items():assert hashlib.sha256(records['tests/'+name]).hexdigest()==digest
 assert len(installation['tests_sha256'])==19
 meta=records[prefix('inspect-01')+'METADATA'].decode();assert 'Version: '+artifact['version'] in meta and 'License-Expression: MIT' in meta
 pilot=obj(prefix('pilot-01')+'receipt.json');assert pilot['positive_roundtrip'] and len(pilot['refusals'])==4 and all(x['refused'] for x in pilot['refusals'])
 assert {x['mode'] for x in pilot['refusals']}=={'source_core','source_addon','package_path','omitted_addon'}
 source_cohort=records['producer/cohort.json']
 for label in expected:
  if prefix(label)+'cohort.json' in records:assert records[prefix(label)+'cohort.json']==source_cohort
 for label,total,fail,code,executed,subtests in [('red_admin-01',0,0,4,0,0),('red_admin-02',1,1,1,1,0),('green_admin-01',24,0,0,19,5),('normal-01',990,0,0,990,0),('pm_fs-01',990,0,0,990,0)]:
  p=prefix(label);r=obj(p+'receipt.json');assert r['pytest_exit_code']==code and r['counts']=={'tests':total,'failures':fail,'errors':0,'skipped':0}
  counts={k:0 for k in ['tests','failures','errors','skipped']}
  for row in ET.fromstring(records[p+'junit.xml']).iter('testsuite'):
   for k in counts:counts[k]+=int(row.get(k,'0'))
  assert counts==r['counts']
  with tempfile.TemporaryDirectory(prefix='dmt-wheel-record-reader-',dir='/tmp') as tmp:
   f=Path(tmp)/'events.jsonl';f.write_bytes(records[p+'events.jsonl']);event=read_artifact(f)
   assert event.complete and event.final.data==r['receptor_final'];final=event.final.data;c=final['counts']
   assert final['exitstatus']==code and c['collected']==c['executed']==executed and c['failed']==fail and c['passed']==executed-fail
   assert c.get('subtests',{}).get('passed',0)==subtests and c['not_executed']==c['skipped']==0
   assert c['deselected']==(1 if label in ['normal-01','pm_fs-01'] else 0)
   assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
  if label in ['normal-01','pm_fs-01']:
   assert r['wheel_sha256']==wheel and not r['molecular_calls_attempted'] and r['source_free_harness']
   assert set(r['installed_origins']['roots'])=={'dockingmt','molsysviewer_dockingmt'} and 'dockingmt.interactions' in r['installed_origins']['loaded']
   sidecar=obj(p+'support-sidecar.json');assert sidecar==r['support'] and sidecar['checks']==7 and len(sidecar['files'])==594
   assert sidecar['imports_retired'] and sidecar['resources_retired'] and sidecar['state']=='verified-support'
   assert sidecar['executed_tests']==990 and sidecar['pytest_exit_code']==0
   assert sum(x['kind']=='code' for x in sidecar['files'])==30 and sum(x['kind']=='data' for x in sidecar['files'])==564
   context=sidecar['binding']['context'];assert context['sha256']==wheel and context['provider_sha']=='95f693be10c9205ab9b912cb53453710a207bf45'
   assert context['qualification_sha'] is None and context['candidate_sha'] is None and sidecar['binding']['source_state']=='unknown'
   assert sidecar['binding']['provider_state']=='verified-commit-and-runner-files'
 normal=prefix('normal-01');pm=prefix('pm_fs-01')
 for name in ['frozen-worker.py','frozen-run.py','frozen-selection.json','frozen-resources.toml','frozen-reporting-tools-receipt.json','frozen-unit-support-receipt.json']:
  assert records[normal+name]==records[pm+name]
 assert obj(normal+'receipt.json')['caller_policy']['standard_units'][:2]==['nm','ps']
 assert obj(pm+'receipt.json')['caller_policy']['standard_units'][:2]==['pm','fs']
 for name,module in tuple(sys.modules.items()):
  if name=='pytest_receptor' or name.startswith('pytest_receptor.'):
   path=Path(module.__file__).resolve();assert path.is_relative_to(_prefix) and hashlib.sha256(path.read_bytes()).hexdigest()==_tool['files_sha256'][str(path.relative_to(_prefix))]
 assert not any(x=='dockingmt' or x.startswith(('dockingmt.','molsysmt','molsysviewer','vina','rdkit','unyt','sympy','mpmath')) for x in sys.modules)
 return {'complete_profiles':['normal','pm_fs'],'cases_per_profile':990,'source_admin_tests':19,'source_admin_passed_subtests':5,'original_descriptor_failure_preserved':True,'original_guard_failures_preserved':1,'zero_test_usage_failure_preserved':True,'same_original_wheel':wheel,'runtime_paths':66,'support_files':594,'validator_refusals':4,'source_runtime_tests_unchanged':True,'native_reporting_and_junit_agree':True,'molecular_replay':False,'scope':'Private wheel with exact editable siblings on Linux/Python3.14; not public/full installed/matrix qualification'}
