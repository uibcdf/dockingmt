# Native unevaluated interaction-family receiving — 2026-11-07

Owner: [DockingMT #80](https://github.com/uibcdf/dockingmt/issues/80).
Registered before execution after the maintainer resumed the complete objective.
Outcome: **not executed at registration**. This is a separate information-state
control, not an amendment of the completed installed-binding population.

## Question and existing evidence

Does the actual installed `bind_interactions`/`PoseInteractions` API preserve a
native named family with zero evaluated frames, distinctly from an evaluated
empty family, through copying, queries and full-carrier persistence?

[The preceding installed receiving](e4_pose_binding_installed_2026-11-07.md)
passes evaluated positive/empty analyses and refusals. Its native unevaluated-family
flag remains false. Its two failed clients, two failed readers and passing records
remain immutable. Source doubles cannot answer this new native question.

Qualification repository base is `daa6da9cecad53eddbb83663b8d3ffec2e431097`.
Reuse the exact private consumer wheel from source
`cfff3866d511e7f1d202e3e03dd8c54a38963dc2`, version `0.0.0+307.gcfff386`,
SHA-256 `bc6da61abcb51a6950b2c5ed388616a70dd7cd393056c2b98d3665f9a40d1c51`.
No rebuild, installation or dependency solve is needed. Its 74 consumer files,
3794 provider files and 641-file import-only Viewer overlay keep their byte
identities and distinct producers. MolSysMT remains `9e1f1b1ad8bf09446374ab6f04ca7208e2717936`;
Viewer remains `78ede79e2e345593db5bfe80d246d3f6c70bd005`. No View is created.
Publication SDK is `95f693be10c9205ab9b912cb53453710a207bf45`.

## Supported derivation and finite population

Use MolSysMT's public `Interactions.invalidate_structures([0])` on the full
saved retained-pose `hbonds` analysis. Its documented contract returns a new
full result with unchanged atom/frame domains, removed selected observations
and unevaluated coverage; it leaves the source and existing queries intact and
never invokes a detector. Attach that result to an owned complete-carrier copy
through the public `MolSys.interactions` setter. Do not edit private arrays,
invent a molecular codec, change coordinates or relabel the original producer.
This is an explicitly derived invalidation control, not a new molecular measurement.

Receive the same original 3238-atom/one-frame carriers and full five-pose result
from original scientific producer `5952053328aac6f737e22906e984c0f9eb938dd7`.
Resolve exact input descriptors through the immutable 238-member archive
`e4_saved_carrier_receiving_2026-11-07`, manifest SHA-256
`73c8114368f0d7011d2e27d229662bf29be1f99bea27c0e0a24065f077e04b4d`.
The original result compressed/decoded SHA-256 remain respectively
`4b1f51cdeb135fd6785a181f6bb09a0d0f631ec3d9de7c169c88703748924249` and
`ed0eeb3ade25e54f8a5829729578fcbec9f0d73d6c0ceb03d146b0c3492d7fac`.

Two bindings per profile:

1. The original retained pose at zero-based index 0, bound to the derived carrier.
   `hbonds` has zero observations and no evaluated frames; the original full
   hydrophobic analysis retains its two observations and evaluated frame 0.
   The complete original five-pose result, scores and provenance remain exact.
2. The separately identified translated saved-carrier control from the previous
   recipe. Both families are evaluated on frame 0 with zero observations. It
   retains its own input-derived ID/provenance and no original score/rank; it
   does not become a sixth original pose or an independent scientific case.

Historical association position 1 is one-based; convert explicitly to API index
0. The declared atom correspondence contains two columns. Preserve its ordered
13 mapped atoms at carrier indices 3220–3232, all 18 ligand atoms, both known
state IDs and the explicit common-frame declaration. Four other original poses
remain unevaluated. No analysis is broadcast or projected to another carrier.

## Acceptance, limits and failure policy

Run normal first, then pm/fs in a fresh isolated process only after the complete
normal selection passes with identical frozen worker/controller/candidate/SDK.
Retain both original native sources before/after, the derived native carrier,
each full analysis payload and exact original result JSON. Verify source
nonmutation, detached accessor mutation controls, provider queries/pages and
two complete H5MSM 0.5 carrier write/readbacks per profile. Mechanical fields
remain absent; topology, chemical states and structure associations stay exact.
Coordinates/box preserve units, shapes/dtypes and explicit physical agreement
at rtol 0, absolute tolerance 1e-12 angstrom. The caller's unit policy is active
before sibling imports and is preserved/restored.

Require `analysis_evaluated['hbonds'] is False` on the invalidated carrier and
true on the evaluated-empty control, with empty evaluated-frame arrays versus
`[0]` in complete payloads and query pages before/after persistence. Retain
original method/parameters/units/source maps/software/execution metadata;
record the control derivation separately. Repeat all fourteen preceding binding,
missing-name and provider query-as-full refusals. Exit zero alone is insufficient:
all semantic completion steps, call counts and terminal resource receipts must pass.

Reuse the exact frozen resource guard functions SHA-256
`3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d`
under MolSysSuite #173. Run serially on CPU0, nice10, one native/build worker;
reserve 8 GiB available RAM, group RSS at most 1 GiB, address space 2 GiB,
45 CPU seconds and 60 wall seconds per profile. Monitor owned descendants;
preserve every failure/interruption, stop only owned work and never automatically
restart after a headroom interruption.

Receiver caps per profile: fourteen binding attempts, two result/two pose/nine
analysis/four carrier accessors, four queries/pages/inspections, twelve native
snapshots, 128 typed exports, one adverse extraction, one empty-analysis store,
one invalidation and one complete derivation copy. Provider-entry caps: convert
128, copy40, get640, has_attribute160, extract1, H5 reads4/writes2, analysis
copy160/remap12/invalidation1 and typed exports128. All direct and observed
provider calls count, including calls made by defensive copies.

No docking, scoring, preparation, H/charge/type assignment, new interaction
detection, RMSD/geometry transformation, alignment, View or manual hosted CI is
allowed. Python uses `-B -I -S`, explicit installed origins and byte checks,
no editable finder and before/after shared Conda metadata equality.

Raw attempts and sources live under `.molsyssuite/e4-native-unevaluated-20261107`,
custody #50, review 2026-11-14. Seal new outputs and failed attempts separately;
do not modify earlier archives. A detached standard-library record reader must
verify stored/decoded hashes, coverage distinctions, original-source/result
nonmutation and the declared cross-profile unit-bearing agreement without
molecular imports or replay. Reader sealing/verification are bounded record
operations, not new scientific cases or producer authentication.

Even a pass accepts only this information-state control. #80 remains partial;
actual addon/scene association, canvas #52/#60, other-carrier correspondence,
E3/MolSysMT #604, independent science/reproduction, public delivery and full
#73 keep separate requirements. Next after a pass: admit the actual single-frame
addon binding through supported scene axes, preserving the complete result and
refusing unknown axes or broadcasts to other poses.

## First receiving and diagnostic amendment before retry

`normal-01` fails after one invalidation, two accepted bindings, four detached
analysis accesses, two provider queries/pages and the first full-carrier write/
readback. The assertion comparing the restored full analysis payload to its
pre-write witness fails. Its native molecular-state roundtrip passes before that
assertion, but this does not accept complete interaction persistence. The process
is terminal after 19.341 s with 536,072,192 bytes sampled group RSS, no resource
interruption and no remaining owned descendant. pm/fs is not started.

Before retry, preserve complete original/derived/pre-write/restored analysis
payloads and a recursive list of differing fields before asserting equality.
The same complete selection, frozen candidate, resource/call limits and exact
equality requirements remain. This diagnostic amendment adds no detector,
molecular transformation, provider patch or passing exception. A further
failure remains failed. Static review suspects unused evidence-label retention:
the HDF5 reader reconstructs labels from active occurrence rows, whereas full
invalidation retains the original label catalog. That is a hypothesis until the
new diagnostic witnesses establish the actual difference. The same read path is
present at fetched MolSysMT `aadefc11df537622602770be2044aa6b75c0f73d`;
that newer source is inspected, not runtime-qualified. Both provider checkouts
remain clean and unchanged despite being behind fetched main.

## Confirmed provider finding and separate empty-source population

`normal-02` fails at the same complete-payload assertion in 19.424 s with
534,171,648 bytes sampled group RSS, no resource interruption and a terminal
owned group. Its explicit delta contains only
`$.hbonds.evidence_labels`: `['baker_hubbard_hbond_geometry']` becomes `[]`.
Coverage stays unevaluated, observations remain zero and other complete payload
fields compare equal. The positive-source invalidation composition remains
**failed**, handed to [MolSysMT #642](https://github.com/uibcdf/molsysmt/issues/642).
pm/fs for that composition is not executed. Do not strip the original labels,
weaken complete equality or count this as passing invalidation persistence.

A **separate population**, registered before its own execution, receives native
zero-evaluated-frame coverage from an already evaluated-empty saved family.
Invalidate frame 0 of the translated control's `hbonds` through the same public
operation; its existing evidence-label table is empty before the edit. Leave
the retained positive carrier unchanged. Thus the first binding has original
3/2 observations and both families evaluated; the separate translated binding
has zero observations in both families, with `hbonds` unevaluated and
`hydrophobic` evaluated. Preserve all original and derived payloads with exactly
the same complete equality, refusal, unit, custody and resource gates.

Name these attempts `empty-normal-01`, then `empty-pm-fs-01` only after normal
passes. Freeze this revised worker separately. The earlier positive-derived
attempts and scripts are retained and remain failed; this population cannot
clear #642. It answers the remaining native information-state question without
changing provider code or inventing molecular observations. A pass is limited
to empty-source invalidation and does not qualify persistence after invalidating
positive observations. Both the independent reader and maintained checkpoint
must retain that distinction explicitly.

## Wall interruption and focused selection registered before execution

`empty-normal-01` is **resource-interrupted**, not passing: the 60 s wall guard
stops its owned group at 60.071 s, sampled peak RSS 622,927,872 bytes. Available
RAM stays above the reserve; this is a wall interruption, not a headroom stop.
Both carrier roundtrips and fourteen expected refusals have returned, but final
source/custody/completion receipts are unreached. pm/fs is not started. Preserve
the entire interrupted selection; its completed pieces do not become a pass.

Register a fresh, narrower information-state selection as `focused-normal-01`,
then `focused-pm-fs-01` only after full normal completion. The installed API,
worker isolation and resource limits are unchanged. There is no implementation
change requiring repetition of every earlier general binding refusal: those
fourteen controls retain their preceding installed qualification at the exact
same consumer/provider bytes. This focused selection completes both bindings,
all four analysis queries/pages, both full-carrier roundtrips, source/carrier/
analysis detachment and nonmutation, caller-policy/origin/custody checks, the
unknown-analysis-name refusal and provider query-as-full refusal. Receiver caps
become two binding attempts, no adverse extraction/empty-store operation, and
the same remaining caps; completion requires exactly two refusals. No prior
partial outcome is reused as completion of this selection.

Add exact before/after full analysis payloads of both original carriers, in
addition to native molecular snapshots, and record child CPU usage beside wall
time to distinguish execution cost from workstation contention. No assertion is
relaxed, full-payload normalization is not allowed, and the positive-source
invalidation failure remains owned by MolSysMT #642. Stop on another resource
interruption; do not keep retrying this selection in the same local session.
