# Scientific-panel provider and artifact admission — 2026-11-07

Owner: [DockingMT #33](../pending_proposals/validate_native_molsysmt_formats.md),
with [#49](../pending_proposals/retire_general_molecular_operations.md) retaining
molecular ownership. Starting checkpoint: `9977317bfdbff60ee783043c5445f5b3e9719920`.
The previous goal turn made progress: complete bounded E5 receiving and #83
resolution, with the complete product objective still active.

## Preserved question and source cases

Retain the original [two-candidate panel design](scientific_panel_design_2026-11-04.md),
all four original downloaded files and the unadmitted 1HSG terminal-control output.
Do not replace a blocked candidate with an easier one, infer missing chemistry,
or treat E5's repeated 1IEP as a new independent molecular case. The proposed
24-search matrix remains unregistered and unexecuted. Terminal, catalytic/ligand
states, waters, other ligand copies and truncation decisions retain their
case-specific admission obligations.

## Refreshed provider state before molecular work

MolSysMT #556 is source-resolved at06c065d3 for CIF primary occupancy/model-local
observations. #557 is source-resolved atfaab727c for experimental public
`physchem.get_chemical_template` and strict `topology.get_atom_name_correspondence`.
#558 remains open for public native terminal-completion correspondence/history.
Source closure is separate from installed consumer receiving.

The actual qualified9e1f1b1 provider payload lacks both new #557 modules. Its
CIF converter SHA differs from the correction and later source. No new source
or binary is therefore relabelled as received. Public `add_terminal_atoms`
requires caller-supplied coordinates and does not generate missing terminal
geometry; it does not replace #558 without a provider-supported composition.
Do not implement a CCD parser, chemistry transfer, atom matcher, OXT placer,
private map extraction or an ad hoc provider module overlay in DockingMT.

A bounded central `suite_status.py` refresh inspects DockingMT and MolSysMT.
DockingMT is synchronized, preserving the untracked original migration; MolSysMT
is clean at9e1f1b1 and120 commits behind fetched main. Preserve both worktrees,
all pinned/private prefixes and prior build interruptions. No merge, source
installation, source-module replacement or native construction is part of this
selection. The #642 construction hold after owned-memory interruption remains.

## Current finite selection

Inspect exact source contracts and available complete artifacts before calling
any molecular API. Read-only public registry acquisition may inspect the uibcdf
Conda MolSysMT package metadata, including actual filenames, platform/Python/
build identities and covering source evidence where supplied. Bound each HTTP
request to25 seconds and16 MiB; record exact bytes/digests and any unavailable
route. No environment solve/install, workflow dispatch, molecular import or
scientific operation is authorized by this inventory.

Metadata/source inventory runs at CPU0/nice10, one worker,45 CPU/60 wall seconds,
2 GiB AS/1 GiB owned RSS, with8 GiB available reserve checked before and during
reads. Preserve interrupted attempts and do not automatically restart owned
heavy work after a headroom stop. The exact original provider/native/source
identities remain separate from current upstream source and advertised files.

If a complete covering artifact is available, register its exact acquisition and
isolated whole-provider admission before execution. If unavailable, publish the
bounded evidence to the existing provider issues/artifact handoff and advance
another independent complete-plan boundary; do not manufacture an installed
PASS from source closure or partial Python replacement. A genuine new provider
defect or missing reusable tool remains the provider's issue.

Task `.molsyssuite/panel-receiving-20261107` retains issue/source/status/registry
snapshots, scripts and receipts under #50, review2026-11-14. Keep #33/#49 partial,
all panel cases unadmitted until their actual criteria pass, and the full Core/
Extended/scientific/public/stabilization objective active. No manual CI; skipped
hosted evidence remains missing.


## Prospective private whole-provider wheel assembly

The exact source comparison establishes identical complete Rust tree
`32cfb07b9c26ae9ad3ed379c1b76fab85669cf67` at qualified source9e1f1b1 and
source-resolved CCD checkpointfaab727c. Build-system requirements, the complete
setuptools-rust extension declaration and ABI3 wheel options are also identical.
The retained qualified extension SHA is
`2a79b9a83b0fe0b00a54c9b80f04bf6c9ace2b3473c53269edbfe29904f8930b`
(101,188,064 bytes). Its existing qualification/source context stays9e1f1b1;
no new compilation or new compiler/source receipt is invented.

Register a separate **whole-provider artifact assembly**, with zero molecular
calls and zero native compiler entries. Use an isolated exact faab727c Git
worktree and unchanged upstream pyproject. Standard setuptools `build_py`
assembles every declared Python package/resource; stage only the unchanged
qualified extension into its declared build output. Standard
`bdist_wheel --skip-build` then packages that complete output, using the provider's
unchanged cp311/ABI3 configuration. Setuptools' inspected installed implementation
skips the build when that option is set; setuptools-rust preserves that contract.
Do not patch module code, alter build classes, forge metadata/RECORD, replace
individual modules in an old installation or invoke Cargo. Generate the version
through the existing versioningit hook on the exact clean source worktree.

Audit actual subprocess launches and refuse every native compiler/build-tool
entry before spawn, including absolute executable paths. Retain build-tool source
identities, all source/build payload hashes, the exact wheel and its native byte
identity. The candidate must contain both new public modules, all declared runtime
packages/resources and the exact prebuilt extension; reject missing files or a
changed Rust/build contract. Use a fresh install target, no dependencies/bytecode,
only after whole-wheel checks pass. Preserve the shared routine environment and
all earlier prefixes. No molecular/scientific acceptance follows from assembly.

This private composition explicitly records Python sourcefaab727c and the reused
native binary/source context9e1f1b1; it is not a new public provider release or
proof of rebuilding native code from that commit. Only Linux/Python3.14 receiving
is selected. Source4d8af6c for #642 has a different Rust tree
`fb25b2eac60b6e706c712e788119b3dad94329fe`: this reuse is forbidden for that fix,
whose held construction/artifact handoff is unchanged. No heavy build restarts.

Allow one serial assembly attempt under the same CPU0/nice10/worker1,
8 GiB reserve/1 GiB RSS/2 GiB AS/45 CPU/60 wall limits. Check at least3 GiB free
task storage before creation. Retain the private wheel/source/worktree until #50
review2026-11-14; retire the temporary route after a covering owner-built artifact
is actually received. Scientific CCD/occupancy calls still require their own
prospective exact input/control/call selection after assembly and import admission.


## Assembly received and admission diagnostic correction

Whole-provider assembly01 passes in12.091 s/291,610,624 sampled group-RSS bytes.
Standard `build_py`/`bdist_wheel --skip-build` produces the complete
`0.23.0+520.gfaab727ca` private wheel with exact upstream modules/resources and
unchanged native SHA. Compiler entries/scientific imports/molecular calls are
zero; source, old native artifact and routine metadata remain unchanged.

Admission01 installs the wheel and imports both public tools but fails its final
caller-policy restoration assertion (8.790 s/277,508,096 bytes). Independent
post-failure file hashes show zero added/deleted/changed prefix files, unchanged
old providers and unchanged routine metadata. The worker called pip's internal
entry in-process, yielding its unsupported-use/import deprecation warnings.
This is not accepted receiving and is not yet assigned as a provider defect.
Preserve the attempt and exact installed files.

Register admission02 with a fresh target and the same exact wheel/source/native/
resource checks. Execute the wheel-only pip command in its own isolated subprocess;
record policy before/inside/after imports and after context exit, and split final
checks so any failure is attributable. No assertion or application authority is
weakened, and no scientific/molecular call is registered by this correction.


## Complete installed admission and prospective reference-only receiving

Admission02 passes in10.448 s/250,896,384 sampled group-RSS bytes. The complete
new wheel is installed into a fresh3793-file prefix, retaining313 unchanged
support files and excluding all3481 old MolSysMT/addon/distribution files.
Both new public tools import from the new prefix, native SHA stays exact, no
Vina import/compiler/molecular call occurs, caller units restore and every old
prefix/routine metadata byte remains unchanged. The failed in-process-pip
receiver is preserved; no provider/unit defect is asserted from that task misuse.

Register `scientific-registration.json` and the six exact files in
`input-ledger.json` before any molecular query: the four original1HSG/1STP
PDB/CIF bytes and the two unmodified MK1/BTN CCD files retained by provider#557
atfaab727c. These are local reference fixtures, not a new online acquisition or
experimental bound-state assignment. One complete normal cell precedes an
identical-worker/input/candidate pm/fs cell. Both inspect the same existing cases;
no new independent complexes or admitted docking rows are counted here.

Per cell permit exactly four source conversions, eight coordinate getters,
four occupancy getters, four selections, ten read-only chemical-readiness
reports, four template-constructor attempts (two positive/two missing-source
controls), six explicit-name-map attempts (four positive/two repeated-query
controls) and four read-only template assessments. Nested public provider caps
are convert64/get1024/get_form2048/select256/has_attribute256/copy64. Keep every
actual getter/call count and typed diagnostic. Source PDB reading is explicitly
`get_missing_bonds=False`; CIF uses its existing named reader policy. Both
asymmetric units supply observed ligand/reference metadata only; the original
full-assembly receptor requirement is not changed.

Construct the coordinate-free neutral CCD reference with explicit
`method='ccd_canonical_descriptor'`, `hydrogen_policy='stored_counts'`,
`descriptor_program='CACTVS'`, `max_matches=4096`. CACTVS identifies the stored
reference descriptor; RDKit is the actually executed interpretation software.
Use the provider's strict unique-name/element tool for template-to-observed
source pairs; label correspondence is not chemical equivalence. Existing
`assess_chemical_template`, state reference and `require_same_graph` report
compatible/conflict/unassessed outcomes without applying assignments or changing
any source. Do not require a scientifically favorable assessment or repair one.

CIF primary occupancy must be present on its native axis, with original atom
counts and finite values; compare only declared distribution counts (1686 ones
for1HSG,930 ones/71 non-unit for1STP), not an invented cross-format positional
map or copied PDB array. Exact source coordinates and readiness before/after,
file bytes, private prefixes and caller policy must remain unchanged. Preserve
full CCD source/report/maps/chemistry observations and every refusal. Fixed-unit
coordinate witnesses explicitly extract to angstrom; report charge integers in
the provider's declared elementary-charge convention. No general quantity codec,
chemical parser/matcher, geometry kernel or reconstruction is implemented here.

No template application, terminal/H generation, charge/type assignment, chemical
repair, alignment/RMSD/distance/detector, energy/search, view/kernel/server or
native build is permitted. Network is denied during these local scientific
cells, including missing-file controls. Resource policy remains CPU0/nice10,
one worker,8 GiB reserve/1 GiB RSS/2 GiB AS/45 CPU/60 wall seconds per cell.
State/environment/terminus/truncation and#558 correspondence remain unresolved.


## Complete reference-only receiving — 2026-11-07

Both complete cells pass: normal 7.781 s / 333,586,432 sampled group-RSS
bytes, pm/fs/coulomb 7.672 s / 333,520,896 bytes. Each executes the exact
registered direct calls and nested observed provider counts (convert 4, get 28,
get_form 592, select 34, has_attribute 8, copy 0), below every cap. All groups
are terminal with no interruption, resource reserve preserved and caller policy
restored. The offline missing-reference and repeated-query controls produce
four expected typed refusals per cell; their ERROR log lines are intentional.

Each policy constructs the coordinate-free MK1/BTN reference (45/16 heavy
atoms, 47/16 stored H; no generated H) and returns complete explicit-label maps
against both original PDB and CIF sources. All four assessments per policy are
compatible under the declared reference/same-graph contract. This is neutral
reference compatibility, not bound protonation or chemical-model acceptance.
Both PDB and CIF report 1HSG occupancy 1,686 values all one, and 1STP 1,001
values with 930 ones / 71 nonunit, minimum 0.42. No cross-format positional
correspondence or copied occupancy vector is manufactured. Source coordinates,
readiness, file bytes, private prefixes and routine metadata remain unchanged
within each cell. No docking case is admitted and all search, preparation,
terminal-generation, energy, RMSD and viewer counters remain zero.

Next freeze terminal records and exact inputs once, retaining original source
files through their existing manifest instead of duplicating them. Retain both
new CCD fixtures with exact provider-source paths/hashes. A fresh stdlib reader
will authenticate every stored/decoded member, original source input, source/
artifact/candidate registration, exact call counts and all failed/positive cells.
It will compare the already explicit angstrom witnesses descriptively, with no
retrospective scientific tolerance or new molecular operation. Administrative
seal/reader/final-check/export cells use the same resource policy. Seal closes
this molecular campaign; further calls require a new prospective admission.
The provider fixture manifest embedded in the input ledger is historical EST
context only: actual MK1/BTN provenance comes from their raw bytes, exact faab
fixture paths and constructor reports, not the unrelated EST manifest.
