"""Independent receipt/source receiving; no product imports or test replay."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import tomllib
import xml.etree.ElementTree as ET

_tool_receipt = Path(__file__).resolve().parents[1] / 'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_receipt.read_bytes()).hexdigest() == '6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool = json.loads(_tool_receipt.read_text())
_prefix = Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)): hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()} == _tool['files_sha256']
sys.path.insert(0, str(_prefix))
from pytest_receptor import read_artifact


def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    expected = {'red-normal': (1, 12, 12), 'green-normal': (1, 251, 7), 'green-pm_fs': (1, 251, 7), 'green-normal-02': (0, 251, 0), 'green-pm_fs-02': (0, 251, 0)}
    failures = {}
    for label, (code, total, failed) in expected.items():
        p = 'attempts/' + label + '/'
        r = obj(p + 'receipt.json')
        reg = obj(p + 'registration.json')
        resource = obj(p + 'resource-outcome.json')
        assert r['pytest_exit_code'] == resource['exit_code'] == code
        assert r['counts'] == {'tests': total, 'failures': failed, 'errors': 0, 'skipped': 0}
        assert r['outcome'] == resource['outcome'] == ('PASS' if code == 0 else 'FAIL')
        assert r['qualification_complete'] and resource['group_terminal']
        assert not resource['remaining_live_owned_pids'] and resource['resource_interruption'] is None
        assert resource['minimum_available_bytes'] >= 13 * 1024**3
        assert resource['sampled_peak_group_rss_bytes'] < 1024**3 and resource['elapsed_seconds'] <= 60
        assert resource['policy'] == reg['policy'] and reg['policy']['cpu'] == 0 and reg['policy']['nice'] == 10 and reg['policy']['workers'] == 1
        assert not r['molecular_calls_attempted'] and r['native_searches'] == 0 and r['versions']['pytest-receptor'] == '1.2.2'
        for key in ['default_form', 'default_parser', 'standard_units']:
            assert r['caller_policy_before'][key] == r['caller_policy_after'][key]
        for name, digest in reg['inputs_sha256'].items():
            assert hashlib.sha256(records[p + 'frozen-' + name.replace('/', '__')]).hexdigest() == digest
        for name, digest in reg['frozen_sha256'].items():
            assert hashlib.sha256(records[p + name]).hexdigest() == digest
        counts = {k: 0 for k in ['tests', 'failures', 'errors', 'skipped']}
        xml = ET.fromstring(records[p + 'junit.xml'])
        for row in xml.iter('testsuite'):
            for k in counts:
                counts[k] += int(row.get(k, '0'))
        assert counts == r['counts']
        failures[label] = [row.find('failure').get('message') for row in xml.iter('testcase') if row.find('failure') is not None]
        with tempfile.TemporaryDirectory(prefix='dmt-api-reference-reader-', dir='/tmp') as tmp:
            path = Path(tmp) / 'events.jsonl'
            path.write_bytes(records[p + 'events.jsonl'])
            artifact = read_artifact(path)
            assert artifact.complete and artifact.final.data == r['receptor_final']
            final = artifact.final.data
            c = final['counts']
            assert final['exitstatus'] == code and c['collected'] == c['executed'] == total
            assert c['failed'] == failed and c['passed'] == total - failed
            assert c['not_executed'] == c['skipped'] == c['deselected'] == 0
            assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
    assert all("No module named 'dockingmt.exceptions'" in message for message in failures['red-normal'])
    for label in ['green-normal', 'green-pm_fs']:
        assert all('Offline admission imported an optional molecular engine' in message for message in failures[label])
    normal = 'attempts/green-normal-02/'
    pm = 'attempts/green-pm_fs-02/'
    assert records[normal + 'frozen-test_child.py'] == records[pm + 'frozen-test_child.py']
    assert obj(normal + 'registration.json')['selection'] == obj(pm + 'registration.json')['selection']
    for name in obj(normal + 'registration.json')['inputs_sha256']:
        frozen = 'frozen-' + name.replace('/', '__')
        assert records[normal + frozen] == records[pm + frozen]
        if name.startswith('tests/') or name in ['pyproject.toml', 'dockingmt/_private/smonitor/__init__.py']:
            assert records['attempts/red-normal/' + frozen] == records[normal + frozen]
    old = ast.parse(records['attempts/red-normal/frozen-dockingmt____init__.py'])
    new = ast.parse(records[normal + 'frozen-dockingmt____init__.py'])
    for node in list(new.body):
        if isinstance(node, ast.ImportFrom) and node.module is None and node.level == 1 and [n.name for n in node.names] == ['exceptions']:
            new.body.remove(node)
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '__all__' for t in node.targets):
            node.value.elts = [n for n in node.value.elts if not (isinstance(n, ast.Constant) and n.value == 'exceptions')]
    assert ast.dump(old) == ast.dump(new)
    aliases = ast.parse(records[normal + 'frozen-dockingmt__exceptions.py'])
    declarations = next(ast.literal_eval(n.value) for n in aliases.body if isinstance(n, ast.Assign))
    imports = [n for n in aliases.body if isinstance(n, ast.ImportFrom)]
    assert len(declarations) == 13 and len(imports) == 1 and imports[0].module == 'dockingmt._private.smonitor'
    assert {n.name for n in imports[0].names} == set(declarations) and all(n.asname is None for n in imports[0].names)
    assert not any(isinstance(n, (ast.ClassDef, ast.FunctionDef)) for n in aliases.body)
    before = tomllib.loads(records['attempts/red-normal/frozen-devtools__conda-build__resources.toml'].decode())
    after = tomllib.loads(records[normal + 'frozen-devtools__conda-build__resources.toml'].decode())
    # Only the added runtime member changes this declaration; all support hashes stay exact.
    def strip_member(value):
        if isinstance(value, dict):
            return {k: strip_member(v) for k, v in value.items()}
        if isinstance(value, list):
            return [strip_member(v) for v in value if v != 'site-packages/dockingmt/exceptions.py']
        return value
    assert before == strip_member(after)
    docs = obj('attempts/docs-03/receipt.json')
    assert docs['outcome'] == 'PASS' and docs['root_exports'] == 33 and docs['model_classes'] == 13
    assert docs['exception_aliases'] == 13 and docs['compiled_snippets'] == 2 and docs['local_links_checked'] == 42
    assert docs['reference_sha256'] == hashlib.sha256(records['attempts/docs-03/frozen-PUBLIC_API.md']).hexdigest()
    assert [r['profile'] for r in docs['smoke_profiles']] == ['normal', 'pm_fs']
    assert all(r['input_unchanged'] and r['exact_alias_identities'] == 13 for r in docs['smoke_profiles'])
    assert not docs['molecular_calls_attempted'] and docs['native_searches'] == 0
    doc_resource = obj('attempts/docs-03/resource-outcome.json')
    assert doc_resource['outcome'] == 'PASS' and doc_resource['group_terminal'] and doc_resource['resource_interruption'] is None
    for label in ['docs-01', 'docs-02']:
        prior = obj('attempts/' + label + '/receipt.json')
        prior_resource = obj('attempts/' + label + '/resource-outcome.json')
        assert prior['outcome'] == prior_resource['outcome'] == 'PASS'
        assert prior_resource['group_terminal'] and prior_resource['resource_interruption'] is None
        assert prior['root_exports'] == 33 and prior['exception_aliases'] == 13
    for name in sys.modules:
        assert name.split('.')[0] not in {'dockingmt', 'molsysmt', 'molsysviewer', 'vina', 'rdkit', 'openmm'}
    return {'complete_profiles': ['normal', 'pm_fs'], 'cases_per_profile': 251, 'original_failures_preserved': 12, 'harness_failures_preserved': 14, 'public_exception_aliases': 13, 'root_exports': 33, 'reference_snippets': 2, 'test_replays': 0, 'molecular_imports': 0}
