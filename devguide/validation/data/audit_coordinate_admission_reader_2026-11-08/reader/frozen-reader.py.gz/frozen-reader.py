"""Independent record receiving with the published Receptor reader; no test replay."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

_tool_receipt=Path(__file__).resolve().parents[1]/'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_receipt.read_bytes()).hexdigest()=='6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool=json.loads(_tool_receipt.read_text());_prefix=Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()}==_tool['files_sha256']
sys.path.insert(0,str(_prefix))
from pytest_receptor import read_artifact

def verify_records(records):
    def obj(name):return json.loads(records[name])
    expected={
        'red-normal':(1,41,16,0),
        'red-normal-02':(1,41,13,0),
        'green-normal':(2,1,0,1),
        'green-normal-02':(0,409,0,0),
        'green-pm_fs':(0,409,0,0),
    }
    for label,(exit_code,total,failed,errors) in expected.items():
        prefix='attempts/'+label+'/'
        r=obj(prefix+'receipt.json');resource=obj(prefix+'resource-outcome.json');registration=obj(prefix+'registration.json')
        assert r['pytest_exit_code']==resource['exit_code']==exit_code
        assert r['counts']=={'tests':total,'failures':failed,'errors':errors,'skipped':0}
        assert r['outcome']==resource['outcome']==('PASS' if exit_code==0 else 'FAIL')
        assert r['qualification_complete'] and r['versions']['pytest-receptor']=='1.2.2'
        assert not resource['remaining_live_owned_pids'] and resource['group_terminal'] and resource['resource_interruption'] is None
        assert resource['sampled_peak_group_rss_bytes']<1024**3 and resource['minimum_available_bytes']>=13*1024**3 and resource['elapsed_seconds']<=60
        assert registration['policy']==resource['policy']
        assert not r['molecular_calls_attempted'] and r['native_searches']==0
        for key in ['default_form','default_parser','standard_units']:assert r['caller_policy_before'][key]==r['caller_policy_after'][key]
        for name,digest in registration['inputs_sha256'].items():assert hashlib.sha256(records[prefix+'frozen-'+name.replace('/','__')]).hexdigest()==digest
        observed={key:0 for key in ['tests','failures','errors','skipped']}
        for row in ET.fromstring(records[prefix+'junit.xml']).iter('testsuite'):
            for key in observed:observed[key]+=int(row.get(key,'0'))
        assert observed==r['counts']
        with tempfile.TemporaryDirectory(prefix='dmt-audit-record-reader-',dir='/tmp') as directory:
            path=Path(directory)/'events.jsonl';path.write_bytes(records[prefix+'events.jsonl'])
            artifact=read_artifact(path);assert artifact.complete and artifact.final.data==r['receptor_final']
            final=artifact.final.data;assert final['exitstatus']==exit_code
            assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
            if errors:
                assert final['counts']['executed']==1 and final['counts']['not_executed']==361 and final['counts']['collected']==362
            else:
                counts=final['counts'];assert counts['collected']==counts['executed']==total
                assert counts['failed']==failed and counts['passed']==total-failed
                assert counts['skipped']==counts['not_executed']==0
                assert counts['deselected']==(1 if exit_code==0 else 0)
    normal='attempts/green-normal-02/';other='attempts/green-pm_fs/'
    for name in obj(normal+'registration.json')['inputs_sha256']:
        assert records[normal+'frozen-'+name.replace('/','__')]==records[other+'frozen-'+name.replace('/','__')]
    for name in ['dockingmt/core/results.py','dockingmt/core/audit.py']:
        assert records['attempts/red-normal-02/frozen-'+name.replace('/','__')]!=records[normal+'frozen-'+name.replace('/','__')]
    assert records['attempts/red-normal-02/frozen-tests__test_audit_coordinate_records.py']==records[normal+'frozen-tests__test_audit_coordinate_records.py']
    before=ast.parse(records['attempts/green-normal/frozen-tests__test_pose_audit.py'])
    after=ast.parse(records[normal+'frozen-tests__test_pose_audit.py'])
    moved=next(n for n in before.body if isinstance(n,ast.ImportFrom) and n.module=='test_engines')
    before.body.remove(moved)
    function=next(n for n in after.body if isinstance(n,ast.FunctionDef) and n.name=='test_fresh_native_scoring_and_rescoring_produce_auditable_evidence')
    assert ast.dump(function.body.pop(0))==ast.dump(moved)
    assert ast.dump(before)==ast.dump(after)
    for label,code in [('probe-01',1),('probe-02',0)]:
        r=obj('attempts/'+label+'/resource-outcome.json')
        assert r['exit_code']==code and r['outcome']==('FAIL' if code else 'PASS')
        assert r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids']
    probe=obj('attempts/probe-02/receipt.json');assert len(probe['observations'])==9 and not probe['forbidden_import_attempts'] and probe['molecular_operations']==0
    assert sum(row['actual']!=row['expected'] for row in probe['observations'])==2
    for name,module in tuple(sys.modules.items()):
        if name=='pytest_receptor' or name.startswith('pytest_receptor.'):
            path=Path(module.__file__).resolve();assert path.is_relative_to(_prefix)
            assert hashlib.sha256(path.read_bytes()).hexdigest()==_tool['files_sha256'][str(path.relative_to(_prefix))]
    assert not any(n=='molsysmt' or n.startswith(('molsysmt.','dockingmt.','rdkit','vina','molsysviewer')) for n in sys.modules)
    return {'complete_profiles':['normal','pm_fs'],'cases_per_profile':409,'new_guard_cases':41,'original_failures_preserved':13,'initial_guard_failures_preserved':16,'collection_failure_preserved':True,'native_cases_deselected_per_profile':1,'receptor_and_junit_agree':True,'source_only':True,'molecular_replay':False,'guard':'tests/test_audit_coordinate_records.py'}
