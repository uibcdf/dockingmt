# Complete installed batch module on the current cohort — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with
#74/#73 source-milestone preparation and #50 custody. Status: registered.
Starting checkpoint 9d84c0ab; unchanged genuine consumer producer 37a61e6,
wheel `0.0.0+359.g37a61e6`, SHA-256
`ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d`.

## Original complete selection and boundaries

Receive all **45 original `tests/test_batch.py` cases**, normal then pm/fs,
without deselection or modified assertions. Preserve all four #106 allocation
controls, lazy ordered iteration, original exception identities, failure records,
source stopping, cleanup/traceback release and restoration/nonmutation checks.
The module remains byte-identical to producer 37a61e6 and its installed harness.

The three existing native cases compare individual/serial execution for Vina
and Vinardo and isolate an intervening missing-file failure. Permit exactly ten
tiny searches per policy, retaining original four/two-atom fixture literals,
seed 123, CPU 1, exhaustiveness 1, at most two requested poses and the original
10 angstrom box. Preserve complete result/outcome comparisons, captured input
hashes and internal audits. Record actual submissions, returned poses/energies
and every export. No preparation, fresh scoring, optimize/randomize or new
independent molecular case is authorized by this receiving.

Use the captured current development cohort: MolSysMT 9df62445/local native
SHA-256 `2dbcf13d148cb3ae13a5908707fcdd61c75a2de5027e50c566ce07de81bdb038`
and the five unchanged sibling sources. Preload and guard all MolSysMT Rust
callables; expected actual molecular/provider/Rust calls are zero. Viewer
construction remains blocked. Compilation provenance stays unassessed; the
provider reference binary 4ffb82e4 is not received. Historical source/native
cohorts and prior batch outcomes retain their actual identities.

Reuse the installed prefix, source-free harness and shared installed runner/
multi-root loaded-import validator at 95f693be. Verify all 67 consumer paths,
metadata/version/PEP 610, 305 qualification inputs, 103 frozen engine files,
six provider source/native identities and 606 shared support declarations before/
after; verify retirement. Unused addon code is payload-authenticated, with no
new eager-addon import claim. Require complete paired collection/program/input
identities and JUnit/Receptor/native qualification exits. No build or install.

## Resource, retention and closing controls

Shared host ixtlilton has 64,978,440,192 B physical RAM and 59,303,362,560 B
available; sampled CPU idle is 87%, swap I/O zero and memory PSI avg10/60/300 zero.
Disk has 23,762,522,112 B available. Slurm tools exist without an allocation;
the earlier bounded socket probe is unavailable. Free capacity is not reserved.
Prior exact-fixture batch cells take about 23 seconds/475 MB sampled group RSS.

Run serial CPU 0/nice 10/one worker with inherited descendant limits. Estimate
768 MiB RSS, retain 1 GiB group cap/2 GiB address space, CPU 60/65 and wall 180
seconds, and monitor a 13 GiB available reserve before/during each cell. Stop
only owned work, preserve interruptions and never automatically restart after a
headroom interruption. No local native construction or held interactive work.

Retain `.molsyssuite/installed-batch-current-20261110` under #47/#74/#73/#50,
review 2026-11-14. Seal and independently authenticate records without molecular/
native/test replay; preserve every failed attempt. Run applicable local and fresh
committed-export resource/archive checks, update maintained checkpoints and
owning issues before direct `[skip ci]` publication. No remote CI, tag, GitHub
Release or package publication follows automatically from this finite profile.
The accepted current 0.1.0 plan still needs its own exact candidate and gates.
