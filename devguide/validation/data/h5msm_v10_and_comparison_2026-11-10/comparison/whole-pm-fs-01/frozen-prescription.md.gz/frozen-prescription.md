# Complete installed saved-score comparison — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with
#30/#73 qualification and #50 custody. Status: registered; execution pending.
Actual consumer producer 37a61e6, wheel `0.0.0+359.g37a61e6`, SHA-256
`ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d`.

## Original selection and exact composition

Run all **54 original `tests/test_score_comparison.py` cases**, normal then pm/fs,
with no deselection or modified assertion. The file is byte-identical to its
[source receiving at 02228c3](source_scoring_evidence_2026-11-10.md).
Preserve method/component/direction/reference/tie/group/unit/identity/admission
controls and all five original saved E1 record files. Molecular preparation and
correspondence seams are explicitly synthetic; original tests forbid actual
scientific operations. An audit/comparison neither authenticates an old producer
nor validates physical ranking or affinity. No molecular observation is replayed.

Reuse the same real private receiver/wheel and source-free Git qualification
harness at producer 37a61e6. Authenticate all 67 installed payload files,
metadata/version/PEP 610, reporting/unit inputs, 305 qualification inputs and
both actual installed runtime roots before/after. Use the shared installed
runner and multi-root validator at 95f693be; verify and retire all 606 unchanged
support declarations per cell. Clear inherited PYTHONPATH/PYTHONHOME. No new
build, install, runtime/test/helper/data edit or local support-staging replacement.

The maintainer updates shared development MolSysMT to clean
`9df62445e49a1e268cf4c13d1ebbdd06b2088674`, with measured local native SHA-256
`2dbcf13d148cb3ae13a5908707fcdd61c75a2de5027e50c566ce07de81bdb038`.
Freeze this new current cohort; preserve every prior receipt's older source/
native identity rather than claiming old 0c6f9c7 still occupies the shared checkout.
Other sources remain Viewer 1187fc18, ArgDigest 07126411, PyUnitWizard f82b618e,
SMonitor c1b6ce29 and DepDigest 032d345b. Actual imported paths, source/native
fingerprints and distribution labels remain separate. No general ABI or published
package floor is accepted from this comparison profile.

Actual optional engines, molecular/preparation/correspondence/geometry operations,
all exposed Rust callables and Viewer construction are independently forbidden.
Allow original controlled fakes and preserve their assertions; they do not become
real provider/native evidence. Observe the complete 54-node collection before
execution and require identical paired worker/selection/artifact/test/cohort bytes.
Retain full JUnit/Receptor/native pytest exits, warnings and caller policy.

## Resource and closing controls

Fresh shared-host preflight: 64,978,440,192 B physical/60,757,651,456 B available,
20 CPUs, load 1.27/1.11/1.16, about 94.7% interval idle, zero sampled swap I/O,
memory PSI avg10 zero/avg60 and avg300 0.01, disk free 35,833,544,704 B. Slurm
exists without an allocation and earlier applicability was inconclusive.
Free capacity is not a reservation.

Execute serially CPU 0/nice 10/one worker, inherited by heavy descendants;
384 MiB expected group RSS, 1 GiB group cap/2 GiB address space, 60/65 CPU and
180 wall seconds, monitored 13 GiB available reserve. Do not overlap the H5MSM
1.0 cells. Stop only owned work and preserve interruptions; never automatically
restart after headroom interruption. No native build or new shared installation.

Retain `.molsyssuite/installed-score-comparison-20261110` under #47/#50, review
2026-11-14, with the original wheel/prefix/harness/source fixtures and all attempts.
Preserve human migration files and earlier scientific producers. Seal actual
outcomes and independently read records without replay. Apply final local and
fresh committed-source resource/archive checks, update maintained checkpoints
and publish a direct `[skip ci]` commit. Missing remote CI remains missing.

This is private installed software comparison on an explicitly newer development
cohort. It does not close full scientific/public Conda/dependency/eight OS-minor/
interactive or stable-format gates. No package publication or remote CI dispatch.
