# Explicit H5MSM 1.0 migration and client receiving — 2026-11-10

Owners: [MolSysMT #256](https://github.com/uibcdf/molsysmt/issues/256),
[DockingMT #73](https://github.com/uibcdf/dockingmt/issues/73); #50 custody.
Status: registered before execution; actual development-binary admission pending.
Consumer checkpoint `d83d86d47c1961fee0177868369141478b912325`; unchanged genuine
private consumer wheel producer 37a61e6/version `0.0.0+359.g37a61e6`.

## Provider acceptance and maintainer-directed composition

MolSysMT's [acceptance at 9df62445](https://github.com/uibcdf/molsysmt/blob/9df62445e49a1e268cf4c13d1ebbdd06b2088674/devtools/data/docking_h5msm_p5_client_receiving_256_20261110.json)
receives all fourteen original experimental-0.6 P5 cases, exact 5e7d65a6/5715bda
scope and the two manifests. Its verification covers eleven selected stored
members, not a whole archive reauthentication or molecular replay. Preserve all
original [P5 observations](h5msm_p5_client_receiving_2026-11-10.md), failures,
producer identities and closed #79/#88/#96 scopes.

The next source reference is `05865fbb3ba499d4117d6ba3e1cf55d98a9e239e`.
The maintainer explicitly confirms the development-source route and updates
`../molsysmt` to clean `9df62445e49a1e268cf4c13d1ebbdd06b2088674`.
Product/Rust/Cargo/runtime metadata bytes are identical to that reference; the
later commit records consumer acceptance. Preserve the historical old cohort in
earlier receipts; it is not the current shared checkout after this human update.

Measure the actual local Linux ABI3 extension before import: 99,068,520 B,
SHA-256 `2dbcf13d148cb3ae13a5908707fcdd61c75a2de5027e50c566ce07de81bdb038`.
It differs from provider reference `4ffb82e4250a1862fff17dbe7725fb8f0770d613ffef2648370389a66983d345`.
Build provenance is unassessed; a filename or source checkout cannot establish
its compilation origin. This task performs its own bounded receiving of the
actual local development binary, not receiving of the reference file or general
native compatibility. No new native compilation/reinstall is required or run.

Create a clean tracked private clone at 9df62445 and copy the exact measured
binary into it. Require ELF64/little-endian/x86_64 before load, actual import/
loaded-map digest and the expected updated neighbor API signature before pytest.
All actual neighbor execution remains forbidden; only the same real unchanged
one-atom/zero-bond topology binding is admitted, twice per whole profile, with
original arguments/result [0]. Use the original private DockingMT receiver;
authenticate all 67 installed files, installed core/addon origins and metadata.
The five other development siblings remain pinned; capture the new MolSysMT
source/Python/native cohort after the maintainer's change and verify it thereafter.

## Immutable inputs and registered selection

Reuse all eleven exact packet files from provider commit 1ce072ae and the
accepted frozen observation oracle. No preparation, assignment, detector or
docking/search result is generated. The three small 0.6 systems have at most
six atoms/three structures; retain typed reference snapshots and original PDBQT.
Keep plain labels distinct from quantities and preserve original evidence.

Run a two-case admission under the normal unit policy: complete-file migration
and complete typed public-reader/PDBQT parity. If it passes, execute identical
ten-case whole normal then pm/fs profiles in fresh processes:

1. Three explicit migrations, one per packet file. Use the real public
   `msm.convert(source, to_form=new_destination, format_version='1.0')`.
   Verify the destination's actual root declares 1.0 and its decoded
   `migration_source` equals all original 0.6 root metadata. Preserve original
   source hashes and refuse an existing destination without altering either file.
2. The same seven accepted P5 client cases, now reading the migrated 1.0 files:
   three complete typed/public readbacks with PDBQT parity; explicit reversed
   atom order plus structures [2, 0], direct bond/state/table/map assertions and
   persisted correspondence; restored coordinate edit with unaffected structures/
   coverage preserved; two future-schema report transport/refusal controls.

Every new derived writer explicitly requests 1.0 and its actual root is checked.
Direct migrations retain old-root provenance; newly derived native-object writes
retain original reports/history without inventing inherited root metadata.
Both unknown assignment families must survive transport/full copy and refuse
projection/export before returning output, preserving source and adverse-file
hashes. Keep the established physical edit tolerance 1e-15 nm and exact
within-policy persistence; other units/dtypes/labels/domains remain exact.

Require exact paired worker/case/oracle/composition bytes, actual loaded native
and source origins, complete JUnit/Receptor/native exit records and unchanged
caller policies. Missing generated stamps keep the owning normal unknown-version
fallback; prevent foreign editable-stamp substitution without fabricating a label.
Source Git identity, distribution labels and native build provenance stay separate.
Existing fixtures/oracles and prior 0.6 observations are not rewritten as 1.0.

## Resource, custody and acceptance boundary

Fresh preflight: 64,978,440,192 B physical/60,757,651,456 B available RAM, 20
logical CPUs, load 1.27/1.11/1.16, about 94.7% sampled idle, zero sampled swap I/O,
PSI avg10 zero (avg60/300 0.01), 35,833,544,704 B free disk. Slurm exists with no
allocation; prior applicability was inconclusive. Free capacity is not reserved.

Run serial CPU 0/nice 10/one native worker, inherited by heavy descendants;
512 MiB expected group RSS, 1 GiB group cap/2 GiB address space, CPU 60/65 and
wall 180 seconds, monitored 13 GiB available reserve. Administrative readers use
45 CPU/60 wall seconds. Stop only owned work, retain interruptions and never
automatically restart after a headroom interruption. Do not start another
scientific cell concurrently or alter the old native-build/interactive holds.

Retain `.molsyssuite/h5msm-v10-client-20261110` under #73/#256/#50, review
2026-11-14. Keep original packet, actual isolated source/native copy, loaded-map
receipts and all failed attempts. Preserve shared installations, old frozen
cohorts, historical resources and the human migration backup. The user-directed
shared update is recorded separately from agent actions.

Seal and independently verify stored observations without repeating molecular
work. Run applicable local and fresh committed-export checks before authorized
direct `[skip ci]` publication. This source/client profile does not accept the
1.0 default-writer decision, all format/candidate/platform/installed/public gates,
provider reference 4ffb82e4 or complete #30/#47/#73. No remote CI/package release.
