"""Receive CI and actual installed records without replaying their operations."""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import tomllib
import xml.etree.ElementTree as ET


def verify_records(records):
    verifier=records['ci/producer/verify_wheel.py.txt'].decode()
    # The preserved first reader retained two old qualification constants.
    # Receive the registered 31-code+564-data / final suffix03 records.
    assert "== 30 and sum(x['kind'] == 'data'" in verifier
    verifier=verifier.replace("== 30 and sum(x['kind'] == 'data'", "== 31 and sum(x['kind'] == 'data'")
    verifier=verifier.replace('attempts/normal-01/', 'attempts/normal-03/').replace('attempts/pm_fs-01/', 'attempts/pm_fs-03/')
    corrected=reader_attempt/'corrected-verify-wheel.py'
    corrected.write_text(verifier)
    exec(compile(verifier,str(corrected),'exec'),globals())
    wheel_records={name.removeprefix('wheel/'):raw for name,raw in records.items() if name.startswith('wheel/')}
    result=verify_wheel(wheel_records)
    def obj(name):return json.loads(records[name])
    def sha(raw):return hashlib.sha256(raw).hexdigest()
    from pytest_receptor import read_artifact
    ci=[]
    for label in ['old-context-01','red-01','green-01','current-context-01','green-02','green-03']:
        prefix='ci/attempts/'+label+'/'
        reg=obj(prefix+'registration.json');r=obj(prefix+'receipt.json');resource=obj(prefix+'resource-outcome.json')
        for name,digest in reg['frozen_sha256'].items(): assert sha(records[prefix+name])==digest
        assert resource['group_terminal'] and not resource['remaining_live_owned_pids'] and resource['resource_interruption'] is None
        assert resource['policy']['cpu']==0 and resource['policy']['nice']==10 and resource['minimum_available_bytes']>=13*1024**3
        if 'context' in label:
            assert r['outcome']==resource['outcome']=='FAIL' and r['preflight_exit_code']==resource['exit_code']==1
            message=records[prefix+'preflight.stderr'].decode()
            assert ('commit/cleanliness' if label=='old-context-01' else 'reviewed HTTPS profile') in message
        else:
            native={key:sum(int(row.get(key,'0')) for row in ET.fromstring(records[prefix+'junit.xml']).iter('testsuite')) for key in ['tests','failures','errors','skipped']}
            assert native==r['counts'] and not r['scientific_imports']
            with tempfile.TemporaryDirectory(prefix='dmt-ci-reader-',dir='/tmp') as tmp:
                path=Path(tmp)/'events.jsonl';path.write_bytes(records[prefix+'events.jsonl']);events=read_artifact(path);assert events.complete and events.final.data==r['receptor_final']
            if label=='red-01':assert native=={'tests':14,'failures':13,'errors':0,'skipped':0}
            elif label=='green-01':assert native=={'tests':125,'failures':1,'errors':0,'skipped':0}
            elif label=='green-02':assert native=={'tests':125,'failures':0,'errors':0,'skipped':0}
            else:
                assert native=={'tests':127,'failures':0,'errors':0,'skipped':0}
                assert r['receptor_final']['counts']['passed']==101 and r['receptor_final']['counts']['subtests']=={'passed':26}
        ci.append({'attempt':label,'outcome':r['outcome'],'preflight_exit_code':r.get('preflight_exit_code'),'counts':r.get('counts')})
    old='ci/attempts/old-context-01/';current='ci/attempts/green-03/'
    for relative in ['devtools/conda-envs/e4_env.yaml','.github/workflows/qualify-source-0.1.0.yml']:
        assert records[old+'frozen-'+relative.replace('/','__')]==records[current+'frozen-'+relative.replace('/','__')]
    failed=obj('wheel/attempts/normal-01/receipt.json');assert failed['outcome']=='FAIL' and failed['pytest_exit_code']==2 and failed['counts']=={'tests':1,'failures':0,'errors':1,'skipped':0}
    for label in ['normal-02','pm_fs-02']:
        prefix='wheel/attempts/'+label+'/'
        r=obj(prefix+'receipt.json');assert r['outcome']=='PASS' and r['counts']=={'tests':1267,'failures':0,'errors':0,'skipped':0}
        resource=obj(prefix+'resource-outcome.json');assert resource['outcome']=='PASS' and resource['resource_interruption'] is None and resource['group_terminal']
    initial=tomllib.loads(records['wheel/attempts/build-01/frozen-resources.toml'].decode())['installed_tests']['support']['files']
    final=tomllib.loads(records['wheel/attempts/normal-03/frozen-resources.toml'].decode())['installed_tests']['support']['files']
    assert len(initial)==594 and len(final)==595 and final[:594]==initial
    helper=records['wheel/tests/dmt_test_support/pdbqt_fixtures.py']
    assert final[-1]=={'source':'dmt_test_support/pdbqt_fixtures.py','target':'dmt_test_support/pdbqt_fixtures.py','sha256':sha(helper)}
    literals={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(helper.decode()).body if isinstance(n,ast.Assign)}
    identities=obj('wheel/producer/fixture-identities.json');assert {k:hashlib.sha256(v.encode()).hexdigest() for k,v in literals.items()}==identities['literal_sha256']
    class Normalize(ast.NodeTransformer):
        def visit_ImportFrom(self,node):return None if node.module in ['test_engines','dmt_test_support.pdbqt_fixtures'] else node
        def visit_Assign(self,node):
            if any(isinstance(t,ast.Name) and t.id in literals for t in node.targets):return None
            return self.generic_visit(node)
    changed=obj('wheel/producer/fixture-import-changes.json')['files'];assert len(changed)==20
    for name in changed:
        before=ast.parse(records['wheel/original-qualification-inputs/'+name].decode());after=ast.parse(records['wheel/tests/'+name].decode());assert ast.dump(Normalize().visit(before))==ast.dump(Normalize().visit(after)),name
    installation=obj('wheel/producer/installation.json')
    for name,digest in installation['qualification_inputs_sha256'].items():assert sha(records['wheel/tests/'+name])==digest
    a='wheel/attempts/normal-03/';b='wheel/attempts/pm_fs-03/'
    assert obj(a+'registration.json')['frozen_sha256']==obj(b+'registration.json')['frozen_sha256']
    result.update(ci_observations=ci,ci_actual_context_accepted=False,ci_admin_tests=101,ci_admin_subtests=26,fixture_import_modules=20,original_support_rows_preserved=594,shared_profile_owner='uibcdf/molsyssuite#178',issues={'100':'partial','101':'bounded installed support received'})
    return result
