# Source scoring evidence and saved comparison — 2026-11-10

Owner: [DockingMT #73](https://github.com/uibcdf/dockingmt/issues/73), with source/
artifact qualification #47 and resource custody #50. Status: registered, pending.
Execution source `02228c3aa94a37c8d0219068ac77bef836dc2e2c`.

## Question and original populations

Receive the complete unchanged `test_pose_audit.py` module, including the fresh
Vina/Vinardo scoring node excluded from the earlier26-module offline selection.
Expected48 cases per caller unit policy with two actual fixed-pose native scores.
Preserve consistent, incomplete and inconsistent meanings, original malformed/
future evidence controls, caller policy, detached reports and the fresh-process
control that deliberately blocks optional providers. An audit checks internal
saved evidence; it does not replay geometry or authenticate a historical producer.

Also receive the entire unchanged `test_score_comparison.py`: expected54 cases
per policy, zero actual native/molecular operations. It uses five original saved
E1 records with deliberately synthetic preparation/correspondence seams. Preserve
method/component/direction/tie/grouping/unit/identity/admission controls and exact
old fixture bytes/producers. These are software comparisons, not new molecular
observations, source authentication, experimental ranking or affinity validation.

No runtime, test, helper, scientific fixture or dependency change is planned.
Execute each whole selection normal then pm/fs, with no deselections or changed
assertions. Keep original saved record identities, declared states and unknowns;
do not infer new chemistry or reuse historical outputs as a new producer.

## Exact composition and bounded work

Use the routine Python3.14 development interpreter with this source checkout and
the unchanged six-provider cohort: MolSysMT0c6f9c7, Viewer1187fc18,
ArgDigest07126411, PyUnitWizardf82b618e, SMonitorc1b6ce29, DepDigest032d345b.
Freeze source/Python/native identities before/after each cell. The old generated
DockingMT package label is retained separately from execution Git identity.
Check and record actual core source origin before and after pytest; this new
population does not reconstruct the prior #106 receipt's missing post-origin.

Reuse the exact original103-file Vina1.2.7 prefix under
`e5-timed-replay-20261107/layouts-admission-01/producer/engine`; verify every byte
before/after and capture actual final loaded extension hashes. Keep SDKs at
738fe8dd/95f693be; no verifier, source remotes, shared environment or build changes.
An old comparison wheel is context only, not installed receiving of this source.

Only the fresh audit node may construct a real engine: original four-record
receptor/two-record partner, origin-centred10-angstrom box, CPU1, seed17,
Vina/Vinardo, current-conformation `unbound_energy=None`. Preserve signatures,
all native parameters and exact eight-component returns. Forbid actual search,
optimization/randomization, pose-output retrieval and visualization. For the
comparison module, forbid actual native construction independently of its original
software doubles. Actual public molecular-call counters must remain empty.

Capture public score results and audit reports only in the fresh native test.
Do not write from an observer in the file-I/O/import-refusal audit controls.
Do not retain or mutate returned records. Keep original fresh-process controls
intact; subprocesses inherit CPU affinity, priority, native workers and memory/
CPU limits and remain under the parent's owned-group memory/wall monitor.
Verify all606 unchanged support declarations directly as source inputs; do not
claim installed support staging or retirement.

## Resource registration and custody

Initial host:64,978,440,192B physical RAM,58,598,387,712B available,20 logical CPUs;
load3.14/3.13/3.35, zero measured swap I/O and zero current memory PSI. Slurm exists
but no allocation; earlier applicability check was inconclusive. Free capacity is
not reserved. Cells are serial CPU0/nice10/one native/build worker,13GiB available
reserve,1GiB group RSS,2GiB address space,60/65 CPU seconds and180 wall seconds.
Estimate768MiB for the audit including its child process,256MiB for comparison;
the earlier native whole-source peak was below448MiB. Monitor owned descendants
and preserve interruptions; no automatic restart after a headroom stop.

Retain original scripts, frozen source/support/fixtures, outcomes and independent
readers under `.molsyssuite/source-scoring-evidence-20261110`, owners#73/#47/#50,
review2026-11-14. Preserve original receiver/engine/SDK custody and the human
migration backup. No package build, source refresh, native rebuild or remote CI.
Full/public/platform/hosted/interactive and source-context admission remain
separate; MolSysMT#521/#558 and original panel admission keep their owners.
