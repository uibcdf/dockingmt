"""Receive complete source scoring-evidence modules with explicit native limits."""
from collections import Counter
from functools import wraps
import inspect
import time
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib
import xml.etree.ElementTree as ET

root=Path(os.environ['DMT_SMALL_ROOT']);task=Path(os.environ['DMT_SMALL_TASK']);attempt=Path(os.environ['DMT_SMALL_ATTEMPT']);reg=json.loads((attempt/'registration.json').read_text())
def sha(p):
 with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
sdk=root/'.molsyssuite/publication-sdk';assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45';assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
old=root/'.molsyssuite/installed-small-fixtures-20261109';artifact=json.loads((attempt/'frozen-artifact.json').read_text());installation=json.loads((attempt/'frozen-installation.json').read_text());site=Path(installation['site']);assert sha(artifact['wheel'])==artifact['wheel_sha256']
assert Path(sys.executable)==Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python')
harness=root;inputs=json.loads((attempt/'frozen-qualification-inputs.json').read_text())
def verify_inputs():
 for name,digest in inputs.items():assert sha(root/name)==digest
verify_inputs();save(attempt/'qualification-inputs.json',inputs)
inventory=tomllib.loads((harness/'devtools/conda-build/resources.toml').read_text());assert len(inventory['installed_tests']['support']['files'])==606
shutil.copyfile(harness/'devtools/conda-build/resources.toml',attempt/'frozen-resources.toml')
selection=json.loads((attempt/('frozen-'+reg['selection']+'.json')).read_text())
for name in selection:
 if not name.startswith('--'):
  module=name.split('::')[0];assert (root/module).read_bytes()==(harness/module).read_bytes();destination=attempt/'inputs'/module;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(harness/module,destination)
def cohort():
 return {name:{'commit':subprocess.check_output(['git','-C',str(root.parent/name),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(root.parent/name),'status','--porcelain'],text=True),'python_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.py')},'native_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.so')},'distribution_version':metadata.version(name)} for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']}
before=cohort();assert before==json.loads((attempt/'frozen-expected-cohort.json').read_text());save(attempt/'cohort.json',before)
engine=root/'.molsyssuite/e5-timed-replay-20261107/layouts-admission-01/producer/engine';engine_receipt=root/'.molsyssuite/e1-public-composition-20261106/final_engine_byte_receipt.json';engine_hashes=json.loads(engine_receipt.read_text())['paths'];assert len(engine_hashes)==103
assert all(sha(engine/n)==digest for n,digest in engine_hashes.items());shutil.copyfile(engine_receipt,attempt/'frozen-engine-receipt.json')
sys.path[:0]=[str(root),str(engine/'lib/python3.14/site-packages')]
import pytest
import pyunitwizard as puw
units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if reg['profile']=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
forbidden_operations=[];engine_calls=[];engine_call_counts=Counter();run_ids={};provider_calls=Counter()
def forbidden(*args,**kwargs):forbidden_operations.append('Unregistered search/optimize/randomize/output/viewer work');raise AssertionError(forbidden_operations[-1])
with puw.context(default_form='pint',default_parser='pint',standard_units=units):
 caller=puw.configure.report();origins={}
 import dockingmt as dmt
 import molsysmt as msm
 import molsysviewer as msv
 import vina
 assert Path(dmt.__file__).resolve()==root/'dockingmt/__init__.py'
 origins={'dockingmt':str(Path(dmt.__file__).resolve())}
 assert Path(vina.__file__).resolve().is_relative_to(engine/'lib/python3.14/site-packages/vina')
 for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']:assert Path(__import__(name).__file__).resolve().is_relative_to(root.parent/name/name)
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 for name in ['dock','optimize','randomize','poses','energies']:setattr(vina.Vina,name,forbidden)
 def native_observed(name,operation):
  signature=inspect.signature(operation)
  @wraps(operation)
  def call(self,*args,**kwargs):
   bound=signature.bind(self,*args,**kwargs);bound.apply_defaults();values={k:v for k,v in bound.arguments.items() if k!='self'}
   if name=='__init__':
    assert reg['selection']=='audit' and 'test_fresh_native_scoring_and_rescoring_produce_auditable_evidence' in os.environ.get('PYTEST_CURRENT_TEST','')
    assert values['cpu']==1 and values['sf_name'] in ['vina','vinardo'];run_ids[id(self)]=engine_call_counts[name]+1
   elif name=='compute_vina_maps':
    assert len(values['center'])==len(values['box_size'])==3 and all(float(x)==0 for x in values['center']) and all(0<float(x)<=10 for x in values['box_size'])
   elif name=='score':assert values['unbound_energy'] is None
   elif name in ['poses','energies']:assert 1<=values['n_poses']<=2
   engine_call_counts[name]+=1;event={'call':name,'run':run_ids[id(self)],'outcome':'started','test_node':os.environ.get('PYTEST_CURRENT_TEST'),'parameters':{}};engine_calls.append(event)
   for key,value in values.items():
    if key in ['pdbqt_string']:continue
    if isinstance(value,(str,int,float,bool)) or value is None:event['parameters'][key]=value
    elif isinstance(value,(list,tuple)):event['parameters'][key]=[float(x) for x in value]
    elif hasattr(value,'tolist'):event['parameters'][key]=value.tolist()
   submissions=[]
   if name=='set_receptor':
    assert values.get('flex_pdbqt_filename') is None
    submissions=[('receptor',Path(values['rigid_pdbqt_filename']).read_bytes(),4)]
   elif name=='set_ligand_from_string':
    assert isinstance(values['pdbqt_string'],str);submissions=[('partner',values['pdbqt_string'].encode(),2)]
   elif name=='set_ligand_from_file':
    assert isinstance(values['pdbqt_filename'],str);submissions=[('partner',Path(values['pdbqt_filename']).read_bytes(),2)]
   for role,blob,maximum in submissions:
    atom_records=sum(line.startswith((b'ATOM  ',b'HETATM')) for line in blob.splitlines());assert 0<atom_records<=maximum and len(blob)<=65536
    target=attempt/'inputs/backend'/str(event['run'])/(role+'.pdbqt');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blob);event[role]={'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'atom_records':atom_records}
   start=time.perf_counter()
   try:result=operation(self,*args,**kwargs)
   except BaseException as error:event.update(outcome='raised',exception_type=type(error).__name__);raise
   else:
    event['outcome']='PASS'
    if isinstance(result,str):
     event['result_sha256']=hashlib.sha256(result.encode()).hexdigest()
     if name=='poses':
      target=attempt/'outputs/backend'/str(event['run'])/('poses-'+str(engine_call_counts[name])+'.pdbqt');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(result)
    elif getattr(result,'shape',None) is not None:
     event['result_shape']=list(result.shape)
     if name=='score':event['native_components']=result.tolist();event['native_unit']='kcal/mol'
    return result
   finally:event['elapsed_seconds']=time.perf_counter()-start;save(attempt/'engine-calls.json',engine_calls)
  return call
 for name in ['__init__','set_receptor','set_ligand_from_string','set_ligand_from_file','compute_vina_maps','score']:setattr(vina.Vina,name,native_observed(name,getattr(vina.Vina,name)))
 msv.MolSysView=forbidden
 if reg['selection']=='comparison':vina.Vina.__init__=forbidden
 def observed(name,operation):
  def call(*args,**kwargs):provider_calls[name]+=1;return operation(*args,**kwargs)
  return call
 for name in ['convert','get','set','copy','select','extract','merge','append_structures','concatenate_structures','permute_atoms']:setattr(msm,name,observed(name,getattr(msm,name)))
 for name in ['assign_partial_charges','assign_autodock_atom_types','add_missing_hydrogens','merge_nonpolar_hydrogens']:setattr(msm.build,name,observed('build.'+name,getattr(msm.build,name)))
 inventory['import_name']='dockingmt';inventory['installed_tests']['paths']=[n for n in selection if not n.startswith('--')];inventory['installed_tests']['pytest_args']=['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'pytest-cache'),'--basetemp='+str(attempt/'pytest-work')]+[n for n in selection if n.startswith('--')]
 for namespace,name in [(msm.structure,'get_rmsd'),(msm.form.string_pdbqt_text,'read_poses'),(msm.form.file_pdbqt,'read_poses')]:setattr(namespace,name,observed(namespace.__name__+'.'+name,getattr(namespace,name)))
 exports=[]
 def capture(kind,record):
  target=attempt/'outputs/exports'/(str(len(exports))+'.json');target.parent.mkdir(parents=True,exist_ok=True);save(target,record);exports.append({'kind':kind,'test_node':os.environ.get('PYTEST_CURRENT_TEST'),'file':str(target.relative_to(attempt)),'sha256':sha(target)});save(attempt/'exports.json',exports)
 def observe_public(name,operation):
  @wraps(operation)
  def call(*args,**kwargs):
   result=operation(*args,**kwargs)
   if 'test_fresh_native_scoring_and_rescoring_produce_auditable_evidence' in os.environ.get('PYTEST_CURRENT_TEST',''):
    capture(name,result.to_dict() if name=='score' else result)
   return result
  return call
 for name in ['score','audit_pose']:setattr(dmt,name,observe_public(name,getattr(dmt,name)))
 status=int(pytest.main(inventory['installed_tests']['pytest_args']+[str(root/n) if not n.startswith('--') else n for n in selection]))
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 final_origins={'dockingmt':str(Path(dmt.__file__).resolve())}
 assert final_origins==origins
counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
from pytest_receptor import read_artifact
events=read_artifact(attempt/'events.jsonl');assert events.complete
verify_inputs();assert cohort()==before and not forbidden_operations and ((engine_call_counts['__init__']==engine_call_counts['score']==0) if reg['selection']=='comparison' else (engine_call_counts['__init__']==engine_call_counts['score']==2)) and all(c['outcome']=='PASS' for c in engine_calls) and all(sha(engine/n)==digest for n,digest in engine_hashes.items())
native_maps={}
for line in Path('/proc/self/maps').read_text().splitlines():
 fields=line.split(None,5)
 if len(fields)==6 and fields[5].startswith('/') and '.so' in fields[5] and Path(fields[5]).is_file():native_maps[fields[5]]=sha(fields[5])
save(attempt/'native-maps.json',native_maps)
save(attempt/'receipt.json',{'profile':reg['profile'],'selection':selection,'pytest_exit_code':status,'counts':counts,'receptor_final':events.final.data,'warnings':events.final.data['counts']['warnings'],'provider_call_counts':dict(provider_calls),'forbidden_operations':forbidden_operations,'engine_call_counts':dict(engine_call_counts),'engine_calls':engine_calls,'actual_engine_version':vina.__version__,'actual_engine_origin':str(Path(vina.__file__).resolve()),'comparison_wheel_sha256':artifact['wheel_sha256'],'runtime_version':dmt.__version__,'qualification_source':reg['qualification_source'],'source_origins':final_origins,'cohort_unchanged':True,'caller_policy':caller,'declared_support_records':606,'scope':'source; no new installed artifact','full_scientific_gate':False,'exports':exports,'deliberate_stubs_are_not_native_calls':True})
raise SystemExit(status)
