"""Authenticate failed E3 selections and their bounded successful prefixes."""
from copy import deepcopy
import hashlib
import json

def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    def sha(value):
        return hashlib.sha256(value).hexdigest()
    legacy='ae0e9d3beb4d14363ea6edb1bff591c56d53b02295082bae8c281d9284d84b9e'
    current='49f054d3fa258bcf965619d7edb4f154949512aa74a3d57a0876da19af8ee9e0'
    original=records['producer/original-worker.py.txt'].decode()
    baseline=records['producer/baseline-worker.py.txt'].decode()
    worker=records['producer/worker.py.txt'].decode()
    assert sha(original.encode())=='70ab5f3f48f2a13116d9da29c16c0f2d0aca387ce7af529761fca681b8ca2487'
    assert sha(baseline.encode())=='1f40c35de0cf402c103311169fcb6d6d5569eb75230b835d0c5ee600f50e609a'
    route=obj('producer/route-change.json')
    assert route['worker_sha256']==sha(worker.encode())
    policy=records['producer/policy-insertion.py.txt'].decode()
    control=records['producer/control-insertion.py.txt'].decode()
    replacement=obj('producer/gate-replacement.json')
    start='        immutable = []'
    end="        stage = 'final-nonmutation-and-custody'"
    def core(text):
        return text[text.index(start):text.index(end)]
    assert core(baseline).replace(policy,'')==core(original)
    assert core(worker).replace(control,'').replace(replacement['new'],replacement['old'])==core(baseline)
    assert sha(records['producer/original-source.pdbqt'])==legacy
    identity=obj('producer/baseline-source-identity.json')
    historic_manifest=records['producer/historical-e2-manifest.json']
    assert sha(historic_manifest)==identity['manifest_sha256']
    historic_row=next(x for x in json.loads(historic_manifest)['files'] if x['path']==identity['member'])
    assert historic_row['decoded_sha256']==identity['source_sha256']==legacy
    policy_identity=obj('producer/provider-policy-identities.json')
    for row in policy_identity['files']:
        assert sha(records['producer/'+row['frozen']])==row['sha256']
    setup=obj('setup-normal-01/failure.json')
    assert setup['outcome']=='FAIL' and setup['scientific_child_started'] is False and setup['molecular_calls']==0
    for label,stage in [('historical-replay-normal','pdbqt'),('paired-control-normal','h5_write')]:
        prefix='attempts/'+label+'/'
        resource=obj(prefix+'resource-outcome.json')
        registration=obj(prefix+'registration.json')
        failure=obj(prefix+'failure.json')
        assert resource['outcome']=='FAIL' and resource['exit_code']==1
        assert resource['resource_interruption'] is None and resource['group_terminal'] and not resource['remaining_live_owned_pids']
        assert failure['stage']==stage and not failure['reference_accepted'] and not failure['e3_accepted']
        assert prefix+'receipt.json' not in records
        assert all(v<=registration['direct_caps'][k] for k,v in failure['direct_counts'].items())
        for role in ['source','experimental']:
            report=obj(prefix+role+'-policy-report.json')
            fields=obj(prefix+role+'-policy-fields.json')
            history=obj(prefix+role+'-policy-history.json')
            assert report['atom_correspondence']=={'indices':'identity','n_atoms':39}
            assert report['hydrogen_atom_indices']==list(range(24,39))
            assert report['changed_atom_indices']==(list(range(24,39)) if role=='source' else [])
            expected=deepcopy(fields['before'])
            expected['allows_implicit_hydrogens'][24:]=[False]*15
            assert fields['after']==expected
            assert history['after'][:-1]==history['before'] and history['after'][-1]['report']==report
            before=obj(prefix+('source-authority' if role=='source' else 'experimental-generated')+'-snapshot.json')
            after=obj(prefix+role+'-policy-closed-snapshot.json')
            before['chemical_states']['version']=2
            state=before['chemical_states']['states'][0]
            actual=after['chemical_states']['states'][0]
            state['preparation_history']=deepcopy(actual['preparation_history'])
            state['atom_attributes']['columns']['allows_implicit_hydrogens']['values']=fields['after']['allows_implicit_hydrogens']
            assert before==after
        witness=obj(prefix+'full39-correspondences.json')
        assert witness['search_complete'] and witness['search_scope']=='all_chemical_correspondences'
        assert witness['n_candidate_matches']==len(witness['atom_correspondences'])==2
        assert all(len(x)==39 for x in witness['context_atom_correspondences'])
    p='attempts/paired-control-normal/'
    actual=obj(p+'source-identity.json')
    assert actual=={'legacy_sha256':legacy,'control_sha256':current,'current_source_sha256':current,'matched_current_source_control':True,'matched_original_source_pdbqt':False,'legacy_source_authenticated':True,'historical_engine_input_replaced':False,'common_receptor_frame_admitted':False}
    assert records[p+'control-prepared.pdbqt']==records[p+'source-prepared.pdbqt']
    assert sha(records[p+'source-prepared.pdbqt'])==current and current!=legacy
    reduced=obj(p+'prepared25-correspondences.json')
    assert reduced['search_complete'] and reduced['search_scope']=='all_chemical_correspondences'
    assert len(reduced['atom_correspondences'])==reduced['n_candidate_matches']==2
    assert all(len(x)==25 for x in reduced['atom_correspondences'])
    for role in ['source','experimental']:
        assert obj(p+role+'-cip.json')['atom_stereochemistry'][7]=='R'
        inventory=obj(p+role+'-hydrogen-inventory.json')
        assert len(inventory['atom_indices'])==25 and sum(inventory['total_hydrogen_counts'])==15
        declaration=obj(p+role+'-prepared-declaration.json')
        assert declaration['n_atoms']==25 and declaration['torsion_dof']==0
    failure=obj(p+'failure.json')
    assert failure['message']=='H5MSM 0.5 probe cannot encode molecular mechanics yet.'
    counts=failure['direct_counts']
    caps=obj(p+'registration.json')['direct_caps']
    assert {k:v for k,v in counts.items() if k not in ['h5_write','h5_read']}=={k:v for k,v in caps.items() if k not in ['h5_write','h5_read']}
    assert counts['h5_write']==3 and counts['h5_read']==0
    assert p+'experimental-heavy24.h5msm' in records and p+'experimental-generated39.h5msm' in records
    assert p+'source-prepared25.h5msm' not in records
    for key in ['producer/campaign-terminal.json','historical-selection/producer/campaign-terminal.json']:
        terminal=obj(key)
        assert terminal['outcome']=='FAIL' and terminal['unattempted']==['pm_fs'] and not terminal['further_molecular_work_permitted']
    return {'complete_profiles':[],'failed_normal_selections':2,'zero_call_setup_failures':1,'pm_fs':'unattempted','current_control_byte_equality':True,'historical_identity_preserved':True,'full39_maps':2,'prepared25_maps':2,'h5_write_calls':3,'h5_read_calls':0,'final_live_nonmutation_and_custody_checks':'unreached','reference_accepted':False,'e3_accepted':False,'molecular_replay':False,'native_searches':0}
