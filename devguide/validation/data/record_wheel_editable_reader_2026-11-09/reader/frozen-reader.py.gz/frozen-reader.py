"""Receive exact installed-record evidence without product imports or replay."""
import base64
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import tomllib
import xml.etree.ElementTree as ET

_tool_path = Path(__file__).resolve().parents[1] / 'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_path.read_bytes()).hexdigest() == '6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool = json.loads(_tool_path.read_text())
_prefix = Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)): hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()} == _tool['files_sha256']
sys.path.insert(0, str(_prefix))
from pytest_receptor import read_artifact


def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    wheel = 'a50b21c25e0e254af321836f404f54553611e9d299ee3fdcfe2abe539889ac11'
    labels = ['build-01', 'setup-01', 'pilot-01', 'normal-01', 'pm_fs-01']
    for label in labels:
        p = 'attempts/' + label + '/'
        r = obj(p + 'resource-outcome.json')
        reg = obj(p + 'registration.json')
        receipt = obj(p + 'receipt.json')
        assert r['outcome'] == receipt['outcome'] == 'PASS' and r['exit_code'] == 0 and receipt['qualification_complete']
        assert r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids']
        assert r['minimum_available_bytes'] >= 13 * 1024**3 and r['sampled_peak_group_rss_bytes'] < 1024**3 and r['elapsed_seconds'] <= 60
        assert r['policy'] == reg['policy'] and r['policy']['cpu'] == 0 and r['policy']['nice'] == 10 and r['policy']['workers'] == 1
        assert reg['source_commit'] == '841a34dd30e848adfb72087a27864253cbe2602d'
        for name, digest in reg['frozen_sha256'].items():
            assert hashlib.sha256(records[p + name]).hexdigest() == digest
        assert records[p + 'cohort.json'] == records['producer/cohort.json']
    artifact = obj('producer/artifact.json')
    installation = obj('producer/installation.json')
    assert artifact['wheel_sha256'] == wheel and artifact['version'] == '0.0.0+342.g841a34d'
    assert artifact['source_commit'] == '841a34dd30e848adfb72087a27864253cbe2602d'
    assert artifact['runtime_paths'] == 67 and len(installation['tests_sha256']) == 21
    inventory = tomllib.loads(records['attempts/build-01/frozen-resources.toml'].decode())
    runtime = {n.removeprefix('site-packages/') for n in inventory['required_paths']}
    assert len(runtime) == 67 and set(installation['consumer_sha256']) == runtime
    assert 'dockingmt/exceptions.py' in runtime
    for name in runtime:
        assert installation['consumer_sha256'][name] == artifact['payload_sha256'][name]
    for name, digest in artifact['source_sha256'].items():
        assert artifact['payload_sha256'][name] == digest
    for name, digest in installation['tests_sha256'].items():
        assert hashlib.sha256(records['tests/' + name]).hexdigest() == digest
    for suffix in ['METADATA', 'RECORD', 'WHEEL', 'LICENSE']:
        name = next(n for n in artifact['payload_sha256'] if n.endswith('/' + suffix))
        assert hashlib.sha256(records['attempts/build-01/' + suffix]).hexdigest() == artifact['payload_sha256'][name]
    meta = records['attempts/build-01/METADATA'].decode()
    assert 'Version: ' + artifact['version'] in meta and 'License-Expression: MIT' in meta
    rows = list(csv.reader(io.StringIO(records['attempts/build-01/RECORD'].decode())))
    assert {r[0] for r in rows} == set(artifact['payload_sha256'])
    for name, digest, size in rows:
        if name.endswith('.dist-info/RECORD'):
            assert not digest and not size
        else:
            assert digest == 'sha256=' + base64.urlsafe_b64encode(bytes.fromhex(artifact['payload_sha256'][name])).rstrip(b'=').decode()
            assert int(size) >= 0
    pilot = obj('attempts/pilot-01/receipt.json')
    assert pilot['positive_roundtrip'] and pilot['public_exception_aliases'] == 13 and pilot['public_argument_error']
    assert len(pilot['refusals']) == 4 and all(x['refused'] for x in pilot['refusals'])
    assert {x['mode'] for x in pilot['refusals']} == {'source_core', 'source_addon', 'package_path', 'omitted_addon'}
    for label in ['normal-01', 'pm_fs-01']:
        p = 'attempts/' + label + '/'
        r = obj(p + 'receipt.json')
        assert r['pytest_exit_code'] == 0 and r['counts'] == {'tests': 1062, 'failures': 0, 'errors': 0, 'skipped': 0}
        xml = ET.fromstring(records[p + 'junit.xml'])
        counts = {k: sum(int(row.get(k, '0')) for row in xml.iter('testsuite')) for k in ['tests', 'failures', 'errors', 'skipped']}
        assert counts == r['counts'] and len(list(xml.iter('testcase'))) == 1062
        with tempfile.TemporaryDirectory(prefix='dmt-wheel-current-reader-', dir='/tmp') as tmp:
            path = Path(tmp) / 'events.jsonl'
            path.write_bytes(records[p + 'events.jsonl'])
            artifact_events = read_artifact(path)
            assert artifact_events.complete and artifact_events.final.data == r['receptor_final']
            final = artifact_events.final.data
            c = final['counts']
            assert final['exitstatus'] == 0 and c['collected'] == c['executed'] == c['passed'] == 1062
            assert c['failed'] == c['errors'] == c['not_executed'] == c['skipped'] == 0 and c['deselected'] == 1
            assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
        assert r['wheel_sha256'] == wheel and not r['molecular_calls_attempted'] and r['source_free_harness']
        assert set(r['installed_origins']['roots']) == {'dockingmt', 'molsysviewer_dockingmt'}
        assert {'dockingmt.interactions', 'dockingmt.exceptions'} <= set(r['installed_origins']['loaded'])
        assert r['sys_prefix'] == installation['prefix'] and r['sys_prefix'] != r['sys_base_prefix']
        sidecar = obj(p + 'support-sidecar.json')
        assert sidecar == r['support'] and sidecar['checks'] == 7 and len(sidecar['files']) == 594
        assert sidecar['imports_retired'] and sidecar['resources_retired'] and sidecar['state'] == 'verified-support'
        assert sidecar['executed_tests'] == 1062 and sidecar['pytest_exit_code'] == 0
        assert sum(x['kind'] == 'code' for x in sidecar['files']) == 30 and sum(x['kind'] == 'data' for x in sidecar['files']) == 564
        context = sidecar['binding']['context']
        assert context['sha256'] == wheel and context['provider_sha'] == '95f693be10c9205ab9b912cb53453710a207bf45'
        assert context['qualification_sha'] is None and context['candidate_sha'] is None and sidecar['binding']['source_state'] == 'unknown'
        assert sidecar['binding']['provider_state'] == 'verified-commit-and-runner-files'
    for name in ['frozen-worker.py', 'frozen-run.py', 'frozen-selection.json', 'frozen-resources.toml', 'frozen-reporting-tools-receipt.json', 'frozen-unit-support-receipt.json', 'frozen-prescription.md']:
        assert records['attempts/normal-01/' + name] == records['attempts/pm_fs-01/' + name]
    assert obj('attempts/normal-01/receipt.json')['caller_policy']['standard_units'][:2] == ['nm', 'ps']
    assert obj('attempts/pm_fs-01/receipt.json')['caller_policy']['standard_units'][:2] == ['pm', 'fs']
    for name, module in tuple(sys.modules.items()):
        if name == 'pytest_receptor' or name.startswith('pytest_receptor.'):
            path = Path(module.__file__).resolve()
            assert path.is_relative_to(_prefix) and hashlib.sha256(path.read_bytes()).hexdigest() == _tool['files_sha256'][str(path.relative_to(_prefix))]
    assert not any(x == 'dockingmt' or x.startswith(('dockingmt.', 'molsysmt', 'molsysviewer', 'vina', 'rdkit', 'unyt', 'sympy', 'mpmath')) for x in sys.modules)
    return {'complete_profiles': ['normal', 'pm_fs'], 'cases_per_profile': 1062, 'same_original_wheel': wheel, 'runtime_paths': 67, 'support_files': 594, 'validator_refusals': 4, 'public_exception_aliases': 13, 'source_runtime_tests_unchanged': True, 'native_reporting_and_junit_agree': True, 'molecular_replay': False, 'scope': 'Private wheel with exact editable siblings on Linux/Python3.14; not public/full installed/matrix qualification'}
