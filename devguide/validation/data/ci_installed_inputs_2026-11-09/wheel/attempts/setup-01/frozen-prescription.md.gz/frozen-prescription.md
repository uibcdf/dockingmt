# Private installed input-declaration receiving

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), #30/#50.
Registered2026-11-09. Fixed code/test producer
`9a40e385d951b0521f6509de6b127083b78be61c`, retaining #97/#98/#99's new
snapshot, source-I/O and offline test-import behavior. Current uncommitted CI
configuration work is excluded from this frozen producer and package.

## Prospective single-artifact route

Build exactly one pure-Python private wheel from a clean detached copy of that
published producer, offline/no-dependencies/no-build-isolation. Preserve generated
version/source distinctions and authenticate every67 runtime path, complete
metadata/RECORD/license/entry point and original wheel SHA-256. No provider,
Rust/Fortran/native build, dependency resolution or public package selection.
Create one real private venv borrowing the routine environment's dependencies;
install that exact consumer wheel normally without dependencies, plus the
already verified private test-only unit/reporting inputs. Preserve metadata/
PEP610/import origins and ordinary pip-check, and inspect all participating
editable provider source/native fingerprints before/after each stage.

The exact current receiving cohort uses MolSysMTefbe67e1, Viewer1187fc18,
ArgDigest07126411 and the unchanged recorded support sources/native bytes.
This is a private installed consumer with development providers, not a public
closure or ordinary hosted clone installation. The separate HTTPS-only shared
source-context refusal under MolSysSuite #178 is retained honestly under #100;
this route does not override or reinterpret it. Earlier wheels/receipts retain
their original source, bytes and older provider composition.

## Installed controls and whole selection

Run the original shared installed-import validator's positive admission and
four actual source-shadow/package-path/omitted-addon refusals in private fresh
processes. Verify all13 public exception aliases against their original classes.
Then execute normal followed by pm/fs, identical code/wheel/test inputs, using
the shared installed-test support mechanism and its complete594-input retirement.
Export the fixed producer to a source-free harness and remove both runtime
packages from that harness. Actual consumer/addon imports must come from the
installed wheel; scientific siblings retain their named development origins.

The complete selection unions the earlier1062-case/21-module offline record
receiving with the five affected declaration/I-O/prepared/outcome/batch modules.
Keep the old native-scoring test and three existing native batch cases explicitly
deselected; every original assertion remains in its own scientific/native gate.
Guard optional engine imports, actual molecular operations and Viewer construction.
No search/scoring/preparation/geometry/canvas, provider update or shared install.
Do not infer numerical performance or full scientific acceptance from test counts.

## Resource and stop policy

Private `.molsyssuite/record-wheel-inputs-20261109`, #47/#30/#50,
review2026-11-14. Serial CPU0/nice10/one native/build worker; check actual available
RAM before each stage, monitor13GiB available reserve/1GiB group RSS/2GiB address
space/45CPU/60wall bounds. Estimated peaks256MiB build,384MiB setup,512MiB pilot/
whole profile. Shared-host preflight retains low load/zero sampled swap/PSI and
no Slurm allocation. Stop on headroom interruption; preserve it and do not
restart automatically or raise bounds. No previous interrupted native build is
restarted by this small pure-Python consumer build.

Seal the actual build/setup/pilot/complete results and original wheel identity,
then read evidence independently without replay. Applicable final local and
fresh committed-source checks precede direct `[skip ci]` publication. Public Conda,
source/native/OS/minor/full installed matrices, actual canvas and hosted #28/#21
remain separate and unexecuted. The wheel is private qualification, not a release,
new canonical version, tag, upload or change to disabled suite PyPI routes.
