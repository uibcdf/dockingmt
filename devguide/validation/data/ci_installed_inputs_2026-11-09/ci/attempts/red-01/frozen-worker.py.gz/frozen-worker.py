"""Administrative gates and the actual shared source-context verifier."""
import hashlib,importlib.abc,json,os,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(os.environ['DMT_CI_ROOT']);task=Path(os.environ['DMT_CI_TASK']);attempt=Path(os.environ['DMT_CI_ATTEMPT']);reg=json.loads((attempt/'registration.json').read_text());stage=reg['stage']
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
r={'stage':stage,'outcome':'PASS','qualification_complete':True,'source_base':reg['source_base'],'scope':reg['scope']}
if stage in ['old-context','current-context']:
 args=[sys.executable,'-B','devtools/check_dependency_routes.py','--context','ci-3.14','--source-root','argdigest-source='+str(root.parent/'argdigest'),'--source-root','molsysmt-source='+str(root.parent/'molsysmt'),'--source-root','viewer-py314='+str(root.parent/'molsysviewer')]
 with (attempt/'preflight.stdout').open('xb') as out,(attempt/'preflight.stderr').open('xb') as err: result=subprocess.run(args,cwd=root,stdout=out,stderr=err)
 r['preflight_exit_code']=result.returncode;r['command']=args
 if result.returncode:
  r['outcome']='FAIL';r['source_scope']='Declared context refused the actual source directories; no compatibility test executed'
 else:
  d=json.loads((attempt/'preflight.stdout').read_text());r['source_scope']='Actual shared installed-context receiving on routine3.14 only';r['preflight']=d
else:
 tool=json.loads((attempt/'frozen-reporting-tools-receipt.json').read_text());prefix=Path(tool['prefix'])
 assert {str(p.relative_to(prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in prefix.rglob('*') if p.is_file()}==tool['files_sha256'];sys.path.insert(0,str(prefix))
 forbidden=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:forbidden.append(fullname);raise AssertionError('Administrative test imported a scientific provider')
 sys.meta_path.insert(0,Block())
 import pytest
 code=int(pytest.main(['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'cache')]+reg['selection']))
 from pytest_receptor import read_artifact
 events=read_artifact(attempt/'events.jsonl');assert events.complete and not forbidden
 counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
 r.update(outcome='PASS' if code==0 else 'FAIL',counts=counts,pytest_exit_code=code,receptor_final=events.final.data,scientific_imports=forbidden)
(attempt/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(0 if r['outcome']=='PASS' else 1)
