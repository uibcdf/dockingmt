"""Bounded declaration/context gates; no molecular or remote CI work."""
import ast,hashlib,json,os,resource,shutil,signal,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];task=Path(__file__).parent
stage=sys.argv[1];assert stage in ['red','green','old-context','current-context']
attempt=task/(stage+'-'+sys.argv[2]);attempt.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py';assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}];assert len(nodes)==6
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60};assert available()>policy['available_reserve_bytes']+512*1024**2
selection=['devtools/tests/test_ci_source_composition.py']
if stage=='green':selection+=['devtools/tests/test_distribution_contract.py','devtools/tests/test_installed_support.py','devtools/tests/test_coverage_workflow.py','devtools/tests/test_result_export_resources.py','devtools/tests/test_source_0_1_0_qualification.py','devtools/tests/test_3ptb_interaction_hosted.py','tests/test_reporting_protocol.py','tests/test_ci_backlog.py']
inputs=['devtools/dependency_routes.toml','devtools/conda-envs/test_env.yaml','devtools/conda-envs/e4_env.yaml','.github/workflows/ci.yml','.github/workflows/full-matrix.yml','.github/workflows/qualify-3ptb-interactions.yml','.github/workflows/qualify-source-0.1.0.yml','devtools/check_dependency_routes.py','devguide/validation/ci_source_alignment_2026-11-09.md']+selection
for name in inputs:shutil.copyfile(root/name,attempt/('frozen-'+name.replace('/','__')))
for name in ['run.py','worker.py','reporting-tools-receipt.json']:shutil.copyfile(task/name,attempt/('frozen-'+name))
reg={'stage':stage,'source_base':'9a40e385d951b0521f6509de6b127083b78be61c','policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':256*1024**2,'selection':selection,'frozen_sha256':{p.name:sha(p) for p in attempt.iterdir() if p.is_file()},'inputs_sha256':{name:sha(root/name) for name in inputs},'scope':'Bounded CI declaration/installed-source context only; no molecular/native/hosted/public gate'}
(attempt/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
env=os.environ.copy();env.update(DMT_CI_ROOT=str(root),DMT_CI_TASK=str(task),DMT_CI_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',DOCKINGMT_SUITE_ROOT=str(root/'.molsyssuite/sdk'))
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
 process=subprocess.Popen([sys.executable,'-B','-I',str(attempt/'frozen-worker.py')],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);outcome=monitor(process,policy)
assert {name:sha(root/name) for name in inputs}==reg['inputs_sha256']
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
if (attempt/'receipt.json').exists():
 r=json.loads((attempt/'receipt.json').read_text());print(json.dumps({k:r[k] for k in ['outcome','counts','preflight_exit_code','source_scope'] if k in r}))
if outcome['outcome']!='PASS':print((attempt/'stdout.log').read_text()[-2600:]);print((attempt/'stderr.log').read_text()[-1200:])
raise SystemExit(0 if outcome['outcome']=='PASS' else 1)
