# Current CI source-context alignment

Owner: [DockingMT #100](https://github.com/uibcdf/dockingmt/issues/100).
Registered2026-11-09; baseline `9a40e385d951b0521f6509de6b127083b78be61c`.
The next source CI checkpoint must distinguish current received development
sources from original manual scientific/candidate contexts. Updating declarations
is not an executed hosted matrix or public dependency qualification.

## Prospective configuration selection

Current ordinary four-minor CI/full-matrix routes select the exact published,
previously received ArgDigest `07126411f108ee1ff607e9c9a0816109b2c9253e`,
MolSysMT `efbe67e1c6042078144bce1db24aa80bb565dbd2` and Viewer
`1187fc187247aa2d20d01791856a541d50562bcb`. The earlier source IDs remain
usable by ordinary CI; add distinct historical source IDs for the original
manual E4 context and only update its preflight labels. Retain every original
E4 checkout/environment/input/scientific command and the fixed0.1.0 candidate
workflow/source declarations. Keep all matrices/triggers/test/native commands,
public runtime bounds/optionality and existing SDK pins unchanged.

Review six immutable old/new provider pyproject records; declare current MT's
h5py/pandas/Jinja2/networkx/tqdm/matplotlib bootstrap requirements explicitly in
the current test environment, without rewriting the frozen E4 environment.
Use the supported shared dependency-context API; no local source installer or
new shared workflow abstraction is introduced. MolSysSuite #31 retains the
measured local source-acquisition variation/removal condition.

## Qualification and limits

First retain the actual old-context preflight refusal against current clean
editable sources and the new configuration guards failing at old declarations.
Then run complete affected administrative/source-context guards and actual
shared installed-context3.14 preflight, with provider metadata/origins and clean
source heads checked. A test guard scopes ordinary CI contexts separately from
frozen E4; their prior accidental equality must not silently couple them.
Independently receive code/declaration/pytest/SDK/input evidence without replay.
No new native scientific calculation/build, shared install, solve or remote CI.

Private `.molsyssuite/ci-alignment-20261109`, owners #100/#47/#50, review2026-11-14.
A bounded cached `suite_status --no-fetch` snapshot compares already received
immutable sources; no sibling source/ref update occurs. Preserve its clean/dirty/
ahead/behind attention items, including human migration and deliberately older
Viewer. Headroom preflight shows60.7GB available, low load(0.52/0.34/0.33),
zero sampled swap activity/PSI and no Slurm allocation. Headroom is not reserved.
Cells run CPU0/nice10/one native worker,13GiB available reserve/1GiB group RSS/
2GiB address space/45CPU/60wall bounds. Stop on headroom interruption without
automatic restart or increased limits. Estimated administrative RSS below256MiB.

Required four-minor/full source/native/platform/public matrices remain unexecuted
under #21/#28/#30/#47. Applicable local/fresh committed-source checks precede
`[skip ci]` publication. Package publication, actual canvas and #558's panel
maps/history stay separate. The independent private-wheel receiving, if executed,
uses its own fixed producer/file/selection and does not replace these gates.

## Measured outcomes and independent provider handoff

The original source-context preflight exits1 at ArgDigest's old declared commit
versus actual current clean directory. New guards fail13 of14 at original
configuration (one preserved candidate-context control passes). After source/
bootstrap alignment, the first whole administrative selection has one reporting-
index failure;125 JUnit items comprise99 tests and26 subtests. Regenerating the
new report index yields99 tests plus26 subtests PASS, no skips/warnings/errors.

Actual aligned routine3.14 preflight still exits1, now at the documented
HTTPS-only repository-origin profile. The three installed clones use ordinary
GitHub SSH origins. Both SDK738fe8dd/publicationSDK95f693be and current canonical
source retain that limitation. This is unsupported profile coverage, not a
provider defect against its contract. [MolSysSuite #178](https://github.com/uibcdf/molsyssuite/issues/178)
requests an existing supported route or bounded reviewed extension. Preserve the
actual refusal; do not change user remotes/shared metadata, normalize provider
logic downstream or override Git configuration to make the probe appear to pass.
Numeric/source-context receiving after that refusal is unreached. #100 stays
partial for its actual-context/hosted evidence; configuration source delivery is
separate. The frozen original E4 environment and fixed-candidate workflow remain
byte-identical, with only E4 source-root labels changed to its historical IDs.
