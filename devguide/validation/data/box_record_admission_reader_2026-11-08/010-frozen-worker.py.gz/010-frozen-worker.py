"""Authenticate original coercion and red/green source qualification records."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(os.environ['DMT_GUIDES_ROOT'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
folder = root / 'devguide/validation/data/box_record_admission_2026-11-08'
expected = 'f115c01e500a2dbb898834978f662e10f14c181ac788f5ba231458ad592260f2'
assert hashlib.sha256((folder / 'manifest.json').read_bytes()).hexdigest() == expected
manifest = json.loads((folder / 'manifest.json').read_text())
assert len(manifest['files']) == 52
records = {}
for row in manifest['files']:
    assert (folder / row['path']).resolve().parent == folder.resolve()
    stored = (folder / row['path']).read_bytes()
    assert len(stored) == row['bytes'] and hashlib.sha256(stored).hexdigest() == row['sha256']
    raw = gzip.decompress(stored)
    assert len(raw) == row['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == row['decoded_sha256']
    assert row['original_path'] not in records
    records[row['original_path']] = raw
def read(name):
    return json.loads(records[name])
for label in ['probe-01', 'red-01', 'green-01']:
    resource = read(label + '/resource-outcome.json')
    assert resource['outcome'] == ('FAIL' if label == 'red-01' else 'PASS')
    assert resource['resource_interruption'] is None and resource['group_terminal'] and not resource['remaining_live_owned_pids']
    assert resource['policy']['available_reserve_bytes'] == 13 * 1024**3
    registration = read(label + '/registration.json')
    assert hashlib.sha256(records[label + '/frozen-worker.py']).hexdigest() == registration['worker_sha256']
observations = read('probe-01/observations.json')['rows']
assert len(observations) == 8 and all(row['caller_record_preserved'] for row in observations)
assert all(row['reader']['accepted'] for row in observations if row['case'] in ['boolean', 'text', 'valid'])
assert all(row['reader']['error'] == 'TypeError' for row in observations if row['case'] == 'complex')
red = read('red-01/receipt.json')
assert red['outcome'] == 'FAIL' and red['observations'] == [{'profile': 'normal', 'exit_code': 1, 'tests': 78, 'failures': 38, 'errors': 0, 'skipped': 0}]
assert red['inputs_sha256']['dockingmt/core/search_domain.py'] == read('plan.json')['original_runtime_sha256']
for label, profiles, count in [('red-01', ['normal'], 78), ('green-01', ['normal', 'pm-fs'], 234)]:
    receipt = read(label + '/receipt.json')
    for name, sha in receipt['inputs_sha256'].items():
        assert hashlib.sha256(records[label + '/frozen-' + name.replace('/', '__')]).hexdigest() == sha
    assert receipt['molecular_operations'] == receipt['native_builds'] == receipt['package_installs'] == 0
    assert [row['profile'] for row in receipt['observations']] == profiles
    for profile in profiles:
        child = read(label + '/' + profile + '-receipt.json')
        assert child['molecular_calls_attempted'] == child['optional_engines_loaded'] == []
        for key in ['default_form', 'default_parser', 'standard_units']:
            assert child['caller_policy_before'][key] == child['caller_policy_after'][key]
        parsed = ET.fromstring(records[label + '/' + profile + '.xml'])
        assert len(list(parsed.iter('testcase'))) == count
        assert len(list(parsed.iter('failure'))) == (38 if label == 'red-01' else 0)
        assert not list(parsed.iter('error')) and not list(parsed.iter('skipped'))
        if label != 'red-01':
            assert child['pytest_exit_code'] == 0
    if label != 'red-01':
        assert receipt['outcome'] == 'PASS' and all(row['tests'] == count and row['failures'] == row['errors'] == row['skipped'] == row['exit_code'] == 0 for row in receipt['observations'])
assert read('green-01/receipt.json')['inputs_sha256']['dockingmt/core/search_domain.py'] != red['inputs_sha256']['dockingmt/core/search_domain.py']
assert read('owner-evidence.json')['owner_issue']['issue_number'] == 85
source = read('artifact-source-review.json')['observations']
assert source['rust_wheels']['rust_tree'] == source['public_argdigest']['rust_tree'] == '32cfb07b9c26ae9ad3ed379c1b76fab85669cf67'
assert source['corrections642644646']['rust_tree'] == 'fb25b2eac60b6e706c712e788119b3dad94329fe'
metadata = read('artifact-triage.json')['metadata']
manual = json.loads(metadata['manual'])['workflow_runs']
assert len(manual) == 15 and len(json.loads(metadata['pull_requests'])['workflow_runs']) == 30 and len(json.loads(metadata['actions_recent'])['workflow_runs']) == 10
assert any(row['id'] == 41839338780 and row['head_sha'] == source['rust_wheels']['source'] for row in manual)
assert any(row['id'] == 42259461880 and row['head_sha'] == source['public_argdigest']['source'] for row in manual)
assert len(json.loads(metadata['releases'])) == 3
assert all(not row['assets'] for row in json.loads(metadata['releases']))
receipt = {'stage': 'reader', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members_verified': 52, 'primary_manifest_sha256': expected, 'original_failed_cases': 38, 'original_red_total': 78, 'final_green_cases_per_policy': 234, 'final_green_policies': ['normal', 'pm-fs'], 'molecular_operations': 0, 'scope': 'Stored/decoded source, original diagnostic/red and raw final two-policy JUnit/policy/resource authentication; no execution rerun or installed/public/scientific acceptance'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
