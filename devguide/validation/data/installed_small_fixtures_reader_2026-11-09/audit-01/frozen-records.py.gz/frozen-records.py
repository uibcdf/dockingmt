"""Seal and independently read this bounded native receiving population."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/installed-small-fixtures-20261109';stage=sys.argv[1]
primary=root/'devguide/validation/data/installed_small_fixtures_2026-11-09';companion=root/'devguide/validation/data/installed_small_fixtures_reader_2026-11-09'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);destination=folder/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_small_fixtures@1','owner':'uibcdf/dockingmt#103','parent_owner':'uibcdf/dockingmt#47','qualification_base':'bed8a8a4a52ee60ddd38e763f9463c357c27192c','fixed_runtime_producer':'bba53f602c2e30a5817808bda303c0f736405651','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 result={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in result;result[row['original_path']]=raw
 return result
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored software evidence; zero molecular replay'}
if stage=='seal':
 names=['run.py','worker.py','source_worker.py','installed_worker.py','gates.py','wheel.py','records.py','pilot.json','expanded.json','source-regression.json','source-expanded.json','installed-expanded.json','installed-regression.json','artifact.json','installation.json','metadata-comparison.json','custody.json','provider-status.json','qualification-inputs.json']
 paths=[(task/name,'producer/'+name+('.txt' if name.endswith('.py') else '')) for name in names]
 labels=['pilot-01','expanded-normal-01','expanded-pm-fs-01','source-red-01','source-red-02','source-green-01','source-expanded-normal-01','source-green-pm-fs-01','source-expanded-pm-fs-01','source-01','source-02','committed-source','build-01','install-01','installed-expanded-normal-01','installed-expanded-pm-fs-01','installed-regression-normal-01','installed-regression-pm-fs-01']
 for label in labels:
  directory=task/label;paths.extend((p,'attempts/'+label+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  if (directory/'inputs').is_dir():paths.extend((p,'attempts/'+label+'/inputs/'+str(p.relative_to(directory/'inputs'))) for p in sorted((directory/'inputs').rglob('*')) if p.is_file())
 for name in ['dockingmt/preparation/_export.py','tests/test_prepared_export_units.py']:
  paths.append((root/name,'qualified/'+name))
 old=task/'old-export.py.txt';old.write_bytes(subprocess.check_output(['git','show','bed8a8a4a52ee60ddd38e763f9463c357c27192c:dockingmt/preparation/_export.py'],cwd=root));paths.append((old,'original/_export.py.txt'))
 receipt.update(seal(primary,paths));save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 old=d('attempts/expanded-pm-fs-01/receipt.json');assert old['counts']=={'tests':64,'failures':1,'errors':0,'skipped':0} and old['pytest_exit_code']==1
 red=d('attempts/source-red-02/receipt.json');assert red['counts']=={'tests':20,'failures':6,'errors':0,'skipped':0}
 for label,count,warnings in [('source-green-01',20,20),('source-green-pm-fs-01',20,20),('source-expanded-normal-01',64,12),('source-expanded-pm-fs-01',64,12),('installed-expanded-normal-01',64,12),('installed-expanded-pm-fs-01',64,12),('installed-regression-normal-01',20,20),('installed-regression-pm-fs-01',20,20)]:
  row=d('attempts/'+label+'/receipt.json');assert row['counts']=={'tests':count,'failures':0,'errors':0,'skipped':0} and row['pytest_exit_code']==0 and row['engine_attempts']==[] and row['cohort_unchanged'] and row['warnings']==warnings
  assert d('attempts/'+label+'/cohort.json')==d('attempts/pilot-01/cohort.json')
  if label.startswith('installed-'):
   assert row['wheel_sha256']=='6ec6fe0214b95ece7850f404ae0c1a281e75775e6d3dd80cb0f1c95b7853fac1';support=d('attempts/'+label+'/support-sidecar.json');assert len(support['files'])==606 and support['executed_tests']==count and support['imports_retired'] and support['resources_retired']
 for a,b in [('source-green-01','source-green-pm-fs-01'),('source-expanded-normal-01','source-expanded-pm-fs-01'),('installed-expanded-normal-01','installed-expanded-pm-fs-01'),('installed-regression-normal-01','installed-regression-pm-fs-01')]:assert data['attempts/'+a+'/frozen-worker.py']==data['attempts/'+b+'/frozen-worker.py']
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   row=json.loads(raw);assert row['resource_interruption'] is None and row['group_terminal'] and row['remaining_live_owned_pids']==[] and row['minimum_available_bytes']>13*1024**3
 artifact=d('producer/artifact.json');assert set(artifact['changed_runtime_paths_from_old'])=={'dockingmt/preparation/_export.py','dockingmt/_version.py'} and artifact['runtime_paths']==67
 comparison=d('producer/metadata-comparison.json');assert set(comparison['changed_metadata_fields'])=={'Version'} and comparison['body_unchanged']
 for name in ['dockingmt/preparation/_export.py','tests/test_prepared_export_units.py']:
  raw=data['qualified/'+name];assert (root/name).read_bytes()==raw;assert hashlib.sha256(raw).hexdigest()==d('attempts/source-green-01/qualification-inputs.json')[name]
 assert hashlib.sha256(data['qualified/dockingmt/preparation/_export.py']).hexdigest()==artifact['payload_sha256']['dockingmt/preparation/_export.py']
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),native_selection_per_policy=64,regression_selection_per_policy=20,original_installed_failure_preserved=True,original_source_failures=6,all_support_inputs=606,runtime_paths=67,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence reader imported a scientific package')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/receipt.json'):continue
   row=json.loads(raw);prefix=name.removesuffix('receipt.json')
   if 'counts' not in row:continue
   junit=data[prefix+'junit.xml'];counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(junit).iter('testsuite')) for k in ['tests','failures','errors','skipped']};assert counts==row['counts']
   path=Path(tmp)/'events.jsonl';path.write_bytes(data[prefix+'events.jsonl']);events=read_artifact(path);assert events.complete and events.final.data==row['receptor_final'];crosschecked[prefix]={'junit':counts,'native_exit_code':row['pytest_exit_code'],'event_outcome':events.final.data['outcome']}
 assert len(crosschecked)==12 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt))
