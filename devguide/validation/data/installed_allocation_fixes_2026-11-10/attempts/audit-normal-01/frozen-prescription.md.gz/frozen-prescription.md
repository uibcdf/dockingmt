# Installed allocation-failure corrections — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with #30/#73
qualification and #50 custody. Status: registered; build/receiving pending.
Exact producer `37a61e61db40f386a4ad031ecd14d578441f61ce` includes source #106/#107.

## Actual artifact and installation

Build one genuine private Python wheel from a clean detached clone of that
commit, with pip wheel/no-index/no-deps/no-build-isolation. No source overlay or
relabelled old archive substitutes for a real build. Authenticate all67 runtime
paths, wheel metadata/version/generated version, license and every RECORD hash.
Relative to the old aeae47d wheel, only batch.py, _vina_scoring.py and the generated
version may differ. Keep that original file and its qualification unchanged.

Install normally with pip into a new private venv, retaining only the reviewed
editable sibling cohort through system-site-packages. Reuse the exact three unit
wheels and verified published Receptor1.2.2 files. Run pip check, require actual
core/addon prefix origins and genuine archive SHA256/PEP610 identity. Create an
independent Git-anchored qualification clone at the producer and remove its two
runtime package directories; do not claim a clean full tree after this deliberate
removal. Tests/helpers/fixtures remain exact. Clear inherited PYTHONPATH/PYTHONHOME
for receiving and keep consumer source paths outside the interpreter.

This is a local private qualification build, without release/tag, package index,
public upload or distribution-route change. The canonical release-notice policy
applies to release/publication events; none is performed here. Public Conda #47/#30
and all exact-candidate/matrix/same-byte gates retain their separate authority.

## Complete original selections and ordered admission

1. Pilot: test_batch.py module plus function deselections selecting only the four
   #106 OS-allocation/ordinary-I/O controls. Expected4 pass/41 deselected, zero
   actual native/molecular calls. Preserve original error objects and laziness.
2. Whole test_input_resource_errors.py, test_backend_contracts.py and
   test_vina_staging_lifecycle.py:155+38+19=212 cases per normal/pm-fs policy,
   no deselections and zero actual native/molecular work. Controlled failures,
   software availability seams and fake constructors are never native evidence.
3. Whole test_pose_audit.py:48 cases per policy, including the original fresh
   Vina/Vinardo audit node; two actual scores with CPU1/seed17, four-record receptor,
   two-record partner and10-angstrom box. Observe only the existing two conversions/
   six geometry reads of the submitted partner. Preserve source-free/unknown
   chemistry and all original ordinary/audit/child-process assertions.
4. Whole test_batch.py:45 cases per policy, including ten actual searches on the
   same tiny inputs, CPU1/seed123/exhaustiveness1/at most two poses. Preserve
   individual/batch complete-record equality, failure isolation, input ownership,
   error identity and result/traceback release. No new scientific case is created.

The main305 cases per policy are software coverage, not independent observations.
The pilot overlaps the batch module. Use the unchanged shared installed runner at
SDK95f693be, module-path selectors and explicit deselection arguments. Verify and
retire all606 unshipped support inputs per cell. Check real runtime/tool/unit/test/
cohort/engine bytes before and after; caller policy must survive unchanged.
Retain actual native input/output/method/node/vector/parameter identities and final
loaded extension hashes. Forbid native work outside the admitted original nodes,
larger inputs/grids, optimization/randomization and viewer activity. Native
constructor absence or a fake return cannot pass a designated live cell.

Keep original MolSysMT0c6f9c7/Viewer1187fc18/ArgDigest07126411/
PyUnitWizardf82b618e/SMonitorc1b6ce29/DepDigest032d345b and their actual native/Python
hashes. Reuse the original authenticated103-file Vina1.2.7 engine prefix under
e5-timed-replay-20261107/layouts-admission-01/producer/engine. Preserve stale sibling
distribution labels separately; do not rewrite shared metadata, remotes or source
verification. The new wheel's own generated version must match its actual producer.

## Shared resources and custody

Initial RAM64,978,440,192B physical/60,336,123,904B available;20 logical CPUs,
load3.15/3.25/3.67, about95% interval idle, zero measured swap I/O/PSI and35GB free
disk. Slurm exists without an allocation; prior applicability was inconclusive.
Free resources are not reserved. Build/install/admin cells use CPU0/nice10/one
worker,256MiB expected RSS,1GiB group RSS/2GiB address space,45 CPU/60 wall seconds.
Scientific receiving stays serial with the same affinity/priority/worker and
13GiB available-RAM reserve; live profiles estimate768MiB, pure controls256MiB,
1GiB group RSS/2GiB address space,60/65 CPU seconds and180 wall seconds. Native
libraries, compiler/build tools and Git packing keep one worker. Monitor owned
descendants, preserve interruptions and never automatically restart after a
headroom stop. No native build or shared installation is authorized by this task.

Retain task resources under `.molsyssuite/installed-allocation-fixes-20261110`,
owners#47/#50, review2026-11-14. The private wheel, new receiver/harness and original
engine/SDK inputs retain custody; retire the managed build clone and exports.
Preserve the human migration backup and old source/artifact producers. Full
#30/#47/#73, public/OS-minor/hosted/interactive and original provider-panel/source-
context holds remain separate. No automatic remote CI or public package operation.
