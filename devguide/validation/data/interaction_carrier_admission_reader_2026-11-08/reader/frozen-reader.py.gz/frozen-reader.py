"""Receive source regressions through Pytest Receptor's supported artifact API."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

from pytest_receptor import read_artifact

def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    expected={
        'red-normal':(1,6,6),
        'green-normal':(0,78,0),
        'green-normal-02':(0,78,0),
        'green-pm_fs-02':(0,78,0),
    }
    for label,(exit_code,total,failed) in expected.items():
        prefix='attempts/'+label+'/'
        r=obj(prefix+'receipt.json')
        resource=obj(prefix+'resource-outcome.json')
        registration=obj(prefix+'registration.json')
        assert r['pytest_exit_code']==resource['exit_code']==exit_code
        assert r['counts']=={'tests':total,'failures':failed,'errors':0,'skipped':0}
        assert r['outcome']==resource['outcome']==('FAIL' if failed else 'PASS')
        assert resource['resource_interruption'] is None and resource['group_terminal'] and not resource['remaining_live_owned_pids']
        assert not r['molecular_calls_attempted'] and r['native_searches']==0
        for key in ['default_form','default_parser','standard_units']:
            assert r['caller_policy_before'][key]==r['caller_policy_after'][key]
        for name,digest in registration['inputs_sha256'].items():
            raw=records[prefix+'frozen-'+name.replace('/','__')]
            assert hashlib.sha256(raw).hexdigest()==digest
        suites=ET.fromstring(records[prefix+'junit.xml']).iter('testsuite')
        observed={key:0 for key in ['tests','failures','errors','skipped']}
        for row in suites:
            for key in observed:
                observed[key]+=int(row.get(key,'0'))
        assert observed==r['counts']
        with tempfile.TemporaryDirectory(prefix='dmt-interaction-receptor-',dir='/tmp') as directory:
            path=Path(directory)/'events.jsonl'
            path.write_bytes(records[prefix+'events.jsonl'])
            artifact=read_artifact(path)
            assert artifact.complete and artifact.final.data==r['receptor_final']
            final=artifact.final.data
            assert final['exitstatus']==exit_code and final['counts']['collected']==final['counts']['executed']==total
            assert final['counts']['failed']==failed and final['counts']['passed']==total-failed
            assert final['counts']['skipped']==final['counts']['deselected']==final['counts']['not_executed']==0
            assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
    final='attempts/green-normal-02/'
    other='attempts/green-pm_fs-02/'
    for filename in ['frozen-dockingmt__interactions.py','frozen-tests__test_interaction_binding.py','frozen-tests__test_viewer_interactions.py','frozen-pyproject.toml']:
        assert records[final+filename]==records[other+filename]
    red_tests=records['attempts/red-normal/frozen-tests__test_interaction_binding.py']
    final_tests=records[final+'frozen-tests__test_interaction_binding.py']
    assert ast.dump(ast.parse(red_tests))==ast.dump(ast.parse(final_tests))
    assert records['attempts/red-normal/frozen-dockingmt__interactions.py']!=records[final+'frozen-dockingmt__interactions.py']
    assert obj('producer/formatting-observation.json')['formatter_changes_test_ast'] is False
    assert not any(n=='molsysmt' or n.startswith(('molsysmt.','dockingmt.','rdkit','vina')) for n in sys.modules)
    return {'complete_profiles':['normal','pm_fs'],'cases_per_profile':78,'new_regressions':6,'original_failures_preserved':6,'preformat_pass_preserved':True,'scientific_operations':0,'native_searches':0,'guard':'tests/test_interaction_binding.py::test_missing_carrier_domains_have_a_local_argument_diagnostic','receptor_and_junit_agree':True,'molecular_replay':False,'source_only':True}
