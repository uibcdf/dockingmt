"""Reading completed reference records using only the standard library."""
import hashlib
import json

def verify_records(records):
    def record(label,name):
        return json.loads(records['attempts/'+label+'/'+name])
    def same_reference(before,after):
        assert before['topology']==after['topology'] and before['n_structures'] is after['n_structures'] is None
        bc,ac=before['chemical_states'],after['chemical_states']
        assert {k:v for k,v in bc.items() if k!='states'}=={k:v for k,v in ac.items() if k!='states'}
        assert len(bc['states'])==len(ac['states'])==1
        b,a=bc['states'][0],ac['states'][0]
        assert {k:v for k,v in b.items() if k!='components'}=={k:v for k,v in a.items() if k!='components'}
        b,a=b['components'],a['components']
        assert b.keys()==a.keys() and b['n_rows']==a['n_rows'] and b['columns'].keys()==a['columns'].keys()
        for column in b['columns']:
            x,y=b['columns'][column],a['columns'][column]
            if column in ['component_name','component_type']:
                assert x['dtype'] in ['str','string'] and y['dtype']=='string'
                assert {k:v for k,v in x.items() if k!='dtype'}=={k:v for k,v in y.items() if k!='dtype'}
            else:
                assert x==y
    hypotheses=json.loads(records['producer/hypothesis.json'])
    assert hashlib.sha256(records['producer/hypothesis.json']).hexdigest()=='a11e4d5f04d1af83eb7afc15e5397870e0c72fe73483d4e73935271ab751d6d2'
    original=records['producer/original-worker.py.txt'].decode()
    start='        live_sources, live_templates, observations = [], [], []'
    end='        support.check()'
    expected_core=original[original.index(start):original.index(end)+len(end)]
    expected_chains={(c['entry'],ch['chain_index']) for c in hypotheses['cases'] for ch in c['chains']}
    assert len(expected_chains)==6
    for label in ['templates-normal','templates-pm_fs','ligand-normal','ligand-pm_fs']:
        outcome=record(label,'resource-outcome.json')
        assert outcome['outcome']=='PASS' and outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids']
        r=record(label,'receipt.json')
        assert r['outcome']=='PASS' and r['qualification_complete'] and r['route']=='editable-development'
        assert r['provider_commit']=='2325038e8c68157f5c730693ffbb8535f0b45540' and r['provider_native_sha256']=='5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
    for label in ['templates-normal','templates-pm_fs']:
        worker=records['attempts/'+label+'/frozen-worker.py'].decode()
        assert worker[worker.index(start):worker.index(end)+len(end)]==expected_core
        registration=record(label,'registration.json')
        r=record(label,'receipt.json')
        assert r['direct_counts']==registration['direct_caps'] and r['protein_reference_templates_received']==6
        assert r['reference_coordinate_structures'] is None and r['structural_domain_present'] is False
        assert r['bound_receptors_admitted']==r['new_independent_docking_cases']==r['native_searches']==0
        assert r['source_and_caller_preserved_in_observed_scope'] and not r['blocked'] and not r['forbidden']
        assert len(r['typed_refusals'])==2 and all(x['type']=='ArgumentError' for x in r['typed_refusals'])
        assert {(x['entry'],x['chain_index']) for x in r['observations']}==expected_chains
        support=record(label,'support-receipt.json')
        assert support['imports_retired'] and support['resources_retired']
        for obs in r['observations']:
            key=obs['entry']+'-chain-'+str(obs['chain_index'])
            assert obs['formal_charge']==obs['expected_formal_charge'] and obs['formal_charge']['unit']=='elementary_charge'
            assert obs['n_indexed_hydrogens']==0 and obs['n_structures'] is None and not obs['structural_domain_present'] and not obs['bound_source_applied']
            assert obs['history_roundtrip'] and obs['canonical_text_storage_received']
            before=record(label,key+'-template-snapshot.json')
            after=record(label,key+'-restored-template-snapshot.json')
            same_reference(before,after)
            audit=record(label,key+'-canonical-text-audit.json')
            assert audit['provider_public_comparison']=={'component_name':True,'component_type':True} and audit['other_public_record_fields_exact'] and audit['native_objects_or_saved_records_normalized'] is False
            assert hashlib.sha256(records['attempts/'+label+'/'+key+'.h5msm']).hexdigest()==obs['template_h5msm_sha256']
            report=record(label,key+'-factory-report.json')
            assert report['n_groups']==obs['n_residues'] and report['n_atoms']==obs['n_atoms'] and len(report['peptide_bond_pairs'])==obs['n_residues']-1
            summary=record(label,key+'-template-summary.json')
            assert summary['n_structures'] is None
    assert records['attempts/templates-normal/frozen-worker.py']==records['attempts/templates-pm_fs/frozen-worker.py']
    assert record('templates-normal','frozen-composition.json')==record('templates-pm_fs','frozen-composition.json')
    ligand_original=records['producer/original-ligand-worker.py.txt'].decode()
    start='    atom_fields ='
    end="    assert counts == plan['direct_caps'] and len(refusals) == 2 and authority() == caller and not blocked"
    core=ligand_original[ligand_original.index(start):ligand_original.index(end)+len(end)]
    for label in ['ligand-normal','ligand-pm_fs']:
        worker=records['attempts/'+label+'/frozen-worker.py'].decode()
        assert worker[worker.index(start):worker.index(end)+len(end)]==core
        plan=record(label,'frozen-plan.json')
        r=record(label,'receipt.json')
        assert r['direct_counts']==plan['direct_caps'] and all(v<=plan['provider_caps'][k] for k,v in r['provider_counts'].items())
        assert r['typed_refusals']==2 and r['native_roundtrip_received'] and r['neutral_source_preserved'] and r['other_assignments_bonds_and_coordinates_absence_preserved'] and r['caller_and_files_preserved']
        assert r['native_builds']==r['template_applications']==r['bound_source_preparations']==r['searches']==r['admitted_docking_cases']==0 and not r['blocked']
        snapshots=record(label,'snapshots.json')
        expected=json.loads(json.dumps(snapshots['neutral']))
        index=snapshots['declared_assignment_atom_source_index']
        expected['atom_fields']['formal_charge'][index]=-1
        expected['atom_fields']['n_explicit_hydrogens'][index]=0
        assert snapshots['curated']==snapshots['restored']==expected
        assert expected['coordinates_absent'] and len(expected['atom_fields']['atom_name'])==16
        assert sum(expected['atom_fields']['formal_charge'])==-1 and sum(expected['atom_fields']['n_explicit_hydrogens'])==15
        refusals=record(label,'refusals.json')
        assert [x['field'] for x in refusals]==['formal_charge','n_explicit_hydrogens'] and all(x['type']=='ArgumentError' for x in refusals)
        readiness=record(label,'readiness.json')
        assert readiness['curated']==readiness['restored']
        assert hashlib.sha256(records['attempts/'+label+'/biotinate-reference.h5msm']).hexdigest()==r['curated_reference']['artifact_sha256']
    assert records['attempts/ligand-normal/frozen-worker.py']==records['attempts/ligand-pm_fs/frozen-worker.py']
    assert record('ligand-normal','frozen-composition.json')==record('ligand-pm_fs','frozen-composition.json')==record('templates-normal','frozen-composition.json')
    return {'complete_profiles':['normal','pm_fs'],'complete_workflows':['templates','ligand'],'protein_references_per_profile':6,'ligand_references_per_profile':1,'assertion_blocks_byte_identical':True,'molecular_operations':0,'scientific_imports':[],'live_nonmutation_scope':'Completed original producer assertions; no separate protein-source after-snapshots were stored','bound_receptors_admitted':0,'new_docking_cases':0}
