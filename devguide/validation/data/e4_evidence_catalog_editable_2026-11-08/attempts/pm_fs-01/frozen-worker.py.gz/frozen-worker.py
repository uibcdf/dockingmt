"""Complete catalog receiving on the actual editable development workspace."""
import ast
from copy import deepcopy
from functools import wraps
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

root = Path(os.environ['DMT_INSTALLED_ROOT'])
task = Path(os.environ['DMT_INSTALLED_TASK'])
attempt = Path(os.environ['DMT_INSTALLED_ATTEMPT'])
profile = os.environ['DMT_INSTALLED_PROFILE']
registration = json.loads((attempt / 'registration.json').read_text())
composition_path = attempt / 'frozen-composition.json'
composition = json.loads(composition_path.read_text())
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')
assert sys.flags.isolated and not sys.flags.no_site
assert os.sched_getaffinity(0) == {0} and os.getpriority(os.PRIO_PROCESS, 0) >= 10
assert hashlib.sha256(composition_path.read_bytes()).hexdigest() == registration['composition_sha256']
output = attempt / 'output'
output.mkdir(exist_ok=False)
completed = []
forbidden_attempts = []
refusals = []
origins = []
counts = {}
budgets={'binding_attempts':1,'result_accessors':1,'pose_accessors':1,'analysis_accessors':4,'carrier_accessors':1,'analysis_queries':2,'analysis_pages':2,'native_snapshots':6,'typed_exports':32,'invalidate':1,'derive_carrier':1}
counts.update({name:0 for name in budgets})
provider_caps={'convert':128,'copy':40,'get':640,'has_attribute':256,'h5_read':3,'h5_write':1,'analysis_copy':128,'analysis_remap':16,'analysis_invalidate':1,'typed_exports':128}
provider_counts={name:0 for name in provider_caps}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, allow_nan=False, separators=(',', ':'))
        stream.write('\n')

def journal(stage, **values):
    with (attempt / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps({'stage': stage, **values, 'receiver_counts': dict(counts), 'provider_counts': dict(provider_counts)}, allow_nan=False) + '\n')

def direct(name, function, *args, **kwargs):
    assert counts[name] < budgets[name], ('receiver cap', name)
    counts[name] += 1
    journal('called', operation=name)
    value = function(*args, **kwargs)
    journal('returned', operation=name)
    return value

def custody(label):
    for filename, expected in composition['python_sources_sha256'].items():
        assert sha(Path(filename)) == expected, ('source drift', filename)
    for directory, expected in composition['source_revisions'].items():
        assert subprocess.check_output(['git','-C',directory,'rev-parse','HEAD'], text=True).strip() == expected
    assert sha(Path(composition['native_path'])) == composition['provider_native_sha256']
    rows = []
    families = tuple(composition['packages'])
    for name, module in tuple(sys.modules.items()):
        matches = [family for family in families if name == family or name.startswith(family + '.')]
        if not matches:
            continue
        family = max(matches, key=len)
        expected = Path(composition['packages'][family]['path']).resolve()
        locations = list(getattr(module, '__path__', ()))
        filename = getattr(module, '__file__', None)
        if filename:
            locations.append(filename)
        if not locations:
            assert name == 'pyunitwizard.main'
            initializer = sys.modules['pyunitwizard']
            for function in (module.__getattr__, module.__dir__):
                assert function.__globals__ is vars(initializer)
                assert Path(function.__code__.co_filename).resolve() == expected / '__init__.py'
            locations = [str(expected / '__init__.py')]
        checked = []
        for value in sorted(set(locations)):
            path = Path(value).resolve()
            assert path.is_relative_to(expected), (name, str(path), str(expected))
            checked.append({'path': str(path), 'sha256': sha(path) if path.is_file() else None})
        rows.append({'module': name, 'locations': checked})
    assert not any(name == 'vina' or name.startswith('vina.') for name in sys.modules)
    natives = set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        fields = line.split(None, 5)
        if len(fields) == 6 and fields[5].startswith('/') and '.so' in fields[5] and Path(fields[5]).is_file():
            natives.add(Path(fields[5]).resolve())
    for entry in entries.values():
        assert sha(Path(entry['path'])) == entry['decoded_sha256']
    origins.append({'label':label,'route':'editable-development','runtime_origins':rows,'native_libraries':[{'path':str(p),'sha256':sha(p)} for p in sorted(natives)],'python_path':list(sys.path)})

def observe_aliases(owner, name, label):
    original = getattr(owner, name)
    @wraps(original)
    def wrapped(*args, **kwargs):
        assert provider_counts[label] < provider_caps[label], ('provider cap', label)
        provider_counts[label] += 1
        if label == 'convert' and kwargs.get('to_form') in ('molsysmt.TopologyDict', 'molsysmt.ChemicalStatesDict', 'molsysmt.InteractionsDict'):
            assert provider_counts['typed_exports'] < provider_caps['typed_exports']
            provider_counts['typed_exports'] += 1
        return original(*args, **kwargs)
    for module_name, module in tuple(sys.modules.items()):
        if not (module_name == 'molsysmt' or module_name.startswith('molsysmt.')):
            continue
        for attribute, value in tuple(vars(module).items()):
            if value is original:
                setattr(module, attribute, wrapped)
    setattr(owner, name, wrapped)

def prohibit_aliases(owner, name):
    original = getattr(owner, name)
    @wraps(original)
    def denied(*args, **kwargs):
        forbidden_attempts.append(name)
        journal('forbidden', operation=name)
        raise AssertionError('Forbidden installed binding operation: ' + name)
    for module_name, module in tuple(sys.modules.items()):
        if not (module_name == 'dockingmt' or module_name.startswith('dockingmt.') or module_name == 'molsysmt' or module_name.startswith('molsysmt.')):
            continue
        for attribute, value in tuple(vars(module).items()):
            if value is original:
                setattr(module, attribute, denied)
    setattr(owner, name, denied)

def expect(label, function, *args, expected=None, **kwargs):
    journal('refusal-started', label=label)
    try:
        function(*args, **kwargs)
    except expected as exc:
        if expected is ArgumentError:
            assert exc.code == 'DMT-E002'
        refusals.append({'label': label, 'type': type(exc).__name__, 'module': type(exc).__module__, 'code': getattr(exc, 'code', None), 'reason': str(exc)})
        journal('refused', label=label)
    else:
        raise AssertionError('Expected refusal was accepted: ' + label)

def assert_native_roundtrip(actual, expected):
    actual_fields, expected_fields = dict(actual), dict(expected)
    for field in ('coordinates', 'box', 'time'):
        observed = actual_fields.pop(field)
        original = expected_fields.pop(field)
        if original is None or observed is None:
            assert observed is original is None, field
            continue
        assert observed['unit'] == original['unit'], field
        a, b = dict(observed['value']), dict(original['value'])
        values_a, values_b = a.pop('array'), b.pop('array')
        assert a == b, (field, 'physical shape/dtype')
        np.testing.assert_allclose(values_a, values_b, rtol=0, atol=1e-12)
    assert actual_fields == expected_fields

class NoVina:
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'vina' or fullname.startswith('vina.'):
            forbidden_attempts.append('vina import')
            raise AssertionError('Vina import is forbidden')

sys.meta_path.insert(0, NoVina())
metadata_before = {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')}
inputs_path = attempt / 'inputs.json'
assert sha(inputs_path) == registration['inputs_sha256']
inputs = json.loads(inputs_path.read_text())
assert inputs['profile'] == profile == registration['profile']
entries = inputs['inputs']
import numpy as np
import pyunitwizard as puw

def authority():
    return {key: puw.configure.report()[key] for key in ('default_form', 'default_parser', 'standard_units', 'provenance')}

previous_policy = authority()
units = ['pm', 'fs', 'kelvin', 'mole', 'dalton', 'coulomb', 'kJ/mol', 'kJ/(mol*pm)', 'kJ/(mol*pm**2)', 'radians'] if profile == 'pm_fs' else ['nm', 'ps', 'kelvin', 'mole', 'dalton', 'elementary_charge', 'kJ/mol', 'kJ/(mol*nm)', 'kJ/(mol*nm**2)', 'radians']
context = puw.context(standard_units=units)
context.__enter__()
caller_policy = authority()
try:
    import dockingmt as dmt
    import molsysmt as msm
    from dockingmt._private.smonitor import ArgumentError
    assert Path(dmt.__file__).resolve() == root / 'dockingmt/__init__.py'
    import molsysmt._rust as loaded_native
    assert Path(loaded_native.__file__).resolve() == Path(composition['native_path'])
    assert authority() == caller_policy
    custody('before-receiving')
    notebook_path = root / 'devguide/validation/e4_saved_carrier_receiving.ipynb'
    notebook_bytes = notebook_path.read_bytes()
    assert hashlib.sha256(notebook_bytes).hexdigest() == 'a6a8561e4aa7d9d2b5967fd43b9c2fdf8793ba13bbbb3c3a5d524e3d53e7d113'
    (attempt / 'frozen-diagnostic-helpers.ipynb').write_bytes(notebook_bytes)
    notebook = json.loads(notebook_bytes)
    cell = next(c for c in notebook['cells'] if c.get('id') == 'e4-carrier-public-tools')
    body = ''.join(cell['source'])
    helper_names = {'diagnostic', 'payload', 'native_state'}
    helpers = [node for node in ast.parse(body).body if isinstance(node, ast.FunctionDef) and node.name in helper_names]
    assert {node.name for node in helpers} == helper_names
    exec(compile(ast.Module(body=helpers, type_ignores=[]), 'frozen-old-native-snapshot-helpers', 'exec'), globals())
    assert diagnostic('pint') == 'pint'
    for owner, name in [(dmt, 'dock'), (dmt, 'dock_many'), (dmt, 'score'), (dmt, 'prepare_ligand'), (dmt, 'prepare_receptor'), (dmt, 'evaluate_redocking'), (dmt, 'compare_scores'), (dmt, 'view'), (dmt, 'show'), (msm.build, 'add_missing_hydrogens'), (msm.build, 'assign_partial_charges'), (msm.build, 'assign_autodock_atom_types'), (msm.interactions.hbonds, 'get_hbonds'), (msm.interactions.hydrophobic, 'get_hydrophobic_interactions')]:
        prohibit_aliases(owner, name)
    for name in ['get_rmsd', 'get_symmetry_corrected_rmsd', 'get_distances', 'get_dihedral_angles', 'align', 'superpose', 'get_superposition']:
        if hasattr(msm.structure, name):
            prohibit_aliases(msm.structure, name)
    for name in ['convert', 'copy', 'get', 'has_attribute']:
        observe_aliases(msm, name, name)
    observe_aliases(msm.h5msm, 'read', 'h5_read')
    observe_aliases(msm.h5msm, 'write', 'h5_write')
    observe_aliases(msm.Interactions, 'copy', 'analysis_copy')
    observe_aliases(msm.Interactions, 'remap', 'analysis_remap')
    observe_aliases(msm.Interactions, 'invalidate_structures', 'analysis_invalidate')

    for name in ['extract','merge','append_structures','set']:
        if hasattr(msm,name):prohibit_aliases(msm,name)
    import molsysviewer as msv
    prohibit_aliases(msv.MolSysView,'__init__')
    assert composition['source_revisions'][str(root.parent / 'molsysmt')] == '2325038e8c68157f5c730693ffbb8535f0b45540'
    assert sha(Path(composition['native_path'])) == composition['provider_native_sha256']
    def analyses(model):
        return {family:diagnostic(payload(value)) for family,value in model.interactions.items()}
    original_record=json.loads(Path(entries['result']['path']).read_text())
    result=dmt.DockingResult.from_dict(original_record);assert len(result)==5 and result.to_dict()==original_record
    association=json.loads(Path(entries['association']['path']).read_text())
    assert association['selected_original_position']==1 and association['original_pose_count']==5
    pose=result[0]
    assert pose.pose_id==association['pose_id'] and pose.scores==association['original_scores']
    assert pose.metadata['source_atom_keys']==association['pose_atom_keys']
    assert association['existing_ligand_atom_correspondence']==[[i,i] for i in range(13)]
    assert association['merged_ligand_atom_indices']['retained_pose']==list(range(3220,3238))
    source=msm.h5msm.read(entries['retained_pose']['path'])
    before=native_state(source);original_analyses=analyses(source)
    assert all(value is None for value in before['mechanics'].values())
    assert source.interactions['hbonds'].n_interactions==3 and source.interactions['hydrophobic'].n_interactions==2
    assert source.interactions['hbonds'].evidence_labels==('baker_hubbard_hbond_geometry',)
    assert source.interactions['hbonds'].evaluated_structure_indices.tolist()==[0]
    save(output/'original-native-before.json',before);save(output/'original-analyses-before.json',original_analyses)
    expected_legacy=json.loads(Path(entries['failed_expected']['path']).read_text())
    legacy=msm.h5msm.read(entries['failed_carrier']['path'])
    legacy_payload=analyses(legacy)
    save(output/'legacy-restored-analyses.json',legacy_payload);assert legacy_payload==expected_legacy
    completed.append('custody_original_and_immutable_failure')
    journal('step-completed',step=completed[-1])
    invalidated=direct('invalidate',source.interactions['hbonds'].invalidate_structures,[0])
    assert invalidated.n_interactions==0 and invalidated.evaluated_structure_indices.tolist()==[]
    assert invalidated.evidence_labels==('baker_hubbard_hbond_geometry',)
    derived=direct('derive_carrier',msm.copy,source)
    derived.interactions={**derived.interactions,'hbonds':invalidated}
    derived_before=native_state(derived);expected=analyses(derived)
    assert derived_before==before
    if profile=='normal':assert expected==expected_legacy
    save(output/'derived-native-before.json',derived_before);save(output/'expected-analyses.json',expected)
    options={'pose_index':0,'pose_atom_indices':list(range(3220,3233)),'partner_state_id':pose.partner_state_id,'receptor_state_id':pose.receptor_state_id,'assume_aligned':True}
    binding=direct('binding_attempts',dmt.bind_interactions,result,derived,**options)
    saved_result=direct('result_accessors',lambda:binding.result)
    saved_pose=direct('pose_accessors',lambda:binding.pose)
    assert saved_result.to_dict()==original_record and saved_pose.to_dict()==original_record['poses'][0]
    assert binding.association['analysis_evaluated']=={'hbonds':False,'hydrophobic':True}
    assert binding.association['original_pose_count']==5 and binding.association['pose_index']==0
    for family in binding.analysis_names:
        layer=direct('analysis_accessors',binding.get_analysis,family)
        assert diagnostic(payload(layer))==expected[family]
        query=direct('analysis_queries',layer.between_selections,list(range(3220,3238)),list(range(3220)),exclusive=True)
        page=diagnostic(direct('analysis_pages',query.to_page,offset=0,limit=20,max_participant_atoms=512))
        assert page['evaluated_structure_indices']['array']==([] if family=='hbonds' else [0])
        assert len(page['occurrence_indices']['array'])==(0 if family=='hbonds' else 2)
        save(output/(family+'-page.json'),page)
        layer.parameters['receiving_mutation_control']=True
        assert diagnostic(payload(direct('analysis_accessors',binding.get_analysis,family)))==expected[family]
    carrier=direct('carrier_accessors',binding.to_molecular_system)
    assert native_state(carrier)==derived_before and analyses(carrier)==expected
    destination=output/'bound-carrier.h5msm';msm.h5msm.write(carrier,str(destination))
    restored=msm.h5msm.read(str(destination));restored_native=native_state(restored)
    assert_native_roundtrip(restored_native,derived_before)
    restored_payload=analyses(restored)
    save(output/'restored-native.json',restored_native);save(output/'restored-analyses.json',restored_payload)
    assert restored_payload==expected
    assert restored.interactions['hbonds'].evidence_labels==('baker_hubbard_hbond_geometry',)
    assert restored.interactions['hbonds'].evaluated_structure_indices.tolist()==[]
    assert restored.interactions['hydrophobic'].n_interactions==2
    completed.append('editable_binding_and_complete_persistence')
    journal('step-completed',step=completed[-1])
    original_after=native_state(source);derived_after=native_state(derived)
    assert original_after==before and derived_after==derived_before
    assert analyses(source)==original_analyses and analyses(derived)==expected
    assert result.to_dict()==original_record and not forbidden_attempts and authority()==caller_policy
    save(output/'original-native-after.json',original_after);save(output/'derived-native-after.json',derived_after)
    save(output/'original-analyses-after.json',analyses(source));save(output/'derived-analyses-after.json',analyses(derived))
    save(output/'result.json',result.to_dict());save(output/'association.json',binding.association)
    completed.append('source_nonmutation_and_original_result')
    journal('step-completed',step=completed[-1]);custody('after-complete-receiving')
    metadata_after={p.name:sha(p) for p in (routine/'conda-meta').glob('*.json')}
    save(attempt/'installed-origins.json',origins);save(attempt/'routine-metadata-before.json',metadata_before);save(attempt/'routine-metadata-after.json',metadata_after)
    completed.append('final_custody_and_origins')
    receipt={'stage':profile,'source_commit':registration['source_commit'],'outcome':'PASS','qualification_complete':True,'route':'editable-development','provider_commit':composition['source_revisions'][str(root.parent/'molsysmt')],'provider_version':composition['packages']['molsysmt']['version'],'provider_native_sha256':composition['provider_native_sha256'],'composition_sha256':sha(composition_path),'completed_steps':completed,'accepted_bindings':1,'complete_carrier_roundtrips':1,'immutable_failed_carrier_now_matches_original_prewrite':True,'complete_analysis_equality':True,'original_result_population':5,'other_original_poses_unevaluated':4,'analysis_coverage':{'hbonds':False,'hydrophobic':True},'observations':{'hbonds':0,'hydrophobic':2},'evidence_labels':['baker_hubbard_hbond_geometry'],'original_hbonds_observations':3,'receiver_counts':counts,'receiver_caps':budgets,'provider_counts':provider_counts,'provider_caps':provider_caps,'forbidden_attempts':forbidden_attempts,'caller_policy':diagnostic(caller_policy),'caller_policy_preserved':True,'shared_metadata_unchanged':metadata_before==metadata_after,'new_detectors':0,'views_created':0,'whole_e4_received':False,'canvas_received':False,'public_delivery_received':False}
except Exception as exc:
    save(attempt/'failure.json',{'exception_type':type(exc).__name__,'message':str(exc),'completed_steps':completed,'receiver_counts':counts,'provider_counts':provider_counts,'forbidden_attempts':forbidden_attempts})
    traceback.print_exc();raise
finally:
    context.__exit__(None,None,None)
assert authority()==previous_policy
receipt['caller_policy_restored']=True
save(output/'receipt.json',receipt);save(attempt/'receipt.json',receipt)
