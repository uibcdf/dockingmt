"""Running the complete registered saved-carrier receiving with finite resources."""
import ast
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.metadata as md
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
task = Path(__file__).parent
profile = sys.argv[1]
assert profile in ('normal', 'pm_fs')
suffix = sys.argv[2] if len(sys.argv)>2 else '01'
assert len(suffix)==2 and suffix.isdigit()
attempt = task / (profile + '-' + suffix)
attempt.mkdir(exist_ok=False)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

guard = root / '.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes = [n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n, ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
assert len(nodes)==6
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available() > policy['available_reserve_bytes'] + 640*1024**2
native=root.parent/'molsysmt/molsysmt/_rust.abi3.so'
assert sha(native)=='5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
packages={}
sources={}
revisions={}
for family,distribution in [('dockingmt','dockingmt'),('molsysviewer_dockingmt','dockingmt'),('molsysmt','molsysmt'),('molsysviewer_molsysmt','molsysmt'),('molsysviewer','molsysviewer'),('argdigest','argdigest'),('pyunitwizard','pyunitwizard'),('smonitor','smonitor'),('depdigest','depdigest'),('ackredit','ackredit')]:
    spec=importlib.util.find_spec(family)
    if spec is None:
        continue
    directory=Path(spec.origin).resolve().parent
    dist=md.distribution(distribution)
    packages[family]={'path':str(directory),'version':dist.version,'direct_url':json.loads(dist.read_text('direct_url.json') or 'null')}
    for path in directory.rglob('*.py'):
        sources[str(path)]=sha(path)
    if directory.parent.parent==root.parent:
        repo=directory.parent
        revisions[str(repo)]=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
assert revisions[str(root)]=='542c5c5853a64ed9472a3317449e900f33f9b952'
assert revisions[str(root.parent/'molsysmt')]=='2325038e8c68157f5c730693ffbb8535f0b45540'
composition={'route':'editable-development','packages':packages,'python_sources_sha256':sources,'source_revisions':revisions,'native_path':str(native),'provider_native_sha256':sha(native)}
composition_bytes=(json.dumps(composition,indent=2)+'\n').encode()
if profile=='normal':
    (task/'composition.json').write_bytes(composition_bytes)
else:
    assert (task/'composition.json').read_bytes()==composition_bytes
    normal=task/'normal-01'
    assert json.loads((normal/'resource-outcome.json').read_text())['outcome']=='PASS'
    assert json.loads((normal/'receipt.json').read_text())['outcome']=='PASS'
    assert sha(normal/'frozen-worker.py')==sha(task/'worker.py')
(attempt/'frozen-composition.json').write_bytes(composition_bytes)
for source,name in [(task/'worker.py','worker.py'),(Path(__file__),'controller.py'),(guard,'resource-guard.py'),(task/'worker-route-change.json','worker-route-change.json'),(root/'devguide/validation/e4_evidence_catalog_editable_2026-11-08.md','prescription.md')]:
    shutil.copyfile(source,attempt/('frozen-'+name))

old=root/'devguide/validation/data/e4_saved_carrier_receiving_2026-11-07'
assert sha(old/'manifest.json')=='73c8114368f0d7011d2e27d229662bf29be1f99bea27c0e0a24065f077e04b4d'
rows=json.loads((old/'manifest.json').read_text())['files']
rel='attempts/'+('normal-02' if profile=='normal' else 'pm-fs-01')+'/inputs.json.gz'
row=next(r for r in rows if r['path']==rel)
blob=(old/rel).read_bytes()
assert hashlib.sha256(blob).hexdigest()==row['sha256']
decoded=gzip.decompress(blob)
assert hashlib.sha256(decoded).hexdigest()==row['decoded_sha256']
descriptors=json.loads(decoded)
entries={k:v for k,v in descriptors['inputs'].items() if k in ['result','association','retained_pose']}
invalid=root/'devguide/validation/data/e4_native_unevaluated_2026-11-07'
assert sha(invalid/'manifest.json')=='b4a676022aa26f0508fadd87bb5f1dee21d9e7650edf4ebe085599c4313793ef'
rows=json.loads((invalid/'manifest.json').read_text())['files']
for key,leaf in [('failed_carrier','bound_carrier.h5msm'),('failed_expected','analyses-before.json')]:
    rel='attempts/normal-02/output/retained_pose/'+leaf+'.gz'
    row=next(r for r in rows if r['path']==rel)
    entries[key]={'repository_path':str((invalid/rel).relative_to(root)),'stored_bytes':row['bytes'],'stored_sha256':row['sha256'],'decoded_bytes':row['decoded_bytes'],'decoded_sha256':row['decoded_sha256']}
directory=attempt/'inputs'
directory.mkdir()
for key,row in entries.items():
    blob=(root/row['repository_path']).read_bytes()
    assert len(blob)==row['stored_bytes'] and hashlib.sha256(blob).hexdigest()==row['stored_sha256']
    decoded=gzip.decompress(blob)
    assert len(decoded)==row['decoded_bytes'] and hashlib.sha256(decoded).hexdigest()==row['decoded_sha256']
    target=directory/(key+('.h5msm' if key in ['retained_pose','failed_carrier'] else '.json'))
    target.write_bytes(decoded)
    target.chmod(0o444)
    entries[key]={**row,'path':str(target)}
(attempt/'inputs.json').write_text(json.dumps({'profile':profile,'inputs':entries,'original_source':descriptors['original_source']},indent=2)+'\n')
registration={'registered_at_utc':datetime.now(timezone.utc).isoformat(),'owner':'uibcdf/dockingmt#80','profile':profile,'source_commit':revisions[str(root)],'provider_commit':revisions[str(root.parent/'molsysmt')],'composition_sha256':sha(attempt/'frozen-composition.json'),'worker_sha256':sha(attempt/'frozen-worker.py'),'inputs_sha256':sha(attempt/'inputs.json'),'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':640*1024**2,'policy':policy,'route':'editable-development'}
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy()
env.update(DMT_INSTALLED_ROOT=str(root),DMT_INSTALLED_TASK=str(task),DMT_INSTALLED_ATTEMPT=str(attempt),DMT_INSTALLED_PROFILE=profile,PYTHONDONTWRITEBYTECODE='1')
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:
    env[key]='1'
for name,key in [('tmp','TMPDIR'),('cache','XDG_CACHE_HOME'),('numba','NUMBA_CACHE_DIR'),('mpl','MPLCONFIGDIR')]:
    path=attempt/name
    path.mkdir()
    env[key]=str(path)
assert available() > policy['available_reserve_bytes']+640*1024**2
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen(['/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python','-B','-I',str(attempt/'frozen-worker.py')],cwd=attempt,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
    outcome=monitor(process,policy)
try:
    receipt=json.loads((attempt/'receipt.json').read_text())
    semantic=receipt['outcome']=='PASS' and receipt['qualification_complete'] and receipt['stage']==profile and receipt['source_commit']==registration['source_commit'] and receipt['complete_analysis_equality'] and receipt['caller_policy_restored']
except Exception as error:
    semantic=False
    outcome['qualification_diagnostic']=type(error).__name__+': '+str(error)
outcome['outcome']='PASS' if semantic and outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome),flush=True)
if outcome['outcome']!='PASS':
    print((attempt/'stderr.log').read_text()[-6000:])
    raise SystemExit(1)
print(json.dumps({'profile':profile,'complete_analysis_equality':True,'original_result_population':receipt['original_result_population'],'receiver_counts':receipt['receiver_counts'],'provider_counts':receipt['provider_counts']}))
