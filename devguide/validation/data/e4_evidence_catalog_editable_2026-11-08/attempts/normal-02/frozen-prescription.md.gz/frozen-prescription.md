# Receiving complete interaction catalogs on the editable workspace — 2026-11-08

Owner: [DockingMT #80](../pending_proposals/receive_docking_interaction_analysis.md).
Provider correction: [MolSysMT #642](https://github.com/uibcdf/molsysmt/issues/642).
Registered before execution; current outcome: **unexecuted**.

## Development composition and unchanged question

Use the maintainer-directed editable development route, not the historical
interrupted wheel construction. DockingMT source is
`542c5c5853a64ed9472a3317449e900f33f9b952`; MolSysMT source is
`2325038e8c68157f5c730693ffbb8535f0b45540`, whose rebuilt native SHA-256 is
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`.
Observe the other actual editable/support origins, versions, Python source
hashes and loaded native identities before and after each complete selection.
Record shared Conda metadata observations; unrelated concurrent metadata changes
must not trigger an environment reset. Relevant source/native drift refuses
receiving. Python 3.14.10 and the existing routine environment are used directly.
No build, install, source overlay, dependency pin change or remote CI is selected.

The previous [exact receiving prescription](e4_evidence_catalog_fix_2026-11-07.md)
and prepared worker retain the scientific requirements and finite operation
budgets. Only import/custody and receipt fields change to describe actual editable
sources rather than unavailable private wheel prefixes. Preserve the complete
binding/persistence assertion block and frozen native-state helpers. Do not
repair or regenerate molecular data, discard labels, weaken equality or represent
these development observations as installed/public artifact qualification.

## Inputs, complete selections and failure disposition

Authenticate the original result, association and positive one-frame 3238-atom
carrier from the existing saved-carrier archive (manifest SHA-256
`73c8114368f0d7011d2e27d229662bf29be1f99bea27c0e0a24065f077e04b4d`).
Also authenticate the immutable already-written failing carrier and its original
pre-write analysis record from the native-unevaluated archive (manifest SHA-256
`b4a676022aa26f0508fadd87bb5f1dee21d9e7650edf4ebe085599c4313793ef`).
The historical molecular producer remains `5952053`; this receiver is separate.

First execute the entire normal-policy selection. Only if it passes, execute
the entire pm/fs/coulomb selection with the identical worker and composition.
Read the original and old failed carriers; retain complete native/typed witnesses.
Invalidate the original hbonds structure 0, derive a detached carrier, bind the
selected existing pose through public DockingMT, receive detached accessors and
two query pages, and write/read one full H5MSM carrier. Require the original
five-pose result, source geometry/state/maps/mechanics and complete analysis
payloads to remain unchanged. The old failed carrier must now restore its exact
original pre-write analysis record. Hbonds retains its evidence catalog with
zero evaluated structures/occurrences; hydrophobic retains two observations.
Four other original poses remain unevaluated. Preserve the original equality
requirements and existing native coordinate tolerance of 1e-12 angstrom.

Per-policy caps stay three H5 reads, one H5 write, one invalidation, one carrier
derivation, one binding, one detached carrier accessor, four analysis accessors,
two queries/pages, six native snapshots and 32 direct typed exports. Nested
provider caps stay convert 128, copy 40, get 640, has_attribute 256, reads 3,
writes 1, analysis copy 128, remap 16, invalidation 1 and typed exports 128.
Preparation, assignment, detectors, distances/RMSD/scoring/search, alignment,
coordinate editing and View/browser/kernel creation remain forbidden.

Every failed or interrupted attempt is retained; an incomplete normal selection
does not admit pm/fs. Diagnose a task failure separately from a provider defect.
Report actionable provider defects in their owner without a local molecular
fallback. A resource/headroom stop does not authorize automatic heavy retries.

## Resources and custody

Use the existing frozen six-function group guard (source SHA-256
`3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d`).
Each cell runs serially on CPU 0/nice 10/one native/build worker, monitored
13 GiB available reserve, 1 GiB group RSS, 2 GiB address space, 45 CPU seconds
and 60 wall seconds. Estimated peak group RSS is 640 MiB from the original
approximately 536 MiB observation. Check RAM/load/swap/pressure before launch;
Slurm is present but no allocation is active, so keep direct work conservative.
All owned descendants must terminate. Preserve raw progress, outputs, warnings,
source/input hashes and resource outcomes under
`.molsyssuite/e4-evidence-editable-20261108`, #50 custody/review 2026-11-14.

After execution, seal exact records and receive them with a standard-library
reader without scientific replay. Update #80 and current checkpoints. Keep
original failures/build interruptions unchanged. Actual canvas, other-carrier
projection, E3 #604, independent scientific panel and public/minor/platform
delivery retain their separate scope; complete #73 stays open.

## Setup failure and complete normal-02 registration

The first normal attempt fails during task instrumentation: the unexecuted old
worker names `molsysviewer.View`, while the actual public constructor is
`molsysviewer.MolSysView`. All molecular/provider/direct counters remain zero;
no input is interpreted, binding or persistence attempted. This is an obsolete
task guard, not a demonstrated provider defect. The failed attempt stays FAIL:
3.977 s, peak sampled group RSS 133,394,432 bytes, minimum available RAM
56,663,564,288 bytes, terminal owned group and no resource interruption.

Amend only the forbidden-constructor guard to the actual public `MolSysView`.
The full binding/persistence assertion block remains byte-identical apart from
its completion label. Register normal-02 as a fresh complete selection, with
the same data, budgets, source/native identities, resource policy and equalities.
Only its success may admit pm/fs. Preserve normal-01's frozen worker, failure,
zero call counts, source composition and resource receipt. No scientific
assertion or tolerance is changed.
