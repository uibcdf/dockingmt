"""Authenticate original coercion and red/green source qualification records."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(os.environ['DMT_GUIDES_ROOT'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
folder = root / 'devguide/validation/data/protocol_energy_record_2026-11-08'
expected = '67ba1078d3a29bc531f0e57dce26095ae1f04f5511ee2fce06c77b53199775de'
assert hashlib.sha256((folder / 'manifest.json').read_bytes()).hexdigest() == expected
manifest = json.loads((folder / 'manifest.json').read_text())
assert len(manifest['files']) == 67
records = {}
for row in manifest['files']:
    assert (folder / row['path']).resolve().parent == folder.resolve()
    stored = (folder / row['path']).read_bytes()
    assert len(stored) == row['bytes'] and hashlib.sha256(stored).hexdigest() == row['sha256']
    raw = gzip.decompress(stored)
    assert len(raw) == row['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == row['decoded_sha256']
    assert row['original_path'] not in records
    records[row['original_path']] = raw
def read(name):
    return json.loads(records[name])
for label in ['probe-01', 'red-01', 'green-01', 'green-02']:
    resource = read(label + '/resource-outcome.json')
    assert resource['outcome'] == ('FAIL' if label == 'red-01' else 'PASS')
    assert resource['resource_interruption'] is None and resource['group_terminal'] and not resource['remaining_live_owned_pids']
    assert resource['policy']['available_reserve_bytes'] == 13 * 1024**3
    registration = read(label + '/registration.json')
    assert hashlib.sha256(records[label + '/frozen-worker.py']).hexdigest() == registration['worker_sha256']
observations = read('probe-01/observations.json')['observations']
assert len(observations) == 7 and all(row['source_preserved'] for row in observations)
assert observations[0]['reader'] == {'accepted': True, 'value': 1.0}
assert observations[1]['reader'] == {'accepted': True, 'value': 0.0}
red = read('red-01/receipt.json')
assert red['outcome'] == 'FAIL' and red['observations'] == [{'profile': 'normal', 'exit_code': 1, 'tests': 33, 'failures': 18, 'errors': 0, 'skipped': 0}]
assert red['inputs_sha256']['dockingmt/core/protocol.py'] == read('plan.json')['original_protocol_sha256']
for label, profiles, count in [('red-01', ['normal'], 33), ('green-01', ['normal', 'pm-fs'], 152), ('green-02', ['normal', 'pm-fs'], 156)]:
    receipt = read(label + '/receipt.json')
    for name, sha in receipt['inputs_sha256'].items():
        assert hashlib.sha256(records[label + '/frozen-' + name.replace('/', '__')]).hexdigest() == sha
    assert receipt['molecular_operations'] == receipt['native_builds'] == receipt['package_installs'] == 0
    assert [row['profile'] for row in receipt['observations']] == profiles
    for profile in profiles:
        child = read(label + '/' + profile + '-receipt.json')
        assert child['molecular_calls_attempted'] == child['optional_engines_loaded'] == []
        for key in ['default_form', 'default_parser', 'standard_units']:
            assert child['caller_policy_before'][key] == child['caller_policy_after'][key]
        parsed = ET.fromstring(records[label + '/' + profile + '.xml'])
        assert len(list(parsed.iter('testcase'))) == count
        assert len(list(parsed.iter('failure'))) == (18 if label == 'red-01' else 0)
        assert not list(parsed.iter('error')) and not list(parsed.iter('skipped'))
        if label != 'red-01':
            assert child['pytest_exit_code'] == 0
    if label != 'red-01':
        assert receipt['outcome'] == 'PASS' and all(row['tests'] == count and row['failures'] == row['errors'] == row['skipped'] == row['exit_code'] == 0 for row in receipt['observations'])
assert read('green-02/receipt.json')['inputs_sha256']['dockingmt/core/protocol.py'] != red['inputs_sha256']['dockingmt/core/protocol.py']
assert read('owner-evidence.json')['owner_issue']['issue_number'] == 84
receipt = {'stage': 'reader', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members_verified': 67, 'primary_manifest_sha256': expected, 'original_failed_cases': 18, 'original_red_total': 33, 'final_green_cases_per_policy': 156, 'final_green_policies': ['normal', 'pm-fs'], 'molecular_operations': 0, 'scope': 'Stored/decoded source, original diagnostic/red and raw final two-policy JUnit/policy/resource authentication; no execution rerun or installed/public/scientific acceptance'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
