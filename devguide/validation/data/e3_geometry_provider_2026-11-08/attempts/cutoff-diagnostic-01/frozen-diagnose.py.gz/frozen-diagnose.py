"""Finite cutoff unit-path diagnosis; never rerun a terminal selection."""
import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

if len(sys.argv)>1 and sys.argv[1]=='worker':
    attempt=Path(os.environ['DMT_DIAGNOSTIC_ATTEMPT'])
    composition=json.loads((attempt/'frozen-composition.json').read_text())
    origins=[]
    blocked=[]
    def audit(event,args):
        if event=='subprocess.Popen':
            executable,argv=os.fsdecode(args[0]),args[1]
            if isinstance(argv,list) and argv[:2]==['git','-C'] and len(argv)==5 and argv[2] in composition['source_revisions'] and argv[3:]==['rev-parse','HEAD']:
                return
            if isinstance(argv,list) and argv==['uname','-p'] and shutil.which(executable)=='/usr/bin/uname':
                return
        if event in ['socket.connect','subprocess.Popen'] or event=='import' and args[0].split('.')[0]=='vina':
            blocked.append(event)
            raise AssertionError(event)
    sys.addaudithook(audit)
    source=(attempt/'frozen-selected-worker.py').read_text()
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='custody')
    exec(compile(ast.Module(body=[node],type_ignores=[]),'frozen-selected-worker.py#custody','exec'),globals())
    custody('before')
    import numpy as np
    import molsysmt as msm
    import pyunitwizard as puw
    from pyunitwizard.record import QuantityRecord
    previous=puw.configure.report()
    chain=np.array([[0.,1.,2.],[1.,0.,1.],[2.,1.,0.]])
    outcomes=[]
    for length,timing in [('nm','ps'),('pm','fs')]:
        with puw.context(standard_units=[length,timing]), msm.configure.context(parallel_mode=False,num_threads=1,max_ram_usage=256*1024**2):
            for label,matrix,cutoff in [('nm-string',puw.quantity(chain,'nm'),'1 nm'),('nm-quantity',puw.quantity(chain,'nm'),puw.quantity(1.,'nm')),('pm-quantity',puw.quantity(chain*1000,'pm'),puw.quantity(1000.,'pm'))]:
                input_values=puw.get_value(matrix).copy()
                scalar=puw.quantity(1.,'nm') if label!='pm-quantity' else puw.quantity(1000.,'pm')
                standardized=puw.standardize(scalar)
                normalized_nm=float(puw.get_value(standardized,to_unit='nm'))
                for method in ['complete_linkage','single_linkage']:
                    result=msm.structure.get_distance_clusters(matrix,cutoff,method=method)
                    records={f:QuantityRecord.from_quantity(result[f],field=f).to_dict() for f in ['cluster_diameters','cutoff_distance']}
                    np.testing.assert_array_equal(puw.get_value(matrix),input_values)
                    outcomes.append({'policy':length,'input':label,'method':method,'clusters':result['cluster_indices'].tolist(),'matrix_sha256':result['matrix_sha256'],'cutoff_after_standardization_nm':normalized_nm,'cutoff_after_standardization_nm_hex':normalized_nm.hex(),'original_cutoff_nm':float(puw.get_value(scalar,to_unit='nm')),'matrix_to_nm':puw.get_value(matrix,to_unit='nm').tolist(),'physical_records':records,'software':result['software']})
    assert len(outcomes)==12 and puw.configure.report()==previous and not blocked
    custody('after')
    (attempt/'results.json').write_text(json.dumps(outcomes,indent=2)+'\n')
    (attempt/'runtime-origins.json').write_text(json.dumps(origins,indent=2)+'\n')
    (attempt/'receipt.json').write_text(json.dumps({'outcome':'PASS','qualification_complete':True,'scope':'Finite diagnosis only; original pm/fs selection remains FAIL','cluster_calls':12,'source_and_caller_preserved':True,'e3_accepted':False},indent=2)+'\n')
    print(json.dumps([{k:x[k] for k in ['policy','input','method','clusters','cutoff_after_standardization_nm_hex']} for x in outcomes]))
    raise SystemExit(0)

root=Path(__file__).resolve().parents[2]
task=Path(__file__).parent
attempt=task/'cutoff-diagnostic-01'
attempt.mkdir(exist_ok=False)
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available()>policy['available_reserve_bytes']+512*1024**2
for original,name in [(Path(__file__),'frozen-diagnose.py'),(task/'composition.json','frozen-composition.json'),(task/'worker.py','frozen-selected-worker.py'),(guard,'frozen-resource-guard.py')]:
    shutil.copyfile(original,attempt/name)
registration={'owner':'uibcdf/molsysmt#659','policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':512*1024**2,'cluster_calls':12,'hypothesis':'An unnecessary cutoff-only standardization roundtrip can change exact inclusive membership; compare string/quantity and original/caller-scaled inputs for both linkage rules in nm and pm','original_selections_restarted':False,'frozen_sha256':{p.name:sha(p) for p in attempt.iterdir() if p.is_file()}}
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy();env.update(DMT_DIAGNOSTIC_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:
    env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen([sys.executable,'-B','-I',str(attempt/'frozen-diagnose.py'),'worker'],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
    outcome=monitor(process,policy)
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
print((attempt/('stdout.log' if outcome['outcome']=='PASS' else 'stderr.log')).read_text()[-5000:])
raise SystemExit(0 if outcome['outcome']=='PASS' else 1)
