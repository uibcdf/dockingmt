# E3 bounded geometry-provider receiving — 2026-11-08

Owner: [DockingMT #79](../pending_proposals/qualify_pose_comparison_and_clustering.md).
Registered before execution; outcome **unexecuted**.

## Independent question and preserved holds

Receive the newly delivered experimental MolSysMT #604 public operations
`structure.get_pairwise_rmsd` and `structure.get_distance_clusters` on the
actual editable development cohort. This separate synthetic control population
does not replace the experimental reference or discharge the failed full E3
selection. Preserve both earlier scientific failures, #88's partial corrected
criterion, #256's native mechanics persistence hold, original saved poses,
their state/producer/frame identities and every original E3 requirement.

Use only declared synthetic common-axis fixtures: three translated two-point
structures and a six-carbon ring with an explicit cyclic atom permutation and
an orthogonal translation. The ring is created from `c1ccccc1` through public
RDKit/MolSysMT conversion; its assigned geometry is an analytic fixture, not
experimental coordinates or a repaired molecular reference. No saved docking
population, experimental-reference metric, fitted alignment, periodic imaging,
native search or new independent molecular case is admitted.

## Frozen controls and direct budgets

Run one complete normal policy followed, only after PASS, by the identical
pm/fs/coulomb policy. Per policy cap direct calls at 18 pairwise operations,
23 clustering operations, four chemical-correspondence operations, one
RDKit/native conversion and one native structure append. Provider-internal
dispatches and existing snapshot helpers have their separate scope. The largest
requested numerical matrix has four members; no stress benchmark or scalability
claim follows.

Check analytic translation values, original/repeated structure order and opaque
member keys, typed empty/singleton outputs, explicit no-fitting/no-imaging and
positional non-chemistry metadata. Check full, cached, identity-restricted and
anchored chemical symmetry with retained scope, winners and inverse-closed maps.
Use a three-member chain to distinguish inclusive complete/single linkage and
reported diameters, medoid/first semantics, exact equality, a strictly smaller
cutoff with declared margin, duplicate/empty/singleton populations and mixed
length units. Compare explicit expected values within 1e-12 nm; no tolerance is
added to the clustering inequality. Refuse invalid coordinate/matrix values,
atom/member/map populations, directional maps, unsupported fitted/score-based
rules, bad dimensions/shapes/cutoffs and work/RAM limits with provider types.
Keep source/cached evidence/key arrays immutable and verify detached returns,
caller policy and provider configuration restoration. Do not monkeypatch a
numerical, chemistry, validation or codec operation.

Persist each returned scientific result with PyUnitWizard QuantityRecord fields
and retain native NumPy dtype/shape observations before diagnostic conversion.
Use the provider's field/unit/dimensional reader handshake for every stored
physical field. Independent receiving verifies these records through PyUnitWizard
without importing MolSysMT/RDKit or recomputing molecular geometry/clustering.
No consumer matrix, atom matcher, clustering algorithm or quantity codec is added.

## Source identity and execution policy

The clean provider checkout is fast-forwarded 16 commits from `2325038e8` to
`8af8628e61ac28b519827802c39cf2e3eaa48b7e`. Its Rust tree remains
`fb25b2eac60b6e706c712e788119b3dad94329fe`; native SHA-256 remains
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`.
No build inputs or extension change, rebuild or reinstall. Source bootstrap
provenance limitation [MolSysMT #657](https://github.com/uibcdf/molsysmt/issues/657)
is retained: observed distribution/version labels are recorded separately from
actual source hashes, Git revision and import/native origins; never rewrite
their attribution as if it reported another version.

Consumer starting source is `3c5145c69367d15148ecb113501ed87dd6106ce1`.
Freeze full participating Python source inventories, imports/native origins,
provider API/private implementation/contract/test identities, fixture/worker/
controller, prescription and unchanged support declaration before execution.
Use existing SDK `95f693be10c9205ab9b912cb53453710a207bf45` support staging;
there is no module overlay, public package wait, runtime/helper/data/pin edit.

Serial CPU 0/nice 10, one native/build worker, 13 GiB available-RAM reserve,
1 GiB group RSS, 2 GiB address space, 45 CPU/60 wall seconds; expected RSS
512 MiB. Inspect current RAM/load/swap/pressure first and monitor owned groups.
Slurm has no allocation; preserve the previously inconclusive applicability
probe and use this small direct route. Stop after a failed gate, preserve every
failed/interrupted/unattempted outcome, and never restart automatically after
a resource stop. Keep `.molsyssuite/e3-geometry-receiving-20261108` under #50,
review 2026-11-14. Seal/read exact records, run applicable local checks and fresh
committed-export resource validation. No browser/kernel/server or remote CI.
