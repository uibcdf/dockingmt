---
summary: Offline audits accept malformed pose identities/ranks or leak array comparison errors.
issue: uibcdf/dockingmt#91
status: active
opened: 2026-11-08
closed:
severity: medium
verification: reproduced
area: [records, audit, provenance]
guard: tests/test_audit_pose_identity_records.py
normative: devguide/validation/result_audit.md
blocked_by: []
supersedes: []
---

# Pose identity and rank record admission

## What

At execution base `d3fc5dc2db8c858a5ad8df38980c0a338184784e`, the offline audit
accepts Boolean/floating ranks and integer pose IDs that the public pose reader
refuses. Coordinating malformed IDs with ranking observations does not make
the types valid. Historical ranks/IDs are not typed before comparison; arrays
can raise ValueError instead of producing an inconsistent report.

## How

An eight-control probe observes seven failures and a legitimate NumPy-integral
rank control, with source preservation and zero molecular operations. Register
the durable guard before runtime changes and retain the original complete red
pytest/Receptor/JUnit outcome. Reuse the existing registered rank/ID digesters
through one private schema helper for current declarations and history records.
Add bounded malformed-field diagnostics and avoid relational comparisons on
invalid identities. Preserve valid report contents and unrelated checks.

## Why

The initial red selection has 73 failures/30 passes, no errors/skips. Preserve
that FAIL population and its full Receptor overflow report. Three failures are
test setup mistakes: two scored fixtures have optional rank=None, which cannot
be passed to NumPy's integer constructor; the historical fixture also has an
extra documentary root field outside the reader's structured export. Register
a fresh red guard on unchanged runtime: explicitly declare rank 1 before the
NumPy-equivalence comparison, and obtain the history control through the public
result reader before modifying it. No assertion or invalid case is removed.
Existing optional ID digesters admit any string, including empty/blank content;
preserve that contract instead of imposing a new nonempty-string requirement.
Existing scoring-state semantic checks retain their own stricter scope.

Offline inspection must not turn malformed scientific identity/ranking claims
into internally consistent evidence or raise ambiguous NumPy truth-value errors.
Existing class admission already defines the scalar contract; no new identity
model or public API is needed.

## What was refuted

No ArgDigest, SMonitor, molecular correspondence or ranking-geometry provider
defect is established. NumPy integral ranks are valid and remain supported.
Unknown optional IDs/ranks, repeated poses and legacy history do not acquire
invented identities, uniqueness requirements or new mandatory evidence.

## Scope and exclusions

Standalone, docking and scored-collection identity/rank fields, plus recorded
ranking observations. Keep order/ties/multiplicity, native and legacy valid audit
digests, missing evidence, schema priority, nonmutation and resource-error
identity. No molecular operation, record migration, helper/data/pin change,
native build, environment repair or remote CI. The maintainer asks to wait for
MolSysMT #256; this work neither polls it nor replaces its H5MSM gate.

## Acceptance criteria

The original guard must fail and the corrected runtime must pass the complete
affected model/record/audit/ranking selection normal then pm/fs, with identical
final source/test bytes. Preserve invalid scalars/arrays, valid NumPy ranks,
unknown IDs, coordinated false claims, history refusal, field-specific paths,
native resource-error identity and every original valid assertion/digest.
Use authenticated published Pytest Receptor 1.2.2 and native JUnit; independently
receive the records without test/molecular replay.

Run serial CPU 0/nice 10/one worker, monitored 13 GiB available reserve, 1 GiB
group RSS, 2 GiB address space, 45 CPU/60 wall seconds. Estimated record-test
peak is 256 MiB. Preserve interruptions without automatic heavy restart. Task
custody: `.molsyssuite/audit-identity-admission-20261108`, #50/review 2026-11-14.
Update contracts, roadmap/plan/handoff, archive the resolved record, regenerate
indexes and synchronize #91. Run Ruff/resource/publication and fresh committed
export checks. Source qualification does not accept installed/scientific/public/
platform/canvas or the full objective; commit with `[skip ci]`.
