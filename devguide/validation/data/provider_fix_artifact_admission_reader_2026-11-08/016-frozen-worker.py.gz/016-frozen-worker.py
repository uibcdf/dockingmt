"""Retain the completed metadata reader and its publication producers."""
import gzip
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
output = root / 'devguide/validation/data/provider_fix_artifact_admission_reader_2026-11-08'
output.mkdir(exist_ok=False)
sources = []
for label in ['seal-01', 'reader-01']:
    for path in sorted((task / label).iterdir()):
        if path.is_file():
            sources.append(path)
sources.append(Path(__file__))
rows = []
for index, path in enumerate(sources):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    relative = f'{index:03d}-{path.name}.gz'
    (output / relative).write_bytes(stored)
    rows.append({'original_path': str(path.relative_to(task)), 'path': relative, 'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(), 'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'schema': 'dockingmt.provider_fix_artifact_admission_reader@1', 'owner': 'uibcdf/dockingmt#33/#49/#80', 'source_commit': 'acce58e3dc0ff17673f091b42765fb65257b8977', 'primary_manifest_sha256': 'e3df5faaff6336e5b43f756c70ac0b2f8cbb92b7fac49afcfa6e0b1613dadc16', 'scope': 'Completed stdlib metadata reader and publication producers; no artifact/runtime/scientific admission', 'files': rows}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {'stage': 'reader-seal', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members': len(rows), 'manifest_sha256': hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest(), 'stored_bytes': sum(row['bytes'] for row in rows), 'molecular_operations': 0}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
