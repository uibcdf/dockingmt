import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root = Path.cwd()
task = Path(__file__).resolve().parent
stage = sys.argv[1]
assert stage in ['inventory', 'seal', 'reader', 'reader-seal', 'final-checks', 'committed-checks']
attempt = task / (stage + '-' + (sys.argv[2] if len(sys.argv) > 2 else '01'))
attempt.mkdir(exist_ok=False)
guard = root / '.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert hashlib.sha256(guard.read_bytes()).hexdigest() == '3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes = [n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n, ast.FunctionDef) and n.name in {'available', 'memory', 'limits', 'group_members', 'stop_owned_group', 'monitor'}]
assert len(nodes) == 6
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(guard), 'exec'), globals())
mem = dict((line.split(':', 1)[0], int(line.split(':', 1)[1].split()[0]) * 1024) for line in Path('/proc/meminfo').read_text().splitlines())
reserve = max(8 * 1024**3, ((mem['MemTotal'] + 5 * 1024**3 - 1) // (5 * 1024**3)) * 1024**3)
policy = {'cpu': 0, 'nice': 10, 'workers': 1, 'available_reserve_bytes': reserve, 'group_rss_limit_bytes': 1024**3, 'address_space_bytes': 2 * 1024**3, 'cpu_seconds': 45, 'wall_seconds': 60}
assert available() >= reserve + 256 * 1024**2
worker = task / {'inventory': 'inspect_artifacts.py', 'seal': 'seal_records.py', 'reader': 'read_records.py', 'reader-seal': 'seal_reader.py', 'final-checks': 'final_checks.py', 'committed-checks': 'committed_checks.py'}[stage]
for source, name in [(guard, 'resource-guard.py'), (worker, 'worker.py'), (Path(__file__), 'controller.py')]:
    shutil.copyfile(source, attempt / ('frozen-' + name))
registration = {'source_commit': 'acce58e3dc0ff17673f091b42765fb65257b8977', 'stage': stage, 'policy': policy, 'physical_ram_bytes': mem['MemTotal'], 'initial_available_bytes': available(), 'estimated_peak_group_rss_bytes': 256 * 1024**2, 'worker_sha256': hashlib.sha256(worker.read_bytes()).hexdigest(), 'scope': 'Bounded source/registry metadata inspection and administrative publication only; no scientific imports, build or installation; no scheduler allocation; availability is not reservation'}
(attempt / 'registration.json').write_text(json.dumps(registration, indent=2) + '\n')
env = os.environ.copy()
env.update(DMT_GUIDES_ROOT=str(root), DMT_GUIDES_TASK=str(task), DMT_GUIDES_ATTEMPT=str(attempt), PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
for key in ['OMP_NUM_THREADS', 'OMP_THREAD_LIMIT', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS', 'RAYON_NUM_THREADS', 'CARGO_BUILD_JOBS', 'MAX_JOBS']:
    env[key] = '1'
with (attempt / 'stdout.log').open('xb') as stdout, (attempt / 'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(['/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python', '-B', '-I', '-S', str(attempt / 'frozen-worker.py')], cwd=root, env=env, stdout=stdout, stderr=stderr, start_new_session=True, preexec_fn=limits)
    outcome = monitor(process, policy)
try:
    receipt = json.loads((attempt / 'receipt.json').read_text())
    semantic = receipt['outcome'] == 'PASS' and receipt['qualification_complete'] and receipt['stage'] == stage and receipt['source_commit'] == registration['source_commit']
except Exception as error:
    semantic = False
    outcome['qualification_diagnostic'] = type(error).__name__ + ': ' + str(error)
outcome['outcome'] = 'PASS' if semantic and outcome['exit_code'] == 0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt / 'resource-outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome))
if outcome['outcome'] != 'PASS':
    print((attempt / 'stderr.log').read_text()[-4000:])
    raise SystemExit(1)
print(json.dumps({'stage': stage, 'checks': len(receipt.get('checks', [])), 'reserve_bytes': reserve}))
