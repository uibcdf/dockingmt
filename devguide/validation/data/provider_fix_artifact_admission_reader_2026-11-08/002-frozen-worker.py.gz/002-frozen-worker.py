"""Freeze bounded source/registry inspection; no package or molecular work."""
import gzip
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
output = root / 'devguide/validation/data/provider_fix_artifact_admission_2026-11-08'
output.mkdir(exist_ok=False)
selected = [(name, task / name) for name in ['plan.json', 'admission-boundary.json', 'owner-evidence.json']]
selected.append(('prior-registry-inventory.json', root / '.molsyssuite/panel-receiving-20261107/inventory-01/artifact-inventory.json'))
selected.extend((str(path.relative_to(task)), path) for path in sorted((task / 'inventory-01').iterdir()) if path.is_file())
rows = []
for index, (original, path) in enumerate(selected):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    name = f'{index:03d}-{path.name}.gz'
    (output / name).write_bytes(stored)
    rows.append({'original_path': original, 'path': name, 'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(), 'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'schema': 'dockingmt.provider_fix_artifact_admission@1', 'owner': 'uibcdf/dockingmt#33/#49/#80', 'source_commit': 'acce58e3dc0ff17673f091b42765fb65257b8977', 'target_provider_source': 'ad67e0e915ba23d90cb9d6331c063c342852d67a', 'scope': 'Source/build-input and advertised registry comparison, not wheel/native/scientific receiving', 'files': rows}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {'stage': 'seal', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members': len(rows), 'manifest_sha256': hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest(), 'stored_bytes': sum(r['bytes'] for r in rows), 'scientific_imports': [], 'native_builds': 0, 'artifact_received': False}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
