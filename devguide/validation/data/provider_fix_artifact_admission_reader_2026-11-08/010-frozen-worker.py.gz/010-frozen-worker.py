"""Independent stdlib metadata-record audit; no Git fetch, build or import."""
import gzip
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
folder = root / 'devguide/validation/data/provider_fix_artifact_admission_2026-11-08'
expected = 'e3df5faaff6336e5b43f756c70ac0b2f8cbb92b7fac49afcfa6e0b1613dadc16'
assert hashlib.sha256((folder / 'manifest.json').read_bytes()).hexdigest() == expected
manifest = json.loads((folder / 'manifest.json').read_text())
assert len(manifest['files']) == 19
records = {}
for row in manifest['files']:
    path = folder / row['path']
    assert path.resolve().parent == folder.resolve()
    stored = path.read_bytes()
    assert len(stored) == row['bytes'] and hashlib.sha256(stored).hexdigest() == row['sha256']
    raw = gzip.decompress(stored)
    assert len(raw) == row['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == row['decoded_sha256']
    assert row['original_path'] not in records
    records[row['original_path']] = raw
def read(name):
    return json.loads(records[name])
resource = read('inventory-01/resource-outcome.json')
assert resource['outcome'] == 'PASS' and resource['group_terminal'] and resource['resource_interruption'] is None and not resource['remaining_live_owned_pids']
assert resource['policy']['available_reserve_bytes'] == 13 * 1024**3
registration = read('inventory-01/registration.json')
assert hashlib.sha256(records['inventory-01/frozen-worker.py']).hexdigest() == registration['worker_sha256']
review = read('inventory-01/source-review.json')
assert review['target'] == 'ad67e0e915ba23d90cb9d6331c063c342852d67a'
assert review['contains_fixes'] == {'catalog_fix': True, 'formal_charge_fix': True}
assert review['revisions']['old_native']['rust_tree'] == review['revisions']['old_python']['rust_tree'] == '32cfb07b9c26ae9ad3ed379c1b76fab85669cf67'
for label in ['catalog_fix', 'formal_charge_fix', 'comparison_fix']:
    assert review['revisions'][label]['rust_tree'] == 'fb25b2eac60b6e706c712e788119b3dad94329fe'
for key in ['rust_tree', 'build-system', 'setuptools-rust', 'distutils']:
    assert review['revisions']['catalog_fix'][key] == review['revisions']['comparison_fix'][key]
for relative, row in review['target_files'].items():
    raw = records['inventory-01/' + row['retained_as']]
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
owner = read('owner-evidence.json')
for key in ['owner_record', 'owner_receipt']:
    raw = owner[key]['content'].encode()
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == owner[key]['sha']
assert json.loads(owner['owner_receipt']['content'])['qualified_source'] == review['target']
new = read('inventory-01/registry-inventory.json')
old = read('prior-registry-inventory.json')
raw_registry = records['inventory-01/registry-response.json']
assert hashlib.sha256(raw_registry).hexdigest() == new['response_sha256'] and len(raw_registry) == new['response_bytes'] == 183573
payload = json.loads(raw_registry)
assert len(payload['files']) == len(new['files']) == len(old['files']) == 107
fields = ('basename', 'version', 'sha256', 'size', 'upload_time')
def identities(rows):
    return sorted(tuple(str(row.get(k)) for k in fields) for row in rows)
assert identities(new['files']) == identities(old['files'])
assert identities(payload['files']) == identities(new['files'])
boundary = read('admission-boundary.json')
assert boundary['registry_file_identities_equal_to_prior_inspection'] and not boundary['new_advertised_files'] and not boundary['old_native_eligible_for_target'] and not boundary['public_or_private_artifact_received']
receipt = read('inventory-01/receipt.json')
assert receipt['scientific_imports'] == [] and receipt['native_builds'] == receipt['environment_installs'] == receipt['molecular_operations'] == 0 and receipt['old_checkout_unchanged']
result = {'stage': 'reader', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members_verified': 19, 'primary_manifest_sha256': expected, 'advertised_files_verified': 107, 'new_advertised_files': 0, 'source_target': review['target'], 'recorded_source_ancestry_reexecuted': False, 'scientific_imports': [], 'molecular_operations': 0, 'native_builds': 0, 'artifact_received': False, 'scope': 'Exact recorded source/metadata identities and producer/resource facts; no runtime/source-independent ancestry or package qualification'}
(attempt / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
