# Receiving the provider evidence-catalog correction — 2026-11-07

Owner: [DockingMT #80](../pending_proposals/receive_docking_interaction_analysis.md).
Provider: [MolSysMT #642](https://github.com/uibcdf/molsysmt/issues/642).
Registered before execution; outcome at registration: **unexecuted**.

## Exact source and artifact boundary

The provider closed #642 with published correction
`4d8af6c34cb6b3f9e22833771b246d8767ef85e9`. Its source tests and real-carrier
checks do not receive DockingMT's actual installed client. Preserve both old
failed consumer attempts and every existing archive. This increment must not
discard unused labels, normalize catalogs or patch an installed provider module.

Use the unchanged DockingMT source `2ef82d2`, private wheel
`0.0.0+310.g2ef82d2`, SHA-256
`6db76835f4f3f9c41d06a163cb3a4fbc9e780597bfd89d2fc6a75d29cff31133`.
Build the complete provider wheel from the exact published correction in a
separate sparse Git checkout containing every runtime package and build input.
The local MolSysMT checkout remains clean at `9e1f1b1`, 111 commits behind its
freshly fetched main; Viewer local checkout/qualified overlay remain unchanged.
New provider Rust sources differ from the old binary, so borrowing that binary
cannot qualify the correction. No provider pin or routine environment changes.

One offline candidate-build attempt uses the installed Rust/Cargo1.99.1 and
setuptools-rust toolchain, a private copy of the cached Cargo registry/target
files and the explicit `SETUPTOOLS_RUST_CARGO_PROFILE=dev`. Preserve exact build
commands, source hashes, cache provenance, wheel RECORD/installed hashes and
new native binary identity. This private development-profile artifact carries
no release, performance, platform, public-channel or dependency-closure claim.
No dependency solve or network acquisition is allowed during that build. Do not
alter source/build configuration to force success; keep any failure/interruption.

Replace the old MolSysMT packages/addon/dist-info in a new task-local provider
prefix; retain every other transported provider byte. Reuse the verified
consumer/Viewer prefixes read-only. Verify loaded Python/native origins and
the routine Conda metadata before/after, without editable/source fallback.

## Finite scientific receiving

Only after a complete candidate build/install receipt passes, run one fresh
normal-policy cell, then one fresh pm/fs cell on identical frozen workers,
candidate and publication SDK `95f693be`. The complete normal selection must
pass before pm/fs. Use the immutable original retained carrier/result/association
from scientific producer `5952053`, exact input hashes from the prior archives.
Also read the immutable already-written failing carrier and compare its complete
typed analyses with its original pre-write diagnostic payload. No molecule is
reconstructed from an inspection dictionary or query page.

For each policy: read the original positive 3238-atom/one-frame carrier; retain
original native/typed witnesses and complete five-pose result. Publicly invalidate
`hbonds` at frame0, copy/reassociate the full carrier, bind the selected original
pose through the actual installed DockingMT API and receive detached accessors,
queries/pages and one full H5MSM write/readback. Require complete typed equality,
including the retained `baker_hubbard_hbond_geometry` catalog and original codes,
zero evaluated hbonds frames/occurrences and unchanged evaluated hydrophobic2.
Verify topology, chemistry, mechanics absence, frame/state/atom maps, coordinates,
units, method/producer metadata and original input/source/result nonmutation.
Original unaffected hbonds remain evaluated with three observations; four other
original poses remain unevaluated. No new docking/control pose is created.

Per-policy direct caps: original/immutable-failure/new-roundtrip H5 reads3,
H5 writes1, invalidation1, carrier derivation1, accepted binding1, detached
carrier accessor1, complete analysis accessor4, public analysis queries2/pages2,
native snapshots6 and typed exports32. Provider nested caps: convert128, copy40,
get640, has_attribute256, H5 reads3/writes1, invalidation1, analysis copy128,
remap16 and typed exports128. All extraction/merge/append/set, preparation,
H/charge/type assignment, detectors, distances/RMSD/energy/scoring/search,
alignment/coordinate transformations and View/browser/kernel creation are
forbidden. No persistence equality or numerical tolerance may be relaxed.

## Resources, custody and closeout

Run every build/scientific cell serially at CPU0/nice10/one native/build worker,
with 8 GiB available-RAM reserve, 1 GiB owned-group RSS, 2 GiB address space,
45 CPU seconds and 60 wall seconds. Reuse the frozen shared-request #173 guard
functions SHA-256
`3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d`.
Apply limits to heavy descendants; preserve terminal groups and interruptions.
Do not automatically restart heavy work after a headroom stop. A partial build,
process exit or passing provider tests alone cannot accept installed receiving.

Task `.molsyssuite/e4-evidence-fix-20261107` retains worktree, Cargo copies,
wheel/prefixes, source/tool/input/candidate identities, all logs and failures
under #50 custody, review 2026-11-14. Original migration files stay untouched.
Seal the completed records and receive them with an independent standard-library
reader. Update #80 and the maintained checkpoints with exact outcomes and limits.
No manual CI; #28 hosted exact-head evidence stays missing under `[skip ci]`.
Actual canvas #52/#60 remains held. Broader E4, E3 #604, Core/E5, independent
scientific reproduction, public/minor/platform delivery and full #73 remain open.
