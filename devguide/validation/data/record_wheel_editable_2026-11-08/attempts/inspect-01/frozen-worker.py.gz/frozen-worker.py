"""Actual private build, install, shared-validator pilot and offline installed tests."""
import ast
import base64
import csv
import hashlib
import importlib.metadata as metadata
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import tomllib
import venv
import zipfile
from email.parser import BytesParser

root=Path(os.environ['DMT_WHEEL_ROOT']);task=Path(os.environ['DMT_WHEEL_TASK']);attempt=Path(os.environ['DMT_WHEEL_ATTEMPT']);stage=os.environ['DMT_WHEEL_STAGE']
source_commit='6310a97b7a900f31d37f84a476bc355a899282de';sdk=root/'.molsyssuite/publication-sdk'
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10

def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def files(path):return {str(p.relative_to(path)):sha(p) for p in path.rglob('*') if p.is_file()}
def command(args,name,cwd=attempt):
 with (attempt/(name+'.log')).open('xb') as stream:subprocess.run(args,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,check=True)
def cohort():
 rows={}
 for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']:
  repo=root.parent/name;package=repo/name
  rows[name]={'commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True),'python_sha256':{str(p.relative_to(repo)):sha(p) for p in package.rglob('*.py')},'native_sha256':{str(p.relative_to(repo)):sha(p) for p in package.rglob('*.so')},'distribution_version':metadata.version(name)}
 return rows
before=cohort();receipt={'stage':stage,'source_commit':source_commit,'outcome':'PASS','qualification_complete':True}
base=Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14');basepy=str(base/'bin/python')
inventory=tomllib.loads((attempt/'frozen-resources.toml').read_text());runtime_names={p.removeprefix('site-packages/') for p in inventory['required_paths']}

if stage in ['red_admin','green_admin']:
 tool=json.loads((attempt/'frozen-reporting-tools-receipt.json').read_text());assert files(Path(tool['prefix']))==tool['files_sha256'];sys.path.insert(0,tool['prefix']);sys.path.insert(0,str(root))
 import pytest
 from pytest_receptor import read_artifact
 import xml.etree.ElementTree as ET
 selection=[str(root/'devtools/tests/test_distribution_contract.py')+('::TestDistributionContract::test_complete_core_addon_and_generated_version_inventory' if stage=='red_admin' else '')]
 status=int(pytest.main(['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'pytest-cache')]+selection))
 counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
 event=read_artifact(attempt/'events.jsonl');assert event.complete
 receipt.update(pytest_exit_code=status,counts=counts,receptor_final=event.final.data)
 if status:receipt['outcome']='FAIL'
elif stage in ['build','inspect']:
 wheel_dir=task/'wheels'
 if stage=='inspect':
  assert json.loads((task/'build-01/resource-outcome.json').read_text())['outcome']=='FAIL'
  source_hashes={n:hashlib.sha256(subprocess.check_output(['git','-C',str(root),'show',source_commit+':'+n])).hexdigest() for n in runtime_names if n!='dockingmt/_version.py'}
 else:
  assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==source_commit
  wheel_dir=task/'wheels';wheel_dir.mkdir()
  with tempfile.TemporaryDirectory(prefix='build-',dir=task) as tmp:
   source=Path(tmp)/'source'
   command(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(root),str(source)],'clone')
   command(['git','-c','core.hooksPath=/dev/null','checkout','--detach',source_commit],'checkout',source)
   assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==source_commit
   source_hashes={n:sha(source/n) for n in runtime_names if n!='dockingmt/_version.py'}
   assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
   command([basepy,'-B','-I','-m','pip','--isolated','--disable-pip-version-check','wheel','--no-index','--no-cache-dir','--no-deps','--no-build-isolation','--wheel-dir',str(wheel_dir),str(source)],'build',source)
   assert not subprocess.check_output(['git','-C',str(source),'diff','--name-only'])
 wheels=list(wheel_dir.glob('*.whl'));assert len(wheels)==1;wheel=wheels[0]
 with zipfile.ZipFile(wheel) as archive:
  names=archive.namelist();assert len(set(names))==len(names) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
  assert {n for n in names if '.dist-info/' not in n}==runtime_names and len(runtime_names)==66
  payload={n:hashlib.sha256(archive.read(n)).hexdigest() for n in names}
  for n,digest in source_hashes.items():assert payload[n]==digest
  meta_name=next(n for n in names if n.endswith('.dist-info/METADATA'));meta=BytesParser().parsebytes(archive.read(meta_name));version=meta['Version']
  assert source_commit[:7] in version and meta['Name']=='dockingmt' and meta['License-Expression']=='MIT'
  from packaging.specifiers import SpecifierSet
  assert SpecifierSet(meta['Requires-Python'])==SpecifierSet('>=3.11,<3.15')
  stamp=ast.parse(archive.read('dockingmt/_version.py'));assert any(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='__version__' for t in n.targets) and ast.literal_eval(n.value)==version for n in stamp.body)
  record_name=next(n for n in names if n.endswith('.dist-info/RECORD'))
  for name,digest,size in csv.reader(io.StringIO(archive.read(record_name).decode())):
   data=archive.read(name)
   if name==record_name:assert not digest and not size
   else:assert digest=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode() and len(data)==int(size)
  license_name=next(n for n in names if n.endswith('.dist-info/licenses/LICENSE'));assert archive.read(license_name)==(root/'LICENSE').read_bytes()
  for name in [meta_name,record_name,license_name,next(n for n in names if n.endswith('.dist-info/WHEEL'))]: (attempt/Path(name).name).write_bytes(archive.read(name))
 build={'source_commit':source_commit,'version':version,'wheel':str(wheel),'wheel_sha256':sha(wheel),'payload_sha256':payload,'runtime_paths':len(runtime_names),'source_sha256':source_hashes,'build_tools':{n:metadata.version(n) for n in ['setuptools','versioningit','wheel','pip']}}
 save(task/'artifact.json',build);receipt.update(version=version,wheel_sha256=build['wheel_sha256'],runtime_paths=len(runtime_names),build_context_retired=True)
else:
 artifact=json.loads((task/'artifact.json').read_text());assert sha(artifact['wheel'])==artifact['wheel_sha256'];prefix=task/'receiver';py=str(prefix/'bin/python');site=prefix/'lib/python3.14/site-packages'
 if stage=='setup':
  assert not prefix.exists();venv.EnvBuilder(system_site_packages=True,with_pip=False).create(prefix)
  unit=json.loads((attempt/'frozen-unit-support-receipt.json').read_text());wheel_dir=Path(unit['prefix']).parent/'wheels'
  for name,digest in unit['archives_sha256'].items():assert sha(wheel_dir/name)==digest
  command([py,'-B','-I','-m','pip','--isolated','--disable-pip-version-check','install','--no-index','--no-cache-dir','--no-deps','--no-compile','--ignore-installed',artifact['wheel']]+[str(wheel_dir/n) for n in unit['archives_sha256']],'install')
  receptor=json.loads((attempt/'frozen-reporting-tools-receipt.json').read_text());tool=Path(receptor['prefix']);assert files(tool)==receptor['files_sha256']
  for name,digest in receptor['files_sha256'].items():
   destination=site/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(tool/name,destination);assert sha(destination)==digest
  command([py,'-B','-I','-m','pip','--isolated','--disable-pip-version-check','check'],'pip-check')
  harness=task/'harness';harness.mkdir();tar=attempt/'source.tar'
  command(['git','-C',str(root),'archive','--format=tar','--output',str(tar),source_commit],'export')
  with tarfile.open(tar) as stream:stream.extractall(harness,filter='data')
  tar.unlink()
  for name in ['dockingmt','molsysviewer_dockingmt']:shutil.rmtree(harness/name)
  (harness/'devtools/conda-build/resources.toml').write_bytes((attempt/'frozen-resources.toml').read_bytes())
  selected=json.loads((task/'selection.json').read_text());tests={n:sha(harness/n) for n in selected if n.startswith('tests/')}
  for name,digest in artifact['payload_sha256'].items():
   if not name.endswith('.dist-info/RECORD'):assert sha(site/name)==digest
  installed={'prefix':str(prefix),'site':str(site),'consumer_sha256':{str(p.relative_to(site)):sha(p) for name in ['dockingmt','molsysviewer_dockingmt'] for p in (site/name).rglob('*') if p.is_file()},'tool_sha256':{name:sha(site/name) for name in receptor['files_sha256']},'unit_sha256':{str(p.relative_to(site)):sha(p) for p in site.rglob('*') if p.is_file() and (p.relative_to(site).parts[0].split('-')[0] in ['unyt','sympy','mpmath'])},'tests_sha256':tests,'harness':str(harness)}
  save(task/'installation.json',installed);receipt.update(version=artifact['version'],runtime_paths=len(installed['consumer_sha256']),source_free_harness=True,selected_modules=len(tests),test_support={'pytest-receptor':'1.2.2',**unit['packages']},ordinary_pip_check=True)
 else:
  installed=json.loads((task/'installation.json').read_text());harness=Path(installed['harness'])
  assert Path(sys.prefix)==prefix and Path(sys.base_prefix)==base and not Path.cwd().is_relative_to(harness)
  def verify():
   for group in ['consumer_sha256','tool_sha256','unit_sha256']:
    for name,digest in installed[group].items():assert sha(site/name)==digest
   for name,digest in installed['tests_sha256'].items():assert sha(harness/name)==digest
  verify();sys.path[:0]=[str(sdk)]
  sys.path[:]=[p for p in sys.path if Path(p or '.').resolve() not in {root,harness}]
  from devtools.scripts.installed_imports import check_installed_imports,runtime_import_roots
  from devtools.scripts.noarch_conda import ContractError
  roots=runtime_import_roots(inventory,'dockingmt');assert set(roots)=={'dockingmt','molsysviewer_dockingmt'}
  import dockingmt as dmt
  import molsysmt as msm
  import molsysviewer as msv
  import molsysviewer_dockingmt as addon
  import pyunitwizard as puw
  assert dmt.__version__==metadata.version('dockingmt')==artifact['version']
  assert json.loads(metadata.distribution('dockingmt').read_text('direct_url.json'))['archive_info']['hashes']['sha256']==artifact['wheel_sha256']
  for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']:
   module=__import__(name);assert Path(module.__file__).resolve().is_relative_to(root.parent/name/name)
  origins=check_installed_imports(roots,prefix,harness)
  forbidden=[]
  def blocked(*args,**kwargs):forbidden.append('real molecular/viewer operation');raise AssertionError('Installed record receiving attempted real molecular/viewer work')
  for name in ['get','select','extract','convert','copy','set']:setattr(msm,name,blocked)
  msv.MolSysView=blocked
  import importlib.abc
  class BlockEngines(importlib.abc.MetaPathFinder):
   def find_spec(self,fullname,path=None,target=None):
    if fullname.split('.')[0] in ['vina','rdkit','openmm']:forbidden.append(fullname);raise AssertionError('Installed record receiving imported an optional engine')
  sys.meta_path.insert(0,BlockEngines())
  if stage=='pilot':
   pose=dmt.DockingPose(puw.quantity([[0,0,0]],'angstrom'));result=dmt.DockingResult([pose]);assert dmt.DockingResult.from_dict(result.to_dict()).to_dict()==result.to_dict()
   code="""import json,sys,tomllib
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from devtools.scripts.installed_imports import check_installed_imports,runtime_import_roots
from devtools.scripts.noarch_conda import ContractError
mode=sys.argv[2];source=Path(sys.argv[3]);harness=Path(sys.argv[4]);inventory=tomllib.loads((harness/'devtools/conda-build/resources.toml').read_text());inventory['import_name']='dockingmt'
try:
 if mode=='omitted_addon':
  inventory['import_roots']=['dockingmt'];runtime_import_roots(inventory,'dockingmt')
 else:
  if mode in ['source_core','source_addon']:sys.path.insert(0,str(source))
  if mode=='source_addon':import molsysviewer_dockingmt
  else:
   import dockingmt
   if mode=='package_path':dockingmt.__path__.append(str(source/'dockingmt'))
  check_installed_imports(('dockingmt','molsysviewer_dockingmt'),Path(sys.prefix),harness)
except ContractError as exc:print(json.dumps({'mode':mode,'refused':True,'reason':str(exc)}))
else:raise AssertionError('Expected shared validator refusal')
"""
   refusals=[]
   for mode in ['source_core','source_addon','package_path','omitted_addon']:
    value=subprocess.run([py,'-B','-I','-c',code,str(sdk),mode,str(root),str(harness)],cwd=attempt,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    (attempt/(mode+'.stdout')).write_text(value.stdout);(attempt/(mode+'.stderr')).write_text(value.stderr)
    assert value.returncode==0,(mode,value.stderr[-1000:]);refusals.append(json.loads(value.stdout))
   receipt.update(refusals=refusals,positive_roundtrip=True)
  else:
   assert json.loads((task/'pilot-01/resource-outcome.json').read_text())['outcome']=='PASS'
   from devtools.scripts.installed_noarch import run_tests
   import pytest_receptor
   from pytest_receptor import read_artifact
   import xml.etree.ElementTree as ET
   units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if stage=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
   selection=json.loads((attempt/'frozen-selection.json').read_text());inventory['import_name']='dockingmt';inventory['installed_tests']['paths']=[n for n in selection if n.startswith('tests/')]
   inventory['installed_tests']['pytest_args']=['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'pytest-cache')]+[n for n in selection if n.startswith('--deselect=')]
   with puw.context(default_form='pint',standard_units=units):
    caller=puw.configure.report();status=run_tests(harness,inventory,support_output=attempt/'support-sidecar.json',support_context={'qualification_sha':source_commit})
    for key in ['default_form','default_parser','standard_units']:assert caller[key]==puw.configure.report()[key]
   counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
   events=read_artifact(attempt/'events.jsonl');assert events.complete
   receipt.update(pytest_exit_code=status,counts=counts,receptor_final=events.final.data,caller_policy=caller,support=json.loads((attempt/'support-sidecar.json').read_text()))
   if status:receipt['outcome']='FAIL'
  assert not forbidden;verify();receipt.update(version=artifact['version'],wheel_sha256=artifact['wheel_sha256'],installed_origins=check_installed_imports(roots,prefix,harness),molecular_calls_attempted=forbidden,sys_prefix=sys.prefix,sys_base_prefix=sys.base_prefix,source_free_harness=True)
assert cohort()==before
save(attempt/'cohort.json',before);save(attempt/'receipt.json',receipt)
if stage=='inspect':save(task/'cohort.json',before)
elif stage not in ['red_admin','green_admin','build']:assert before==json.loads((task/'cohort.json').read_text())
print(json.dumps({'stage':stage,'outcome':receipt['outcome'],'version':receipt.get('version'),'counts':receipt.get('counts')}))
raise SystemExit(0 if receipt['outcome']=='PASS' else 1)
