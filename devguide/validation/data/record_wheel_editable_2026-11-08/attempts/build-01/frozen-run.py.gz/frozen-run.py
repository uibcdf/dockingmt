"""Bound each private installed-receiving stage and preserve its original records."""
import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2];task=Path(__file__).parent
stage=sys.argv[1];assert stage in ['build','setup','pilot','normal','pm_fs']
suffix=sys.argv[2] if len(sys.argv)>2 else '01';attempt=task/(stage+'-'+suffix);attempt.mkdir(exist_ok=False)
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
estimate={'build':256,'setup':384,'pilot':512,'normal':512,'pm_fs':512}[stage]*1024**2
assert available()>policy['available_reserve_bytes']+estimate
sdk=root/'.molsyssuite/publication-sdk';assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45'
assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
for name in ['run.py','worker.py','selection.json','reporting-tools-receipt.json','unit-support-receipt.json']:shutil.copyfile(task/name,attempt/('frozen-'+name))
shutil.copyfile(guard,attempt/'frozen-guard.py');shutil.copyfile(root/'devguide/validation/record_wheel_editable_2026-11-08.md',attempt/'frozen-prescription.md')
if stage=='pm_fs':
 previous=task/'normal-01'
 assert json.loads((previous/'resource-outcome.json').read_text())['outcome']=='PASS'
 assert (previous/'frozen-worker.py').read_bytes()==(attempt/'frozen-worker.py').read_bytes()
 assert (previous/'frozen-selection.json').read_bytes()==(attempt/'frozen-selection.json').read_bytes()
registration={'stage':stage,'source_commit':'6310a97b7a900f31d37f84a476bc355a899282de','policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':estimate,'frozen_sha256':{p.name:sha(p) for p in attempt.iterdir() if p.is_file()},'sdk_sha256':{str(p.relative_to(sdk)):sha(p) for p in (sdk/'devtools/scripts').glob('*.py')},'scope':'Private installed record API with actual editable sibling sources; no scientific/public/Conda/matrix acceptance'}
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy();env.update(DMT_WHEEL_ROOT=str(root),DMT_WHEEL_TASK=str(task),DMT_WHEEL_ATTEMPT=str(attempt),DMT_WHEEL_STAGE=stage,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(attempt/'tmp'),XDG_CACHE_HOME=str(attempt/'cache'),MPLCONFIGDIR=str(attempt/'mpl'),MAKEFLAGS='-j1',CMAKE_BUILD_PARALLEL_LEVEL='1')
for name in ['tmp','cache','mpl']:(attempt/name).mkdir()
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:env[key]='1'
py=str(task/'receiver/bin/python') if stage in ['pilot','normal','pm_fs'] else sys.executable
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
 process=subprocess.Popen([py,'-B','-I',str(attempt/'frozen-worker.py')],cwd=attempt,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
 outcome=monitor(process,policy)
try:
 receipt=json.loads((attempt/'receipt.json').read_text());semantic=receipt['outcome']=='PASS' and receipt['qualification_complete']
except Exception as exc:semantic=False;outcome['qualification_diagnostic']=str(exc)
outcome['outcome']='PASS' if semantic and outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
if outcome['outcome']!='PASS':print((attempt/'stderr.log').read_text()[-2400:]);print((attempt/'stdout.log').read_text()[-1000:]);raise SystemExit(1)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['cohort','files_sha256','sdk_sha256','payload_sha256']}))
