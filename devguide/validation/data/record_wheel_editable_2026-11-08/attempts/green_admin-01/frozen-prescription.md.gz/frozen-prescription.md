# Installed record API on editable siblings — 2026-11-08

Owners: [#47](../pending_proposals/adopt_python_distribution_controls.md),
[#30](../pending_proposals/adopt_required_python_314.md); full plan #73.
Producer: `6310a97b7a900f31d37f84a476bc355a899282de`.
Status at registration: **unexecuted**, #47 comment 6731943957.

Build one genuine private development wheel from a clean owned local clone of
that exact commit, without changing the source checkout, shared environment or
existing private artifacts. Verify the 65 declared runtime paths, wheel RECORD,
source hashes, generated version, metadata and license. Install it normally in
an owned Python 3.14 venv borrowing the routine environment's editable siblings.
Reuse the exact published Receptor 1.2.2 and unyt 3.2.0/SymPy 1.14.0/mpmath 1.3.0
support; no network solve or provider build/refresh. Preserve the migration and
Viewer's 32-commit lag in the explicit offline workspace snapshot.

First require a positive installed-import/payload pilot and four fresh-process
refusals through unmodified shared SDK `95f693be`: actual source core, actual
source addon, contaminated package search path and omitted addon import root.
Then execute the fixed union of the previous restoration and input-resource
module selections: 19 complete modules, with the same one real-native pose-audit
test explicitly outside this offline scope. Do not add their overlapping counts.
Run normal before pm/fs, keeping tests, installed bytes, tools and provider source
inventories fixed. Retain every assertion and failed/interrupted attempt.

The shared installed runner owns import checks and unchanged 594-input support
staging/retirement; the full publication descriptor remains unchanged. Read saved
records and test provider doubles only. Block actual molecular operations, optional
engines and viewer construction. No preparation/search/scientific replay or canvas.

Each separately guarded stage uses CPU0/nice10/one native/build worker, monitored
13 GiB available reserve, 1 GiB group RSS, 2 GiB AS and CPU45/wall60 seconds.
Estimated build256 MiB/setup384 MiB/test512 MiB. Inspect headroom, load, swap and
pressure first; a free resource is not reserved. Run full profiles only after a
safe pilot. Preserve a resource interruption and never automatically restart it.
No Slurm allocation exists; prior applicability probing remains inconclusive.

Retain private wheel, venv, source-free harness, published test support and original
receipts under #47/#30/#50, review2026-11-14. Seal and independently read records
without tests or molecular replay. Run final documentation/resource/publication
checks including a fresh committed export. No remote/manual CI or package upload.
This can qualify only this private consumer wheel on Linux/Python3.14 with exact
editable siblings, not public dependency closure, the full installed/scientific
suite, Conda delivery or all platforms/minors. Preserve #256's original H5MSM gate,
#558 maps/history and #52/#60 scheduling. No public release/version is selected.


## Declaration correction amendment — before further receiving

The single build completes, but its exact payload gate fails: 66 runtime files
versus 65 required paths. Only the already-shipped `dockingmt/interactions.py`
is undeclared. #93 owns the one-line resource correction and existing complete-
coverage distribution guard; no new regression or runtime change is needed.
Keep wheel `0.0.0+339.g6310a97`, SHA-256
`13169bd91cc90a16bd3b8f60329856ee2cb1921a0dd69ebb598230f543e6fa92`.
Do not rebuild it. Inspect/install these same original-producer bytes against a
separately frozen corrected 66-path qualification descriptor. Test/runtime source
stays at `6310a97`; only the qualification descriptor changes in the source-free
harness. All 594 support inputs and the fixed 19-module selection remain exact.
Normalize equivalent Python version specifier ordering in metadata inspection;
never change the supported range. Preserve the original gate failure and the
zero-test initial relative-selector usage failure. Execute the corrected original
guard, full distribution controls, original-wheel inspection, then pilot/profiles.
