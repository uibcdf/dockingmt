# Source-free installed 1IEP replay — 2026-11-07

Owner: [DockingMT #83](../pending_proposals/qualify_independent_installed_reproduction.md).
Registered before execution. Initial outcome: **unexecuted**.

## Source admission and actual retained inputs

The existing `dmt_test_support.validate_1iep_pdbqt._source_revision` assumes its
staging parent contains both the runtime package and a Git checkout. It therefore
cannot identify the actually imported installed core. Reuse the already received
`redocking_181l` attribution for imported runtime/helper bytes and optional shared
Git identity, extending its digest with the two actual 1IEP helper files. Add no
new generic loader, molecular algorithm, source spoofing or replay-version policy.
Keep the strict recorded-source, software-version, protocol, input/map and result
comparisons. Update the exact changed helper SHA in the installed-support
declaration. The support namespace remains outside the runtime wheel.

Before native execution, qualify relocation without Git, stable identity across
equivalent installations and changed identity for either 1IEP helper. Use the
existing 1IEP replay, generic replay/benchmark attribution and installed-support
controls under `pytest --receptor=llm`, with complete native pytest/JUnit evidence.
Source selection: `tests/test_1iep_replay.py`,
`tests/test_result_export_benchmark.py` and
`devtools/tests/test_installed_support.py`. The separate 181L native replay module
is not in this source-only selection. Source tests may import providers but forbid
molecular operations and Vina import.
Record their actual complete selection and preserve any failed attempt.

The current checkout/support declaration retains the pinned original SDF and
PDBQT bytes plus the old #16 narrative, not the two September #16 result manifests.
Bounded inspection of tracked 1IEP paths, the migration manifest and four complete
later 1IEP audit archives does not locate those exact `benchmark_source`/
`benchmark_source_revision` records. Later flexibility/representation/conformer
results are other populations and cannot replace them. Do not claim recovered
September records or create them from the narrative. The migration is read-only
and remains untouched/untracked.

## New measured producer and independent receivers

Register a separately identified current producer of the same pinned reference/
displaced-box recipe, then receive those complete stored manifests independently.
This creates new observations with their actual producer; historical #16 and its
reported values remain unchanged and are not retrospectively requalified.
The E5 target remains the whole representative workflow, including both controls,
strict attribution/inputs/protocol/population/numeric comparisons and explicit
missing information. Software repetition is not a new independent complex.

After source qualification and exact support/candidate admission, the finite
selection permits **six native searches total**: two for a fresh normal-policy
producer, two for a fresh normal receiving installation, then two for a fresh
pm/fs receiving installation. Complete normal receiving must pass before pm/fs.
All processes use the same exact consumer wheel, scientific provider/native
bytes and qualified helper bytes. Freeze their exact artifacts, source identity,
inputs, direct/nested call caps, workers and stage registrations before launch.
Any additional scientific call requires a separate prospective registration.

Use unchanged consumer source `2ef82d2`, wheel `0.0.0+310.g2ef82d2`, SHA-256
`6db76835f4f3f9c41d06a163cb3a4fbc9e780597bfd89d2fc6a75d29cff31133`,
with the already qualified MolSysMT `9e1f1b1` composition and Vina1.2.7. Inspect
and verify actual provider/Vina payloads and loaded native origins before use.
This is independent of held newer-provider #642 construction: do not restart
that build or mix/relabel its sources/binaries. No public-artifact/platform or
whole-environment compatibility claim follows from the private composition.

Stage helpers/data using MolSysSuite's declared `staged_support` mechanism from
clean source inputs without a runtime package. Keep source roots/editable finders
out of receiving imports, check actual runtime/support origins before/after and
retire every owned support namespace/resource. Producer input staging and live
objects must be gone before replay; receivers get only complete saved manifests,
not original source paths, generated molecular objects or comparison JSON as a
restoration input. Preserve complete original/new records, captured byte hashes,
old producer and new receiving identities and routine Conda/source nonmutation.

Use the existing pinned recipe unchanged: upstream
`3c65c0b3e6c2c1d183f6a175ecb65e3c5ba91645`, original receptor/ligand/SDF hashes,
reference box center `[15.190,53.903,16.917]` angstrom and size `[20,20,20]`,
control offset `[30,0,0]` angstrom, Vina scoring `vina`, seed42, cpu1,
exhaustiveness1, five requested poses and captured backend inputs. Source69 atoms/
73 bonds, retained40 atoms/37 heavy atoms and a verified case-specific source map
retain their actual acceptance checks. External preparation remains unassessed.
No H/charge/type assignment, preparation-model change, new scoring/ranking rule,
alignment, scientific-case substitution or tolerance adjustment is permitted.

Keep original tolerances: maximum score drift0.05 kcal/mol; pose-coordinate and
source-reference positional RMSD drift0.25 angstrom; near-native cutoff2.5
angstrom. The reference must retain at least one near-native pose and displaced
control none. All poses, ranks/IDs/state/metadata/score names, native input/box,
source/protocol/software identity and recorded classification must agree under
the existing strict replayer. Existing unshipped case-specific analytic comparison
controls retain their #49 scope; no new molecular matcher/metric is introduced.

Before search, receive missing/corrupt captured bytes, false source maps and
changed protocol/source/version controls with actionable errors and zero native
search where required. Freeze the complete adverse matrix before execution;
existing source tests alone do not establish installed/native refusal behavior.

## Resources and evidence

Run scientific/source cells serially, CPU0/nice10, one native/build worker,
8 GiB available-RAM reserve, 1 GiB group RSS, 2 GiB address space, 45 CPU/60 wall
seconds. Reuse frozen #173 guard functions SHA-256
`3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d`.
Apply limits to descendants and stop owned work if the reserve/group bound is
threatened. Preserve interruptions and no automatic heavy restart after headroom
stop. Partial semantic completion or exit zero alone is not a pass.

Task `.molsyssuite/e5-replay-20261107` retains registrations, frozen inputs/tools,
candidate/support prefixes, all attempts and native/pytest records under #50,
review2026-11-14. Seal original records and a detached independent reader without
scientific replay. Update the owning issue/checkpoints after each increment.
No manual CI; #28 exact-head hosted evidence remains missing under `[skip ci]`.
Actual browser/comm/canvas, E3 #604, #642 client receiving, wider scientific-panel,
public/minor/platform delivery and full Core/Extended #73 remain unproven.
