# Installed live-engine reader controls — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with the
public molecular boundary #49 and complete functional plan #73. Status: registered;
native pilot pending. Execution base `697d75442a174e5d4632c85c0c1532550164c06d`.

## Question and exact software inputs

Receive the previously excluded live-engine controls from the actual installed
consumer, first one small rigid case, then bounded whole selections if measured
resource use permits. This is finite synthetic software integration, not a new
biological docking, accuracy, ranking or performance study. Preserve all original
fixture bodies, seeds, numerical assertions, methods and producer identities.

Reuse the genuine normally installed wheel from producer
`aeae47d50c5e90687c2558437cb22cf8f271ce85`, version `0.0.0+351.gaeae47d`,157821B,
SHA256 `0b303ae371466a6736e8d194a89a54048f8bc51de3cd293cdc68c06050ae042b`.
Its original receiver, independently anchored source-free aeae47d test root,
private reporting/unit support,67-path payload and606 declared support records
remain in `installed-reconstruction-20261109`. No reinstall, rebuild or new wheel.
Shared test staging/retirement remains SDK95f693be; source checks use SDK738fe8dd.
The fixed six-provider cohort is the received MolSysMT0c6f9c7/Viewer1187fc18/
ArgDigest07126411/PyUnitWizardf82b618e/SMonitorc1b6ce29/DepDigest032d345b set.
Record exact source/native hashes separately from stale distribution labels.

Use the retained103-file original engine prefix at
`.molsyssuite/e5-timed-replay-20261107/layouts-admission-01/producer/engine`.
Verify its immutable bytes before/after each cell; reject absent/shadowed or
unexecuted engines. The old administrative byte receipt does not recover failed
historical process mappings. This new population must record actual engine version,
import origin, native call liveness and its own final loaded-library hashes.
No native build is started or restarted. Existing build/canvas holds stay separate.

## Small fixture and call admission

The original MINIMAL_REC_PDBQT has four synthetic atom records; CO and hexane
controls retain their existing deterministic fixture construction, charge/type
methods and projection inputs. No large receptor or target-specific preparation is
admitted. Backend input snapshots preserve submitted bytes/hashes and atom counts.
Worker limits reject more than12 partner atoms, more than4 receptor records or
more than64KiB per input. Grid center is the origin; every box side is at most16
angstrom. All original tests use CPU1,exhaustiveness1 and one/two requested poses.
The unchanged native default max_evals0 remains bounded by external process limits.

Native method wrappers use functools.wraps, preserve signatures/arguments/results
and delegate to the real engine. They record attempted/completed calls, CPU/seed/
box/search parameters, elapsed operation times, submitted input bytes and returned
pose text. These timings diagnose resource requirements, not comparative speed.
Direct score/optimize/randomize and viewer construction remain refused. Native
internal calculations inside the actual dock method remain the original engine.
Public provider readers and original failure controls must execute as declared;
no monkeypatched result, alternate parser or softened assertion may replace them.

## Ordered selections and denominators

1. Pilot: the actual frozen collected node
   `test_production_reader_uses_actual_export_once_and_preserves_written_axis[angstrom-False]`
   in `test_prepared_pose_reading.py`, one case, no exclusions. It covers one real
   rigid input/export/search/public-reader path with seed321 and two requested poses.
2. After measured admission, receive the whole `test_prepared_pose_reading.py`
   selection normal then pm/fs: expected15 cases, no exclusions, including the
   previously excluded nine live-engine cases and six staged-only cases. Expected
   nine actual constructor/dock calls per cell. Preserve original handled provider
   errors and staged-file cleanup assertions.
3. Receive the two original parameter cases of
   `test_known_source_pose_consumption.py::test_real_dockingmt_vina_output_matches_native_pose_reader`
   under normal and pm/fs. The seed14 hexane control independently rereads actual
   engine output on the source axis and retains its original tolerances, map/
   payload hashes and source snapshots. Save its original receiving.json and poses.

Keep each entire selected function/module and both caller policies independently
identified; the pilot overlaps later module coverage. No pytest skip, warning filter
or assertion/source/input edit is introduced. A passing pytest report in a failed
process or altered-input cell is unqualified. Do not infer full scientific/native/
platform acceptance from these finite controls.

## Shared-resource policy and retention

Shared host:64,978,440,192B physical RAM,20 logical CPUs; initial available
60,628,234,240B, load0.57/0.40/0.31,95% interval CPU idle, no active swap I/O and
zero memory PSI. Slurm commands exist but there is no allocation; earlier scheduler
applicability probing was inconclusive. Free capacity is not reserved.

Pilot runs on CPU0,nice10,one native/build worker,13GiB available reserve,1GiB
owned-group RSS,2GiB address space,60 soft/65 hard CPU seconds and180 wall seconds;
expected peak512MiB. Check headroom for every cell and monitor only owned groups.
Use pilot measurements to register any necessary bounded whole-selection budget
before increasing work. Preserve failures/interruption and never automatically
restart after a headroom stop. Other users' jobs and interactive access have priority.

Retain task-local programs, registrations, original output/warnings, constructor/
method and input/output observations, exact source/artifact/native identities and
independent stored-evidence reading under
`.molsyssuite/installed-live-reader-20261110`, owners#47/#49/#50, review2026-11-14.
Retain original engine/receiver/harness/SDK roots; managed shared test support retires
per cell. Original scientific outputs remain under their original producers. Full
#47/#30/#73, public Conda/closure/eight installed OS-minor cells, SSH #100 under
MolSysSuite #178, hosted #21/#28 and actual browser/canvas/comm/kernel evidence
remain separate. CI pins and prior fixed candidates stay unchanged. No remote CI,
new dataset/accuracy case, public package or shared environment mutation follows.
