import numpy as np

from molsysmt._private.smonitor import ArgumentError


def digest_component_type(component_type, caller=None):
    """Checks if `component_type` has the expected type and value.

    Parameters
    ----------
    component_type : Any
        The `component_type` argument for digestion.
    caller: str, optional
        Name of the function or method that is being digested.

    .. _PEP 484:
        https://www.python.org/dev/peps/pep-0484/#the-any-type

    Returns
    -------
    bool
        Either True or False when caller is `get`.

    Raises
    -------
    ArgumentError
        If the given `component_type` has not of the correct type or value.
    """

    if caller == "molsysmt.basic.set.set" or (
        isinstance(caller, str)
        and caller.startswith(
            (
                "molsysmt.form.molsysmt_ChemicalStates.set.",
                "molsysmt.form.molsysmt_ChemicalStatesDict.set.",
            )
        )
    ):
        from molsysmt.native._chemical_component_values import normalize_assignment

        return normalize_assignment("component_type", component_type, caller)

    if caller in ("molsysmt.basic.get.get", "molsysmt.basic.compare.compare"):
        if isinstance(component_type, bool):
            return component_type
    elif (
        isinstance(caller, str)
        and caller.startswith("molsysmt.form.")
        and caller.count(".to_") == 2
    ):
        return component_type

    if isinstance(component_type, str):
        return component_type

    elif isinstance(component_type, list):
        return component_type

    elif isinstance(component_type, tuple):
        return list(component_type)

    elif isinstance(component_type, np.ndarray):
        return component_type.tolist()

    raise ArgumentError(
        "component_type", value=component_type, caller=caller, message=None
    )
