"""Bounded public metadata/source-object inspection; no build or package import."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib
import urllib.request

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def save(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
source = root.parent / 'molsysmt'
before = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain', '--untracked-files=no'])
source_head = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert source_head == '9e1f1b1ad8bf09446374ab6f04ca7208e2717936' and not before
registry = {'url': 'https://api.anaconda.org/package/uibcdf/molsysmt', 'status': 'UNAVAILABLE'}
try:
    with urllib.request.urlopen(registry['url'], timeout=20) as response:
        assert response.status == 200
        data = bytearray()
        while chunk := response.read(65536):
            data.extend(chunk)
            assert len(data) <= 16 * 1024**2
        registry.update(headers={k: response.headers.get(k) for k in ['ETag', 'Last-Modified', 'Date']})
    raw = bytes(data)
    (attempt / 'registry-response.json').write_bytes(raw)
    payload = json.loads(raw)
    rows = []
    for item in payload.get('files', []):
        attrs = item.get('attrs', {})
        rows.append({'basename': item.get('basename'), 'version': item.get('version'), 'sha256': item.get('sha256'), 'size': item.get('size'), 'upload_time': item.get('upload_time'), 'labels': item.get('labels'), 'subdir': attrs.get('subdir'), 'build': attrs.get('build'), 'depends': attrs.get('depends'), 'source_git_url': attrs.get('source_git_url'), 'source_git_rev': attrs.get('source_git_rev')})
    registry.update(status='AVAILABLE', response_sha256=hashlib.sha256(raw).hexdigest(), response_bytes=len(raw), latest_version=payload.get('latest_version'), versions=payload.get('versions'), files=rows)
except Exception as error:
    registry.update(exception_type=type(error).__name__, message=str(error), scope='Failed bounded observation, not proof of artifact absence')
save('registry-inventory.json', registry)
objects = task / 'source-objects.git'
assert not objects.exists()
commands = []
def run(args, *, capture=False):
    commands.append(args)
    result = subprocess.run(args, check=True, capture_output=capture, text=True, timeout=25)
    return result.stdout.strip() if capture else None
run(['git', '-c', 'gc.auto=0', 'clone', '--shared', '--bare', str(source), str(objects)])
run(['git', '-C', str(objects), 'remote', 'add', 'upstream', 'https://github.com/uibcdf/molsysmt.git'])
target = 'ad67e0e915ba23d90cb9d6331c063c342852d67a'
run(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', 'pack.threads=1', '-c', 'fetch.parallel=1', '-C', str(objects), 'fetch', '--no-tags', '--filter=blob:none', 'upstream', target])
def git(*args):
    return run(['git', '-C', str(objects), *args], capture=True)
revisions = {'old_native': source_head, 'old_python': 'faab727ca5b5c9078e2f2e505971fc0ea1cf1a8d', 'catalog_fix': '4d8af6c34cb6b3f9e22833771b246d8767ef85e9', 'formal_charge_fix': '64f8c955ac8b93198f4926642d4f3d257a1d0c27', 'comparison_fix': target}
review = {'target': target, 'revisions': {}, 'contains_fixes': {}, 'scope': 'Immutable Git source/build-input inspection only; no native binary, wheel or client scientific receiving'}
for label, commit in revisions.items():
    project = tomllib.loads(git('show', commit + ':pyproject.toml'))
    review['revisions'][label] = {'commit': commit, 'rust_tree': git('rev-parse', commit + ':rust'), 'build-system': project['build-system'], 'setuptools-rust': project['tool']['setuptools-rust'], 'distutils': project['tool']['distutils']}
for name in ['catalog_fix', 'formal_charge_fix']:
    result = subprocess.run(['git', '-C', str(objects), 'merge-base', '--is-ancestor', revisions[name], target], check=False, timeout=10)
    assert result.returncode in (0, 1)
    review['contains_fixes'][name] = result.returncode == 0
for relative in ['molsysmt/_private/argdigest/argument/component_type.py', 'molsysmt/_private/argdigest/argument/formal_charge.py', 'molsysmt/basic/compare.py']:
    raw = subprocess.check_output(['git', '-C', str(objects), 'show', target + ':' + relative], timeout=20)
    filename = 'target-' + relative.replace('/', '__')
    (attempt / filename).write_bytes(raw)
    review.setdefault('target_files', {})[relative] = {'git_blob': git('rev-parse', target + ':' + relative), 'sha256': hashlib.sha256(raw).hexdigest(), 'retained_as': filename}
save('source-review.json', review)
save('source-commands.json', commands)
assert subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain', '--untracked-files=no']) == before
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == source_head
assert not any(name.split('.')[0] in {'molsysmt', 'dockingmt', 'rdkit', 'vina', 'numpy', 'pyunitwizard'} for name in sys.modules)
save('receipt.json', {'source_commit': 'acce58e3dc0ff17673f091b42765fb65257b8977', 'stage': 'inventory', 'outcome': 'PASS', 'qualification_complete': True, 'at_utc': datetime.now(timezone.utc).isoformat(), 'registry_status': registry['status'], 'advertised_files': len(registry.get('files', [])), 'target_source': target, 'contains_fixes': review['contains_fixes'], 'scientific_imports': [], 'native_builds': 0, 'environment_installs': 0, 'molecular_operations': 0, 'old_checkout_unchanged': True, 'source_receiving_only': True})
