"""Seal and independently read finite actual-engine software controls."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/installed-execution-boundaries-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/installed_execution_boundaries_2026-11-10';companion=root/'devguide/validation/data/installed_execution_boundaries_reader_2026-11-10'
qualified=['dockingmt/batch.py','dockingmt/core/outcome.py','dockingmt/engines/base.py','dockingmt/engines/vina.py','dockingmt/engines/_vina_scoring.py','dockingmt/dock.py','dockingmt/core/results.py','tests/test_batch.py','tests/test_backend_contracts.py','tests/test_vina_staging_lifecycle.py']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_execution_boundaries@1','owner':'uibcdf/dockingmt#47','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'qualification_base':'958f16a15ebaaef8c641a6c77924d3b55de92456','runtime_producer':'aeae47d50c5e90687c2558437cb22cf8f271ce85','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored actual-engine software evidence; zero native/molecular replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 for name in qualified:paths.append((root/name,'qualified/'+name))
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 artifact=d('producer/artifact.json');assert artifact['source_commit']=='aeae47d50c5e90687c2558437cb22cf8f271ce85' and artifact['wheel_sha256']=='0b303ae371466a6736e8d194a89a54048f8bc51de3cd293cdc68c06050ae042b' and artifact['runtime_paths']==67
 cohort=d('producer/expected-cohort.json');assert cohort['molsysmt']['commit']=='0c6f9c746dbd10b02dfe8474a5af280b857ace0d';baseline=d('attempts/pilot-normal-01/support-sidecar.json')['files'];assert len(baseline)==606
 refs=d('producer/reference-fixtures.json');measured={};total_native=0
 ledger=d('producer/execution-ledger.json');assert ledger['expected_cases_per_policy']==98 and ledger['prior_offline_batch_count']==38 and len(ledger['modules'])==3 and len(ledger['modules'][0]['prior_offline_exclusions'])==3
 assert [r['original_collected_count'] for r in ledger['modules']]==[41,38,19]
 for row in ledger['modules']:assert row['test_source_sha256']==d('producer/qualification-inputs.json')[row['module']]
 for label,count,deselected,runs in [('pilot-normal-01',1,40,2),('batch-normal-01',41,0,10),('batch-pm-fs-01',41,0,10),('controls-normal-01',57,0,0),('controls-pm-fs-01',57,0,0)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['counts']=={'tests':count,'failures':0,'errors':0,'skipped':0} and row['pytest_exit_code']==0 and row['warnings']==0 and not row['forbidden_operations'] and row['cohort_unchanged'] and row['deliberate_stubs_are_not_native_calls']
  counts=row['engine_call_counts'];assert counts.get('__init__',0)==counts.get('dock',0)==runs and not any(counts.get(n,0) for n in ['score','optimize','randomize'])
  assert row['receptor_final']['counts']['deselected']==deselected and row['wheel_sha256']==artifact['wheel_sha256'] and row['actual_engine_version']=='1.2.7' and d(prefix+'cohort.json')==cohort
  support=d(prefix+'support-sidecar.json');assert support['files']==baseline and support['executed_tests']==count and support['imports_retired'] and support['resources_retired']
  calls=row['engine_calls'];assert all(c['outcome']=='PASS' for c in calls)
  if runs:assert calls==d(prefix+'engine-calls.json')
  groups={}
  for call in calls:
   params=call['parameters'];node=call['test_node'];assert any(n in node for n in ['test_native_batch_matches_individual_seeded_docking','test_native_missing_file_failure_does_not_contaminate_next_execution'])
   if call['call']=='__init__':assert params['cpu']==1 and params['sf_name'] in ['vina','vinardo'] and params['seed']==123
   if call['call']=='compute_vina_maps':assert params['center']==[0.0]*3 and params['box_size']==[10.0]*3
   if call['call']=='dock':
    assert params['exhaustiveness']==1 and 1<=params['n_poses']<=2;groups[node]=groups.get(node,0)+1
   for role in ['receptor','partner']:
    if role not in call:continue
    info=call[role];blob=data[prefix+'inputs/backend/'+str(call['run'])+'/'+role+'.pdbqt'];assert len(blob)==info['bytes'] and hashlib.sha256(blob).hexdigest()==info['sha256']
    assert sum(line.startswith((b'ATOM  ',b'HETATM')) for line in blob.splitlines())==info['atom_records']==(4 if role=='receptor' else 2)
    assert info['sha256']==refs['MINIMAL_REC_PDBQT' if role=='receptor' else 'MINIMAL_LIG_PDBQT']['sha256']
  if runs:
   assert sorted(groups.values())==([2] if label.startswith('pilot') else [2,4,4])
   maps=d(prefix+'native-maps.json');engine=d(prefix+'frozen-engine-receipt.json')['paths'];native='lib/python3.14/site-packages/vina/_vina_wrapper.cpython-314-x86_64-linux-gnu.so';assert [digest for path,digest in maps.items() if path.endswith('/'+native)]==[engine[native]]
   exports=d(prefix+'exports.json');assert exports==row['exports'] and len(exports)>0;comparisons={};isolation={};outcomes={}
   for export in exports:
    raw=data[prefix+export['file']];assert hashlib.sha256(raw).hexdigest()==export['sha256'];record=__import__('json').loads(raw);node=export['test_node']
    if export['kind']=='outcome':
     assert record['status']=='success' and record['error'] is None and record['index'] in [0,1];outcomes.setdefault((node,record['index']),[]).append(record)
    else:
     label_id=record['problem_info']['metadata']['ligand_id']
     if 'test_native_batch_matches_individual_seeded_docking' in node:
      record['provenance'].pop('elapsed_seconds');staged=record['provenance']['backend_output']['engine_info'].pop('rigid_receptor');assert isinstance(staged,str)
      comparisons.setdefault((node,label_id),[]).append(record)
     else:isolation.setdefault(label_id,[]).append(record)
   if not label.startswith('pilot'):
    assert len(comparisons)==4 and len(outcomes)==4 and sum(map(len,outcomes.values()))==12
    for records in outcomes.values():assert len(records)==3 and all(r==records[0] for r in records)
    for records in comparisons.values():assert len(records)>=2 and all(r==records[0] for r in records)
   assert set(isolation)=={'first','third'}
   for records in isolation.values():assert records
   first=isolation['first'][0]['poses'][0];third=isolation['third'][0]['poses'][0];assert first['scores']==third['scores'] and first['coordinates']==third['coordinates']
  else:assert not calls and not row['exports'] and row['provider_call_counts']=={}
  total_native+=runs;measured[label]={'cases':count,'deselected':deselected,'native_constructor_and_search_calls':runs,'warnings':0}
 assert total_native==22
 for selection in ['batch','controls']:assert data['attempts/'+selection+'-normal-01/frozen-worker.py']==data['attempts/'+selection+'-pm-fs-01/frozen-worker.py']
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   r=json.loads(raw);assert r['outcome']=='PASS' and r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids'] and r['minimum_available_bytes']>13*1024**3
 for name in qualified:
  raw=data['qualified/'+name];assert (root/name).read_bytes()==raw
  if name.startswith('dockingmt/'):assert hashlib.sha256(raw).hexdigest()==artifact['payload_sha256'][name]
  else:assert hashlib.sha256(raw).hexdigest()==d('producer/qualification-inputs.json')[name]
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),populations=measured,qualified_sources=10,support_records=606,actual_native_searches=total_native,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json']);path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete and row['counts']==counts and row['receptor_final']==events.final.data
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':row['pytest_exit_code'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==5 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1600])
