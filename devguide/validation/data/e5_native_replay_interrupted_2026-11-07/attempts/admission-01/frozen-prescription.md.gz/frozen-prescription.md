# Whole installed 1IEP producer/replay receiving — 2026-11-07

Owner: [DockingMT #83](../pending_proposals/qualify_independent_installed_reproduction.md).
Registered before execution. Initial outcome: **unexecuted**.
Prerequisite: [source and installed attribution](e5_installed_replay_2026-11-07.md)
published at `08324fe2f72ee8afb5be3874700fc789c374aee8`.

## Exact installations and retained inputs

Admit unchanged consumer `2ef82d2`, wheel `0.0.0+310.g2ef82d2`, SHA-256
`6db76835f4f3f9c41d06a163cb3a4fbc9e780597bfd89d2fc6a75d29cff31133`,
75 consumer files/3794 qualified provider files/MolSysMT `9e1f1b1` and the
641-file Viewer `78ede79e` overlay. Bind the existing candidate receipt to its
immutable 342-member archive copy before byte transport. Vina is absent from
the routine Python installation; use the existing qualified 103-path Vina1.2.7/
Boost1.86 overlay, whose two Conda metadata records and every payload digest
match the immutable E2 native registration. Do not solve/install into Conda,
build native code, change providers/pins or resume held #642 construction.

Make three independent byte copies of runtime/provider/Viewer/engine prefixes:
producer, normal receiver and pm/fs receiver. Verify every byte, original source
custody and distinct inode/path for actual Python/native runtime files. Use
`-B -I -S`, no editable finder/source import root, exact SDK95f693be and a
process-local engine-library path. Record all loaded Python/native origins,
including the actual relocated Vina/Boost libraries. Reused routine libraries
and metadata remain explicit; this is no public/environment/platform closure.

Export only the594 declared support source inputs from exact helper commit
08324fe into an owner tree without runtime packages/Git. Use the shared
`staged_support` mechanism; all30 helper and564 historical data targets retain
their declared hashes. The source-free code identity must remain
`2612b3e060b95a2e4a8f98ea2ddaad0eeac01057c10c34580f90b5a525e0bf46`.
Keep owned support temporary resources/imports retired on success or failure.
The producer's original staged input paths must be absent before receiving.
During scientific replay, deny reads of original checkout inputs and staged
non-code support fixtures; only captured manifest bytes may restore inputs.
Bookkeeping validation may read declared support bytes outside that operation.

## Population and native budget

Use the unchanged public 1IEP SDF/receptor/ligand hashes, 69-source/73-bond graph,
40-retained/37-heavy map, fixed reference/control boxes, Vina1.2.7/scoring `vina`,
seed42/cpu1/exhaustiveness1/five requested poses, captured inputs and existing
strict helper comparisons. External preparation remains unassessed. No missing
September manifest is manufactured; this is a new measured producer of the
same pinned recipe, followed by whole replay of its actual retained records.

The complete native budget remains **six searches**, with at most two public
DockingMT dock calls, Vina initializations, receptor/ligand loads, grid creations
and native `dock` entries per successful producer/receiver cell. Run producer2,
then normal2; pm/fs2 requires a complete passing normal receiver and identical
candidate/worker/SDK bytes. Source-free admission/adverse/reader cells permit
zero native searches. Register any additional scientific call before execution.

Observe real method calls without replacing scientific returns. Per scientific
cell cap Vina `poses`4/`energies`2/`info`8; no explicit score/optimize/randomize,
weights changes or map loading. Keep nested provider caps convert128/copy64/
get1024/get_form512/has_attribute512/select128 and actual getter/copy/reader
counts. Forbid H/charge/type assignment, new preparation, alignment, transforms,
detectors, RMSD/distance kernels, scoring/ranking APIs and View/kernel/browser
creation. Existing unshipped case-specific analytic map/comparison controls keep
their admitted #49 scope; no molecular algorithm is added or generalized.

Capture complete new DockingResults from each unchanged real `dmt.dock` return,
all score descriptors/history/input/source/protocol/native metadata, helper
reports and original result nonmutation. Pose counts/values come from this
producer, not the old narrative. Require source/protocol/versions/input/box/
pose identity and every old numerical comparison unchanged: score drift≤0.05
kcal/mol, coordinate/reference RMSD drift≤0.25 angstrom, cutoff2.5 angstrom.
Reference must have at least one near-native pose and displaced control none.
Caller units enter before sibling imports, are preserved, and restore afterwards.

## Complete adverse matrix before receiver search

Use detached copies of the new producer's complete pair. Run each through the
existing replayer with native entry forbidden and require its actual diagnostic:
missing manifest; missing backend artifacts; missing SDF bytes; corrupt SDF;
corrupt captured receptor; corrupt captured partner; one-sided false source map;
same false map in both records; changed protocol in both protocol fields;
changed source-code identity in both records; changed reference domain; false
recorded source-file fingerprint. Original pair must remain byte-identical.
Map/domain controls may use the existing source conversion/getter path; all
controls require zero native initialization/grid/search. Register exact changed
fields and expected exception/message before that cell.

Software-version drift is the existing post-run `_compare_run` contract: after
an actual passing replay, use the unchanged comparison helper on a detached
version-altered record and real retained receiving result, requiring
`versions_match=False` and `within_tolerance=False`, with no further dock call.
Do not falsely claim that this replayer checks versions before search. Freeze
the three version fields, invocation/metric caps and physical references first.

## Resources, custody and limits

Every cell runs serially at CPU0/nice10, one native/build worker, with8 GiB
available-RAM reserve,1 GiB owned-group RSS,2 GiB address space,45 CPU seconds/
60 wall seconds. Reuse frozen #173 guard functions SHA-256
`3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d`.
Monitor descendants and preserve interruptions. Do not automatically restart
heavy work after headroom interruption. No partial semantic result is a pass.

Task `.molsyssuite/e5-native-replay-20261107`, #50/review2026-11-14, retains all
layouts, source/support/native input identities, workers, counters, warnings,
raw logs and failed/passing terminal receipts. Seal complete evidence and verify
records independently without new scientific replay. Preserve earlier source/
metadata archives and every historical scientific producer. Update devguide,
#83 and the complete-plan checkpoint after each increment. No manual CI; #28
exact-head hosted evidence stays missing under `[skip ci]`. #642 construction,
E3 #604 and live browser/comm/canvas holds remain. Full #73/Core/Extended,
independent scientific panel and public/minor/platform delivery remain unproven.
