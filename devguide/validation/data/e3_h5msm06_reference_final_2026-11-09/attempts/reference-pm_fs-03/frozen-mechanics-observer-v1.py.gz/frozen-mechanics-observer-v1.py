"""Read-only evidence for this reference selection; not a molecular codec."""
import math
import pandas as pd


def observed_value(value, path):
    if value is None:
        return {'kind': 'none'}
    if value is pd.NA:
        return {'kind': 'pandas.NA'}
    if isinstance(value, dict):
        assert all(isinstance(key, str) for key in value)
        return {key: observed_value(item, path + '/' + key) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return {'kind': type(value).__name__, 'items': [observed_value(item, path + '/' + str(i)) for i, item in enumerate(value)]}
    if puw.is_quantity(value):
        field = 'e3.mechanics.' + path
        unit = str(puw.get_unit(value))
        record = puw.QuantityRecord.from_quantity(value, field=field).to_dict()
        recovered = puw.QuantityRecord.from_dict(record).to_quantity(field=field, unit=unit)
        expected = np.asarray(puw.get_value(value, to_unit=unit))
        actual = np.asarray(puw.get_value(recovered, to_unit=unit))
        assert actual.dtype == expected.dtype and actual.shape == expected.shape
        np.testing.assert_array_equal(actual, expected)
        return {'kind': 'quantity', 'field': field, 'original_unit': unit, 'record': record}
    if isinstance(value, np.ndarray):
        return {'kind': 'ndarray', 'dtype': str(value.dtype), 'shape': list(value.shape), 'items': observed_value(value.tolist(), path)}
    if isinstance(value, np.generic):
        return {'kind': 'numpy_scalar', 'dtype': str(value.dtype), 'value': observed_value(value.item(), path)}
    if type(value) is float:
        return {'kind': 'float', 'hex': value.hex()}
    if type(value) in (bool, int, str):
        return {'kind': type(value).__name__, 'value': value}
    raise TypeError('Unobserved mechanical evidence type: ' + type(value).__name__)


def mechanics_witness(mechanics):
    if mechanics is None:
        return {'schema': 'dockingmt.e3_mechanics_observation@1', 'present': False}
    table = mechanics.atoms_ff
    frame = None if table is None else {
        'columns': observed_value(list(table.columns), 'atoms_ff/columns'),
        'index': observed_value(table.index.to_numpy(), 'atoms_ff/index'),
        'index_names': observed_value(list(table.index.names), 'atoms_ff/index_names'),
        'dtypes': [str(dtype) for dtype in table.dtypes],
        'values': observed_value(table.to_numpy(dtype=object), 'atoms_ff/values'),
    }
    return {
        'schema': 'dockingmt.e3_mechanics_observation@1',
        'present': True,
        'parameters': observed_value(mechanics.to_dict(), 'parameters'),
        'atoms_ff': frame,
        'partial_charge_assignment': observed_value(mechanics.partial_charge_assignment, 'partial_charge_assignment'),
        'atom_type_assignment': observed_value(mechanics.atom_type_assignment, 'atom_type_assignment'),
        'native_partial_charge_unit': 'elementary_charge',
    }


def mechanical_adverse_controls(mechanics):
    assert mechanics.partial_charge_assignment is not None
    assert mechanics.atom_type_assignment is not None
    assert mechanics.atoms_ff is not None and len(mechanics.atoms_ff) == 25
    expected = mechanics_witness(mechanics)
    received = []
    for field in ['partial_charge_assignment', 'atom_type_assignment']:
        changed = call('mechanical_copy', mechanics.copy)
        setattr(changed, field, None)
        assert mechanics_witness(changed) != expected
        assert mechanics_witness(mechanics) == expected
        received.append('missing_' + field)
    changed = call('mechanical_copy', mechanics.copy)
    column = changed.atoms_ff.columns.get_loc('partial_charge')
    changed.atoms_ff.iloc[0, column] = float(changed.atoms_ff.iloc[0, column]) + 0.125
    assert mechanics_witness(changed) != expected
    assert mechanics_witness(mechanics) == expected
    received.append('changed_partial_charge_value')
    changed = call('mechanical_copy', mechanics.copy)
    changed.atoms_ff['partial_charge'] = changed.atoms_ff['partial_charge'].astype(object)
    assert mechanics_witness(changed) != expected
    assert mechanics_witness(mechanics) == expected
    received.append('changed_partial_charge_dtype')
    return received


def observed_format(path):
    import h5py
    with h5py.File(path, 'r') as stream:
        version = str(stream.attrs['version'])
    assert version == '0.6'
    return version
