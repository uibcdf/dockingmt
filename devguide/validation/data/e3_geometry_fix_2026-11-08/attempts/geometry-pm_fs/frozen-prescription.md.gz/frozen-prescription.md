# Receiving the E3 clustering cutoff correction — 2026-11-08

Owner: [DockingMT #79](../pending_proposals/qualify_pose_comparison_and_clustering.md).
Provider: [MolSysMT #659](https://github.com/uibcdf/molsysmt/issues/659).
Registered before execution; outcome **unexecuted**.

## Original question and unchanged controls

Execute the complete original [independent geometry selection](e3_geometry_provider_receiving_2026-11-08.md)
on the corrected editable provider. Preserve its original normal PASS, pm/fs
FAIL and separate unit diagnosis as immutable historical populations. Create a
new task; never overwrite or restart the old terminal campaign.

The scientific worker is byte-identical to the original, SHA-256
`65627af215163a9c012da536f4450df2892f04db2816d8c8fea6791fc2c49c5c`.
Keep every original fixture, analytic expected value, 1e-12 nm comparison
tolerance, exact inclusive cutoff, member/map population, chemical search scope,
adverse assertion and final live check. No fuzzy cutoff, adjusted input,
different unit provider, assertion relaxation or consumer algorithm is added.

Per policy retain 18 pairwise, 23 cluster, four correspondence, one RDKit/native
conversion and one structure-append call. This includes nine successful
pairwise records, ten cluster records and 22 typed refusals. Preserve original/
repeated axes, analytic translation and permutation, full/cached/restricted/
anchored chemistry, inclusive complete/single linkage and diameters, medoid/
first/ties, empty/singleton/duplicates, mixed units, work/RAM refusals,
detachment, sources, caller policy, provider configuration and final custody.
Execute normal completely before the identical pm/fs/coulomb process.

## Actual development composition

Consumer baseline: `d594fb66cd2bd91fec1a31eae1f50e1c05b07d52`. Clean editable
MolSysMT advances six commits from `8af8628e6` to
`fab8cbccf570a60205a3863aad19dd4b7cfb8d3a`, including #659 fix
`68350e0b27249b8337c04779ba0a86196d861a18` and #657 version-bootstrap resolution.
Rust tree remains `fb25b2eac60b6e706c712e788119b3dad94329fe`, native SHA-256
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`.
No Rust/build-input changes, build/reinstall or package acquisition follows.
Freeze full participating Python inventories, actual imports/native origins,
current provider code/contracts/tests, original worker/body, composition,
prescription and resource/support declaration before execution. Refuse drift.
Unchanged source support uses SDK `95f693be10c9205ab9b912cb53453710a207bf45`.

#657 now prefers the actual package-local generated build stamp, then explicitly
owning distribution records, otherwise `0+unknown`, without Git/build processes.
An editable build label is not a live source fingerprint. Retain observed labels
verbatim and actual source identity separately. The unchanged worker's #657
annotation is its historical pointer, not a claim that the issue remains open.
Do not rewrite original producer labels or infer installed/public qualification.

## Resources, records and completion boundary

Use serial CPU 0/nice 10/one native and build worker, monitored 13 GiB available
RAM reserve, 1 GiB group RSS, 2 GiB address space, 45 CPU/60 wall seconds. Estimated
peak RSS remains 512 MiB; original cells observed at most 228,356,096 bytes.
Check RAM/load/swap/pressure before execution. Slurm has no allocation; retain
the earlier bounded inconclusive applicability probe and use this small direct
route. Stop on failure, preserve interrupted/unattempted outcomes and never
automatically restart after a resource interruption.

Seal exact records and independently receive physical fields through
PyUnitWizard's field/unit/dimensional handshake without molecular replay. Update
the owning report, roadmap, complete plan and handoff; run applicable local
and fresh committed-export resource checks. Retain
`.molsyssuite/e3-geometry-fix-receiving-20261108` under #50/review 2026-11-14.
No original diagnosis, new docking/search, detector, browser/kernel or remote CI.

Passing receives the original two-policy analytic/adverse provider profile only.
The original reference's #256 mechanics persistence, #88's incomplete full source
control, saved-pose/state/common-frame admission, full E3/science, canvas and
installed/public/minor/platform requirements remain. The provider's new #256
route inspection verifies no existing complete transport; it does not waive the
original H5MSM gate or authorize discarding mechanics/private codecs.
