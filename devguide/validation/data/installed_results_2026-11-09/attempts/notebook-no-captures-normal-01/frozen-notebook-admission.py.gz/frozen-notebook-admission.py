"""Verify the exact original and reproduce the declared detached software control."""
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parents[2];task=Path(__file__).parent
source=root/'devguide/validation/data/human_3ptb/native_result_2026-10-20.json.gz';raw=source.read_bytes();assert hashlib.sha256(raw).hexdigest()=='4b1f51cdeb135fd6785a181f6bb09a0d0f631ec3d9de7c169c88703748924249'
original=json.loads(gzip.decompress(raw));control=deepcopy(original)
for value in control['provenance']['backend_artifacts'].values():value.pop('content_base64',None)
assert control['poses']==original['poses'];derived=gzip.compress((json.dumps(control,indent=2,allow_nan=False)+'\n').encode(),mtime=0)
for name,blob in [('original',raw),('no-captures',derived)]:
 config=json.loads((task/('notebook-'+name+'.json')).read_text());assert Path(config['input']).read_bytes()==blob and hashlib.sha256(blob).hexdigest()==config['input_sha256'] and hashlib.sha256(Path(config['notebook']).read_bytes()).hexdigest()==config['notebook_sha256']
print('Exact original and deterministic detached control verified; no files rewritten')
