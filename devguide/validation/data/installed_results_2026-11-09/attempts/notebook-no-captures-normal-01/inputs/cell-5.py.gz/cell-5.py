wrong_schema = deepcopy(record)
wrong_schema['schema_version'] = 'unsupported-tutorial-control'
assert dmt.audit_result(wrong_schema)['status'] == 'inconsistent'
try:
    dmt.DockingResult.from_dict(wrong_schema)
except CatalogException as error:
    assert error.extra.get('arg_name') == 'schema_version'
    schema_refusal = {'code': error.code, 'argument': error.extra['arg_name']}
else:
    raise AssertionError('The unsupported schema was not refused.')

capture_refusal = None
if captures_available:
    damaged = deepcopy(record)
    digest = damaged['provenance']['backend_artifacts']['partner']['sha256']
    damaged['provenance']['backend_artifacts']['partner']['sha256'] = (
        '0' if digest[0] != '0' else '1'
    ) + digest[1:]
    damaged_audit = dmt.audit_result(damaged)
    assert any(
        check['check'] == 'captured_input'
        and check['path'] == '/provenance/backend_artifacts/partner'
        and check['status'] == 'inconsistent'
        for check in damaged_audit['checks']
    )
    try:
        dmt.verify_captured_inputs(damaged['provenance']['backend_artifacts'])
    except CatalogException as error:
        assert error.extra.get('arg_name') == 'artifacts'
        assert error.extra.get('role') == 'partner'
        capture_refusal = {
            'code': error.code,
            'argument': error.extra['arg_name'],
            'role': 'partner',
        }
    else:
        raise AssertionError('The changed captured-input digest was not refused.')
assert record == original_record
assert result.to_dict() == result_snapshot
print(
    {
        'unsupported_schema_refused': schema_refusal,
        'damaged_capture_refused': capture_refusal,
    }
)