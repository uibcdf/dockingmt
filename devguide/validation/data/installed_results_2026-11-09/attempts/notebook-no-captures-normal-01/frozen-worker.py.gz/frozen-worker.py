"""Execute eight unmodified public notebook cells through the installed reader."""
import ast
from contextlib import redirect_stdout
from copy import deepcopy
import gzip
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
root=Path(os.environ['DMT_SMALL_ROOT']);task=Path(os.environ['DMT_SMALL_TASK']);attempt=Path(os.environ['DMT_SMALL_ATTEMPT']);reg=json.loads((attempt/'registration.json').read_text())
def sha(p):
 with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
artifact=json.loads((attempt/'frozen-artifact.json').read_text());installation=json.loads((attempt/'frozen-installation.json').read_text());site=Path(installation['site']);assert Path(sys.prefix)==Path(installation['prefix']) and sha(artifact['wheel'])==artifact['wheel_sha256']
def verify_receiver():
 for group in ['consumer_sha256','tool_sha256','unit_sha256']:
  for name,digest in installation[group].items():assert sha(site/name)==digest
verify_receiver()
def cohort():
 return {name:{'commit':subprocess.check_output(['git','-C',str(root.parent/name),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(root.parent/name),'status','--porcelain'],text=True),'python_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.py')},'native_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.so')},'distribution_version':metadata.version(name)} for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']}
before=cohort();assert before==json.loads((attempt/'frozen-expected-cohort.json').read_text());save(attempt/'cohort.json',before)
config=json.loads((attempt/('frozen-'+reg['selection']+'.json')).read_text());notebook=Path(config['notebook']);input_path=Path(config['input']);original=Path(config['original_source']);assert sha(notebook)==config['notebook_sha256'] and sha(input_path)==config['input_sha256'] and sha(original)==config['original_source_sha256']=='4b1f51cdeb135fd6785a181f6bb09a0d0f631ec3d9de7c169c88703748924249'
inputs=attempt/'inputs';inputs.mkdir();shutil.copyfile(notebook,inputs/'installed_result_inspection.ipynb');shutil.copyfile(input_path,inputs/'result.json.gz');shutil.copyfile(task/'notebook_admission.py',attempt/'frozen-notebook-admission.py');save(attempt/'input-config.json',config)
reference=json.loads(gzip.decompress(original.read_bytes()));actual=json.loads(gzip.decompress(input_path.read_bytes()));assert reference['poses']==actual['poses'] and len(actual['poses'])==5
if reg['selection']=='notebook-no-captures':
 expected=deepcopy(reference)
 for value in expected['provenance']['backend_artifacts'].values():value.pop('content_base64',None)
 assert actual==expected
else:assert input_path.read_bytes()==original.read_bytes()
cells=[''.join(c['source']) for c in json.loads(notebook.read_text())['cells'] if c['cell_type']=='code'];assert len(cells)==8
for i,source in enumerate(cells,1):(inputs/('cell-'+str(i)+'.py')).write_text(source)
assert root not in [Path(p).resolve() for p in sys.path if p] and Path(installation['harness']) not in [Path(p).resolve() for p in sys.path if p]
import pyunitwizard as puw
units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if reg['profile']=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
attempts=[]
def forbidden(*args,**kwargs):attempts.append('out-of-scope molecular/engine/viewer work');raise AssertionError(attempts[-1])
with puw.context(default_form='pint',default_parser='pint',standard_units=units):
 caller=puw.configure.report()
 import dockingmt as dmt
 import molsysmt as msm
 assert Path(dmt.__file__).resolve().is_relative_to(site/'dockingmt') and dmt.__version__==artifact['version']==metadata.version('dockingmt')
 assert Path(msm.__file__).resolve().is_relative_to(root.parent/'molsysmt/molsysmt')
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 for name in ['get','set','copy','convert','select','extract','merge','append_structures','concatenate_structures','permute_atoms']:setattr(msm,name,forbidden)
 for name in ['assign_partial_charges','assign_autodock_atom_types','add_missing_hydrogens','merge_nonpolar_hydrogens']:setattr(msm.build,name,forbidden)
 msm.structure.get_rmsd=forbidden
 for name in ['dock','score','dock_many','view','show','evaluate_redocking','prepare_ligand','prepare_receptor']:setattr(dmt,name,forbidden)
 dmt.DockingPose.to_molecular_system=forbidden;dmt.DockingPose.get_rmsd=forbidden;dmt.DockingResult.get_rmsds=forbidden
 os.environ['DOCKINGMT_RESULT_PATH']=str(inputs/'result.json.gz');os.environ['DOCKINGMT_RESULT_SHA256']=config['input_sha256'];namespace={'__name__':'__main__'};completed=[]
 for i,source in enumerate(cells,1):
  with (attempt/('cell-'+str(i)+'.stdout.log')).open('x') as stream,redirect_stdout(stream):exec(compile(source,'installed_result_inspection.ipynb:cell-'+str(i),'exec'),namespace)
  completed.append({'cell':i,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'outcome':'PASS'})
 receipt=namespace['receipt'];assert receipt['pose_count']==5 and receipt['record_audit_status']==config['expected_audit'] and receipt['recorded_producer']['dockingmt_version']==config['expected_recorded_dockingmt_version'] and receipt['reader']['dockingmt_version']==artifact['version'] and receipt['reader']['archive_sha256_if_recorded']==artifact['wheel_sha256'] and receipt['molecular_problem_restored'] is False
 assert receipt['captured_bytes_verified']==(config['expected_audit']=='consistent')
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 assert not attempts
 save(attempt/'notebook-receipt.json',receipt)
verify_receiver();assert cohort()==before and sha(notebook)==config['notebook_sha256'] and sha(input_path)==config['input_sha256'] and sha(original)==config['original_source_sha256']
save(attempt/'receipt.json',{'profile':reg['profile'],'selection':reg['selection'],'cells':completed,'completed_cells':len(completed),'notebook_sha256':config['notebook_sha256'],'input_sha256':config['input_sha256'],'original_input_sha256':config['original_source_sha256'],'input_kind':config['kind'],'notebook_receipt':receipt,'wheel_sha256':artifact['wheel_sha256'],'qualification_source':artifact['source_commit'],'runtime_version':artifact['version'],'installed_origin':str(Path(dmt.__file__).resolve()),'cohort_unchanged':True,'engine_attempts':attempts,'no_sdk_harness_source_injection':True,'no_molecular_operations':True,'headless_python_not_real_kernel':True,'new_scientific_case':False,'full_scientific_public_platform_gate':False})
print(json.dumps({'cells':len(completed),'audit':receipt['record_audit_status'],'recorded_producer':receipt['recorded_producer']['dockingmt_version'],'reader':artifact['version']}))
