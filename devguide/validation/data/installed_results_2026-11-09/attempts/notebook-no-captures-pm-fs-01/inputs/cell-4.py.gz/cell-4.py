rows = []
for index, (pose, saved) in enumerate(
    zip(result.poses, record.get('poses', []), strict=True)
):
    assert pose.pose_id == saved.get('pose_id')
    assert pose.rank == saved.get('rank')
    assert pose.partner_state_id == saved.get('partner_state_id')
    assert pose.receptor_state_id == saved.get('receptor_state_id')
    assert pose.scores == saved.get('scores', {})
    definitions = pose.score_definitions
    assert definitions == (saved.get('metadata') or {}).get('score_definitions', {})
    coordinate_record = saved['coordinates']
    expected_coordinates = puw.quantity(
        coordinate_record['value'], coordinate_record['unit']
    )
    assert puw.are_close(pose.coordinates, expected_coordinates, rtol=1e-12, atol=0)
    score_rows = []
    for name, value in pose.scores.items():
        definition = definitions.get(name) or {}
        score_rows.append(
            {
                'name': name,
                'value': value,
                'unit': definition.get('unit'),
                'method': definition.get('method'),
                'component': definition.get('component'),
                'kind': definition.get('kind'),
            }
        )
    coordinates_angstrom = puw.get_value(
        pose.coordinates, to_unit='angstrom', value_type=list
    )
    rows.append(
        {
            'index': index,
            'position': index + 1,
            'rank': pose.rank,
            'pose_id': pose.pose_id,
            'n_atoms': pose.n_atoms,
            'scores': score_rows,
            'first_stored_coordinate': coordinates_angstrom[:1],
            'coordinate_unit': 'angstrom',
        }
    )
print(json.dumps(rows, indent=2, allow_nan=False))