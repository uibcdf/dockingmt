policy_before = puw.configure.report()
with puw.context(
    standard_units=['pm', 'fs', 'K', 'mole', 'dalton', 'e', 'kJ/mol', 'degrees']
):
    chosen_policy = puw.configure.report()
    policy_result = dmt.DockingResult.from_dict(record)
    assert policy_result.problem is None
    assert policy_result.to_dict() == result_snapshot
    assert puw.configure.report() == chosen_policy
assert puw.configure.report() == policy_before
print(
    {'nondefault_policy_preserves_record_meaning': True, 'caller_policy_restored': True}
)