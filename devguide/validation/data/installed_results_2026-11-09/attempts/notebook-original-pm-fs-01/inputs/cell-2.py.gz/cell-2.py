input_bytes = result_path.read_bytes()
actual_file_sha256 = hashlib.sha256(input_bytes).hexdigest()
if actual_file_sha256 != expected_file_sha256:
    raise ValueError(
        'The supplied file does not match the externally expected identity.'
    )
encoding = 'gzip' if result_path.suffix == '.gz' else 'identity'
decoded = gzip.decompress(input_bytes) if encoding == 'gzip' else input_bytes


def reject_nonfinite(value):
    raise ValueError('Nonfinite JSON constants are unsupported.')


record = json.loads(decoded.decode('utf-8'), parse_constant=reject_nonfinite)
original_record = deepcopy(record)
print(
    {
        'file_identity_matches': True,
        'encoding': encoding,
        'file_bytes': len(input_bytes),
        'decoded_bytes': len(decoded),
    }
)