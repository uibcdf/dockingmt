exported = result.to_dict()
reread = dmt.DockingResult.from_dict(exported)
assert reread.problem is None and reread.to_dict() == result_snapshot
exported['poses'].clear()
assert result.to_dict() == reread.to_dict() == result_snapshot
assert record == original_record
assert hashlib.sha256(result_path.read_bytes()).hexdigest() == actual_file_sha256
print(
    {
        'independent_roundtrip': True,
        'original_input_unchanged': True,
        'molecular_problem_restored': False,
    }
)