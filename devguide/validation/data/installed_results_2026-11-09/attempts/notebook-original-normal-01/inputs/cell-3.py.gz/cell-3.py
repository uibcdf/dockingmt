audit = dmt.audit_result(record)
if audit['status'] == 'inconsistent':
    raise ValueError(
        'The record contains inconsistent evidence; inspect audit["checks"].'
    )
result = dmt.DockingResult.from_dict(record)
assert result.problem is None
result_snapshot = result.to_dict()

provenance = record.get('provenance') or {}
capture_checks = [
    check for check in audit['checks'] if check['check'] == 'captured_input'
]
captures_available = len(capture_checks) == 2 and all(
    check['status'] == 'consistent' for check in capture_checks
)
captured_sizes = None
if captures_available:
    captured_sizes = dmt.verify_captured_inputs(provenance['backend_artifacts'])

print(
    {
        'record_audit': audit['status'],
        'poses': len(result.poses),
        'problem_attached': result.problem is not None,
        'captured_bytes_verified': captures_available,
        'captured_sizes_bytes': captured_sizes,
    }
)