receipt = {
    'schema': 'dockingmt.installed_result_inspection@1',
    'scope': 'saved_result_record_inspection',
    'input': {
        'file_sha256': actual_file_sha256,
        'decoded_sha256': hashlib.sha256(decoded).hexdigest(),
        'encoding': encoding,
        'external_expected_identity_matches': True,
    },
    'recorded_producer': {
        name: provenance.get(name)
        for name in (
            'dockingmt_version',
            'molsysmt_version',
            'backend',
            'backend_version',
        )
    },
    'reader': {
        'dockingmt_version': dmt.__version__,
        'python': platform.python_version(),
        'pyunitwizard_version': metadata.version('pyunitwizard'),
        'smonitor_version': metadata.version('smonitor'),
        'module_origin_within_prefix': str(reader_origin.relative_to(prefix)),
        'editable': False,
        'archive_sha256_if_recorded': installation.get('archive_info', {})
        .get('hashes', {})
        .get('sha256'),
    },
    'record_audit_status': audit['status'],
    'pose_count': len(result.poses),
    'captured_bytes_verified': captures_available,
    'captured_sizes_bytes': captured_sizes,
    'schema_refusal': schema_refusal,
    'capture_refusal': capture_refusal,
    'identity_order_scores_and_descriptors_preserved': True,
    'coordinate_roundtrip_relative_tolerance': 1e-12,
    'coordinate_roundtrip_absolute_tolerance': 0,
    'coordinate_display_unit': 'angstrom',
    'nondefault_policy_preserved': True,
    'caller_policy_restored': True,
    'detached_roundtrip_verified': True,
    'input_file_and_record_unchanged': True,
    'molecular_problem_restored': False,
    'whole_case_authentication': False,
    'historical_software_bytes_verified': False,
    'chemical_validity_verified': False,
    'browser_or_C6_acceptance': False,
}
print(json.dumps(receipt, indent=2, allow_nan=False))