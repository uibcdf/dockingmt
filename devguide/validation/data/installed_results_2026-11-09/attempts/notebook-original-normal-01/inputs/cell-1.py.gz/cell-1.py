import gzip
import hashlib
import importlib.metadata as metadata
import json
import os
import platform
import sys
from copy import deepcopy
from pathlib import Path

import pyunitwizard as puw
from smonitor.integrations import CatalogException

import dockingmt as dmt

result_path = Path(os.environ['DOCKINGMT_RESULT_PATH']).expanduser().resolve()
expected_file_sha256 = os.environ['DOCKINGMT_RESULT_SHA256'].lower()
if len(expected_file_sha256) != 64 or any(
    char not in '0123456789abcdef' for char in expected_file_sha256
):
    raise ValueError('Supply an externally expected SHA-256 digest.')

prefix = Path(sys.prefix).resolve()
reader_origin = Path(dmt.__file__).resolve()
distribution = metadata.distribution('dockingmt')
installation = json.loads(distribution.read_text('direct_url.json') or '{}')
if not reader_origin.is_relative_to(prefix) or installation.get('dir_info', {}).get(
    'editable', False
):
    raise RuntimeError(
        'Select an ordinary-installed DockingMT kernel without a source overlay.'
    )
assert dmt.__version__ == metadata.version('dockingmt')
print({'reader_version': dmt.__version__, 'python': platform.python_version()})