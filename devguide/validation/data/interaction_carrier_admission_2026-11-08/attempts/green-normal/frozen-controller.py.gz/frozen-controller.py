"""Freeze and bound each source-test cell independently."""
import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2]
task=Path(__file__).parent
stage,profile=sys.argv[1:3]
assert stage in ['red','green'] and profile in ['normal','pm_fs']
attempt=task/(stage+'-'+profile)
attempt.mkdir(exist_ok=False)
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available()>policy['available_reserve_bytes']+512*1024**2
selection=['tests/test_interaction_binding.py::test_missing_carrier_domains_have_a_local_argument_diagnostic'] if stage=='red' else ['tests/test_interaction_binding.py','tests/test_viewer_interactions.py']
inputs=['dockingmt/interactions.py','tests/test_interaction_binding.py','tests/test_viewer_interactions.py','pyproject.toml']
for relative in inputs:
    shutil.copyfile(root/relative,attempt/('frozen-'+relative.replace('/','__')))
for source,name in [(Path(__file__),'controller.py'),(task/'test_child.py','test_child.py'),(guard,'guard.py')]:
    shutil.copyfile(source,attempt/('frozen-'+name))
registration={'source_commit':'1ffff2ea3066ceef98a2ebd530337709290cecd3','stage':stage,'profile':profile,'selection':selection,'policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':256*1024**2,'inputs_sha256':{name:sha(root/name) for name in inputs},'frozen_sha256':{p.name:sha(p) for p in attempt.iterdir() if p.is_file()},'scheduler':'Slurm binaries present, no allocation; preserved bounded applicability probe inconclusive, direct small serial source cell','scope':'Consumer partial-carrier diagnostic; preserve red failures, no real molecular/backend/visual operations'}
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy();env.update(DMT_SOURCE_ROOT=str(root),DMT_SOURCE_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:
    env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen([sys.executable,'-B','-I',str(attempt/'frozen-test_child.py')],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
    outcome=monitor(process,policy)
assert {name:sha(root/name) for name in inputs}==registration['inputs_sha256']
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
if (attempt/'receipt.json').is_file():
    r=json.loads((attempt/'receipt.json').read_text()); print(json.dumps({'stage':stage,'profile':profile,'counts':r['counts'],'pytest_exit_code':r['pytest_exit_code']}))
else:
    print((attempt/'stderr.log').read_text()[-3000:])
raise SystemExit(0 if outcome['outcome']=='PASS' else 1)
