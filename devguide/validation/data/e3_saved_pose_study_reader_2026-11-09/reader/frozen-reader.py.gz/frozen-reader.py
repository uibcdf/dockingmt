"""Independent saved evidence receiving; no molecular imports or replay."""
import hashlib
import json
import sys
from copy import deepcopy

import numpy as np
import pyunitwizard as puw


def verify_records(records):
    def obj(name): return json.loads(records[name])
    def sha(raw): return hashlib.sha256(raw).hexdigest()
    assert obj('producer/e2-authentication.json')['members_authenticated']==193
    assert sha(records['producer/e2-manifest.json'])=='4535ecab26c9fbe4d80bf50fabb48ec3a74ae067979f4e970f5523f703c98e46'
    reuse=obj('producer/geometry-reuse.json')
    assert len(reuse['unchanged_files'])==6 and reuse['native_sha256']=='5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
    assert obj('producer/setup-failure.json')['scientific_calls']==0
    failed=[]
    for suffix,expected_gets in [('01',2),('02',8)]:
        prefix='attempts/study-normal-'+suffix+'/'
        r=obj(prefix+'resource-outcome.json');f=obj(prefix+'failure.json')
        assert r['outcome']=='FAIL' and r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids']
        assert f['direct_counts']['get']==expected_gets and f['direct_counts']['pose_reconstruction']==0
        assert f['stage']=='get' and not f['e3_accepted'];failed.append(suffix)
    arrays={}; quantities=0;handshake_sample=None
    for profile in ['normal','pm_fs']:
        p='attempts/study-'+profile+'-03/'
        reg=obj(p+'registration.json');r=obj(p+'receipt.json');res=obj(p+'resource-outcome.json')
        assert r['outcome']==res['outcome']=='PASS' and r['qualification_complete'] and r['pose_count']==3
        assert r['profile']==profile and r['source_and_caller_preserved'] and r['common_receptor_frame_admitted']
        assert r['native_searches']==0 and not r['e3_accepted'] and r['independent_receiving_pending'] and not r['blocked']
        assert r['provider_commit']=='efbe67e1c6042078144bce1db24aa80bb565dbd2'
        for name,digest in reg['frozen_sha256'].items(): assert sha(records[p+name])==digest
        for name,digest in reg['input_sha256'].items(): assert sha(records[p+name])==digest
        assert res['policy']==reg['policy'] and res['policy']['cpu']==0 and res['policy']['nice']==10
        assert res['minimum_available_bytes']>=13*1024**3 and res['sampled_peak_group_rss_bytes']<1024**3
        assert res['group_terminal'] and not res['remaining_live_owned_pids'] and res['resource_interruption'] is None and res['exit_code']==0
        for key,value in r['direct_counts'].items(): assert value<=reg['direct_caps'][key]
        for key in ['h5_read','convert','select','frame_rmsd','name_correspondence','dihedral','translate','pose_reconstruction','concatenate','graph_witnesses','pairwise','reference_rmsd','clusters']: assert r['direct_counts'][key]==reg['direct_caps'][key]
        assert sha(records[p+'p59-original.json'])=='c71b4789274f008130ecf512095246e310a18d3856344986f25d174abcde8a0e'
        assert sha(records[p+'p69-original.json'])=='9cdbb66fc60517abd73533d2b4094191057b3b292ebe38396df7d7cc5eb7f8f3'
        original=obj(p+'p59-original.json');analysis=obj(p+'analysis.json')
        assert analysis['original_record_sha256']==sha(records[p+'p59-original.json'])
        assert [x['pose_id'] for x in original['poses']]==['pose_1','pose_2','pose_3'] and [x['rank'] for x in original['poses']]==analysis['original_ranks']==[1,2,3]
        assert analysis['original_positions']==[0,1,2] and analysis['full_chemical_maps']==2 and analysis['scores_preserved']
        assert analysis['sample_count']==3 and analysis['independent_original_runs']==analysis['independent_molecular_cases']==1
        assert analysis['alignment']==analysis['periodic_imaging']=='none' and not analysis['probability_or_affinity_interpretation']
        assert all(x['partner_state_id']==analysis['state'] and x['receptor_state_id']==analysis['receptor_state'] for x in original['poses'])
        assert obj(p+'different-state-refusal.json')['molecular_operations_before_refusal']==0
        assert obj(p+'translated-frame-refusal.json')['original_frame_preserved']
        frame=obj(p+'frame-certificate.json');assert frame['alignment']==frame['reflection']==frame['periodic_imaging']=='none' and not frame['automatic_frame_recognition']
        assert len(frame['ligand_source_indices'])==len(frame['reference_heavy_indices'])==24 and len(frame['anchor_pairs'])==4
        def quantity(record,field,unit='nm',dimension={'[L]':1}):
            nonlocal quantities
            q=puw.QuantityRecord.from_dict(record).to_quantity(field=field,unit=unit,dimensionality=dimension)
            values=np.asarray(puw.get_value(q,to_unit=unit));assert np.all(np.isfinite(values));quantities+=1
            return values
        np.testing.assert_allclose(quantity(frame['input_coordinate_tolerance'],'frame.tolerance'),.0002,rtol=0,atol=1e-18)
        np.testing.assert_allclose(quantity(frame['heavy_preservation_tolerance'],'frame.heavy_tolerance'),1e-13,rtol=0,atol=1e-28)
        for name,bound in [('pdb-ligand',.0002),('retained-heavy',1e-13),('receptor-anchors',.0002)]:
            assert np.max(quantity(obj(p+name+'-rmsd.json'),name+'.rmsd'))<=bound
        np.testing.assert_allclose(quantity(obj(p+'translated-negative-rmsd.json'),'translated-negative.rmsd'),[1],rtol=0,atol=1e-12)
        angle=quantity(obj(p+'anchor-dihedral.json'),'anchor_dihedral','radians',{});assert np.all(np.abs(np.sin(angle))>1e-6)
        for name in ['self','reference']:
            witness=obj(p+name+'-correspondences.json');assert witness['search_complete'] and witness['search_scope']=='all_chemical_correspondences' and len(witness['atom_correspondences'])==2
            assert np.asarray(witness['atom_correspondences']).shape==(2,24,2) and np.asarray(witness['context_atom_correspondences']).shape==(2,25,2)
        outputs={}
        for name in ['pairwise-symmetry','pairwise-positional','independent-reference','clusters-primary','clusters-sensitivity']:
            record=obj(p+name+'.json');value=record['result'];outputs[name]=value
            for field in record['quantity_fields']:
                array=quantity(value[field],name+'.'+field);arrays[(profile,name,field)]=array
                if field=='rmsd': assert np.all(array>=0)
            if name.startswith('pairwise'):
                array=arrays[(profile,name,'rmsd')];assert array.shape==(3,3)
                np.testing.assert_array_equal(array,array.T);np.testing.assert_array_equal(np.diag(array),np.zeros(3))
                assert value['alignment']==value['periodic_imaging']=='none' and value['cartesian_axes']=='caller_declared_common'
                assert value['member_keys']==analysis['member_keys']
            if name=='independent-reference': assert value['raw_rmsd'] is None and arrays[(profile,name,'rmsd')].shape==(3,)
            if name.startswith('clusters'):
                assert value['inequality']=='<=' and value['tie_break']=='earliest_original_member_pair'
                assert value['cluster_indices']==value['member_indices']==value['representative_indices']==[0,1,2]
                assert value['cluster_offsets']==[0,1,2,3]
                np.testing.assert_allclose(arrays[(profile,name,'cutoff_distance')],.2,rtol=0,atol=1e-15)
                assert value['matrix_sha256']==hashlib.sha256(np.asarray(arrays[(profile,'pairwise-symmetry','rmsd')].shape,dtype='<i8').tobytes()+np.ascontiguousarray(arrays[(profile,'pairwise-symmetry','rmsd')],dtype='<f8').tobytes()).hexdigest()
        support=obj(p+'support-receipt.json');assert support['state']=='verified-support' and support['resources_retired'] and support['imports_retired']
        handshake_sample=outputs['pairwise-symmetry']['rmsd']
    normal='attempts/study-normal-03/';pm='attempts/study-pm_fs-03/'
    for name in obj(normal+'registration.json')['frozen_sha256']: assert records[normal+name]==records[pm+name]
    for name in ['p59-original.json','p69-original.json','source-prepared25.h5msm','experimental-prepared25.h5msm','experimental-heavy24.h5msm']:
        assert records[normal+name]==records[pm+name]
    for (profile,name,field),value in arrays.items():
        if profile=='normal': np.testing.assert_allclose(value,arrays[('pm_fs',name,field)],rtol=0,atol=1e-12)
    refusals=[]
    for kind in ['wrong-field','wrong-dimension','changed-value','changed-unit']:
        altered=deepcopy(handshake_sample);field='pairwise-symmetry.rmsd';unit='nm'
        if kind=='wrong-field': field='different.field'
        elif kind=='wrong-dimension': unit='kJ/mol'
        elif kind=='changed-value': altered['values'][0][1]+=1
        else: altered['manifest']['unit']='meter'
        try: puw.QuantityRecord.from_dict(altered).to_quantity(field=field,unit=unit,dimensionality={'[L]':1})
        except Exception as error: refusals.append({'name':kind,'type':type(error).__name__})
        else: raise AssertionError('Invalid quantity evidence admitted: '+kind)
    assert not any(name=='molsysmt' or name.startswith(('molsysmt.','dockingmt','rdkit','vina','molsysviewer')) for name in sys.modules)
    return {'complete_profiles':['normal','pm_fs'],'e3_bounded_accepted':True,'scientific_replays':0,'quantity_fields_verified':quantities,'invalid_handshakes_refused':refusals,'preserved_failed_profiles':failed,'preserved_setup_failures':1,'pose_count':3,'new_native_searches':0,'cross_policy_atol_nm':1e-12,'public_or_general_scientific_acceptance':False}
