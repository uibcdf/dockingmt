# E3 current-producer paired source control — 2026-11-08

Owners: [DockingMT #88](https://github.com/uibcdf/dockingmt/issues/88) for the
qualification criterion and [#79](../pending_proposals/qualify_pose_comparison_and_clustering.md)
for the reference prerequisite. Registered before execution; outcome **unexecuted**.

## Normative amendment and distinct claims

Preserve the first [indexed-H receiving selection](e3_indexed_h_policy_receiving_2026-11-08.md)
as FAIL at its historical full-file checksum gate, with pm/fs unattempted.
Its scientific prefix, original prescription, workers, warnings and resource
outcome remain frozen. Never relabel that selection as passing.

Authenticate the historical source PDBQT verbatim through its original E2
manifest and SHA-256
`ae0e9d3beb4d14363ea6edb1bff591c56d53b02295082bae8c281d9284d84b9e`.
It remains a different producer/artifact from a new export. Original saved poses,
scores, state and mappings retain their original producer; the current export
does not replace their engine input or establish their common receptor frame.

For a fresh current-source compatibility selection, prepare an independent
control from the original unnormalized 39-atom source authority, before the two
explicit public H-policy operations. Use the same current source/native
composition and caller unit policy as the treatment, Gasteiger-Marsili charge
assignment with explicit neutral total, AD4 chemical-environment typing, rigid
`prepare_ligand(active_torsion_bonds=[], state_id='e2-5x72-p59')`, and public PDBQT
export. Retain its reports, snapshots, prepared declaration and complete bytes.
Require the normalized source treatment's complete export to match this control
byte for byte. No comments, fields, units or coordinates may be stripped,
canonicalized, rounded again or given a new tolerance to obtain equality.

This explicitly replaces only the historical-reexport checksum assertion in
the new selection. It tests the effect of the declared H-policy operation within
one current producer; it does not claim equality with the old producer.
Record actual legacy/current/control hashes and equality booleans separately.
Keep every earlier failed outcome and every other original assertion: both SDF
identities, complete strict full39 and prepared25 chemical correspondences,
R stereochemistry at atom 7, 15 indexed/generated H, coordinate preservation
within 1e-12 angstrom, rigid25 preparation, four native writes/two reads with
exact snapshots, source nonmutation and caller policy restoration. Preserve
the #645 insertion's typed history/identity/flag and conservative chemistry gates.

## Composition, controls and budget

Use DockingMT `dfff57a34f0278fa6185e88df2098ba6d650e90c`, editable MolSysMT
`2325038e8c68157f5c730693ffbb8535f0b45540`, native SHA-256
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`,
and the unchanged SDK `95f693be10c9205ab9b912cb53453710a207bf45` support route.
Freeze the two original SDFs, historical artifact, original and amended workers,
explicit replacement/insertion, plan, resource guard, composition and provider
policy guide/API/implementation identities before each execution. Refuse relevant
source/import/native drift. No source overlay, install, build or dependency change.

Per policy retain original caps and the two normalization/four flag/four history
calls. Add exactly one control charge, type, preparation and PDBQT call, tracked
separately. Complete normal must pass before executing the identical pm/fs/coulomb
selection. Stop at the first failure; retain failed/interrupted/unattempted
members. No automatic restart after resource interruption.

Execute serially on one logical CPU (CPU 0), nice 10, one native/build worker,
13 GiB available-memory reserve, 1 GiB group RSS, 2 GiB address space, 45 CPU and
60 wall seconds. Expected peak RSS is 512 MiB. Inspect RAM/load/swap/pressure
first. Slurm has no allocation; preserve the prior inconclusive applicability
probe and use this bounded direct execution. Monitor owned work only.

Keep `.molsyssuite/e3-reference-editable-20261108` and
`.molsyssuite/e3-source-control-20261108` under #50/review 2026-11-14.
Seal all outcomes and independently read records with no molecular replay.
No RMSD, matrix/clustering, docking/search, interaction detection, View/browser/
kernel or CI dispatch. Complete E3, independent science, actual canvas and
installed/public/minor/platform acceptance remain unproven.
