"""Seal and independently read complete installed offline software controls."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/h5msm-p5-client-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/h5msm_p5_client_2026-11-10';companion=root/'devguide/validation/data/h5msm_p5_client_reader_2026-11-10'
qualified=json.loads((task/'qualified-files.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.h5msm_p5_client@1','owner':'uibcdf/dockingmt#73','co_owners':['uibcdf/molsysmt#256','uibcdf/dockingmt#50'],'qualification_base':'e90c0446b7d3cb89cdf3285516f23db1e058d801','runtime_producer':'37a61e61db40f386a4ad031ecd14d578441f61ce','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored P5 client evidence; zero test/native/molecular replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 for name in qualified:paths.append((root/name,'qualified/'+name))
 paths.extend((p,'packet/'+str(p.relative_to(task/'packet'))) for p in sorted((task/'packet').rglob('*')) if p.is_file())
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 import ast,math
 import xml.etree.ElementTree as ET
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 def plain(value):
  if isinstance(value,list):return [plain(v) for v in value]
  if not isinstance(value,dict):return value
  if value.get('sequence') in ['list','tuple']:return [plain(v) for v in value['values']]
  if all(k in value for k in ['dtype','shape','values']):return plain(value['values'])
  return {k:plain(v) for k,v in value.items()}
 artifact=d('producer/artifact.json');installed=d('producer/installation.json');composition=d('producer/composition.json')
 assert artifact['source_commit']=='37a61e61db40f386a4ad031ecd14d578441f61ce' and artifact['version']=='0.0.0+359.g37a61e6' and artifact['wheel_sha256']=='ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d'
 for folder,ref in d('producer/prior-artifact-receiving.json').items():
  parent=root/'devguide/validation/data'/folder;assert sha(parent/'manifest.json')==ref['manifest_sha256'];previous=read(parent);assert len(previous)==ref['members']
  if folder=='installed_allocation_fixes_2026-11-10':assert json.loads(previous['producer/artifact.json'])==artifact and json.loads(previous['producer/installation.json'])==installed
 assert composition['provider_source']=='5e7d65a665425fe6077f016dd95cbd65d424ee91' and composition['native_copy_sha256']=='5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
 assert composition['native_changed_paths']==['rust/src/neighbors.rs'] and composition['changed_native_entrypoint']=='neighbor_list_csr_multi'
 assert hashlib.sha256(data['producer/unchanged-topology.rs.txt']).hexdigest()==composition['allowed_native_entrypoint']['source_sha256']
 for name,digest in composition['packet_files'].items():assert hashlib.sha256(data['packet/'+name]).hexdigest()==digest
 packet=d('packet/manifest.json');assert packet['unchanged_product_source']==composition['provider_source'] and packet['native_backend_sha256']==composition['provider_reference_native'] and packet['root_version']=='0.6' and len(packet['fixtures'])==3
 for fixture in packet['fixtures']:
  for name,row in fixture['files'].items():assert len(data['packet/'+name])==row['bytes'] and hashlib.sha256(data['packet/'+name]).hexdigest()==row['sha256']
 original={n.name:n for n in ast.parse(data['producer/provider-oracle-original.py.txt']).body if isinstance(n,ast.FunctionDef)}
 current={n.name:n for n in ast.parse(data['producer/oracle.py.txt']).body if isinstance(n,ast.FunctionDef)}
 assert set(original)==set(current)=={'_plain','_snapshot','_hdf_snapshot'}
 original['_hdf_snapshot'].body=[n for n in original['_hdf_snapshot'].body if not isinstance(n,ast.ImportFrom)]
 assert all(ast.dump(original[n],include_attributes=False)==ast.dump(current[n],include_attributes=False) for n in original)
 populations={};accepted={}
 specifications=[('admit-normal-01',1,0,'FAIL'),('admit-normal-02',1,0,'FAIL'),('admit-normal-03',1,0,'PASS'),('whole-normal-01',7,2,'FAIL'),('whole-normal-02',7,2,'FAIL'),('whole-normal-03',7,0,'PASS'),('whole-pm-fs-03',7,0,'PASS')]
 for label,count,failures,outcome in specifications:
  prefix='attempts/'+label+'/';resource=d(prefix+'resource-outcome.json');xml=ET.fromstring(data[prefix+'junit.xml']);counts={k:sum(int(n.get(k,'0')) for n in xml.iter('testsuite')) for k in ['tests','failures','errors','skipped']}
  assert counts=={'tests':count,'failures':failures,'errors':0,'skipped':0};assert resource['outcome']==outcome and resource['exit_code']==(0 if outcome=='PASS' else 1) and resource['resource_interruption'] is None and resource['group_terminal'] and not resource['remaining_live_owned_pids'] and resource['minimum_available_bytes']>13*1024**3
  populations[label]={'junit':counts,'qualification_outcome':outcome,'final_receipt_available':prefix+'receipt.json' in data}
  if outcome=='FAIL':
   assert prefix+'receipt.json' not in data
   if label=='admit-normal-01':assert prefix+'import-origins.json' not in data
   if label=='admit-normal-02':assert not Path(d(prefix+'import-origins.json')['molsysmt._version']).is_relative_to(composition['provider_tree'])
   if label=='whole-normal-02':assert prefix+'native-calls.json' not in data and prefix+'native-maps.json' not in data
   continue
  row=d(prefix+'receipt.json');assert row['counts']==counts and row['pytest_exit_code']==0 and row['warnings']==0 and row['provider_source']==composition['provider_source'] and row['native_sha256']==composition['native_copy_sha256'] and row['provider_version']=='0+unknown' and row['consumer_version']==artifact['version'] and row['wheel_sha256']==artifact['wheel_sha256']
  assert not row['forbidden_operations'] and row['optional_imports']==[] and row['shared_sources_unchanged'] and row['packet_files']==composition['packet_files']
  assert 'neighbor_list_csr_multi' in row['native_kernels_guarded'];assert row['native_kernel_calls']==(0 if count==1 else 2)
  for key in ['default_form','default_parser','standard_units']:assert row['caller_policy_before'][key]==row['caller_policy_after'][key]
  for key in ['installed_origins_before','installed_origins_after']:
   assert row[key]['state']=='verified-loaded-imports' and {'dockingmt','molsysviewer_dockingmt'}<=set(row[key]['loaded'])
  origins=d(prefix+'import-origins.json');assert 'molsysmt._version' not in origins
  assert all(Path(path).is_relative_to(Path(composition['provider_tree'])/'molsysmt') for name,path in origins.items() if name.startswith('molsysmt.'))
  expected_scopes=['complete'] if count==1 else ['complete','projected','merged']
  for scope in expected_scopes:
   oracle=d('packet/'+scope+'-expected.json');assert d(prefix+'outputs/'+scope+'-read.json')==d(prefix+'outputs/'+scope+'-convert.json')==oracle
   assert d(prefix+'outputs/'+scope+'-exports.json')==d('packet/'+scope+'-pdbqt.json')
  if count==1:continue
  assert all(e['outcome']=='PASS' for e in row['public_io']) and len(row['public_io'])==15
  assert all(e['kwargs']=={'format_version':'0.6'} for e in row['public_io'] if e['operation']=='h5msm.write')
  native=d(prefix+'native-calls.json');assert native==row['native_calls'] and len(native)==2
  for event in native:
   assert event['call']=='get_component_index_from_bonded_atom_pairs' and event['n_atoms']==1 and event['n_atoms_type']=='int64' and event['pairs']==[] and event['pairs_shape']==[0,2] and event['pairs_dtype']=='int64' and event['result']==[0] and event['result_dtype']=='int64' and event['outcome']=='PASS' and 'test_unknown_report_transports_but_refuses_use' in event['test_node']
  maps=d(prefix+'native-maps.json');assert maps=={str(Path(composition['provider_tree'])/'molsysmt/_rust.abi3.so'):composition['native_copy_sha256']}
  source=d(prefix+'outputs/axis-source.json');transformed=d(prefix+'outputs/axis-transformed.json');assert d(prefix+'outputs/axis-restored.json')==transformed
  a=plain(source);b=plain(transformed);order=list(range(5,-1,-1));report=plain(d(prefix+'outputs/axis-map.json'));assert report['output_to_source_atom_indices']==report['source_to_output_atom_indices']==order
  assert a['structures']['coordinates']['unit']==b['structures']['coordinates']['unit']=='nanometer'
  coordinates=a['structures']['coordinates']['magnitude'];assert b['structures']['coordinates']['magnitude']==[[coordinates[f][i] for i in order] for f in [2,0]]
  assert b['topology']['atoms']==[a['topology']['atoms'][i] for i in order]
  for old_state,new_state in zip(a['chemical_states']['states'],b['chemical_states']['states']):
   old_bonds=old_state['bonds']['columns'];new_bonds=new_state['bonds']['columns']
   expected_edges={tuple(sorted([order[i],order[j]])):v for i,j,v in zip(old_bonds['atom1_index']['values'],old_bonds['atom2_index']['values'],old_bonds['bond_order']['values'])}
   actual_edges={tuple(sorted([i,j])):v for i,j,v in zip(new_bonds['atom1_index']['values'],new_bonds['atom2_index']['values'],new_bonds['bond_order']['values'])};assert actual_edges==expected_edges
  assert b['interactions']['synthetic']['evaluated_structure_indices']==[0,1]
  before=d(prefix+'outputs/edit-source.json');after=d(prefix+'outputs/edit-changed.json');assert d(prefix+'outputs/edit-restored.json')==after
  for key in ['topology','chemical_states','state_associations','mechanics','mechanical_columns','charge_assignment','type_assignment','history']:assert after[key]==before[key]
  for key in before['structures']:
   if key!='coordinates':assert before['structures'][key]==after['structures'][key]
  old_xyz=plain(before)['structures']['coordinates']['magnitude'];new_xyz=plain(after)['structures']['coordinates']['magnitude'];assert new_xyz[:2]==old_xyz[:2]
  assert all(abs(new_xyz[2][i][j]-old_xyz[2][i][j]-(1 if j==0 else 0))<=1e-15 for i in range(6) for j in range(3))
  old_analysis=plain(d(prefix+'outputs/edit-analysis-before.json'));new_analysis=plain(d(prefix+'outputs/edit-analysis-after.json'));assert old_analysis['evaluated_structure_indices']==[0,2] and new_analysis['evaluated_structure_indices']==[0] and new_analysis['structure_indices']==[]
  for key in ['n_atoms','n_structures','source_n_atoms','source_n_structures','source_id','software','measure_units']:assert old_analysis[key]==new_analysis[key]
  for field,key in [('partial_charge_assignment','charge_assignment'),('atom_type_assignment','type_assignment')]:
   refusal=d(prefix+'outputs/'+field+'-refusals.json');assert refusal['original_file_sha256']==composition['packet_files']['complete.h5msm'] and refusal['report']['schema'].endswith('@999')
   assert hashlib.sha256(data[prefix+'outputs/'+field+'-unknown.h5msm']).hexdigest()==refusal['unknown_file_sha256']
   assert d(prefix+'outputs/'+field+'-transported.json')[key]==refusal['report']
   assert [r['operation'] for r in refusal['refusals']]==['project','export']
   assert all(r['error_type']=='StructuralInconsistencyError' and r['output_returned'] is False and ('report' in r['message'].lower() or 'schema' in r['message'].lower()) for r in refusal['refusals'])
  accepted[label]=row
 a='attempts/whole-normal-03/';b='attempts/whole-pm-fs-03/'
 for name in ['run.py','worker.py','client_cases.py','oracle.py','composition.json','artifact.json','installation.json','expected-cohort.json','qualification-inputs.json']:assert data[a+'frozen-'+name]==data[b+'frozen-'+name]
 for name,raw in data.items():
  if name.startswith(a+'outputs/') and name.endswith('.json') and name.removeprefix(a+'outputs/') not in ['partial_charge_assignment-refusals.json','atom_type_assignment-refusals.json']:
   assert json.loads(raw)==json.loads(data[b+name.removeprefix(a)])
 for name in qualified:
  raw=data['qualified/'+name];assert (root/name).read_bytes()==raw
  if name!='devtools/conda-build/resources.toml':assert hashlib.sha256(raw).hexdigest()==artifact['payload_sha256'][name]
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),qualified_sources=len(qualified),populations=populations,accepted_p5_cases_per_policy=7,accepted_pair_native_topology_calls=4,earlier_whole02_native_count_unavailable=True,packet_hashes_verified=True,typed_oracles_preserved=True,source_shared_environment_unchanged=True,stable_h5msm_1_0_gate=False,provider_reference_native_4ffb82e4_received=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete
   row=json.loads(data[prefix+'receipt.json']) if prefix+'receipt.json' in data else None
   if row is not None:assert row['counts']==counts and row['receptor_final']==events.final.data
   assert events.final.data['counts']['executed']==counts['tests'] and events.final.data['counts']['failed']==counts['failures']
   resource=json.loads(data[prefix+'resource-outcome.json']);crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':events.final.data['exitstatus'],'qualification_exit':resource['exit_code'],'qualification_outcome':resource['outcome'],'final_receipt_available':row is not None}

 assert len(crosschecked)==7 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1600])
