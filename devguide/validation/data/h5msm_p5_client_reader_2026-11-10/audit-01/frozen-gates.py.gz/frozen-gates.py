"""Bounded source/committed gates for this native export correction."""
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time

root=Path(os.environ.get('DMT_GATE_ROOT',str(Path(__file__).resolve().parents[2])));task=root/'.molsyssuite/h5msm-p5-client-20261110'
stage,label=sys.argv[1:3]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
if len(sys.argv)>3:
 attempt=Path(os.environ['DMT_GATE_ATTEMPT']);py='/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python';private=str(root/'.molsyssuite/record-wheel-inputs-20261109/receiver/bin/python');suite=root/'.molsyssuite/sdk';publication=root/'.molsyssuite/publication-sdk'
 for path,head in [(suite,'738fe8dd731abb99dac421b0bb2acc8564110180'),(publication,'95f693be10c9205ab9b912cb53453710a207bf45')]:assert subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','-C',str(path),'status','--porcelain'])
 if stage in ['build','install']:
  raise SystemExit(subprocess.run([sys.executable,'-I','-B',str(attempt/'frozen-wheel.py'),stage],cwd=attempt).returncode)
 if stage in ['seal','reader','audit','reader-seal']:
  raise SystemExit(subprocess.run([sys.executable,'-I','-B',str(attempt/'frozen-records.py'),stage],cwd=attempt).returncode)
 env=os.environ.copy();env['DOCKINGMT_SUITE_ROOT']=str(suite)
 def validate(target):
  commands=[('ruff-check',[str(Path(py).parent/'ruff'),'check','.', '--extend-exclude','dockingmt-migration-2026-11-06']),('ruff-format',[str(Path(py).parent/'ruff'),'format','--check','.', '--extend-exclude','dockingmt-migration-2026-11-06']),('index',[py,'devtools/devguide_index.py','--check']),('resources',[py,str(publication/'devtools/scripts/noarch_conda.py'),'--root',str(target),'--plan','devtools/conda-build/release_plan.example.toml']),('contract',[py,str(publication/'devtools/scripts/conda_release_contract.py'),str(target)])]
  if stage!='committed':commands.append(('diff',['git','diff','--check']))
  results=[]
  for name,args in commands:
   with (attempt/(name+'.log')).open('xb') as stream:result=subprocess.run(args,cwd=target,env=env,stdout=stream,stderr=subprocess.STDOUT)
   assert result.returncode==0,(name,result.returncode);results.append(name)
  if (task/'reader-receipt.json').is_file():
   records={}
   for folder,label in [('h5msm_p5_client_2026-11-10','primary-receipt.json'),('h5msm_p5_client_reader_2026-11-10','reader-receipt.json')]:
    base=target/'devguide/validation/data'/folder;expected=json.loads((task/label).read_text());assert sha(base/'manifest.json')==expected['manifest_sha256'];manifest=json.loads((base/'manifest.json').read_text());assert len(manifest['files'])==expected['members']
    for row in manifest['files']:
     blob=(base/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256']
     if row['original_path'].startswith('qualified/'):records[row['original_path'].removeprefix('qualified/')]=raw
   for name,raw in records.items():assert (target/name).read_bytes()==raw
   assert len(records)==67;results.append('archive-and-qualified-bytes')
  return results
 if stage=='committed':
  commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root)
  with tempfile.TemporaryDirectory(prefix='dmt-small-committed-',dir='/tmp') as tmp:
   target=Path(tmp)/'source';target.mkdir();archive=Path(tmp)/'source.tar'
   with archive.open('wb') as stream:subprocess.run(['git','archive','HEAD'],cwd=root,stdout=stream,check=True)
   with tarfile.open(archive) as stream:stream.extractall(target,filter='data')
   results=validate(target)
  receipt={'source_commit':commit,'checks':results,'export_retired':not Path(tmp).exists()}
 else:
  results=validate(root)
  code='''import importlib.abc,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(sys.argv[1]);output=Path(sys.argv[2]);sys.path.insert(0,str(root));blocked=[]
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Administrative gates imported a scientific package')
sys.meta_path.insert(0,Block())
import pytest
selected=['devtools/tests/test_distribution_contract.py','devtools/tests/test_installed_support.py','devtools/tests/test_test_support_boundaries.py','tests/test_reporting_protocol.py']
status=int(pytest.main(['--receptor=llm','--receptor-events='+str(output/'events.jsonl'),'--junitxml='+str(output/'junit.xml'),'-o','cache_dir='+str(output/'pytest-cache')]+[str(root/n) for n in selected]))
counts={k:sum(int(row.get(k,'0')) for row in ET.parse(output/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
from pytest_receptor import read_artifact
events=read_artifact(output/'events.jsonl');assert events.complete and not blocked
(output/'admin-receipt.json').write_text(json.dumps({'counts':counts,'receptor_final':events.final.data,'blocked':blocked}))
raise SystemExit(status)
'''
  with (attempt/'admin.log').open('xb') as stream:result=subprocess.run([private,'-I','-B','-c',code,str(root),str(attempt)],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
  assert result.returncode==0;receipt={'checks':results+['administrative'],'admin':json.loads((attempt/'admin-receipt.json').read_text())}
 (attempt/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt)[:1200]);raise SystemExit(0)
attempt=task/(stage+'-'+label);attempt.mkdir(exist_ok=False)
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60};assert available()>policy['available_reserve_bytes']+256*1024**2
if stage in ['build','install']:shutil.copyfile(task/'wheel.py',attempt/'frozen-wheel.py')
if stage in ['seal','reader','audit','reader-seal']:shutil.copyfile(task/'records.py',attempt/'frozen-records.py')
shutil.copyfile(Path(__file__),attempt/'frozen-gates.py');(attempt/'registration.json').write_text(json.dumps({'policy':policy,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'initial_available_bytes':available(),'estimated_group_rss_bytes':256*1024**2,'program_sha256':sha(attempt/'frozen-gates.py')},indent=2)+'\n')
env=os.environ.copy();env.update(DMT_GATE_ROOT=str(root),DMT_GATE_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1')
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
 process=subprocess.Popen([sys.executable,'-I','-B',str(attempt/'frozen-gates.py'),stage,label,'worker'],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);outcome=monitor(process,policy)
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL';(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome));print((attempt/'stderr.log').read_text()[-1200:])
raise SystemExit(0 if outcome['outcome']=='PASS' else 1)
