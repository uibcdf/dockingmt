import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2]
task=Path(__file__).parent
attempt=task/'probe-02';attempt.mkdir(exist_ok=False)
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert hashlib.sha256(guard.read_bytes()).hexdigest()=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available()>policy['available_reserve_bytes']+512*1024**2
for p,name in [(task/'probe.py','probe.py'),(Path(__file__),'controller.py'),(guard,'guard.py')]:shutil.copyfile(p,attempt/('frozen-'+name))
source=['dockingmt/core/audit.py','dockingmt/core/pose_audit.py','dockingmt/core/results.py']
for name in source:shutil.copyfile(root/name,attempt/('frozen-'+name.replace('/','__')))
registration={'source_commit':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':256*1024**2,'frozen_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in attempt.iterdir() if p.is_file()},'scope':'Nine offline length-record controls; no provider, engine or search'}
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy();env.update(DMT_SOURCE_ROOT=str(root),DMT_SOURCE_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1')
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen([sys.executable,'-B','-I',str(attempt/'frozen-probe.py')],env=env,cwd=root,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
    outcome=monitor(process,policy)
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome));print((attempt/'stdout.log').read_text());print((attempt/'stderr.log').read_text()[-2000:])
raise SystemExit(0 if outcome['outcome']=='PASS' else 1)
