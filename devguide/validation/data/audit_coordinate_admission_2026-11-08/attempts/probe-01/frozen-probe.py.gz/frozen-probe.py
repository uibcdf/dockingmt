import hashlib
import importlib.abc
import json
import os
from pathlib import Path
import sys
from copy import deepcopy

import numpy as np
import pyunitwizard as puw

root=Path(os.environ['DMT_SOURCE_ROOT'])
attempt=Path(os.environ['DMT_SOURCE_ATTEMPT'])
denied=[]
class Offline(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'molsysmt','molsysviewer','vina','rdkit','openmm'}:
            denied.append(fullname)
            raise AssertionError('Record-only probe imported a molecular provider')
sys.meta_path.insert(0,Offline())
import dockingmt as dmt
assert Path(dmt.__file__).resolve()==root/'dockingmt/__init__.py'
fixture=root/'devguide/validation/data/audit/minimal_vina_result.json'
original=json.loads(fixture.read_text())
observations=[]
for name,value in [('boolean',True),('numeric-string','1.0')]:
    for field in ['coordinates','grid_spacing','box_center','box_size']:
        record=deepcopy(original)
        if field=='coordinates':record['poses'][0]['coordinates']['value'][0][0]=value
        elif field=='grid_spacing':
            for pose in record['poses']:
                for definition in pose['metadata']['score_definitions'].values():
                    definition['context']['grid_spacing']['value']=value
        else:
            key='center' if field=='box_center' else 'size'
            record['provenance']['backend_box'][key][0]=value
            for pose in record['poses']:
                for definition in pose['metadata']['score_definitions'].values():
                    definition['context']['backend_box'][key][0]=value
        before=deepcopy(record)
        report=dmt.audit_result(record)
        assert record==before
        observations.append({'case':field+'-'+name,'expected':'inconsistent','actual':report['status'],'checks':report['checks']})
pose=dmt.DockingPose(puw.quantity(np.empty((0,3)),'nm'))
record=pose.to_dict();assert record['coordinates']['value']==[]
assert dmt.DockingPose.from_dict(record).n_atoms==0
report=dmt.audit_pose(record)
observations.append({'case':'own-empty-pose-snapshot','expected':'incomplete','actual':report['status'],'checks':report['checks']})
assert not denied
(attempt/'receipt.json').write_text(json.dumps({'outcome':'PASS','qualification_complete':True,'scope':'Bounded defect observation, not product acceptance','fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'observations':observations,'forbidden_import_attempts':denied,'molecular_operations':0},indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['case','expected','actual']} for r in observations]))
