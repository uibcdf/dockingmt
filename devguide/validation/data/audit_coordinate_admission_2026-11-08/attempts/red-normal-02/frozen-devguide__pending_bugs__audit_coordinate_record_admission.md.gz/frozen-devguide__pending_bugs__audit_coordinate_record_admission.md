---
summary: Offline coordinate audits disagree with the existing pose-record admission.
issue: uibcdf/dockingmt#90
status: active
opened: 2026-11-08
closed:
severity: medium
verification: reproduced
area: [records, audit, quantities]
guard: tests/test_audit_coordinate_records.py
normative: devguide/validation/result_audit.md
blocked_by: []
supersedes: []
---

# Offline coordinate-record admission

## What

At execution base `a6e636902af26fc624eb5ff60c782a75a95732b7`, an audit of the
minimal saved software result incorrectly accepts a mixed Boolean coordinate.
The existing pose reader rejects it. A canonical empty `DockingPose.to_dict()`
coordinate value `[]` roundtrips through that reader, but the standalone audit
incorrectly marks it inconsistent. These are record-boundary defects; no new
molecular measurement is involved.

## How

A nine-control record-only probe observes both defects and seven already
inconsistent malformed controls. It preserves inputs and makes zero molecular
calls. An earlier probe setup fails before observations because the task guard
forbids the package's required MolSysMT import; retain that failure separately.
The corrected probe permits ordinary imports and forbids actual molecular calls.

The initial durable guard records 16 failures/25 passes, no errors/skips. Nine
failures corroborate Boolean/complex coercion through all three audit routes;
four corroborate canonical-empty rejection. Three others expose a test setup
mistake: its deliberately malformed-unit collection omitted the required root
provenance container, so the audit correctly stopped as incomplete before pose
inspection. Preserve that complete FAIL population. Register a corrected red
selection with the empty provenance mapping present, retaining every assertion
and malformed-unit case, before changing runtime. The imaginary component is
also silently discarded by the old conversion, with three ComplexWarnings.

Register the new durable guard before changing runtime. Run it against the
original runtime and retain the complete red pytest/Receptor/JUnit evidence.
Extract the existing xyz-record scalar/shape admission from `DockingPose.from_dict`
into a shared private helper; use it in the offline audit before unit conversion.
Do not change the reader's admitted values, root/nested schema priority, explicit
unit policy or public signature. Empty xyz width is fixed by this existing schema.

## Why

The report must distinguish a valid empty coordinate snapshot from absent
evidence, and reject malformed recorded numbers before conversion hides their
types. Users need the reader and offline audit to agree on the same schema.

## What was refuted

Seven other malformed magnitude/context probe controls are already inconsistent;
they do not establish extra product failures. No PyUnitWizard, ArgDigest,
SMonitor or molecular-provider implementation defect is established. No general
quantity codec, molecular geometry or source normalization belongs in this fix.

## Scope and exclusions

Standalone, docking and scored-collection coordinate records only. Preserve
canonical valid audit digests, unrelated missing/inconsistent evidence, exact
producer identities, source nonmutation, report isolation, resource exceptions,
all previous tests and historical inputs. Do not drop contradictory fields,
recompute chemistry, migrate records or change helpers/data/pins. MolSysMT #256
is being worked on according to the maintainer; no polling/build/transport work.

## Acceptance criteria

The new Boolean and canonical-empty guards fail on the original runtime, then
pass through all applicable public audit paths. Retain numeric-string/complex/
nonfinite/wrong-shape and invalid/missing-unit refusals, plus valid units and
resource-error identity. Run the complete affected record/audit/serialization
selection normal then pm/fs with identical final source/test bytes and native
pytest completion. Use the published authenticated Pytest Receptor 1.2.2 tool
prefix without changing the shared environment.

Run serial CPU 0/nice 10/one native worker, monitored 13 GiB available reserve,
1 GiB group RSS, 2 GiB address space, 45 CPU/60 wall seconds. Estimate 256 MiB
for record tests; stop/preserve an interruption, never restart heavy work
automatically. Retain task `.molsyssuite/audit-length-admission-20261108` under
#50, review 2026-11-14. Update contracts/roadmap/plan/handoff, regenerate indexes,
run Ruff and applicable resource/publication checks including fresh committed
export, archive this record and synchronize #90. No remote CI or full scientific/
installed/public/canvas/objective acceptance follows.
