# Current private wheel with editable siblings

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47);
component source/public qualification: [#30](https://github.com/uibcdf/dockingmt/issues/30).
Registered source producer: `841a34dd30e848adfb72087a27864253cbe2602d`.
This checkpoint receives #94's public exception namespace and #95's audit
resource correction in a genuine installed consumer. Prior wheels/receipts retain
their original producers, bytes and acceptance; this is a separate private file.

## Registered prescription

Build one wheel once from the exact committed producer, with the existing
development build tools and no dependency acquisition. Inspect its complete
67-path runtime payload, source hashes, generated version, metadata, license,
RECORD and absence of shipped administration/test support. Install that exact
wheel SHA into a task-owned venv borrowing the existing editable sibling cohort.
Verify PEP 610 attribution and ordinary pip check. No shared prefix is modified.

Use the reviewed shared installed/support verifier at MolSysSuite
`95f693be10c9205ab9b912cb53453710a207bf45`. Export the exact producer tests into
a harness with both production namespaces removed. Keep all source assertions,
clear inherited pytest paths, verify both loaded production import roots against
the actual installed prefix, and retain the four shared import refusals. Stage
and retire all 30 helper/564 data inputs with their unchanged declared hashes.

The complete selection is the earlier 19-module/990-case offline union plus
`tests/test_public_exceptions.py` and `tests/test_audit_resource_errors.py`:
expected **21 modules/1,062 cases** per caller policy. The same existing real
native scoring test remains explicitly excluded, with unchanged assertions.
Start with a small installed pilot: record roundtrip, exact public aliases,
actual owned error and shared import refusals. Proceed to the whole normal then
pm/fs selection only after safe pilot measurements and fresh headroom. Guard
actual molecular get/select/extract/convert/copy/set, viewer construction and
optional Vina/RDKit/OpenMM imports; no such operation is part of this question.

Retain source/test/fixture/tool/SDK/native/cohort inventories, artifact/install
receipts, every attempt and all native JUnit/Receptor/support outcomes. Check
caller unit policy, input/source/runtime bytes and support import retirement.
Independently read the frozen records without running molecular code or tests.
Final local and fresh committed-export checks cover the completed docs/resource/
publication state. Routine publication uses `[skip ci]`, with no remote CI.

## Resource policy and stop condition

Serial CPU 0/nice 10, one native/build worker, monitored **13 GiB available-memory
reserve**, 1 GiB group RSS, 2 GiB address space and 45 CPU/60 wall-second bounds
per cell. Expected pilot/test peaks are below 512 MiB. The direct shared-machine
route has no Slurm allocation; preserve the prior inconclusive applicability
probe and do not treat available headroom as a reservation. Measure a small
pilot and check current RAM/load/swap/pressure before the larger selection.

Preserve any interrupted attempt. Do not automatically restart after a headroom
stop or raise bounds. If the whole union cannot fit, retain that interruption
and register a lower-cost selection structure before proceeding; do not drop
failing assertions. Preserve previous artifacts, human migration files and the
interrupted sibling-native build.

This cannot certify Conda/public closure, other Python/OS lanes, full scientific
or actual browser/comm/canvas acceptance. #47/#30/#73 remain partial; #256/#558
and the native-build hold retain their original scope. No provider poll/pull/
build, new scientific calculation, public release/tag or shared installation.
Private task `.molsyssuite/record-wheel-20261109`, custody #47/#30/#50,
review 2026-11-14. Append observed outcomes below without rewriting producers.
