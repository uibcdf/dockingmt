"""Prospective, bounded E3 experimental-reference chemistry receiving."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from copy import deepcopy
import sys
import tomllib
import traceback
from dataclasses import asdict

root = Path(os.environ['DMT_E3_ROOT'])
task = Path(os.environ['DMT_E3_TASK'])
attempt = Path(os.environ['DMT_E3_ATTEMPT'])
registration = json.loads((attempt / 'registration.json').read_text())
composition=json.loads((attempt/'frozen-composition.json').read_text())
origins=[]
metadata_observations=[]
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')
sdk = root / '.molsyssuite/publication-sdk/devtools/scripts'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def files(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}

def write(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

assert sys.flags.isolated and not sys.flags.no_site
assert os.sched_getaffinity(0) == {0} and os.getpriority(os.PRIO_PROCESS, 0) >= 10
sys.path.insert(0,str(sdk))
blocked, allowed_subprocesses = [], []
declaration = tomllib.loads((attempt / 'frozen-resources.toml').read_text())['installed_tests']['support']
git_files = {str(root): (registration['source_commit'], {r['source'] for r in declaration['files']}), str(sdk.parents[1]): ('95f693be10c9205ab9b912cb53453710a207bf45', {'devtools/scripts/installed_test_support.py', 'devtools/scripts/installed_noarch.py', 'devtools/scripts/installed_imports.py', 'devtools/scripts/installed_test_dependencies.py'})}
for repository,commit in composition['source_revisions'].items():
    git_files.setdefault(repository,(commit,set()))
git_read_count = 0
def audit(event, args):
    global git_read_count
    if event == 'subprocess.Popen':
        executable, argv = os.fsdecode(args[0]), args[1]
        if shutil.which(executable) == json.loads((attempt / 'frozen-plan.json').read_text())['git_executable'] and isinstance(argv, list) and len(argv) >= 4 and argv[:2] == ['git', '-C'] and argv[2] in git_files:
            commit, paths = git_files[argv[2]]
            if argv[3:] == ['rev-parse', 'HEAD'] or any(argv[3:] in (['rev-parse', commit + ':' + path], ['hash-object', '--no-filters', str(Path(argv[2]) / path)]) for path in paths):
                git_read_count += 1
                return
        if shutil.which(executable) == '/usr/bin/uname' and argv == ['uname', '-p']:
            allowed_subprocesses.append({'executable': '/usr/bin/uname', 'arguments': ['-p'], 'purpose': 'stdlib platform.processor during h5py import'})
            return
    if event == 'socket.connect' or event == 'subprocess.Popen' or event == 'import' and args[0].split('.')[0] == 'vina':
        blocked.append(event)
        raise AssertionError('Network, native search and non-platform subprocesses forbidden')
sys.addaudithook(audit)
from installed_test_support import staged_support
import numpy as np
import pyunitwizard as puw

def policy():
    return {k: puw.configure.report()[k] for k in ['default_form', 'default_parser', 'standard_units', 'provenance']}

counts = dict.fromkeys(registration['direct_caps'], 0)
stage = 'custody'
def call(key, function, *args, **kwargs):
    global stage
    stage = key
    counts[key] += 1
    assert counts[key] <= registration['direct_caps'][key], key
    with (attempt / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps({'operation': key, 'direct_counts': counts}) + '\n')
    return function(*args, **kwargs)

def custody(label):
    current = {}
    for package in composition['packages'].values():
        for path in Path(package['path']).rglob('*.py'):
            current[str(path)] = sha(path)
    assert current == composition['python_sources_sha256'], 'Python source inventory drift'
    for directory, expected in composition['source_revisions'].items():
        assert subprocess.check_output(['git', '-C', directory, 'rev-parse', 'HEAD'], text=True).strip() == expected
    assert sha(composition['native_path']) == composition['provider_native_sha256']
    modules = []
    for name, module in tuple(sys.modules.items()):
        families = [p for p in composition['packages'] if name == p or name.startswith(p + '.')]
        if not families:
            continue
        expected = Path(composition['packages'][max(families, key=len)]['path']).resolve()
        locations = list(getattr(module, '__path__', ()))
        if getattr(module, '__file__', None):
            locations.append(module.__file__)
        if not locations:
            assert name == 'pyunitwizard.main'
            initializer = sys.modules['pyunitwizard']
            for function in (module.__getattr__, module.__dir__):
                assert function.__globals__ is vars(initializer)
                assert Path(function.__code__.co_filename).resolve() == expected / '__init__.py'
            locations = [str(expected / '__init__.py')]
        rows = []
        for value in sorted(set(locations)):
            path = Path(value).resolve()
            assert path.is_relative_to(expected), (name, str(path), str(expected))
            rows.append({'path': str(path), 'sha256': sha(path) if path.is_file() else None})
        modules.append({'module': name, 'locations': rows})
    natives = set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        fields = line.split(None, 5)
        if len(fields) == 6 and fields[5].startswith('/') and ('.so' in fields[5]) and Path(fields[5]).is_file():
            natives.add(Path(fields[5]).resolve())
    origins.append({'label': label, 'route': 'editable-development', 'runtime_origins': modules, 'native_libraries': [{'path': str(p), 'sha256': sha(p)} for p in sorted(natives)]})

support = None
try:
    custody('before')
    previous=policy()
    units=['nm','ps','kelvin','mole','dalton','elementary_charge','kJ/mol','kJ/(mol*nm)','kJ/(mol*nm**2)','radians'] if registration['profile']=='normal' else ['pm','fs','kelvin','mole','dalton','coulomb','kJ/mol','kJ/(mol*pm)','kJ/(mol*pm**2)','radians']
    context={'candidate_sha':registration['source_commit'],'qualification_sha':registration['source_commit'],'provider_sha':'95f693be10c9205ab9b912cb53453710a207bf45'}
    with puw.context(standard_units=units), staged_support(root,declaration,('dockingmt','molsysviewer_dockingmt'),context=context) as support:
        caller=policy()
        import molsysmt as msm
        import dockingmt as dmt
        import molsysmt._rust as native
        from pyunitwizard.record import QuantityRecord
        from dmt_test_support.qualify_chemical_templates import snapshot, detached_record
        assert Path(msm.__file__).resolve()==Path(composition['packages']['molsysmt']['path'])/'__init__.py'
        assert Path(native.__file__).resolve()==Path(composition['native_path']) and policy()==caller
        version=msm.__version__
        exec(compile((attempt/'frozen-mechanics-observer.py').read_text(),str(attempt/'frozen-mechanics-observer.py'),'exec'),globals())
        immutable=[]
        def keep(name,system):
            record={'snapshot':snapshot(system),'mechanics':mechanics_witness(system.molecular_mechanics)}
            immutable.append((name,system,record));write(name+'-before.json',record)
        def coords(system,selection='all'):
            return puw.get_value(call('get',msm.get,system,selection=selection,coordinates=True),to_unit='angstrom')
        def qrecord(q,field,unit='nm',dimension={'[L]':1}):
            record=QuantityRecord.from_quantity(q,field=field).to_dict()
            received=QuantityRecord.from_dict(record).to_quantity(field=field,unit=unit,dimensionality=dimension)
            np.testing.assert_array_equal(puw.get_value(received,to_unit=unit),puw.get_value(q,to_unit=unit))
            return record
        def save_result(name,result,fields):
            assert result['software']['molsysmt']==version
            output=dict(result)
            for field in fields: output[field]=qrecord(result[field],name+'.'+field)
            arrays={k:{'dtype':str(v.dtype),'shape':list(v.shape)} for k,v in result.items() if isinstance(v,np.ndarray)}
            write(name+'.json',{'result':detached_record(output),'array_types':arrays,'quantity_fields':fields})
            return result
        def frame_rmsd(name,system,reference,selection='all',reference_selection='all'):
            q=call('frame_rmsd',msm.structure.get_rmsd,system,selection=selection,reference_molecular_system=reference,reference_selection=reference_selection,heavy_mode='off',parallel=False,num_threads=1,use_gpu=False)
            write(name+'-rmsd.json',qrecord(q,name+'.rmsd'))
            return puw.get_value(q,to_unit='angstrom')
        configuration={k:getattr(msm.configure,k) for k in ['parallel_mode','num_threads','max_ram_usage']}
        with msm.configure.context(parallel_mode=False,num_threads=1,max_ram_usage=256*1024**2):
            original=json.loads((attempt/'p59-original.json').read_text())
            control=json.loads((attempt/'p69-original.json').read_text())
            assert len(original['poses'])==3 and len(control['poses'])==2
            state='e2-5x72-p59';receptor_state='e2-5x72-protein-only-provided'
            def admit_population(record):
                if any(p['partner_state_id']!=state or p['receptor_state_id']!=receptor_state for p in record['poses']):
                    raise ValueError('Declared original partner/receptor state differs; population refused before molecular operations')
            admit_population(original)
            try: admit_population(control)
            except ValueError as error: write('different-state-refusal.json',{'type':type(error).__name__,'message':str(error),'molecular_operations_before_refusal':0})
            else: raise AssertionError('Different-state control admitted')
            result=dmt.DockingResult.from_dict(original)
            result_before=deepcopy(result.to_dict())
            source=call('h5_read',msm.convert,str(attempt/'source-prepared25.h5msm'),to_form='molsysmt.MolSys')
            reference=call('h5_read',msm.convert,str(attempt/'experimental-prepared25.h5msm'),to_form='molsysmt.MolSys')
            heavy=call('h5_read',msm.convert,str(attempt/'experimental-heavy24.h5msm'),to_form='molsysmt.MolSys')
            for label,system in [('source25',source),('reference25',reference),('heavy24',heavy)]: keep(label,system)
            pdb=call('convert',msm.convert,str(attempt/'5x72.pdb'),to_form='molsysmt.MolSys',get_missing_bonds=False)
            receptor=call('convert',msm.convert,str(attempt/'5x72_receptor.pdbqt'),to_form='molsysmt.MolSys')
            for label,system in [('pdb',pdb),('receptor',receptor)]: keep(label,system)
            ligand_selection="group_name=='P59' and group_id=='201' and chain_id=='A'"
            ligand=call('select',msm.select,pdb,selection=ligand_selection)
            retained=call('select',msm.select,reference,selection='atom_type!="H"')
            assert len(ligand)==len(retained)==24
            elements_pdb=call('get',msm.get,pdb,element='atom',selection=ligand,atom_type=True)
            elements_heavy=call('get',msm.get,heavy,element='atom',atom_type=True)
            assert list(elements_pdb)==list(elements_heavy)
            xyz=coords(heavy);pdb_xyz=coords(pdb,ligand);retained_xyz=coords(reference,retained)
            np.testing.assert_allclose(pdb_xyz,xyz,rtol=0,atol=.002)
            np.testing.assert_allclose(retained_xyz,xyz,rtol=0,atol=1e-12)
            assert np.max(frame_rmsd('pdb-ligand',pdb,heavy,ligand))<=.002
            assert np.max(frame_rmsd('retained-heavy',reference,heavy,retained))<=1e-12
            anchor_selection="group_name=='MET' and group_id=='1' and chain_id=='A' and atom_name in ['C','O','CA','CB']"
            pairs=call('name_correspondence',msm.topology.get_atom_name_correspondence,pdb,selection=anchor_selection,reference_molecular_system=receptor,reference_selection=anchor_selection)
            assert pairs.dtype==np.dtype('int64') and pairs.shape==(4,2)
            anchor_xyz=coords(pdb,pairs[:,0]); receptor_xyz=coords(receptor,pairs[:,1])
            np.testing.assert_allclose(anchor_xyz,receptor_xyz,rtol=0,atol=.002)
            assert np.max(frame_rmsd('receptor-anchors',pdb,receptor,pairs[:,0],pairs[:,1]))<=.002
            angle=call('dihedral',msm.structure.get_dihedral_angles,pdb,dihedral_quartets=[pairs[:,0].tolist()],pbc=False,use_gpu=False)
            radians=puw.get_value(angle,to_unit='radians');assert np.all(np.isfinite(radians)) and np.all(np.abs(np.sin(radians))>1e-6)
            write('anchor-dihedral.json',qrecord(angle,'anchor_dihedral','radians',{}))
            translated=call('translate',msm.structure.translate,heavy,translation=puw.quantity([1,0,0],'nm'),in_place=False)
            displaced=frame_rmsd('translated-negative',translated,heavy)
            np.testing.assert_allclose(displaced,[10],rtol=0,atol=1e-12)
            try: np.testing.assert_allclose(coords(translated),xyz,rtol=0,atol=.002)
            except AssertionError: write('translated-frame-refusal.json',{'type':'AssertionError','physical_displacement':qrecord(puw.quantity([1,0,0],'nm'),'negative_frame.translation'),'criterion':'all component differences <= 0.002 angstrom','original_frame_preserved':True})
            else: raise AssertionError('Translated frame admitted')
            write('frame-certificate.json',{'schema':'dockingmt.e3_pinned_frame@1','scope':'fixed 5x72 P59 A201 identity-axis pair only','ligand_source_indices':ligand.tolist(),'reference_heavy_indices':retained.tolist(),'anchor_pairs':pairs.tolist(),'anchor_selection':anchor_selection,'ligand_selection':ligand_selection,'input_coordinate_tolerance':qrecord(puw.quantity(.002,'angstrom'),'frame.tolerance'),'heavy_preservation_tolerance':qrecord(puw.quantity(1e-12,'angstrom'),'frame.heavy_tolerance'),'alignment':'none','periodic_imaging':'none','reflection':'none','automatic_frame_recognition':False,'independent_receptor_preparation_validated':False})
            poses=[call('pose_reconstruction',pose.to_molecular_system,partner=source) for pose in result]
            for position,(pose,system) in enumerate(zip(result,poses)):
                assert pose.pose_id=='pose_'+str(position+1) and pose.rank==position+1
                keep('pose-'+str(position),system)
            combined=call('concatenate',msm.concatenate_structures,poses,to_form='molsysmt.MolSys',attribute_policy='strict')
            keep('combined',combined)
            assert call('get',msm.get,combined,n_structures=True)==3
            indices=call('select',msm.select,combined,selection='atom_type!="H"')
            assert indices.tolist()==list(range(24))
            witness=call('graph_witnesses',msm.chemical_states.get_atom_correspondences,combined,selection=indices,reference_molecular_system=reference,reference_selection=retained,max_matches=4096)
            self_witness=call('graph_witnesses',msm.chemical_states.get_atom_correspondences,combined,selection=indices,max_matches=4096)
            for label,w in [('reference',witness),('self',self_witness)]:
                assert w['search_complete'] and w['search_scope']=='all_chemical_correspondences' and len(w['atom_correspondences'])==2 and w['context_atom_correspondences'].shape[1:]==(25,2)
                write(label+'-correspondences.json',detached_record(w))
            witness_before=detached_record(witness);self_before=detached_record(self_witness)
            keys=['e2-5x72-rigid-20261107/p59-main/'+str(i)+'/'+pose.pose_id for i,pose in enumerate(result)]
            pairwise=save_result('pairwise-symmetry',call('pairwise',msm.structure.get_pairwise_rmsd,combined,selection=indices,method='symmetry_corrected',correspondences=self_witness,max_matches=4096,member_keys=keys,max_work=100000,heavy_mode='off',parallel=False,num_threads=1),['rmsd','tie_tolerance'])
            positional=save_result('pairwise-positional',call('pairwise',msm.structure.get_pairwise_rmsd,combined,selection=indices,method='positional',member_keys=keys,max_work=100000,heavy_mode='off',parallel=False,num_threads=1),['rmsd','tie_tolerance'])
            comparisons=save_result('independent-reference',call('reference_rmsd',msm.structure.get_symmetry_corrected_rmsd,combined,selection=indices,reference_molecular_system=reference,reference_selection=retained,correspondences=witness,max_matches=4096,heavy_mode='off',parallel=False,num_threads=1),['rmsd','tie_tolerance'])
            for value in [pairwise,positional,comparisons]: assert value['alignment']==value['periodic_imaging']=='none'
            assert comparisons['raw_rmsd'] is None
            for value in [pairwise,positional]:
                distances=puw.get_value(value['rmsd'],to_unit='nm');assert distances.shape==(3,3) and np.all(np.isfinite(distances)) and np.all(distances>=0)
                np.testing.assert_array_equal(distances,distances.T);np.testing.assert_array_equal(np.diag(distances),np.zeros(3))
            clusters={}
            for name,method in [('primary','complete_linkage'),('sensitivity','single_linkage')]:
                value=call('clusters',msm.structure.get_distance_clusters,pairwise['rmsd'],cutoff_distance='2 angstrom',method=method,representative='medoid',member_keys=keys,max_work=100000)
                assert value['inequality']=='<=' and value['tie_break']=='earliest_original_member_pair'
                clusters[name]=save_result('clusters-'+name,value,['cluster_diameters','cutoff_distance'])
            assert detached_record(witness)==witness_before and detached_record(self_witness)==self_before
            assert result.to_dict()==result_before
            write('analysis.json',{'schema':'dockingmt.e3_saved_pose_analysis@1','original_record_sha256':sha(attempt/'p59-original.json'),'source_commit':registration['source_commit'],'provider_commit':composition['source_revisions'][str(root.parent/'molsysmt')],'native_sha256':composition['provider_native_sha256'],'member_keys':keys,'original_positions':[0,1,2],'original_ranks':[1,2,3],'state':state,'receptor_state':receptor_state,'scores_preserved':True,'population':'24 heavy atoms, complete fixed25 context','full_chemical_maps':len(witness['atom_correspondences']),'pairwise_metric':'symmetry_corrected','secondary_metric':'positional','cutoff':qrecord(puw.quantity(2,'angstrom'),'analysis.cutoff'),'primary_linkage':'complete_linkage','sensitivity_linkage':'single_linkage','representative':'medoid','alignment':'none','periodic_imaging':'none','native_searches':0,'independent_molecular_cases':1,'independent_original_runs':1,'sample_count':3,'probability_or_affinity_interpretation':False})
        assert configuration=={k:getattr(msm.configure,k) for k in configuration}
        for name,system,before in immutable:
            assert {'snapshot':snapshot(system),'mechanics':mechanics_witness(system.molecular_mechanics)}==before,name
        assert policy()==caller
        support.check()
    assert policy()==previous and not blocked
    custody('after')
    for basename,digest in registration['input_sha256'].items(): assert sha(attempt/basename)==digest
    for key,value in counts.items(): assert value<=registration['direct_caps'][key]
    for key in ['h5_read','convert','select','frame_rmsd','name_correspondence','dihedral','translate','pose_reconstruction','concatenate','graph_witnesses','pairwise','reference_rmsd','clusters']: assert counts[key]==registration['direct_caps'][key],(key,counts)
    write('runtime-origins.json',origins)
    write('receipt.json',{'stage':'pose-study','profile':registration['profile'],'source_commit':registration['source_commit'],'provider_commit':composition['source_revisions'][str(root.parent/'molsysmt')],'outcome':'PASS','qualification_complete':True,'pose_count':3,'direct_counts':counts,'source_and_caller_preserved':True,'common_receptor_frame_admitted':True,'native_searches':0,'molecular_case_count':1,'scope':'bounded original fixed P59 state/frame/population only; no general docking accuracy or public delivery','e3_accepted':False,'independent_receiving_pending':True,'blocked':blocked,'allowed_subprocesses':allowed_subprocesses})
except BaseException as error:
    write('failure.json',{'stage':stage,'exception_type':type(error).__name__,'exception_module':type(error).__module__,'message':str(error),'direct_counts':counts,'e3_accepted':False})
    traceback.print_exc()
    raise
finally:
    if support is not None: write('support-receipt.json',support.receipt)
