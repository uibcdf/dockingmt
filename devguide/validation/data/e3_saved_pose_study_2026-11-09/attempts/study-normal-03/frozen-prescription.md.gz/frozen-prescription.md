# E3 saved-pose comparison and clustering

Owner: [DockingMT #79](https://github.com/uibcdf/dockingmt/issues/79).
Prospective registration: 2026-11-09, issue comment 6746958468; source
`ae0db98560f66ac6be7a933fb053f6e1e9917d99`, editable MolSysMT
`efbe67e1c6042078144bce1db24aa80bb565dbd2`, unchanged native SHA-256
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`.

## Population and prerequisites

Use the original three P59 poses, positions 0/1/2, ranks 1/2/3, from the
[E2 native archive](e2_native_collection_2026-11-07.md). Authenticate all 193
members against manifest SHA-256
`4535ecab26c9fbe4d80bf50fabb48ec3a74ae067979f4e970f5523f703c98e46`.
Original P59 decoded record SHA-256
`c71b4789274f008130ecf512095246e310a18d3856344986f25d174abcde8a0e`;
P69 control `9cdbb66fc60517abd73533d2b4094191057b3b292ebe38396df7d7cc5eb7f8f3`.
Require state `e2-5x72-p59` and receptor state
`e2-5x72-protein-only-provided`; refuse P69 before molecular work.
Preserve original coordinates, scores, histories, rank and producer identities.
Three poses from one original run are not independent molecular cases.

The complete suffix-03 [reference prerequisite](e3_h5msm06_reference_receiving_2026-11-09.md)
passes normal/pm-fs with the corrected text-aware mechanical observer and five
altered-copy refusals. Independent 261-member receiving passes, with zero actual
quantity objects in the mechanical domain (unit-like text remains text).
Primary manifest `ae734a2ecc51a61defbb29a584527ce0acc72df80bb995a23dd8e4faa24d4eda`;
nine-member reader `f60c0dd34f1e8d8da0ed199fa7b685f3a3cbf8f1743eac6df775640612630935`.
Use the same fixed normal-03 source25/reference25/heavy24 H5 files in both new
profiles, not separately regenerated references.

## Frame and identity admission

Pin `tests/data/vina_torsions/5x72.pdb`, provided receptor PDBQT and box by
SHA-256 in the frozen plan. Their provenance is the unchanged upstream Vina
example at commit `3c65c0b3e6c2c1d183f6a175ecb65e3c5ba91645`; retain the fixture README.
Read PDB with `get_missing_bonds=False`; do not assign chemistry to that PDB.
Select P59 A201. Identity order is only a candidate for this fixed pair:
require all 24 per-position elements equal and every Cartesian component within
**0.002 angstrom** of heavy24, plus public positional RMSD under that bound.
No inferred atom map, relabeling, superposition or alternate selection on failure.
Retained reference25 heavy coordinates stay within the original **1e-12 angstrom**.

Public exact-name correspondence matches four unique MET A1 anchors C/O/CA/CB
between original PDB and provided receptor. Require the same component and RMSD
bound and a finite nonplanar public dihedral. This admits only these pinned axes;
it neither validates receptor chemistry/preparation nor implements general frame
recognition. A public 1 nm translation must fail the same component criterion,
with original source unchanged. No centering, rotation, reflection or PBC imaging.

## Measurements and preservation

Reconstruct all three poses through `DockingPose.to_molecular_system` using the
same-axis source25 template. Concatenate with public strict-attribute policy.
Two fresh strict public chemical witnesses admit heavy24 within full fixed25
context: self and independent reference. No graph/H/state/stereo relaxation.
Call public symmetry-corrected and positional pairwise RMSD, independent
symmetry-corrected reference RMSD, complete-linkage primary clustering and
single-linkage sensitivity clustering. Cutoff **2 angstrom**, inclusive `<=`,
medoid representatives, original member order/tie rules. No score-selected member,
local RMSD/matrix/linkage implementation or new native search.

Serialize actual physical output fields with PyUnitWizard QuantityRecord and
explicit length handshakes; preserve provider maps/winners/provenance, array
dtypes/shapes and attribution. New analysis stays separate from original records.
Check source topology/structures/states/mechanics/reports, caller policy, configuration,
support retirement and exact source/import/native custody at completion.
Existing complete analytic/adverse geometry receiving (18 pairwise, 23 clustering,
22 typed refusals per policy) remains applicable only after verifying unchanged
relevant geometry/cutoff/test/native hashes; retain those comparisons in the task.

## Limits and execution

Private task `.molsyssuite/e3-pose-study-20261109`, owners #79/#50, review 2026-11-14.
Direct maxima per profile: three H5 reads, two PDB/PDBQT conversions, three
selections, 16 public getters, four frame RMSD, one name correspondence, one
dihedral, one translation, three pose reconstructions, one concatenation, two
chemical witnesses, two pairwise, one reference RMSD and two cluster calls.
Metadata/copy calls inside supported tools are recorded by their public boundary;
no H/charge/type assignment, search, detector, View or hidden source regeneration.

Run normal then pm/fs serially, identical frozen code/inputs. CPU 0, nice 10,
one native/build worker, monitored **13 GiB available-memory reserve**, 1 GiB
group RSS, 2 GiB address space, 45 CPU/60 wall seconds. Expected RSS below512MiB;
check actual headroom before each cell. No Slurm allocation; original bounded
inconclusive applicability probe retained. Stop on headroom loss; no automatic
restart or increased limits. Preserve every failure and unreached operation.
Compare final physical matrices/reference vectors across policies at **1e-12 nm**,
cluster membership/representatives exactly; canonical matrix byte digests may
honestly differ across float unit roundtrips. Receive records independently without
molecular replay before bounded E3 acceptance. Full scientific accuracy, broader
panel, actual canvas, installed/public/platform and hosted qualification remain
separate. No remote CI or shared installation is authorized by this selection.

One task-setup path typo is preserved before scientific-child creation; E2
hash authentication had completed but no molecular calls occurred. Its corrected
archive name does not change any scientific input, producer or assertion.

## First selection and call correction

Normal-01 fails after three H5 reads, two conversions, two selections and two
getters: our second atom-type request omitted `element="atom"`, leaving the
public getter at its system default. This is consumer invocation misuse, not a
provider defect. Preserve the failed process, logs and unreached operations.
Explicitly name the atom element in both element-inventory requests and execute
a fresh whole suffix-02 selection. Inputs, gates, counts and resource limits
are unchanged; no automatic resource-interruption restart is involved.

Normal-02 passes all physical frame/anchor/nonplanarity/translated-refusal
checks, then fails while serializing the public selection: it is a Python list,
not an array with `.tolist()`. Preserve the whole failed outcome. Replace only
three selection-list serialization/admission expressions with `list(...)`; no
index contents/order or scientific assertion changes. Fresh suffix-03 repeats
the complete selection with the same caps and limits before final receiving.
