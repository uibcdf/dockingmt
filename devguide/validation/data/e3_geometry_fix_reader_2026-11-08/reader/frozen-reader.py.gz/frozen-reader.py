"""Read the original complete geometry controls through the owning unit codec."""
import hashlib
import json
import sys
import numpy as np
import pyunitwizard as puw
from pyunitwizard.record import QuantityRecord, RecordError

def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    def quantity(document,field):
        return puw.get_value(QuantityRecord.from_dict(document[field]).to_quantity(field=field,unit='nm',dimensionality={'[L]':1},form='pint'),to_unit='nm')
    worker=records['producer/worker.py.txt']
    assert hashlib.sha256(worker).hexdigest()=='65627af215163a9c012da536f4450df2892f04db2816d8c8fea6791fc2c49c5c'
    assert obj('producer/worker-identity.json')['worker_byte_identical']
    for row in obj('producer/provider-identities.json'):
        assert hashlib.sha256(records['producer/'+row['frozen']]).hexdigest()==row['sha256']
    fields_read=0
    quantities={}
    for label in ['geometry-normal','geometry-pm_fs']:
        prefix='attempts/'+label+'/'
        outcome=obj(prefix+'resource-outcome.json')
        registration=obj(prefix+'registration.json')
        receipt=obj(prefix+'receipt.json')
        assert records[prefix+'frozen-worker.py']==worker
        assert outcome['outcome']=='PASS' and outcome['exit_code']==0 and outcome['resource_interruption'] is None
        assert outcome['group_terminal'] and not outcome['remaining_live_owned_pids']
        assert receipt['outcome']=='PASS' and receipt['qualification_complete']
        assert receipt['direct_counts']==registration['direct_caps']=={'pairwise':18,'clusters':23,'maps':4,'convert':1,'append':1}
        assert receipt['successful_pairwise_records']==9 and receipt['successful_cluster_records']==10 and receipt['typed_refusals']==22
        assert receipt['source_and_caller_preserved'] and receipt['provider_configuration_restored'] and not receipt['blocked']
        assert not receipt['reference_accepted'] and not receipt['e3_accepted'] and receipt['native_searches']==0
        assert receipt['source_commit']=='d594fb66cd2bd91fec1a31eae1f50e1c05b07d52'
        assert receipt['provider_commit']=='fab8cbccf570a60205a3863aad19dd4b7cfb8d3a'
        assert receipt['provider_native_sha256']=='5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
        provider=obj(prefix+'producer-label.json')
        assert provider['actual_source_commit']==receipt['provider_commit'] and provider['observed_version']==receipt['observed_provider_version']
        rows={};physical={}
        for path,raw in records.items():
            if not path.startswith(prefix) or not path.endswith('.json'):
                continue
            d=json.loads(raw)
            if not isinstance(d,dict) or 'quantity_fields' not in d:
                continue
            name=path[len(prefix):-5];r=d['result'];rows[name]=d
            assert r['software']['molsysmt']==provider['observed_version']
            for field in d['quantity_fields']:
                q=quantity(r,field);physical[name,field]=q
                assert np.isfinite(q).all()
                fields_read+=1
        assert len(rows)==19
        quantities[label]=physical
        for name in ['translation','repeated','empty','singleton','ring-positional','ring-symmetry','ring-cached','ring-identity','ring-anchored']:
            r=rows[name]['result']
            assert r['alignment']==r['periodic_imaging']=='none' and r['cartesian_axes']=='caller_declared_common'
            assert rows[name]['array_types']['pair_indices']['dtype']=='int64'
        np.testing.assert_allclose(physical['translation','rmsd'],[[0,1,2],[1,0,1],[2,1,0]],rtol=0,atol=1e-12)
        np.testing.assert_allclose(physical['repeated','rmsd'],[[0,2,1,0],[2,0,1,2],[1,1,0,1],[0,2,1,0]],rtol=0,atol=1e-12)
        assert rows['repeated']['result']['structure_indices']==[2,0,1,2]
        assert rows['repeated']['result']['pair_indices']==[[1,0],[2,0],[3,0],[2,1],[3,1],[3,2]]
        assert physical['empty','rmsd'].shape==(0,0) and rows['empty']['array_types']['pair_indices']['shape']==[0,2]
        for name in ['ring-symmetry','ring-cached']:
            r=rows[name]['result']
            np.testing.assert_allclose(physical[name,'rmsd'],[[0,0,.2],[0,0,.2],[.2,.2,0]],rtol=0,atol=1e-12)
            assert r['chemistry_checked'] and r['search_scope']=='all_chemical_correspondences'
        assert rows['ring-identity']['result']['search_scope']=='supplied_atom_correspondences'
        assert rows['ring-anchored']['result']['search_scope']=='anchored_chemical_correspondences'
        np.testing.assert_allclose(physical['ring-identity','rmsd'],physical['ring-positional','rmsd'],rtol=0,atol=1e-12)
        assert rows['chain-complete']['result']['cluster_indices']==[0,0,1]
        assert rows['chain-single']['result']['cluster_indices']==[0,0,0]
        assert rows['chain-complete']['result']['inequality']==rows['chain-single']['result']['inequality']=='<='
        np.testing.assert_allclose(physical['chain-complete','cluster_diameters'],[1,0],rtol=0,atol=1e-12)
        np.testing.assert_allclose(physical['chain-single','cluster_diameters'],[2],rtol=0,atol=1e-12)
        assert rows['exact-cutoff']['result']['cluster_indices']==[0,0] and rows['below-cutoff']['result']['cluster_indices']==[0,1,2]
        assert rows['medoid']['result']['representative_indices']==[1] and rows['first']['result']['representative_indices']==[0]
        assert rows['duplicate']['result']['representative_indices']==[0]
        assert rows['empty-cluster']['result']['cluster_offsets']==[0] and rows['singleton-cluster']['result']['cluster_offsets']==[0,1]
        assert obj(prefix+'ring-before.json')==obj(prefix+'ring-after.json') and all(obj(prefix+'source-final.json').values())
        refused=[json.loads(raw) for path,raw in records.items() if path.startswith(prefix) and path.endswith('-refusal.json')]
        assert len(refused)==22 and {x['type'] for x in refused}=={'ArgumentError','StructuralInconsistencyError','UnsupportedHeavyOperationError','MemoryBudgetExceededError'}
    for key,value in quantities['geometry-normal'].items():
        np.testing.assert_allclose(value,quantities['geometry-pm_fs'][key],rtol=0,atol=1e-12)
    for path in ['attempts/geometry-normal/translation.json','attempts/geometry-pm_fs/translation.json']:
        q=obj(path)['result']['rmsd']
        for options in [{'field':'wrong','unit':'nm'},{'field':'rmsd','unit':'ps'}]:
            try:
                QuantityRecord.from_dict(q).to_quantity(**options)
            except RecordError:
                pass
            else:
                raise AssertionError('Invalid receiver handshake accepted')
    terminal=obj('producer/campaign-terminal.json')
    assert terminal['outcome']=='PASS' and terminal['accepted_profiles']==['normal','pm_fs'] and not terminal['e3_accepted']
    assert not any(n=='molsysmt' or n.startswith(('molsysmt.','rdkit')) for n in sys.modules)
    return {'complete_profiles':['normal','pm_fs'],'worker_byte_identical':True,'quantity_fields_received':fields_read,'invalid_quantity_handshakes_refused':4,'typed_refusals_per_profile':22,'inclusive_cutoff_received':True,'source_and_caller_checks_received':True,'molecular_replay':False,'reference_accepted':False,'e3_accepted':False,'native_searches':0}
