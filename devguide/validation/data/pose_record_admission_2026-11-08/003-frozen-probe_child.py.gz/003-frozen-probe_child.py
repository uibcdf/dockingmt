"""Observe empty-pose and malformed-coordinate record reading only."""
from copy import deepcopy
import json
import os
from pathlib import Path

import numpy as np
import pyunitwizard as puw
import dockingmt as dmt

attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
empty = dmt.DockingPose(puw.quantity(np.empty((0, 3)), 'nm'), pose_id='empty-record')
assert empty.n_atoms == 0 and empty.to_dict()['coordinates']['value'] == []
valid = dmt.DockingPose(puw.quantity([[1, 2, 3]], 'nm'), pose_id='valid-record').to_dict()
rows = []
for label, record, reader in [
    ('empty_pose', empty.to_dict(), dmt.DockingPose.from_dict),
    ('empty_pose_in_result', dmt.DockingResult([empty]).to_dict(), dmt.DockingResult.from_dict),
    ('valid_pose', valid, dmt.DockingPose.from_dict),
    ('missing_coordinates', {}, dmt.DockingPose.from_dict),
    ('null_coordinates', {'coordinates': None}, dmt.DockingPose.from_dict),
    ('bad_unit', {'coordinates': {'value': [[1, 2, 3]], 'unit': 'not-a-unit'}}, dmt.DockingPose.from_dict),
]:
    before = deepcopy(record)
    try:
        restored = reader(record)
        outcome = {'accepted': True, 'roundtrip': restored.to_dict() == record}
    except Exception as error:
        outcome = {'accepted': False, 'error': type(error).__name__, 'code': getattr(error, 'code', None), 'field': getattr(error, 'extra', {}).get('arg_name')}
    assert record == before
    rows.append({'case': label, 'reader': outcome, 'caller_preserved': True})
assert not rows[0]['reader']['accepted'] and not rows[1]['reader']['accepted'] and rows[2]['reader']['accepted']
(attempt / 'observations.json').write_text(json.dumps({'rows': rows, 'molecular_operations': 0, 'scope': 'Zero-coordinate records only; no molecular pose or native-input admission'}, indent=2) + '\n')
print(json.dumps({'diagnosis_complete': True, 'rows': len(rows)}))
