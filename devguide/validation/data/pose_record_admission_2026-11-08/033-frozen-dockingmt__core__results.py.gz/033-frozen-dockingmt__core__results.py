from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from copy import deepcopy
from math import isfinite
from numbers import Real
from typing import Any, Iterator

import numpy as np
import pyunitwizard as puw
from argdigest import arg_digest

from dockingmt._private.artifacts import inspect_artifact
from dockingmt._private.serialization import SCHEMA_VERSION, validate_schema_version
from dockingmt._private.smonitor import ArgumentError
from dockingmt.core._scores import (
    comparable_definition,
    make_ranking_record,
    normalize_definitions,
    ranking_history,
)
from dockingmt.core.problem import DockingProblem


def _verify_prepared_recovery(problem, recorded, provenance):
    """Bind supplied docking declarations and available submitted-byte evidence.

    Molecular rendering belongs to the existing MolSysMT-backed prepared writer.
    This checks recorded declarations/bytes, not original molecular identity.
    """
    from dockingmt.preparation import PreparedLigand, PreparedReceptor

    inputs = {'receptor': problem.receptor, 'partner': problem.partner}
    for role, value in inputs.items():
        entry = recorded.get(role, {})
        if entry.get('type') != 'object':
            continue
        serializer = getattr(value, 'to_dict', None)
        if not callable(serializer):
            raise ArgumentError(
                arg_name=role,
                reason='The recorded prepared input declaration requires a matching object, not a replacement representation.',
            )
        try:
            expected = json.dumps(entry.get('value'), sort_keys=True, allow_nan=False)
            actual = json.dumps(serializer(), sort_keys=True, allow_nan=False)
        except (TypeError, ValueError) as exc:
            raise ArgumentError(
                arg_name=role,
                reason='The prepared input declaration must contain finite JSON data.',
            ) from exc
        if actual != expected:
            raise ArgumentError(
                arg_name=role,
                reason='The supplied prepared input declaration differs from the recorded one.',
            )
    prepared = {
        role: value
        for role, value in inputs.items()
        if isinstance(value, (PreparedReceptor, PreparedLigand))
    }
    if provenance.get('backend') != 'vina' or not prepared:
        return
    artifacts = provenance.get('backend_artifacts', {})
    if not isinstance(artifacts, Mapping):
        raise ArgumentError(
            arg_name='backend_artifacts',
            reason='The recorded PDBQT artifacts are invalid.',
        )
    bound = {}
    # Check all retained evidence before requesting any molecular export.
    for role in inputs:
        artifact = artifacts.get(role)
        status, reason, _ = inspect_artifact(artifact, role)
        if status == 'inconsistent':
            raise ArgumentError(arg_name=role, reason=reason)
        if (
            role in prepared
            and isinstance(artifact, Mapping)
            and artifact.get('format') == 'pdbqt'
            and artifact.get('sha256') is not None
        ):
            bound[role] = artifact['sha256']
    for role, expected in bound.items():
        payload = prepared[role].to_pdbqt().encode('utf-8')
        if hashlib.sha256(payload).hexdigest() != expected:
            raise ArgumentError(
                arg_name=role,
                reason='The supplied PDBQT input differs from the recorded representation.',
            )


def _score_error(value: Any, score_name: str, pose_index: int | None) -> ArgumentError:
    return ArgumentError(
        arg_name='scores',
        reason=f"Score '{score_name}' must be a finite real number.",
        score_name=score_name,
        pose_index=pose_index,
        value_type=type(value).__name__,
    )


def _normalize_score(
    value: Any, score_name: str, pose_index: int | None = None
) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise _score_error(value, score_name, pose_index)
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise _score_error(value, score_name, pose_index) from exc
    if not isfinite(number):
        raise _score_error(value, score_name, pose_index)
    return number


def _normalize_scores(scores: Any) -> dict[str, float]:
    if scores is None:
        return {}
    if not isinstance(scores, Mapping):
        raise ArgumentError(
            arg_name='scores',
            reason='Use a mapping of score names to finite real numbers.',
        )
    normalized = {}
    for name, value in scores.items():
        if not isinstance(name, str) or not name.strip():
            raise ArgumentError(
                arg_name='scores', reason='Score names must be nonempty strings.'
            )
        normalized[name] = _normalize_score(value, name)
    return normalized


def _coordinate_values(values: Any) -> np.ndarray:
    """Validate numerical pose-record contents without coercing or copying them."""
    try:
        raw = np.asarray(values)
    except (TypeError, ValueError) as exc:
        raise ArgumentError(
            arg_name='coordinates', reason='Coordinates must have shape (N, 3).'
        ) from exc
    if raw.ndim != 2 or raw.shape[1:] != (3,):
        raise ArgumentError(
            arg_name='coordinates',
            reason=f"'coordinates' must have shape (N, 3), got shape {raw.shape}.",
        )
    if (
        not np.issubdtype(raw.dtype, np.number)
        or not np.isrealobj(raw)
        or not np.isfinite(raw).all()
    ):
        raise ArgumentError(
            arg_name='coordinates',
            reason='Coordinates must contain finite real numbers.',
        )
    return raw


def _ensure_coordinates_quantity(coords: Any) -> Any:
    """Require finite real (N, 3) length data and normalize it to nanometers."""
    if not puw.is_quantity(coords):
        raise ArgumentError(
            arg_name='coordinates',
            reason="'coordinates' must be a physical quantity with length units (e.g. using PyUnitWizard).",
        )
    if not puw.are_compatible(coords, 'nm'):
        unit_str = str(puw.get_unit(coords))
        raise ArgumentError(
            arg_name='coordinates',
            reason=f"'coordinates' has unit '{unit_str}', which is not compatible with length.",
        )
    _coordinate_values(puw.get_value(coords))
    try:
        with np.errstate(over='raise', invalid='raise'):
            normalized = puw.get_value(
                coords, to_unit='nm', value_type=np.ndarray, dtype=float
            )
    except (FloatingPointError, OverflowError) as exc:
        raise ArgumentError(
            arg_name='coordinates',
            reason='Coordinates must remain finite when normalized to nanometers.',
        ) from exc
    return puw.quantity(_coordinate_values(normalized), 'nm')


def _atom_key(record: dict[str, str | None]) -> tuple[str | None, ...]:
    return tuple(
        record.get(field)
        for field in ('atom_id', 'atom_name', 'element', 'group_id', 'group_name')
    )


def _molecular_atom_keys(
    molsys: Any, *, atom_indices: Any = None
) -> list[dict[str, str | None]]:
    """Read identities on an explicit DockingMT pose axis, preserving its order."""
    import molsysmt as msm

    required = ('atom_id', 'atom_type')
    if any(not msm.has_attribute(molsys, attribute) for attribute in required):
        raise ArgumentError(
            arg_name='partner',
            reason='A pose atom map requires source atom IDs and elements.',
        )
    atom_ids = msm.get(molsys, element='atom', atom_id=True)
    n_atoms = int(msm.get(molsys, element='system', n_atoms=True))
    atom_names = (
        msm.get(molsys, element='atom', name=True)
        if msm.has_attribute(molsys, 'atom_name')
        else [None] * n_atoms
    )
    elements = msm.get(
        molsys,
        element='atom',
        atom_type=True,
        chemical_state='structure',
        structure_indices=0,
    )
    group_ids = (
        msm.get(molsys, element='atom', group_id=True)
        if msm.has_attribute(molsys, 'group_id')
        else [None] * n_atoms
    )
    # MolSysMT currently raises IndexError for group-free group_name queries (#233).
    group_names = (
        msm.get(molsys, element='atom', group_name=True)
        if msm.has_attribute(molsys, 'group_name')
        else [None] * n_atoms
    )
    columns = (atom_ids, atom_names, elements, group_ids, group_names)
    if any(len(column) != n_atoms for column in columns):
        raise ArgumentError(
            arg_name='partner', reason='Source atom identity arrays are incomplete.'
        )
    indices = range(n_atoms) if atom_indices is None else atom_indices
    if any(
        column[index] is None or not str(column[index]).strip()
        for column in (atom_ids, elements)
        for index in indices
    ):
        raise ArgumentError(
            arg_name='partner',
            reason='Source atom IDs and elements must be set.',
        )
    records = [
        {
            'atom_id': str(atom_ids[i]),
            'atom_name': str(atom_names[i]) if atom_names[i] is not None else None,
            'element': str(elements[i]),
            'group_id': str(group_ids[i]) if group_ids[i] is not None else None,
            'group_name': str(group_names[i]) if group_names[i] is not None else None,
        }
        for i in indices
    ]
    if len({_atom_key(record) for record in records}) != len(records):
        raise ArgumentError(
            arg_name='partner', reason='Source atom identities are not unique.'
        )
    return records


class DockingPose:
    """A candidate bound configuration tied to molecular state and provenance.

    Parameters
    ----------
    coordinates : Any
        Finite real coordinates of shape (N, 3), with explicit length units.
    scores : dict[str, float], optional
        Finite real scores indexed by nonempty names (e.g. {'vina': -7.5}).
        Numeric values are normalized to Python floats without inferring units.
    rank : int, optional
        Positive 1-indexed integer ranking assigned by an explicit ranking policy.
    pose_id : str, optional
        Unique identifier for the pose.
    partner_state_id : str, optional
        Identifier linking this pose to its specific ligand/partner molecular state.
    receptor_state_id : str, optional
        Identifier linking this pose to its receptor conformation/state.
    metadata : dict[str, Any], optional
        Arbitrary structured annotations (e.g. interaction flags, clusters).
    score_definitions : dict[str, dict[str, Any]], optional
        Declared score semantics, stored in metadata['score_definitions'].
        Absent descriptors remain unknown; units are never inferred from names.
    """

    @arg_digest(
        config='dockingmt._argdigest',
        native_constructor='dockingmt.core.results.DockingPose.__init__',
    )
    def __init__(
        self,
        coordinates: Any,
        scores: dict[str, float] | None = None,
        rank: int | None = None,
        pose_id: str | None = None,
        partner_state_id: str | None = None,
        receptor_state_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        score_definitions: dict[str, dict[str, Any]] | None = None,
    ):
        self._coordinates = coordinates
        self.scores: dict[str, float] = scores
        self.rank = rank
        self.pose_id = pose_id
        self.partner_state_id = partner_state_id
        self.receptor_state_id = receptor_state_id
        self.metadata: dict[str, Any] = dict(metadata) if metadata is not None else {}
        if score_definitions is not None:
            if 'score_definitions' in self.metadata:
                raise ArgumentError(
                    arg_name='score_definitions',
                    reason='Supply descriptors once, through the argument or metadata.',
                )
            self.metadata['score_definitions'] = normalize_definitions(
                score_definitions, self.scores
            )
        elif 'score_definitions' in self.metadata:
            self.metadata['score_definitions'] = normalize_definitions(
                self.metadata['score_definitions'], self.scores
            )

    @property
    def score_definitions(self) -> dict[str, dict[str, Any]]:
        """Validated independent descriptors for this pose's named scores."""
        return normalize_definitions(
            self.metadata.get('score_definitions', {}), self.scores
        )

    @property
    def coordinates(self) -> Any:
        """Atomic coordinates (N, 3) in nanometers."""
        return self._coordinates

    @property
    def n_atoms(self) -> int:
        """Number of atoms in the pose."""
        return int(puw.get_value(self._coordinates).shape[0])

    @arg_digest(config='dockingmt._argdigest')
    def with_scores(
        self,
        scores: dict[str, float],
        score_definitions: dict[str, dict[str, Any]] | None = None,
    ) -> DockingPose:
        """Return an independent pose with additional named evaluations.

        Existing names cannot be replaced. Descriptors describe only the new
        scores; absent descriptors remain unknown. Coordinates, identity, rank,
        prior scores and nested metadata are preserved in detached copies.
        """
        previous = _normalize_scores(self.scores)
        additions = _normalize_scores(scores)
        overlap = previous.keys() & additions.keys()
        if overlap:
            raise ArgumentError(
                arg_name='scores',
                reason=f'Existing score names cannot be replaced: {sorted(overlap)}.',
            )
        definitions = self.score_definitions
        if score_definitions is not None:
            definitions.update(normalize_definitions(score_definitions, additions))
        metadata = deepcopy(self.metadata)
        metadata.pop('score_definitions', None)
        return DockingPose(
            coordinates=deepcopy(self.coordinates),
            scores={**previous, **additions},
            score_definitions=definitions
            if definitions or 'score_definitions' in self.metadata
            else None,
            rank=deepcopy(self.rank),
            pose_id=deepcopy(self.pose_id),
            partner_state_id=deepcopy(self.partner_state_id),
            receptor_state_id=deepcopy(self.receptor_state_id),
            metadata=metadata,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize pose to an independent structured dictionary snapshot."""
        coordinates = _coordinate_values(puw.get_value(self._coordinates))
        definitions = self.score_definitions
        metadata = dict(self.metadata)
        metadata.pop('score_definitions', None)
        record = deepcopy(
            {
                'schema_version': SCHEMA_VERSION,
                'pose_id': self.pose_id,
                'rank': self.rank,
                'partner_state_id': self.partner_state_id,
                'receptor_state_id': self.receptor_state_id,
                'scores': _normalize_scores(self.scores),
                'metadata': metadata,
            }
        )
        if 'score_definitions' in self.metadata:
            record['metadata']['score_definitions'] = definitions
        # tolist owns its new nested lists; copying them again adds no isolation.
        record['coordinates'] = {
            'value': coordinates.tolist(),
            'unit': str(puw.get_unit(self._coordinates)),
        }
        return record

    @classmethod
    @arg_digest(config='dockingmt._argdigest')
    def from_dict(cls, data: dict[str, Any]) -> DockingPose:
        """Reconstruct a pose independently of its supplied dictionary record."""
        validate_schema_version(data, cls.__name__)
        data = deepcopy(data)
        c_info = data.get('coordinates')
        if (
            not isinstance(c_info, Mapping)
            or 'value' not in c_info
            or 'unit' not in c_info
        ):
            raise ArgumentError(
                arg_name='coordinates',
                reason='Supply a coordinate record with both value and unit.',
            )
        # Preserve wire scalar types until admission: NumPy/quantity factories
        # can otherwise turn mixed booleans or numeric strings into real values.
        try:
            values = np.asarray(c_info['value'], dtype=object)
        except (TypeError, ValueError) as exc:
            raise ArgumentError(
                arg_name='coordinates', reason='Coordinates must have shape (N, 3).'
            ) from exc
        if any(
            isinstance(value, (bool, np.bool_)) or not isinstance(value, Real)
            for value in values.flat
        ):
            raise ArgumentError(
                arg_name='coordinates',
                reason='Coordinates must contain finite real numbers.',
            )
        # The wire schema fixes xyz width; [] is the serializer's zero-row output.
        numeric = (
            np.empty((0, 3), dtype=float)
            if values.shape == (0,)
            else np.asarray(c_info['value'])
        )
        numeric = _coordinate_values(numeric)
        try:
            coords = puw.quantity(numeric, c_info['unit'])
        except MemoryError:
            raise
        except Exception as exc:
            raise ArgumentError(
                arg_name='coordinates',
                reason='Supply finite real xyz coordinates with explicit length units.',
            ) from exc
        return cls(
            coordinates=coords,
            scores=data.get('scores'),
            rank=data.get('rank'),
            pose_id=data.get('pose_id'),
            partner_state_id=data.get('partner_state_id'),
            receptor_state_id=data.get('receptor_state_id'),
            metadata=data.get('metadata'),
        )

    @arg_digest(
        config='dockingmt._argdigest',
        native_helper='dockingmt.core.results.DockingPose.get_rmsd',
    )
    def get_rmsd(self, reference: Any, selection: str = 'all') -> Any:
        """Compute the RMSD of this pose against a reference structure or pose.

        Parameters
        ----------
        reference : Any
            A reference DockingPose, coordinate quantity array, or MolSysMT system.
            Molecular references require the pose's verified source atom map.
            Coordinate arrays are compared positionally by explicit caller choice.
        selection : str, default 'all'
            Selection expression if reference is a MolSysMT system. Extra reference
            hydrogens may be omitted from the mapped comparison.

        Returns
        -------
        Any
            RMSD as a PyUnitWizard length quantity.
        """
        import molsysmt as msm

        coords = puw.quantity(
            np.expand_dims(puw.get_value(self._coordinates), axis=0),
            puw.get_unit(self._coordinates),
        )

        ref_sys: Any
        if isinstance(reference, DockingPose):
            keys = self._verified_atom_keys()
            reference_keys = reference._verified_atom_keys()
            reference_lookup = {
                _atom_key(record): index for index, record in enumerate(reference_keys)
            }
            if set(reference_lookup) != {_atom_key(record) for record in keys}:
                raise ArgumentError(
                    arg_name='reference',
                    reason='Pose atom identities differ from reference pose identities.',
                )
            reference_coordinates = puw.get_value(reference._coordinates)[
                [reference_lookup[_atom_key(record)] for record in keys]
            ]
            ref_sys = puw.quantity(
                np.expand_dims(reference_coordinates, axis=0),
                puw.get_unit(reference._coordinates),
            )
        elif puw.is_quantity(reference):
            ref_val = np.asarray(puw.get_value(reference))
            if ref_val.ndim == 2:
                ref_sys = puw.quantity(
                    np.expand_dims(ref_val, axis=0), puw.get_unit(reference)
                )
            else:
                ref_sys = reference
        else:
            keys = self._verified_atom_keys()
            reference_molsys = msm.convert(reference, to_form='molsysmt.MolSys')
            if msm.get(reference_molsys, element='system', n_structures=True) != 1:
                raise ArgumentError(
                    arg_name='reference',
                    reason='Molecular RMSD requires one reference structure.',
                )
            reference_keys = _molecular_atom_keys(reference_molsys)
            selected = msm.select(reference_molsys, selection=selection)
            selected_keys = [reference_keys[int(index)] for index in selected]
            reference_lookup = {
                _atom_key(record): int(index)
                for index, record in zip(selected, selected_keys)
            }
            pose_keys = {_atom_key(record) for record in keys}
            if not pose_keys.issubset(reference_lookup) or any(
                record['element'] != 'H'
                for record in selected_keys
                if _atom_key(record) not in pose_keys
            ):
                raise ArgumentError(
                    arg_name='reference',
                    reason=(
                        'Reference atoms do not match the verified pose map; '
                        'only omitted hydrogens may remain in the reference.'
                    ),
                )
            reference_coordinates = msm.get(
                reference_molsys, element='atom', coordinates=True
            )
            values = puw.get_value(reference_coordinates)[
                0, [reference_lookup[_atom_key(record)] for record in keys], :
            ]
            ref_sys = puw.quantity(
                np.expand_dims(values, axis=0),
                puw.get_unit(reference_coordinates),
            )

        res = msm.structure.get_rmsd(
            coords,
            reference_molecular_system=ref_sys,
            selection='all',
        )
        return res[0]

    def _verified_atom_keys(self) -> list[dict[str, str | None]]:
        keys = self.metadata.get('source_atom_keys')
        if (
            self.metadata.get('pose_atom_order') != 'verified_pdbqt_order'
            or not isinstance(keys, list)
            or len(keys) != self.n_atoms
            or any(not isinstance(record, dict) for record in keys)
            or any(
                any(
                    not isinstance(record.get(field), str) or not record[field]
                    for field in ('atom_id', 'element')
                )
                or any(
                    record.get(field) is not None and not isinstance(record[field], str)
                    for field in ('atom_name', 'group_id', 'group_name')
                )
                for record in keys
            )
            or len({_atom_key(record) for record in keys}) != len(keys)
        ):
            raise ArgumentError(
                arg_name='pose',
                reason='Molecular reconstruction and RMSD require a verified source atom map.',
            )
        return keys

    @arg_digest(config='dockingmt._argdigest')
    def to_molecular_system(self, partner: Any) -> Any:
        """Convert this pose into a MolSysMT molecular system using partner topology.

        Parameters
        ----------
        partner : Any
            The source partner/ligand molecular system or PreparedLigand. Its ordered
            atom identities must match the verified pose map. Omitted hydrogens
            remain absent from the returned molecular system.

        Returns
        -------
        Any
            MolSysMT MolSys instance with this pose's coordinates.
        """
        import molsysmt as msm

        expected_keys = self._verified_atom_keys()
        base_sys: Any
        if hasattr(partner, 'to_molecular_system'):
            base_sys = partner.to_molecular_system()
        else:
            base_sys = msm.convert(partner, to_form='molsysmt.MolSys')
        molsys = msm.copy(base_sys)
        partner_n_atoms = msm.get(molsys, element='system', n_atoms=True)
        selected = self.metadata.get('selected_atom_indices')
        expected_n_atoms = self.metadata.get('selected_partner_n_atoms')
        if selected is not None:
            if (
                expected_n_atoms != partner_n_atoms
                or not isinstance(selected, list)
                or len(selected) != self.n_atoms
                or len(set(selected)) != len(selected)
                or any(
                    not isinstance(i, int) or i < 0 or i >= partner_n_atoms
                    for i in selected
                )
            ):
                raise ArgumentError(
                    arg_name='partner',
                    reason='The pose-to-partner atom indices are invalid.',
                )
            molsys = msm.extract(molsys, selection=selected)
            partner_n_atoms = msm.get(molsys, element='system', n_atoms=True)
        if partner_n_atoms != self.n_atoms:
            raise ArgumentError(
                arg_name='partner',
                reason=(
                    f'Pose has {self.n_atoms} atoms but partner has {partner_n_atoms}; '
                    'a verified pose-to-partner atom map is required.'
                ),
            )
        molecular_keys = _molecular_atom_keys(molsys)
        pose_index_by_key = {
            _atom_key(record): index for index, record in enumerate(expected_keys)
        }
        if {_atom_key(record) for record in molecular_keys} != set(pose_index_by_key):
            raise ArgumentError(
                arg_name='partner',
                reason='Partner atom identities differ from the verified pose map.',
            )
        molecular_order = [
            pose_index_by_key[_atom_key(record)] for record in molecular_keys
        ]
        coords_3d = puw.quantity(
            np.expand_dims(puw.get_value(self._coordinates)[molecular_order], axis=0),
            puw.get_unit(self._coordinates),
        )
        msm.set(molsys, element='atom', coordinates=coords_3d)
        return molsys

    def __repr__(self) -> str:
        if not hasattr(self, '_coordinates'):
            return f'{type(self).__name__}(uninitialized)'
        rank_str = f', rank={self.rank}' if self.rank is not None else ''
        scores_str = f', scores={self.scores}' if self.scores else ''
        return f'DockingPose(n_atoms={self.n_atoms}{rank_str}{scores_str})'


class DockingResult:
    """Structured scientific output of a docking run or protocol execution.

    Parameters
    ----------
    poses : list[DockingPose]
        Collection of candidate docking poses.
    problem_info : dict[str, Any], optional
        Contextual info on the problem (receptor, partner, domain references).
    protocol_info : dict[str, Any], optional
        Resolved protocol choices, parameters and defaults.
    provenance : dict[str, Any], optional
        Execution metadata (backend, versions, random seeds, environment).
    problem : Any, optional
        Original DockingProblem instance if available in-memory.
    """

    @arg_digest(
        config='dockingmt._argdigest',
        native_constructor='dockingmt.core.results.DockingResult.__init__',
    )
    def __init__(
        self,
        poses: list[DockingPose],
        problem_info: dict[str, Any] | None = None,
        protocol_info: dict[str, Any] | None = None,
        provenance: dict[str, Any] | None = None,
        problem: Any = None,
    ):
        self._poses = list(poses)
        self.problem_info: dict[str, Any] = (
            dict(problem_info) if problem_info is not None else {}
        )
        self.protocol_info: dict[str, Any] = (
            dict(protocol_info) if protocol_info is not None else {}
        )
        self.provenance: dict[str, Any] = (
            dict(provenance) if provenance is not None else {}
        )
        self.problem = problem
        ranking_history(self.provenance, detach=False)

    @property
    def ranking_history(self) -> list[dict[str, Any]]:
        """Independent evidence for successive ranking decisions."""
        return ranking_history(self.provenance)

    def __len__(self) -> int:
        return len(self._poses)

    def __getitem__(self, index: int) -> DockingPose:
        return self._poses[index]

    def __iter__(self) -> Iterator[DockingPose]:
        return iter(self._poses)

    @property
    def poses(self) -> list[DockingPose]:
        """List of all docking poses."""
        return list(self._poses)

    @property
    def top_pose(self) -> DockingPose | None:
        """The top-ranked pose (rank 1), or the first pose if unranked."""
        if not self._poses:
            return None
        ranked = [p for p in self._poses if p.rank == 1]
        return ranked[0] if ranked else self._poses[0]

    @arg_digest(config='dockingmt._argdigest')
    def rank_by(self, score_name: str, ascending: bool = True) -> DockingResult:
        """Produce a new DockingResult with poses ranked according to a named score.

        Parameters
        ----------
        score_name : str
            The key in pose.scores to rank by (e.g. 'vina').
        ascending : bool, default True
            If True, lower scores receive top rank (standard for binding affinities/energies).
            If False, higher scores receive top rank.

        Ties preserve input order. Invalid scores are rejected before a ranking
        is returned, including invalid values assigned during later rescoring.
        Declared definitions and molecular-state IDs must match across poses.
        The explicit direction overrides a descriptor's advisory preference.
        Success appends detached scalar evidence to provenance.ranking_history.
        """
        score_values = []
        definition = comparable_definition(self._poses, score_name)
        history = self.ranking_history
        for i, pose in enumerate(self._poses):
            if score_name not in pose.scores:
                raise ArgumentError(
                    arg_name='score_name',
                    reason=f"Pose at index {i} does not have score '{score_name}'. Available: {list(pose.scores.keys())}",
                    score_name=score_name,
                    pose_index=i,
                )
            score_values.append(
                _normalize_score(pose.scores[score_name], score_name, i)
            )

        sorted_indices = sorted(
            range(len(self._poses)),
            key=score_values.__getitem__,
            reverse=not ascending,
        )

        new_poses: list[DockingPose] = []
        for rank_idx, pose_index in enumerate(sorted_indices, start=1):
            pose = self._poses[pose_index]
            new_pose = DockingPose(
                coordinates=pose.coordinates,
                scores=pose.scores,
                rank=rank_idx,
                pose_id=pose.pose_id,
                partner_state_id=pose.partner_state_id,
                receptor_state_id=pose.receptor_state_id,
                metadata=deepcopy(pose.metadata),
            )
            new_poses.append(new_pose)

        new_provenance = deepcopy(
            {
                key: value
                for key, value in self.provenance.items()
                if key != 'ranking_history'
            }
        )
        if not history and 'ranking_policy' in self.provenance:
            previous = self.provenance['ranking_policy']
            if not isinstance(previous, Mapping):
                raise ArgumentError(
                    arg_name='ranking_policy', reason='Use a structured ranking policy.'
                )
            history.append(
                {
                    'schema_version': '1.0',
                    'evidence': 'legacy_policy_only',
                    'score_name': previous.get('score_name'),
                    'ascending': previous.get('ascending'),
                    'policy': deepcopy(previous),
                }
            )
        history.append(
            make_ranking_record(
                self._poses,
                score_name,
                ascending,
                definition,
                score_values,
                sorted_indices,
                'rank_by',
            )
        )
        new_provenance['ranking_history'] = history
        new_provenance['ranking_policy'] = {
            'score_name': score_name,
            'ascending': ascending,
        }

        return DockingResult(
            poses=new_poses,
            problem_info=deepcopy(self.problem_info),
            protocol_info=deepcopy(self.protocol_info),
            provenance=new_provenance,
            problem=self.problem,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize the result to an independent versioned dictionary snapshot."""
        ranking_history(self.provenance, detach=False)
        record = deepcopy(
            {
                'schema_version': SCHEMA_VERSION,
                'problem_info': self.problem_info,
                'protocol_info': self.protocol_info,
                'provenance': self.provenance,
            }
        )
        snapshots = []
        for pose in self._poses:
            serializer = pose.to_dict
            snapshot = serializer()
            # The native serializer owns its output. Preserve the result's
            # defensive copy for custom serializers with unknown ownership.
            if getattr(serializer, '__func__', None) is not DockingPose.to_dict:
                snapshot = deepcopy(snapshot)
            snapshots.append(snapshot)
        record['poses'] = snapshots
        return record

    @classmethod
    @arg_digest(config='dockingmt._argdigest')
    def from_dict(cls, data: dict[str, Any]) -> DockingResult:
        """Reconstruct a result independently of its supplied dictionary record."""
        validate_schema_version(data, cls.__name__)
        for pose_data in data.get('poses', []):
            validate_schema_version(pose_data, 'DockingPose')
        data = deepcopy(data)
        poses = [DockingPose.from_dict(p) for p in data.get('poses', [])]
        return cls(
            poses=poses,
            problem_info=data.get('problem_info'),
            protocol_info=data.get('protocol_info'),
            provenance=data.get('provenance'),
        )

    @arg_digest(config='dockingmt._argdigest', record_factory=True)
    def reconstruct_problem(
        self, receptor: Any = None, partner: Any = None
    ) -> DockingProblem:
        """Recover the recorded problem, checking available input evidence.

        File-backed inputs can be loaded from the manifest alone. Molecular
        objects that were not serialized must be supplied explicitly.
        Prepared inputs must match stored declarations and available Vina input
        hashes, rendered through their native writer. Missing legacy evidence
        cannot establish original chemistry or full-precision coordinate identity.
        No preparation, scoring or search is performed. A failure preserves the
        previously attached problem and the saved record.
        """
        if not self.problem_info:
            raise ArgumentError(
                arg_name='problem_info',
                reason='The result has no recorded docking problem to reconstruct.',
            )
        problem = DockingProblem.from_dict(
            self.problem_info, receptor=receptor, partner=partner
        )
        _verify_prepared_recovery(problem, self.problem_info, self.provenance)
        self.problem = problem
        return problem

    @arg_digest(
        config='dockingmt._argdigest',
        native_helper='dockingmt.core.results.DockingResult.get_rmsds',
    )
    def get_rmsds(self, reference: Any, selection: str = 'all') -> list[Any]:
        """Compute the RMSD of each pose in this result against a reference structure.

        Parameters
        ----------
        reference : Any
            Reference pose, coordinate array, or MolSysMT system.
        selection : str, default 'all'
            Selection expression if reference is a MolSysMT system.

        Returns
        -------
        list[Any]
            List of RMSD length quantities for each pose.
        """
        return [
            pose.get_rmsd(reference=reference, selection=selection)
            for pose in self._poses
        ]

    def __repr__(self) -> str:
        if not hasattr(self, '_poses'):
            return f'{type(self).__name__}(uninitialized)'
        return f'DockingResult(n_poses={len(self._poses)})'
