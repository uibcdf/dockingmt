"""Retain independent reader and evidence-publication producers, no science."""
import gzip
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
output = root / 'devguide/validation/data/panel_receptor_models_reader_2026-11-08'
output.mkdir(exist_ok=False)
sources = []
for label in ['seal-01', 'seal-02', 'reader-01']:
    for path in sorted((task / label).iterdir()):
        if path.is_file():
            sources.append(path)
sources.append(Path(__file__))
rows = []
for index, path in enumerate(sources):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    relative = f'{index:03d}-{path.name}.gz'
    (output / relative).write_bytes(stored)
    rows.append({'original_path': str(path.relative_to(task)), 'path': relative, 'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(), 'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'schema': 'dockingmt.panel_receptor_reference_reader_evidence@1', 'owner': 'uibcdf/dockingmt#33', 'source_commit': 'b014b2598a1194eaee51c139e105e00ee259758a', 'primary_manifest_sha256': '8111abe7233e7b21920959c53a8e8407273cbd5f35a822c3875c7bb8faf0d847', 'scope': 'Independent stdlib record reading and actual publication producers; no molecular receiving or reference acceptance', 'files': rows}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {'stage': 'reader-seal', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members': len(rows), 'manifest_sha256': hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest(), 'molecular_operations': 0}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
