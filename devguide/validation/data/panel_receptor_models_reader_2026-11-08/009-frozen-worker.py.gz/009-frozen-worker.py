"""Freeze actual reference attempts and minimal diagnostics; no molecular imports."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
output = root / 'devguide/validation/data/panel_receptor_models_2026-11-08'
output.mkdir(exist_ok=False)
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
attempts = ['templates-normal', 'receiving-02/templates-normal', 'receiving-03/templates-normal', 'persistence-diagnostic/diagnostic-normal', 'argument-diagnostic/argument-diagnostic-normal', 'argument-diagnostic-02/argument-diagnostic-normal']
selected = []
for path in sorted(task.iterdir()):
    if path.is_file() and path.suffix == '.json':
        selected.append((path.name, path))
for label in ['receiving-02', 'receiving-03', 'persistence-diagnostic', 'argument-diagnostic', 'argument-diagnostic-02']:
    for name in ['plan.json', 'hypothesis.json', 'campaign-terminal.json']:
        path = task / label / name
        if path.is_file():
            selected.append((str(path.relative_to(task)), path))
for label in attempts:
    for path in sorted((task / label).iterdir()):
        if path.is_file():
            selected.append((str(path.relative_to(task)), path))
source = root / '.molsyssuite/panel-receiving-20261107/provider-source-faab'
source_files = ['molsysmt/physchem/get_peptide_chemical_template.py', 'molsysmt/_private/peptide_chemical_template.py', 'molsysmt/data/databases/peptide_templates/residue_fragments.json', 'molsysmt/basic/compare.py', 'molsysmt/_private/argdigest/argument/component_type.py', 'molsysmt/native/molsys.py', 'devguide/h5msm_format.md']
review = {}
for relative in source_files:
    path = source / relative
    blob = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'faab727ca5b5c9078e2f2e505971fc0ea1cf1a8d:' + relative], text=True).strip()
    review[relative] = {'source': 'faab727ca5b5c9078e2f2e505971fc0ea1cf1a8d', 'git_blob': blob, 'sha256': sha(path)}
    selected.append(('provider-source/' + relative, path))
assert review['molsysmt/_private/argdigest/argument/component_type.py']['git_blob'] == '5a882f3c084a7f15850e060a7c1578fcc90d658a'
(task / 'source-review.json').write_text(json.dumps(review, indent=2) + '\n')
selected.append(('source-review.json', task / 'source-review.json'))
candidate = json.loads((task / 'templates-normal/frozen-candidate.json').read_text())
for key, field in [('prefix', 'provider_files_sha256'), ('consumer_prefix', 'consumer_files_sha256'), ('viewer_prefix', 'viewer_files_sha256')]:
    prefix = Path(candidate[key])
    assert {str(p.relative_to(prefix)): sha(p) for p in prefix.rglob('*') if p.is_file()} == candidate[field]
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/conda-meta')
current_metadata = {p.name: sha(p) for p in routine.glob('*.json')}
metadata_change = json.loads((task / 'routine-metadata-change.json').read_text())
assert current_metadata == metadata_change['metadata_sha256_now']
assert metadata_change['added'] == ['giflib-6.1.3-hebe6cf0_2.json', 'openjdk-21.0.10-h1602c4f_22.json', 'xorg-libxt-1.3.1-h7cc23a3_1.json']
assert not metadata_change['modified'] and not metadata_change['removed']
assert all(current_metadata[k] == value for k, value in candidate['routine_metadata_sha256'].items())
custody = {'private_provider_consumer_viewer_payloads_unchanged': True, 'routine_metadata_unchanged': False, 'old_routine_metadata_unchanged': True, 'added_routine_packages': metadata_change['added'], 'fresh_scientific_receiving_of_changed_environment': False, 'scope': 'Post-process file custody; three concurrent additions after final successful diagnostic, no original metadata removed/changed; not unreached final live checks of failed scientific selections', 'attempts': {}}
for label in attempts:
    resource = json.loads((task / label / 'resource-outcome.json').read_text())
    expected = 'PASS' if label.startswith(('persistence-diagnostic/', 'argument-diagnostic-02/')) else 'FAIL'
    assert resource['outcome'] == expected and resource['group_terminal'] and resource['resource_interruption'] is None and not resource['remaining_live_owned_pids']
    custody['attempts'][label] = {k: resource[k] for k in ['outcome', 'elapsed_seconds', 'sampled_peak_group_rss_bytes', 'group_terminal', 'resource_interruption']}
(task / 'custody.json').write_text(json.dumps(custody, indent=2) + '\n')
selected.append(('custody.json', task / 'custody.json'))
terminal = {'owner': 'uibcdf/dockingmt#33', 'whole_reference_selections_attempted': 3, 'whole_reference_selections_accepted': 0, 'successful_diagnostic_selections': 2, 'failed_task_argument_diagnostic': 1, 'further_molecular_work_permitted': False, 'next': 'Receive provider646 correction before a fresh whole six-chain/two-policy selection; preserve all old failures and provider558/644/environment holds'}
(task / 'task-terminal.json').write_text(json.dumps(terminal, indent=2) + '\n')
selected.append(('task-terminal.json', task / 'task-terminal.json'))
unique = {}
for name, path in selected:
    if name in unique:
        assert unique[name].resolve() == path.resolve()
    unique[name] = path
selected = list(unique.items())
rows = []
for number, (name, path) in enumerate(selected):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    destination = f'{number:03d}-{Path(name).name}.gz'
    (output / destination).write_bytes(stored)
    rows.append({'original_path': name, 'path': destination, 'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(), 'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()})
assert len({r['original_path'] for r in rows}) == len(rows)
manifest = {'schema': 'dockingmt.panel_receptor_reference_evidence@1', 'owner': 'uibcdf/dockingmt#33', 'provider_issue': 'uibcdf/molsysmt#646', 'source_commit': 'b014b2598a1194eaee51c139e105e00ee259758a', 'classification': 'Three failed whole reference selections, documented canonical-storage diagnostic, one failed task-only diagnostic and two-policy minimal valid-flag rejection; zero admitted receptors/cases', 'files': rows}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {'stage': 'seal', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members': len(rows), 'manifest_sha256': sha(output / 'manifest.json'), 'stored_bytes': sum(r['bytes'] for r in rows), 'molecular_operations': 0, 'whole_reference_selections_accepted': 0}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
