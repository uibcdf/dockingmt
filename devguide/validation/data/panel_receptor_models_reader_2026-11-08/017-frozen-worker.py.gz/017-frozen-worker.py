"""Independent stdlib-only reading of failed-reference and argument evidence."""
import gzip
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
folder = root / 'devguide/validation/data/panel_receptor_models_2026-11-08'
expected = '8111abe7233e7b21920959c53a8e8407273cbd5f35a822c3875c7bb8faf0d847'
assert hashlib.sha256((folder / 'manifest.json').read_bytes()).hexdigest() == expected
manifest = json.loads((folder / 'manifest.json').read_text())
assert manifest['owner'] == 'uibcdf/dockingmt#33' and len(manifest['files']) == 156
records = {}
for row in manifest['files']:
    path = folder / row['path']
    assert path.resolve().parent == folder.resolve()
    stored = path.read_bytes()
    assert len(stored) == row['bytes'] and hashlib.sha256(stored).hexdigest() == row['sha256']
    raw = gzip.decompress(stored)
    assert len(raw) == row['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == row['decoded_sha256']
    assert row['original_path'] not in records
    records[row['original_path']] = raw
def read(name):
    return json.loads(records[name])
labels = ['templates-normal', 'receiving-02/templates-normal', 'receiving-03/templates-normal', 'persistence-diagnostic/diagnostic-normal', 'argument-diagnostic/argument-diagnostic-normal', 'argument-diagnostic-02/argument-diagnostic-normal']
for label in labels:
    resource = read(label + '/resource-outcome.json')
    expected_outcome = 'PASS' if label.startswith(('persistence-diagnostic/', 'argument-diagnostic-02/')) else 'FAIL'
    assert resource['outcome'] == expected_outcome and resource['group_terminal'] and not resource['remaining_live_owned_pids'] and resource['resource_interruption'] is None
    assert resource['policy']['available_reserve_bytes'] == 13 * 1024**3
    registration = read(label + '/registration.json')
    for relative, digest in registration['frozen_sha256'].items():
        assert hashlib.sha256(records[label + '/' + relative]).hexdigest() == digest
    for name, digest in registration['input_sha256'].items():
        assert hashlib.sha256(records[label + '/' + name]).hexdigest() == digest
first = read('templates-normal/failure.json')
second = read('receiving-02/templates-normal/failure.json')
third = read('receiving-03/templates-normal/failure.json')
assert first['stage'] == 'template_summaries' and first['direct_counts']['factory_attempts'] == 1 and first['direct_counts']['h5_writes'] == 0
assert second['stage'] == 'h5_reads' and second['direct_counts']['factory_attempts'] == second['direct_counts']['h5_writes'] == second['direct_counts']['h5_reads'] == 1
assert third['stage'] == 'component_comparisons' and third['exception_type'] == 'ArgumentError' and third['direct_counts']['component_comparisons'] == 1 and "component_type" in third['message']
for row in [first, second, third]:
    assert row['bound_receptors_admitted'] == 0 and row['whole_template_selection_accepted'] is False
    assert row['direct_counts']['pdb_conversions'] == row['direct_counts']['assemblies'] == row['direct_counts']['group_tables'] == 1
for relative in ['hypothesis.json', 'receiving-02/hypothesis.json', 'receiving-03/hypothesis.json']:
    assert records[relative] == records['hypothesis.json']
diagnostic = read('persistence-diagnostic/diagnostic-normal/receipt.json')
assert diagnostic['direct_counts'] == {'h5_reads': 2, 'domain_exports': 4, 'summaries': 2, 'history_reads': 2}
assert not diagnostic['provider_persistence_received'] and not diagnostic['whole_reference_selection_accepted']
assert len(diagnostic['observations']) == 2
differences = read('persistence-differences.json')['differences']
assert differences == [{'path': 'chemical_states.states[0].components.columns.component_name.dtype', 'before': 'str', 'after': 'string'}, {'path': 'chemical_states.states[0].components.columns.component_type.dtype', 'before': 'str', 'after': 'string'}]
for row in diagnostic['observations']:
    assert row['topology_equal'] and not row['chemical_states_history_equal'] and not row['exact_snapshot_equal'] and row['n_structures_before'] is row['n_structures_after'] is None and not row['structural_domain_present_after'] and row['caller_preserved']
initial_argument = read('argument-diagnostic/argument-diagnostic-normal/failure.json')
assert initial_argument['exception_type'] == 'AttributeError' and not any(initial_argument['direct_counts'].values())
argument = read('argument-diagnostic-02/argument-diagnostic-normal/receipt.json')
assert argument['direct_counts'] == {'constructors': 2, 'comparisons': 6} and not argument['provider_boundary_received'] and not argument['whole_reference_selection_accepted']
assert [r['profile'] for r in argument['observations']] == ['normal', 'pm_fs']
for row in argument['observations']:
    assert row['control_before'] == row['control_after'] == {'n_atoms': True} and row['caller_preserved']
    assert row['observed_exception']['type'] == 'ArgumentError' and row['observed_exception']['valid_component_type_flag_rejected']
custody = read('custody.json')
assert custody['private_provider_consumer_viewer_payloads_unchanged'] and not custody['routine_metadata_unchanged'] and custody['old_routine_metadata_unchanged'] and not custody['fresh_scientific_receiving_of_changed_environment']
change = read('routine-metadata-change.json')
assert change['added'] == ['giflib-6.1.3-hebe6cf0_2.json', 'openjdk-21.0.10-h1602c4f_22.json', 'xorg-libxt-1.3.1-h7cc23a3_1.json'] and not change['modified'] and not change['removed']
terminal = read('task-terminal.json')
assert terminal['whole_reference_selections_attempted'] == 3 and terminal['whole_reference_selections_accepted'] == 0 and terminal['successful_diagnostic_selections'] == 2 and terminal['failed_task_argument_diagnostic'] == 1 and not terminal['further_molecular_work_permitted']
receipt = {'stage': 'reader', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'primary_manifest_sha256': expected, 'members_verified': 156, 'scientific_imports': [], 'molecular_operations': 0, 'whole_reference_selections_accepted': 0, 'failed_whole_reference_selections': 3, 'successful_diagnostic_selections': 2, 'minimal_comparison_flag_profiles': 2, 'provider_boundary_received': False, 'provider_issue': 'uibcdf/molsysmt#646', 'new_independent_docking_cases': 0, 'routine_metadata_added_only': change['added']}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
