# Installed reconstruction and composition — 2026-11-09

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with
molecular delegation #49 and complete functional plan #73. Status: consumer correction received in the new installed wheel; provider receiving active.

## Question and inputs

Receive actual public native reconstruction, known-axis permutation and
multi-frame composition against the existing normally installed private wheel.
This is bounded software integration, not docking search, scoring, a new
scientific accuracy case or actual browser/canvas receiving.

Runtime producer `bba53f602c2e30a5817808bda303c0f736405651`, wheel version
`0.0.0+349.gbba53f6`, SHA256
`6ec6fe0214b95ece7850f404ae0c1a281e75775e6d3dd80cb0f1c95b7853fac1`.
Qualification base `dc4a0c51c576518f7b40121d0475d1868787b6c2`. Reuse its verified
private receiver/source-free harness from `installed-small-fixtures-20261109`.
All 67 runtime paths, 606 declared helper/data records, original fixture producers
and source/installed origins remain separate and unchanged.

Selection: both `tests/test_flexible_reconstruction.py` and
`tests/test_molecular_delegation.py`, with one explicit exclusion:
`test_actual_vina_pose_reconstructs_source_free_prepared_axis`. That case performs
real search and is outside this registration; it is not passed or silently skipped.
Expected 18 executed cases, one deselected. Preserve every assertion/input byte.
Use shared SDK `95f693be10c9205ab9b912cb53453710a207bf45` staging and installed
origin checks; actual engine/viewer construction and scoring/search are refused.

Fixtures are finite three/six-atom manual representations, a small explicitly
prepared six-heavy-atom ligand, and the existing public alanine-dipeptide H5MSM
input (95KiB, demo-manifest declaration: 22 atoms). Record its exact source/path,
bytes/SHA256, actual public atom/frame query and input immutability before use.
The catalog's 12-versus-22 contradiction remains MolSysMT #677, until actually
received evidence distinguishes the declarations. No new dataset generation.

First execute complete normal and pm/fs cells on the unchanged received cohort:
MolSysMT `efbe67e1`, Viewer `1187fc18`, ArgDigest `07126411`, PyUnitWizard
`f82b618e`, SMonitor `c1b6ce29`, DepDigest `032d345b`; retain exact source/native
hashes and stale distribution labels separately. No rebuild/reinstallation.

## Provider delivery review

MolSysMT #675 is closed with delivery `af46ea3f31afb9f77455b9910af3537a9cd267ae`.
The local checkout is still efbe67e1. Remote comparison reports a 22-commit
fast-forward with no Rust/build-source delta; review actual local fetched changes,
source cleanliness, metadata/dependencies and native bytes before updating the
editable checkout. Do not infer client receiving merely from issue closure.

If that update is admitted, keep baseline outcomes immutable and register the new
exact cohort before repeating complete reconstruction/composition and the prior
64-case/20-case preparation/export controls. Expected diagnostic change: the
index-only off-axis warnings disappear; genuine observation/axis warnings and
all numerical/identity/failure controls remain. Do not change consumer tests,
warning filters, provider logic, user remotes or shared metadata to force a pass.
No native build is authorized by this review. Other providers stay fixed.

## Resource and custody limits

Shared host: 64,978,440,192B RAM,20 logical CPUs; initially60,810,313,728B
available, load0.33/0.30/0.34,97% interval CPU idle, no active swap I/O or memory
PSI. Slurm commands exist but no allocation is present; earlier scheduler
applicability probing was inconclusive. Free capacity is not reserved.

Each native cell is serial, CPU0/nice10, one native/build worker,13GiB available
reserve,1GiB group RSS cap,2GiB address space,45 CPU/60 wall seconds; expected
peak512MiB. Monitor owned descendants and preserve every failure/interruption.
Never automatically restart native work after a headroom stop. Actual GUI/native
build holds, public/platform/hosted evidence and SSH-source context #100 under
MolSysSuite #178 remain separate.

Retain task-local exact programs, registrations, reports, input/data identities,
provider transition and all outcomes under
`.molsyssuite/installed-reconstruction-20261109`, owners#47/#49/#50,
review2026-11-14. It depends on the original bba53f6 wheel/receiver/harness and
authenticated 103-file E5 import engine; release custody only when all owners
permit. No shared installation, package publication, remote workflow or new
molecular experiment is part of this receiving.


## Qualification-root correction before baseline execution

The first baseline attempt admits the unchanged public input (22 atoms, one
structure) but the shared support binder refuses before pytest: the old plain
export discovers the enclosing repository's newer dc4a0c5 HEAD, whereas the
supplied immutable qualification identity is bba53f6. The byte inventory itself
is unchanged. This is a task-root mismatch, not an installed product failure;
retain the original attempt and source-data observation.

A dedicated shared-object local clone now has its own actual detached bba53f6
HEAD. Both runtime source directories are deliberately removed;606 support/input
records stay exact and the original normally installed receiver is reused. The
shared verifier remains untouched and checks real selected-file/Git bindings.
No candidate identity is omitted, rewritten or borrowed from the later parent
checkout; no clean-whole-tree claim follows after runtime removal. `setup-01`
passes with no installation, build or scientific test. Re-execute the complete
baseline selection under both policies using this independently anchored root.


## Native materialization defect #104 and registered source selection

Baseline-normal-02 executes18 cases with no errors/skips and one explicit
search deselection. Baseline-pm-fs-01 executes18 with17 passes/one original failure:
source-backed materialization unconditionally sets unchanged coordinates on its
independent copy, changing canonical nm bits. Preserve both populations; source
and provider-native/input files stay exact. The first source-red setup stops on
a retained reference-wheel hash mismatch before tests. Corrected source-red-02
executes24 new controls with20 failures/4 passes. Source-green-01 passes24 after
a private exact native-coordinate comparison is shared with export: native
materialization still copies, but only real coordinate edits invoke the setter.
The new guards include both roles, all nine unit pairs, exact unchanged native
snapshots, one-ULP edit transport and original copy/read/set MemoryError identity.

Measured pilot peak is below300MiB and the shared reserve remains ample. Receive
a complete source selection containing the two original modules, the new24-case
regression and existing molecular-variant ownership module: expected52 executed,
one explicit search deselection, normal then pm/fs. Also receive the complete
20-case export-unit regression separately under both policies, since #103's
comparison is now reused. All original scientific assertions, fixture/producers,
606 support rows and provider/native bytes remain unchanged. Changes are confined
to the four existing preparation modules and new regression; no runtime path is
added. Generic reconstruction still applies coordinates as before; source-free
parser/permutation behavior is unchanged. Source success requires a genuinely new
wheel before claiming installed correction. MolSysMT remains efbe67e1 throughout
this isolated consumer correction; fetched source97a9857 is not yet merged.


Source-complete-normal-01 executes52 passing cases, but qualification correctly
fails afterward: two public-method docstrings were edited during that cell.
Their final file hashes differ from its frozen inputs. This population is not
accepted as a final source pass, and its raw passing pytest output plus failed
custody check are preserved. No resource interruption occurred. Repeat the whole
52-case selection under fixed runtime/test bytes; do not salvage a partial pass.


## Source checkpoint for native-copy correction

Final fixed source populations pass under both caller policies: the complete
52-case reconstruction/materialization/ownership selection (one explicit search
exclusion), and the20-case export-unit regression. The24-case pilot is a separate
earlier population, not extra independent coverage. New24-case guards retain the
original20 failures/4 passes; both-copy/read/set identity and all nine unit pairs
now pass. Source-complete-normal-01 remains unqualified after concurrent docstring
edits, despite passing pytest. Corrected whole source cells have exact stable
runtime/test/helper bytes before and after execution.

Both public materializers keep their independent provider copy. Unchanged native
coordinates are not reinserted through a setter; exact explicit prepared edits
still are. The shared private comparison performs public native/PyUnitWizard
reads, adds no scientific tolerance or public runtime path, and preserves generic
and source-free behavior. Current policies for available native chemistry and
mechanics are unchanged. All606 support declarations/input producers remain exact.

Source-mode execution is explicitly a measured working-tree overlay on dc4a0c5.
The reused source-mode registration's bba53f6 labels name the retained reference
wheel; they do not claim that the new uncommitted source existed in that commit.
Original registrations stay immutable; task-local source-provenance clarification
and frozen runtime/test SHA256 inputs make that distinction explicit. Future
installed claims require their own real committed producer.

The fetched provider main97a9857 contains #675 but is not yet merged. Rust tree,
pyproject and native build/package inputs are unchanged. Keep MolSysMTefbe67e1
fixed through source/new-consumer-wheel receiving, then independently receive the
provider diagnostic update with original/new cohorts separate. No release, remote
CI, metadata reinstall or native build is part of this checkpoint.


## Genuine new consumer wheel on the original provider cohort

Committed producer `aeae47d50c5e90687c2558437cb22cf8f271ce85` builds private wheel
`dockingmt-0.0.0+351.gaeae47d-py3-none-any.whl`,157821B, SHA256
`0b303ae371466a6736e8d194a89a54048f8bc51de3cd293cdc68c06050ae042b`.
All67 runtime paths, generated version, source payload, wheel RECORD, license,
PEP610 archive identity, ordinary private pip installation/check and origins pass.
Only the four preparation files and generated version differ from bba53f6;
METADATA changes only Version. No dependency, public payload path, support record,
original data/fixture producer or shared environment installation changes.

The independently anchored installed qualification root has its own actual detached
producer HEAD, with both runtime source directories removed. The new receiver
passes complete52-case reconstruction/materialization/ownership and20-case export
controls under normal and pm/fs policies on the unchanged original provider cohort.
Each52-case cell retains one explicit real-search deselection and28 warnings
(25 index diagnostics, three legacy-H5MSM warnings); export retains20 index warnings.
There are no test errors/skips, actual engine/viewer operations or mutated inputs.

The first installed52-case attempt reaches its60-second wall limit after raw pytest
passes; no final integrity receipt exists, so it is a retained resource interruption,
not qualified success. A task-local review extends elapsed allowance to90 seconds
while keeping45 CPU seconds,CPU0/nice10,one worker,13GiB reserve,1GiB group RSS and
2GiB address space. Repeated whole cells pass in32–43 seconds with stable inputs;
no headroom stop, native rebuild or increased parallelism occurs. Source gates also
pass Ruff,index,shared resources/release contract,diff and29 administrative tests
plus five subtests, without importing scientific packages.

## Registered provider receiving — exact source-only transition

Following immutable old-cohort receiving, the clean editable MolSysMT checkout
fast-forwards efbe67e1 to `0c6f9c746dbd10b02dfe8474a5af280b857ace0d`.
That reviewed26-commit transition includes #675's af46ea3 correction and #677's
0c6f9c7 catalog correction. Later owner changes have also been reviewed; the
caller-scoped selection/capping, cached PDB producer/version, angular analysis,
constraint translation and viewer-panel changes do not justify broader claims.
Rust tree remains `fb25b2eac60b6e706c712e788119b3dad94329fe`; actual native SHA256
remains `5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`.
No Rust/build/package/data bytes, source cleanliness, shared installed metadata or
other provider identities change. Existing distribution version labels stay distinct
from actual source/native identities; no reinstall is needed for this Python update.

Receive complete52-case and20-case consumer selections plus the existing64-case
preparation/map/writer/ownership selection, each normal then pm/fs against the same
new consumer wheel and frozen new cohort. Expected index-only warning removal:
52-case warnings28 to three legacy-H5MSM warnings;20/64-case warnings to zero.
Keep all assertions and warning filters exact. Also receive six original owner
guards separately: five regenerated-index diagnostics cases (including a real
lost-time observation warning) and the actual catalog/manifest/public-input query.
This owner-source test copying preserves byte identities and is not presented as
consumer installed qualification. The public input remains the exact96624B,
SHA256 `92ec5f1d3e2b2e753891488c7e984631609819ab07b1b046b2c7b312bed47069`
legacy fixture,22 atoms/one structure. CI source pins, E4 records, fixed candidates,
public matrices and actual Viewer1187fc18 remain independent and unchanged.


### Provider finalization resource review

Provider-complete-normal-01 writes a passing52-case pytest result and final
integrity receipt, then its process exits on SIGKILL. The whole cell is failed,
not accepted; its original monitor reports no classified resource interruption.
The historical guard has a45-second hard CPU limit, consistent with that exit,
but no original CPU accounting proves the cause. There is no memory/headroom
warning. Preserve the raw unclassified signal and the explicit task review.

Subsequent cells retain one CPU,nice10,one worker,13GiB available reserve,1GiB RSS
and2GiB address space, with60 soft/65 hard CPU seconds and90 wall seconds. This
task-local launcher records child user/system CPU and diagnoses a soft CPU-limit
signal; it does not edit the frozen historical guard. Provider-complete-pm-fs-01
finishes under its original45-second CPU allowance. Repeat the complete normal
selection with the bounded finalization allowance and unchanged scientific bytes;
no passing pytest result overrides a failed process or integrity check.
