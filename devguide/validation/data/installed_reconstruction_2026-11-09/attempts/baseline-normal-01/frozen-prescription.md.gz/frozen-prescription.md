# Installed reconstruction and composition — 2026-11-09

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with
molecular delegation #49 and complete functional plan #73. Status: registered.

## Question and inputs

Receive actual public native reconstruction, known-axis permutation and
multi-frame composition against the existing normally installed private wheel.
This is bounded software integration, not docking search, scoring, a new
scientific accuracy case or actual browser/canvas receiving.

Runtime producer `bba53f602c2e30a5817808bda303c0f736405651`, wheel version
`0.0.0+349.gbba53f6`, SHA256
`6ec6fe0214b95ece7850f404ae0c1a281e75775e6d3dd80cb0f1c95b7853fac1`.
Qualification base `dc4a0c51c576518f7b40121d0475d1868787b6c2`. Reuse its verified
private receiver/source-free harness from `installed-small-fixtures-20261109`.
All 67 runtime paths, 606 declared helper/data records, original fixture producers
and source/installed origins remain separate and unchanged.

Selection: both `tests/test_flexible_reconstruction.py` and
`tests/test_molecular_delegation.py`, with one explicit exclusion:
`test_actual_vina_pose_reconstructs_source_free_prepared_axis`. That case performs
real search and is outside this registration; it is not passed or silently skipped.
Expected 18 executed cases, one deselected. Preserve every assertion/input byte.
Use shared SDK `95f693be10c9205ab9b912cb53453710a207bf45` staging and installed
origin checks; actual engine/viewer construction and scoring/search are refused.

Fixtures are finite three/six-atom manual representations, a small explicitly
prepared six-heavy-atom ligand, and the existing public alanine-dipeptide H5MSM
input (95KiB, demo-manifest declaration: 22 atoms). Record its exact source/path,
bytes/SHA256, actual public atom/frame query and input immutability before use.
The catalog's 12-versus-22 contradiction remains MolSysMT #677, until actually
received evidence distinguishes the declarations. No new dataset generation.

First execute complete normal and pm/fs cells on the unchanged received cohort:
MolSysMT `efbe67e1`, Viewer `1187fc18`, ArgDigest `07126411`, PyUnitWizard
`f82b618e`, SMonitor `c1b6ce29`, DepDigest `032d345b`; retain exact source/native
hashes and stale distribution labels separately. No rebuild/reinstallation.

## Provider delivery review

MolSysMT #675 is closed with delivery `af46ea3f31afb9f77455b9910af3537a9cd267ae`.
The local checkout is still efbe67e1. Remote comparison reports a 22-commit
fast-forward with no Rust/build-source delta; review actual local fetched changes,
source cleanliness, metadata/dependencies and native bytes before updating the
editable checkout. Do not infer client receiving merely from issue closure.

If that update is admitted, keep baseline outcomes immutable and register the new
exact cohort before repeating complete reconstruction/composition and the prior
64-case/20-case preparation/export controls. Expected diagnostic change: the
index-only off-axis warnings disappear; genuine observation/axis warnings and
all numerical/identity/failure controls remain. Do not change consumer tests,
warning filters, provider logic, user remotes or shared metadata to force a pass.
No native build is authorized by this review. Other providers stay fixed.

## Resource and custody limits

Shared host: 64,978,440,192B RAM,20 logical CPUs; initially60,810,313,728B
available, load0.33/0.30/0.34,97% interval CPU idle, no active swap I/O or memory
PSI. Slurm commands exist but no allocation is present; earlier scheduler
applicability probing was inconclusive. Free capacity is not reserved.

Each native cell is serial, CPU0/nice10, one native/build worker,13GiB available
reserve,1GiB group RSS cap,2GiB address space,45 CPU/60 wall seconds; expected
peak512MiB. Monitor owned descendants and preserve every failure/interruption.
Never automatically restart native work after a headroom stop. Actual GUI/native
build holds, public/platform/hosted evidence and SSH-source context #100 under
MolSysSuite #178 remain separate.

Retain task-local exact programs, registrations, reports, input/data identities,
provider transition and all outcomes under
`.molsyssuite/installed-reconstruction-20261109`, owners#47/#49/#50,
review2026-11-14. It depends on the original bba53f6 wheel/receiver/harness and
authenticated 103-file E5 import engine; release custody only when all owners
permit. No shared installation, package publication, remote workflow or new
molecular experiment is part of this receiving.
