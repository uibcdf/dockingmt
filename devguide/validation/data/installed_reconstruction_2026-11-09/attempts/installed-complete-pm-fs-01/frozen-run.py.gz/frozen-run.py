"""Finite monitored installed receiving; task-local orchestration only."""
import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2];task=Path(__file__).parent
label,selection,profile=sys.argv[1:];assert profile in ['normal','pm_fs']
attempt=task/label;attempt.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py';assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}];assert len(nodes)==6
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':90}
assert available()>policy['available_reserve_bytes']+512*1024**2
for name in ['run.py','worker.py',selection+'.json']:shutil.copyfile(task/('setup_worker.py' if name=='worker.py' and selection=='setup' else 'source_worker.py' if name=='worker.py' and selection.startswith('source-') else 'installed_worker.py' if name=='worker.py' and selection.startswith('installed-') else name),attempt/('frozen-'+name))
shutil.copyfile(root/'devguide/validation/installed_reconstruction_2026-11-09.md',attempt/'frozen-prescription.md')
shutil.copyfile(guard,attempt/'frozen-resource-guard.py')
reg={'owner':'uibcdf/dockingmt#47','scope':'Actual installed finite reconstruction/composition controls; no search/scoring/new accuracy experiment','policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':512*1024**2,'profile':profile,'selection':selection,'qualification_source':'bed8a8a4a52ee60ddd38e763f9463c357c27192c','runtime_source':'9a40e385d951b0521f6509de6b127083b78be61c','frozen_sha256':{p.name:sha(p) for p in attempt.iterdir() if p.is_file()}}
reg['qualification_source']='bba53f602c2e30a5817808bda303c0f736405651';reg['runtime_source']=reg['qualification_source']
if selection.startswith('installed-'):
 artifact=json.loads((task/'artifact.json').read_text());reg.update(qualification_source=artifact['source_commit'],runtime_source=artifact['source_commit'],runtime_wheel_sha256=artifact['wheel_sha256'])
(attempt/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
engine=root/'.molsyssuite/e5-timed-replay-20261107/layouts-admission-01/producer/engine'
env=os.environ.copy();env.update(DMT_SMALL_ROOT=str(root),DMT_SMALL_TASK=str(task),DMT_SMALL_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(attempt/'tmp'),XDG_CACHE_HOME=str(attempt/'cache'),MPLCONFIGDIR=str(attempt/'mpl'),MAKEFLAGS='-j1',CMAKE_BUILD_PARALLEL_LEVEL='1',LD_LIBRARY_PATH=str(engine/'lib')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else ''))
for name in ['tmp','cache','mpl']:(attempt/name).mkdir()
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:env[key]='1'
py=(task/'receiver/bin/python') if selection.startswith('installed-') else root/'.molsyssuite/installed-small-fixtures-20261109/receiver/bin/python'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
 process=subprocess.Popen([str(py),'-I','-B',str(attempt/'frozen-worker.py')],cwd=attempt,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);outcome=monitor(process,policy)
outcome['outcome']='PASS' if outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
if (attempt/'receipt.json').exists():
 receipt=json.loads((attempt/'receipt.json').read_text());print(json.dumps({k:receipt[k] for k in ['counts','pytest_exit_code','engine_attempts','provider_call_counts','warnings'] if k in receipt}))
if outcome['outcome']!='PASS':print((attempt/'stdout.log').read_text()[-2400:]);print((attempt/'stderr.log').read_text()[-1400:]);raise SystemExit(1)
