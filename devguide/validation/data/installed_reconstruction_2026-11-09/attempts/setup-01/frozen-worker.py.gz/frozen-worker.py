"""Give the reused consumer qualification its own actual source commit."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path(os.environ['DMT_SMALL_ROOT']);task=Path(os.environ['DMT_SMALL_TASK']);attempt=Path(os.environ['DMT_SMALL_ATTEMPT'])
producer='bba53f602c2e30a5817808bda303c0f736405651';old=root/'.molsyssuite/installed-small-fixtures-20261109'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def command(args,name,cwd=attempt):
 with (attempt/(name+'.log')).open('xb') as stream:subprocess.run(args,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,check=True)
harness=task/'harness';assert not harness.exists()
command(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(root),str(harness)],'clone')
command(['git','-c','core.hooksPath=/dev/null','checkout','--detach',producer],'checkout',harness)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=harness,text=True).strip()==producer
assert not subprocess.check_output(['git','status','--porcelain'],cwd=harness)
inputs=json.loads((old/'qualification-inputs.json').read_text())
for name,digest in inputs.items():assert sha(harness/name)==digest
for name in ['dockingmt','molsysviewer_dockingmt']:shutil.rmtree(harness/name)
reference=json.loads((old/'installation.json').read_text());reference['harness']=str(harness);reference['original_installation_record']=str(old/'installation.json');reference['qualification_source']=producer
(task/'receiver-reference.json').write_text(json.dumps(reference,indent=2)+'\n');(task/'qualification-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
receipt={'actual_qualification_head':producer,'own_git_root':subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=harness,text=True).strip(),'source_runtime_removed':True,'original_receiver_reused_without_installation':True,'original_qualification_inputs_unchanged':True,'scope':'Selected support bytes are bound to their own immutable source; no claim of whole clean working tree after runtime removal'}
(attempt/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
