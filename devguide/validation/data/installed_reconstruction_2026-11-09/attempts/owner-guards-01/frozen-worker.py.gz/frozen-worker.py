"""Receive six exact upstream guards separately from consumer installed tests."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
root=Path(os.environ['DMT_SMALL_ROOT']);task=Path(os.environ['DMT_SMALL_TASK']);attempt=Path(os.environ['DMT_SMALL_ATTEMPT']);provider=root.parent/'molsysmt'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
reg=json.loads((attempt/'registration.json').read_text());cohort=json.loads((attempt/'frozen-provider-cohort.json').read_text());assert cohort['molsysmt']['commit']==subprocess.check_output(['git','-C',str(provider),'rev-parse','HEAD'],text=True).strip() and not subprocess.check_output(['git','-C',str(provider),'status','--porcelain'])
for group in ['python_sha256','native_sha256']:
 for name,digest in cohort['molsysmt'][group].items():assert sha(provider/name)==digest
paths=json.loads((attempt/'frozen-owner-guards.json').read_text());inputs={name:sha(provider/name) for name in paths};save(attempt/'qualification-inputs.json',inputs)
engine=root/'.molsyssuite/e5-timed-replay-20261107/layouts-admission-01/producer/engine';sys.path.insert(0,str(engine/'lib/python3.14/site-packages'))
import pyunitwizard as puw
import molsysmt as msm
assert Path(msm.__file__).resolve().is_relative_to(provider/'molsysmt')
import pytest
with tempfile.TemporaryDirectory(prefix='owner-guards-',dir=attempt) as tmp:
 selected=[]
 for name in paths:
  source=provider/name;stored=attempt/'inputs/provider'/name;stored.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,stored);dest=Path(tmp)/Path(name).name;shutil.copyfile(stored,dest);selected.append(str(dest))
 with puw.context(default_form='pint',default_parser='pint',standard_units=['pm','fs','K','mole','dalton','coulomb','J/mol','radians']):
  policy=puw.configure.report();status=int(pytest.main(['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'--import-mode=importlib','--confcutdir='+tmp,'-o','pythonpath=','-o','cache_dir='+str(attempt/'pytest-cache')]+selected));assert puw.configure.report()==policy
counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
from pytest_receptor import read_artifact
events=read_artifact(attempt/'events.jsonl');assert events.complete and counts=={'tests':6,'failures':0,'errors':0,'skipped':0}
for name,digest in inputs.items():assert sha(provider/name)==digest
for group in ['python_sha256','native_sha256']:
 for name,digest in cohort['molsysmt'][group].items():assert sha(provider/name)==digest
assert not subprocess.check_output(['git','-C',str(provider),'status','--porcelain'])
save(attempt/'receipt.json',{'counts':counts,'pytest_exit_code':status,'receptor_final':events.final.data,'warnings':events.final.data['counts']['warnings'],'source_owner':'uibcdf/molsysmt','source_commit':cohort['molsysmt']['commit'],'original_source_inputs':inputs,'temporary_pytest_root_retired':not Path(tmp).exists(),'consumer_installed_gate':False,'scope':'Five #675 owner cases including real off-axis time warning, plus actual #677 catalog/manifest/public-input guard; original bytes, isolated ordinary pytest'})
raise SystemExit(status)
