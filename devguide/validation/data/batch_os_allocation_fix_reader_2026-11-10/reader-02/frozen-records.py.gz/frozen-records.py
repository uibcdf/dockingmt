"""Seal and independently read finite actual-engine software controls."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/batch-os-allocation-fix-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/batch_os_allocation_fix_2026-11-10';companion=root/'devguide/validation/data/batch_os_allocation_fix_reader_2026-11-10'
qualified=['dockingmt/batch.py','dockingmt/core/outcome.py','tests/test_batch.py']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.batch_os_allocation_fix@1','owner':'uibcdf/dockingmt#106','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'qualification_base':'85d91c1d98bbac83988e5d9274b36753a5fc29eb','runtime_producer':'Explicit source overlay on base, bound by qualified hashes; old aeae47d artifact is comparison only','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored actual-engine software evidence; zero native/molecular replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 for name in qualified:paths.append((root/name,'qualified/'+name))
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 import ast
 from collections import Counter
 measured={};cohort=d('producer/expected-cohort.json');refs=d('producer/reference-fixtures.json')
 assert d('producer/support-source-check.json')['checked']==606 and d('producer/support-source-check.json')['source_sha256_unchanged']
 for label,tests,failures,code,runs in [('red-01',0,0,4,0),('red-02',1,1,1,0),('batch-normal-01',45,0,0,10),('batch-pm-fs-01',45,0,0,10)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['counts']=={'tests':tests,'failures':failures,'errors':0,'skipped':0} and row['pytest_exit_code']==code and row['warnings']==0 and row['scope']=='source; no new installed artifact'
  assert row['source_origins']=={} and row['cohort_unchanged'] and d(prefix+'cohort.json')==cohort and not row['forbidden_operations']
  assert b"assert Path(dmt.__file__).resolve()==root/'dockingmt/__init__.py'" in data[prefix+'frozen-worker.py']
  assert b'verify_inputs();' in data[prefix+'frozen-worker.py']
  counts=row['engine_call_counts'];assert counts.get('__init__',0)==counts.get('dock',0)==runs and row['provider_call_counts']=={}
  if runs:
   assert len(row['exports'])==39
   calls=d(prefix+'engine-calls.json');assert calls==row['engine_calls'] and all(c['outcome']=='PASS' for c in calls)
   for c in calls:
    params=c['parameters']
    if c['call']=='__init__':assert params['cpu']==1 and params['sf_name'] in ['vina','vinardo'] and params['seed']==123
    if c['call']=='compute_vina_maps':assert params['center']==[0.0]*3 and params['box_size']==[10.0]*3
    if c['call']=='dock':assert params['exhaustiveness']==1 and 1<=params['n_poses']<=2
    for role in ['receptor','partner']:
     if role not in c:continue
     info=c[role];raw=data[prefix+'inputs/backend/'+str(c['run'])+'/'+role+'.pdbqt'];assert hashlib.sha256(raw).hexdigest()==info['sha256']==refs['MINIMAL_REC_PDBQT' if role=='receptor' else 'MINIMAL_LIG_PDBQT']['sha256'];assert info['atom_records']==(4 if role=='receptor' else 2)
   maps=d(prefix+'native-maps.json');engine=d(prefix+'frozen-engine-receipt.json')['paths'];native='lib/python3.14/site-packages/vina/_vina_wrapper.cpython-314-x86_64-linux-gnu.so';assert [v for k,v in maps.items() if k.endswith('/'+native)]==[engine[native]]
   for export in row['exports']:assert hashlib.sha256(data[prefix+export['file']]).hexdigest()==export['sha256']
  measured[label]={'tests':tests,'failures':failures,'pytest_exit':code,'actual_native_searches':runs}
 assert b'file or directory not found' in data['attempts/red-01/stderr.log']
 assert b'DID NOT RAISE' in data['attempts/red-02/stdout.log']+data['attempts/red-02/stderr.log']
 assert data['attempts/batch-normal-01/frozen-worker.py']==data['attempts/batch-pm-fs-01/frozen-worker.py']
 green=d('attempts/batch-normal-01/frozen-qualification-inputs.json');assert green==d('attempts/batch-pm-fs-01/frozen-qualification-inputs.json')
 red=d('attempts/red-02/frozen-qualification-inputs.json');assert set(red)==set(green) and [n for n in red if red[n]!=green[n]]==['dockingmt/batch.py']
 assert hashlib.sha256(data['producer/baseline-batch.py.txt']).hexdigest()==red['dockingmt/batch.py']
 original=data['producer/baseline-test_batch.py.txt'];current=data['qualified/tests/test_batch.py'];old_nodes=Counter(ast.dump(n,include_attributes=False) for n in ast.parse(original).body);new_nodes=Counter(ast.dump(n,include_attributes=False) for n in ast.parse(current).body);assert not old_nodes-new_nodes and sum((new_nodes-old_nodes).values())==3
 probe=d('attempts/original-installed-diagnostic/receipt.json');rows=probe['rows'];assert probe['controlled_exceptions_only'] and not probe['actual_memory_exhaustion'] and not probe['native_execution']
 assert rows[0]['propagated'] and rows[0]['same_exception'] and rows[0]['calls']==['first','bad'] and not rows[1]['propagated'] and rows[1]['errno']==12 and rows[1]['calls']==['first','bad','third'] and rows[2]['errno']==2 and rows[2]['calls']==['first','bad','third']
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   r=json.loads(raw);assert r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids'] and r['minimum_available_bytes']>13*1024**3
   assert r['outcome']==('FAIL' if '/red-' in name else 'PASS')
 for name in qualified:assert (root/name).read_bytes()==data['qualified/'+name] and hashlib.sha256(data['qualified/'+name]).hexdigest()==green[name]
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),populations=measured,qualified_sources=3,initial_source_import_checked_by_executed_driver=True,serialized_post_execution_source_origins_available=False,original_test_declarations_preserved=True,actual_source_native_searches=20,installed_correction_received=False,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json']);path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete and row['counts']==counts and row['receptor_final']==events.final.data
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':row['pytest_exit_code'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==4 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','reader-02','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1600])
