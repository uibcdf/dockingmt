"""Sealing, independently reading and checking the exact completed records."""
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time

root = Path(os.environ.get('DMT_RECORD_ROOT', str(Path(__file__).resolve().parents[2])))
task = root / '.molsyssuite/plan-push-20261109'
source_commit = '9b077fabf41e19ffdfb945bc7aa3fb6c53265e0f'
stage = sys.argv[1]
assert stage in ('seal','reader','reader-seal','checks','committed')
py = '/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python'
primary = root / 'devguide/validation/data/declaration_io_final_2026-11-09'
companion = root / 'devguide/validation/data/declaration_io_final_reader_2026-11-09'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def seal(folder, paths):
    folder.mkdir(exist_ok=False)
    rows=[]
    for original,relative in paths:
        raw=original.read_bytes()
        blob=gzip.compress(raw,compresslevel=6,mtime=0)
        destination=folder/(relative+'.gz')
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(blob)
        rows.append({'path':relative+'.gz','original_path':relative,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
    manifest={'schema':'dockingmt.declaration_io_receiving@1','source_commit':source_commit,'provider_commit':'efbe67e1c6042078144bce1db24aa80bb565dbd2','owner':'uibcdf/dockingmt#97','criterion_owner':'uibcdf/dockingmt#97','files':rows}
    (folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}

def read_archive(folder, expected):
    assert sha(folder/'manifest.json')==expected['manifest_sha256']
    manifest=json.loads((folder/'manifest.json').read_text())
    assert manifest['source_commit']==source_commit and len(manifest['files'])==expected['members']
    decoded={}
    for row in manifest['files']:
        blob=(folder/row['path']).read_bytes()
        assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256']
        raw=gzip.decompress(blob)
        assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256']
        decoded[row['original_path']]=raw
    return decoded

if len(sys.argv)>2 and sys.argv[2]=='worker':
    attempt=Path(os.environ['DMT_RECORD_ATTEMPT'])
    archive_expectations=json.loads((attempt/'frozen-archives-list.json').read_text()) if stage in ['checks','committed'] else []
    receipt={'stage':stage,'source_commit':source_commit,'outcome':'PASS','qualification_complete':True}
    if stage=='seal':
        names=['run.py','test_child.py','read_records.py','original-test_engines.py.txt','reporting-tools-receipt.json','unit-support-receipt.json','registry.py','source-custody.json','admin.py','admin-before-indentation-correction.py.txt','sealing-setup-failure.json','admin-initial-envelope.py.txt']
        paths=[(task/name,'producer/'+name+('.txt' if name.endswith('.py') else '')) for name in names]
        paths += [(p,'registry/'+p.name) for p in sorted(task.glob('registry-*.json'))]
        for label in ['red-normal-01','green-normal-01','green-normal-02','green-pm_fs-02']:
            paths.extend((p,'attempts/'+label+'/'+p.name) for p in sorted((task/label).iterdir()) if p.is_file())
        sealed=seal(primary,paths)
        (task/'reader-input.json').write_text(json.dumps(sealed,indent=2)+'\n')
        receipt.update(sealed)
    elif stage=='reader':
        expected=json.loads((task/'reader-input.json').read_text())
        records=read_archive(primary,expected)
        parser=attempt/'frozen-reader.py'
        registration=json.loads((attempt/'registration.json').read_text())
        assert sha(parser)==registration['reader_sha256']
        tools=json.loads(records['producer/reporting-tools-receipt.json'])
        tools_prefix=Path(tools['prefix'])
        assert {str(p.relative_to(tools_prefix)):sha(p) for p in tools_prefix.rglob('*') if p.is_file()}==tools['files_sha256']
        sys.path.insert(0,str(tools_prefix))
        reader_attempt=attempt
        for label in ['red-normal-01','green-normal-01','green-normal-02','green-pm_fs-02']:
            (attempt/(label+'-events.jsonl')).write_bytes(records['attempts/'+label+'/events.jsonl'])
        exec(compile(parser.read_text(),str(parser),'exec'),globals())
        receipt.update(verify_records(records))
        receipt.update(received_manifest_sha256=expected['manifest_sha256'],members_verified=expected['members'])
    elif stage=='reader-seal':
        directory=task/'reader-01'
        paths=[(p,'reader/'+p.name) for p in sorted(directory.iterdir()) if p.is_file()]
        paths.append((task/'reader-input.json','reader-input.json'))
        sealed=seal(companion,paths)
        (task/'companion-input.json').write_text(json.dumps(sealed,indent=2)+'\n')
        receipt.update(sealed)
    else:
        sdk=root/'.molsyssuite/publication-sdk'
        assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45'
        assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
        env=os.environ.copy()
        env['DOCKINGMT_SUITE_ROOT']=str(root/'.molsyssuite/sdk')
        checks=[]
        def check(directory):
            commands=[('indexes',[py,'-B','devtools/devguide_index.py','--check']),('resources',[py,'-B',str(sdk/'devtools/scripts/noarch_conda.py'),'--root',str(directory),'--plan','devtools/conda-build/release_plan.example.toml']),('publication',[py,'-B',str(sdk/'devtools/scripts/conda_release_contract.py'),str(directory)])]
            commands=[('ruff',[str(Path(py).parent/'ruff'),'check','.', '--extend-exclude','dockingmt-migration-2026-11-06']),('format',[str(Path(py).parent/'ruff'),'format','--check','.', '--extend-exclude','dockingmt-migration-2026-11-06'])]+commands
            for name,command in commands:
                with (attempt/(name+'.log')).open('xb') as stream:
                    result=subprocess.run(command,cwd=directory,env=env,stdout=stream,stderr=subprocess.STDOUT)
                checks.append({'name':name,'exit_code':result.returncode})
                assert result.returncode==0,(name,(attempt/(name+'.log')).read_text()[-3000:])
        if stage=='checks':
            check(root)
            subprocess.run(['git','diff','--check'],cwd=root,check=True)
            checks.append({'name':'diff','exit_code':0})
            assert not subprocess.check_output(['git','diff','--name-only','--','molsysviewer_dockingmt','dmt_test_support','devtools'],cwd=root)
            expected=json.loads((task/'reader-input.json').read_text())
            assert sha(primary/'manifest.json')==expected['manifest_sha256']
            reader=json.loads((task/'reader-01/receipt.json').read_text())
            assert reader['received_manifest_sha256']==expected['manifest_sha256']
            assert reader['outcome']=='PASS' and reader['complete_profiles']==['normal','pm_fs'] and reader['issues_received']==[97,98,99] and reader['test_or_molecular_replays']==0
            for relative,digest in json.loads((task/'green-normal-02/registration.json').read_text())['inputs_sha256'].items():
                assert sha(root/relative)==digest
            for expected_archive in archive_expectations:
                decoded=read_archive(root/'devguide/validation/data'/expected_archive['name'],expected_archive)
                del decoded
            checks.append({'name':'exact-new-archives-and-qualified-inputs','exit_code':0,'archives':len(archive_expectations),'members':sum(x['members'] for x in archive_expectations)})
        else:
            assert not subprocess.check_output(['git','diff','--name-only'],cwd=root)
            assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
            head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
            assert subprocess.check_output(['git','rev-parse','HEAD^'],cwd=root,text=True).strip()==source_commit
            with tempfile.TemporaryDirectory(prefix='dmt-e4-editable-committed-',dir='/tmp') as tmp:
                directory=Path(tmp)/'source'
                directory.mkdir()
                archive=Path(tmp)/'source.tar'
                subprocess.run(['git','archive','--format=tar','--output',str(archive),head],cwd=root,check=True)
                with tarfile.open(archive) as stream:
                    stream.extractall(directory,filter='data')
                check(directory)
                for relative,digest in json.loads((task/'green-normal-02/registration.json').read_text())['inputs_sha256'].items():
                    assert sha(directory/relative)==digest
                for expected_archive in archive_expectations:
                    decoded=read_archive(directory/'devguide/validation/data'/expected_archive['name'],expected_archive)
                    del decoded
                checks.append({'name':'exact-new-archives-and-qualified-inputs','exit_code':0,'archives':len(archive_expectations),'members':sum(x['members'] for x in archive_expectations)})
            receipt['committed_source']=head
        receipt['checks']=checks
    (attempt/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))
    raise SystemExit(0)

suffix=sys.argv[2] if len(sys.argv)>2 else '01'
assert len(suffix)==2 and suffix.isdigit()
attempt=task/(stage+'-'+suffix)
attempt.mkdir(exist_ok=False)
guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
assert len(nodes)==6
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available()>policy['available_reserve_bytes']+512*1024**2
shutil.copyfile(Path(__file__),attempt/'frozen-admin.py')
shutil.copyfile(guard,attempt/'frozen-resource-guard.py')
if stage in ['checks','committed']:
    shutil.copyfile(task/'archives-list.json',attempt/'frozen-archives-list.json')
if stage=='reader':
    shutil.copyfile(task/'read_records.py',attempt/'frozen-reader.py')
(attempt/'registration.json').write_text(json.dumps({'stage':stage,'source_commit':source_commit,'policy':policy,'estimated_peak_group_rss_bytes':512*1024**2,'initial_available_bytes':available(),'worker_sha256':sha(attempt/'frozen-admin.py'),'reader_sha256':sha(attempt/'frozen-reader.py') if stage=='reader' else None,'scope':'Source-record sealing, independent reading or documentation qualification; no molecular replay'},indent=2)+'\n')
env=os.environ.copy()
env.update(DMT_RECORD_ROOT=str(root),DMT_RECORD_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1')
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:
    env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen([py,'-B','-I']+([] if stage=='reader' else ['-S'])+[str(attempt/'frozen-admin.py'),stage,'worker'],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
    outcome=monitor(process,policy)
try:
    r=json.loads((attempt/'receipt.json').read_text())
    semantic=r['outcome']=='PASS' and r['qualification_complete'] and r['stage']==stage and r['source_commit']==source_commit
except Exception as error:
    semantic=False
    outcome['qualification_diagnostic']=type(error).__name__+': '+str(error)
outcome['outcome']='PASS' if semantic and outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
if outcome['outcome']!='PASS':
    print((attempt/'stderr.log').read_text()[-6000:])
    raise SystemExit(1)
print((attempt/'stdout.log').read_text()[-2500:])
