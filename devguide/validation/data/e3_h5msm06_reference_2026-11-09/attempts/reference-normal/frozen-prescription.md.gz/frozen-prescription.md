# E3 reference receiving through public H5MSM 0.6

Owners: [DockingMT #79](https://github.com/uibcdf/dockingmt/issues/79),
[#88](https://github.com/uibcdf/dockingmt/issues/88), provider
[MolSysMT #256](https://github.com/uibcdf/molsysmt/issues/256).
Registered before execution, 2026-11-09. DockingMT source `ae0db98560f66ac6be7a933fb053f6e1e9917d99`;
provider `efbe67e1c6042078144bce1db24aa80bb565dbd2`.

## Provider handoff and prospective storage amendment

The maintainer requests checking current provider progress and continuing the
accepted plan. The #256 owner has delivered public experimental H5MSM 0.6 with
mechanics, explicitly requested by `format_version='0.6'`; the default remains
0.5. The provider issue stays open for independent P5 receiving and the final
stable-root/default-writer freeze. Its source evidence is not client acceptance.
#558 remains open; #642 already has editable-client receiving and is not rerun.

Bounded suite-status inspection refreshes seven relevant component references.
DockingMT's human migration directory is preserved. MolSysMT is clean/27 behind
and is fast-forwarded from `fab8cbccf` to the exact owner main above; the other
sources stay fixed, including deliberately unrefreshed Viewer `1187fc18` (54
behind). All 118 changed paths contain no Rust/Cargo/Fortran/build or project
metadata/instruction change. Native bytes remain SHA-256
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`;
no provider build or reinstall occurs. Source/import/file hashes and distribution
labels are recorded independently; no new public package version is inferred.

The [original current-producer paired-control prescription](e3_source_control_receiving_2026-11-08.md)
remains authoritative for its population, scientific assertions and limits.
Create a fresh complete selection with exactly one prospective storage change:
add `format_version='0.6'` to its existing public `msm.convert` writer call.
Only annotate the receiving receipt's format identity in addition. This keeps
the original H5MSM persistence question and complete native snapshot equality;
it is not a substitute transport, private codec, removed mechanical state or
reinterpretation of an old failed run.

Keep both original SDF hashes, historical source PDBQT bytes/authentication,
independent current-producer unnormalized preparation, treatment/control complete
PDBQT equality, two explicit H-policy operations and their typed maps/history,
strict full39/prepared25 correspondence, stereochemistry and H/heavy-coordinate
controls. Keep all four native writes, both complete readbacks, source/caller/
support/custody assertions and original per-operation caps. No new native search,
RMSD, clustering, common-receptor-frame or independent molecular case is admitted
by this reference prerequisite.

## Execution and stop rule

Execute complete normal then pm/fs in separate fresh processes. Serial CPU 0,
nice 10, one native/build worker, monitored **13 GiB available-memory reserve**,
1 GiB group RSS, 2 GiB address space and 45 CPU/60 wall-second bounds per cell.
Expected peak below 512 MiB; original small references only. The direct host
has no Slurm allocation; preserve the original bounded inconclusive scheduler
probe. Current preflight shows about 60 GB available, low load, zero sampled
swap activity and no memory pressure. Headroom is not reserved capacity.

Preserve any failed/interrupted attempt; stop on unavailable headroom and do
not automatically restart or raise bounds. Preserve both original failed
campaigns and their unreached pm/fs/final checks. New source receiving cannot
retroactively pass them. Authenticate all producer/input/output/tool/native
bytes and independently read records without replay. If both complete profiles
pass, receive/archive #88's criterion correction, then preregister remaining
E3 saved-pose/common-frame/comparison/clustering work separately.

Private task `.molsyssuite/e3-h5msm06-20261109`, owners #79/#88/#50, review
2026-11-14. Preserve migration, shared environment, old wheels/receivers and the
historical native-build interruption. No shared install, remote CI, publication,
tag, actual browser/comm/canvas or restart of the held build. Final applicable
local and fresh committed-source checks precede `[skip ci]` publication.
