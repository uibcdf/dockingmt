"""Execute the prospectively amended E3 paired-control selection."""
import ast
from datetime import datetime,timezone
import hashlib
import importlib.metadata as md
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2]
task=Path(__file__).parent
profile=sys.argv[1]
assert profile in ['normal','pm_fs'] and not (task/'campaign-terminal.json').exists()
suffix='-'+sys.argv[2] if len(sys.argv)>2 else ''
attempt=task/('reference-'+profile+suffix)
attempt.mkdir(exist_ok=False)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

guard=root/'.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert sha(guard)=='3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
nodes=[n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n,ast.FunctionDef) and n.name in {'available','memory','limits','group_members','stop_owned_group','monitor'}]
assert len(nodes)==6
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard),'exec'),globals())
policy={'cpu':0,'nice':10,'workers':1,'available_reserve_bytes':13*1024**3,'group_rss_limit_bytes':1024**3,'address_space_bytes':2*1024**3,'cpu_seconds':45,'wall_seconds':60}
assert available()>policy['available_reserve_bytes']+1024**3
old_controller=root/'.molsyssuite/e4-evidence-editable-20261108/run_receiving.py'
source=old_controller.read_text()
block=source[source.index("native=root.parent/'molsysmt/molsysmt/_rust.abi3.so'"):source.index('composition_bytes=')]
block=block.replace('542c5c5853a64ed9472a3317449e900f33f9b952','ae0db98560f66ac6be7a933fb053f6e1e9917d99').replace('2325038e8c68157f5c730693ffbb8535f0b45540','efbe67e1c6042078144bce1db24aa80bb565dbd2')
exec(compile(block,str(old_controller)+'#composition','exec'),globals())
composition_bytes=(json.dumps(composition,indent=2)+'\n').encode()
if profile=='normal':
    (task/'composition.json').write_bytes(composition_bytes)
else:
    assert (task/'composition.json').read_bytes()==composition_bytes
    previous=task/('reference-normal'+suffix)
    assert json.loads((previous/'resource-outcome.json').read_text())['outcome']=='PASS'
    assert sha(previous/'frozen-worker.py')==sha(task/'worker.py')
original=json.loads((task/'original-plan.json').read_text())
caps={**original['direct_caps'],'policy_normalization':2,'policy_fields':4,'policy_history_reads':4,'control_charges':1,'control_types':1,'control_prepare':1,'control_pdbqt':1,'mechanical_copy':4,'format_inspection':4}
plan={'source_commit':'ae0db98560f66ac6be7a933fb053f6e1e9917d99','owner':'uibcdf/dockingmt#79','profiles':['normal','pm_fs'],'inputs':original['inputs'],'direct_caps':caps,'git_executable':shutil.which('git'),'git_sha256':sha(shutil.which('git')),'scheduler':original['scheduler'],'scope':'E3 reference public H5MSM 0.6 receiving; original failed 0.5 population preserved; no common-frame/RMSD/clustering/search/public acceptance'}
if profile=='normal':
    (task/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
else:
    assert json.loads((task/'plan.json').read_text())==plan
(attempt/'frozen-composition.json').write_bytes(composition_bytes)
frozen={}
for original_path,name in [(guard,'guard.py'),(task/'worker.py','worker.py'),(Path(__file__),'controller.py'),(old_controller,'composition-producer.py'),(task/'plan.json','plan.json'),(task/'route-change.json','route-change.json'),(task/'provider-policy-identities.json','provider-policy-identities.json'),(task/'provider-policy-guide.md','provider-policy-guide.md'),(root/'devtools/conda-build/resources.toml','resources.toml'),(root/'devguide/validation/e3_h5msm06_reference_receiving_2026-11-09.md','prescription.md'),(task/'original-source.pdbqt','original-source.pdbqt'),(task/'baseline-source-identity.json','baseline-source-identity.json'),(task/'baseline-worker.py','baseline-worker.py'),(task/'control-insertion.py.txt','control-insertion.py.txt'),(task/'provider-handoff.json','provider-handoff.json'),(task/'workspace-before.json','workspace-before.json'),(task/'original-worker.py','original-worker.py'),(task/'mechanics-observer.py','mechanics-observer.py'),(task/'plan-before-mechanics-amendment.json','plan-before-mechanics-amendment.json'),(task/'gate-replacement.json','gate-replacement.json'),(task/'policy-insertion.py.txt','policy-insertion.py.txt'),(task/'provider-policy-api.py.txt','provider-policy-api.py.txt'),(task/'provider-policy-implementation.py.txt','provider-policy-implementation.py.txt')]:
    destination=attempt/('frozen-'+name)
    shutil.copyfile(original_path,destination)
    frozen[destination.name]=sha(destination)
for relative,expected in plan['inputs'].items():
    original_path=root/relative
    assert sha(original_path)==expected
    shutil.copyfile(original_path,attempt/original_path.name)
if profile=='pm_fs':
    assert frozen==json.loads((task/('reference-normal'+suffix)/'registration.json').read_text())['frozen_sha256']
registration={'source_commit':plan['source_commit'],'stage':'reference','profile':profile,'owner':plan['owner'],'registered_at_utc':datetime.now(timezone.utc).isoformat(),'policy':policy,'initial_available_bytes':available(),'estimated_peak_group_rss_bytes':512*1024**2,'frozen_sha256':frozen,'composition_sha256':sha(attempt/'frozen-composition.json'),'input_sha256':{Path(name).name:digest for name,digest in plan['inputs'].items()},'direct_caps':plan['direct_caps'],'scope':plan['scope'],'scheduler':plan['scheduler']}
(attempt/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
env=os.environ.copy()
env.update(DMT_E3_ROOT=str(root),DMT_E3_TASK=str(task),DMT_E3_ATTEMPT=str(attempt),PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
for name,key in [('tmp','TMPDIR'),('cache','XDG_CACHE_HOME'),('numba','NUMBA_CACHE_DIR'),('mpl','MPLCONFIGDIR')]:
    path=attempt/name
    path.mkdir()
    env[key]=str(path)
for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS','MAX_JOBS']:
    env[key]='1'
with (attempt/'stdout.log').open('xb') as stdout,(attempt/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen(['/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python','-B','-I',str(attempt/'frozen-worker.py')],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
    outcome=monitor(process,policy)
try:
    receipt=json.loads((attempt/'receipt.json').read_text())
    semantic=receipt['outcome']=='PASS' and receipt['qualification_complete'] and receipt['profile']==profile and receipt['policy_reports_received']==2 and receipt['full39_heavy_maps']>=1 and receipt['prepared25_maps']>=1 and receipt['matched_current_source_control'] and receipt['legacy_source_authenticated']
except Exception as error:
    semantic=False
    outcome['qualification_diagnostic']=type(error).__name__+': '+str(error)
outcome['outcome']='PASS' if semantic and outcome['exit_code']==0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt/'resource-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome),flush=True)
if outcome['outcome']!='PASS':
    (task/'campaign-terminal.json').write_text(json.dumps({'outcome':'FAIL','failed_attempt':attempt.name,'further_molecular_work_permitted':False,'unattempted':['pm_fs'] if profile=='normal' else []},indent=2)+'\n')
    print((attempt/'stderr.log').read_text()[-6000:])
    raise SystemExit(1)
print(json.dumps({'profile':profile,'full39_heavy_maps':receipt['full39_heavy_maps'],'prepared25_maps':receipt['prepared25_maps'],'policy_observations':receipt['policy_observations'],'direct_counts':receipt['direct_counts'],'native_searches':0}))
if profile=='pm_fs':
    (task/'campaign-terminal.json').write_text(json.dumps({'outcome':'PASS','further_molecular_work_permitted':False,'accepted_profiles':['normal','pm_fs'],'e3_accepted':False},indent=2)+'\n')
