"""Run the unchanged seven consumer controls with the actual routine provider."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import runpy
import sys

task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
control = task / 'original-control.py'
assert hashlib.sha256(control.read_bytes()).hexdigest() == 'e16b04e90932724ee9c937967211c8b885227a9a46f10c7879c50d6328af08fe'
observe = runpy.run_path(str(control), run_name='dmt_depdigest47_receiving')['observe']
result = observe()
assert result['passed'] == result['total'] == 7
assert result['temporary_fixtures_retired']
import depdigest
import dockingmt
import molsysmt
assert Path(depdigest.__file__).resolve().parent.parent == task.parent.parent.parent / 'depdigest'
assert Path(dockingmt.__file__).resolve().parent.parent == task.parent.parent
blocked = {'vina', 'molsysviewer', 'rdkit', 'openmm', 'meeko', 'pdbfixer'}
assert not blocked.intersection(name.split('.')[0] for name in sys.modules)
result.update(provider_version=importlib.metadata.version('depdigest'), provider_origin=depdigest.__file__, consumer_origin=dockingmt.__file__, hard_molecular_provider_origin=molsysmt.__file__, loaded_optional_engines=[], molecular_operations=0, native_builds=0, original_control_sha256=hashlib.sha256(control.read_bytes()).hexdigest())
(attempt / 'audit-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'total': result['total'], 'provider_version': result['provider_version']}))
