"""Receive routine static auditing and existing bootstrap/optional guards."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
plan = json.loads((task / 'plan.json').read_text())
provider = root.parent / 'depdigest'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()
def source_snapshot(path, names):
    paths = subprocess.check_output(['git', '-C', str(path), 'ls-files', '-z', '--', *names]).decode().rstrip('\0').split('\0')
    return {'head': git(path, 'rev-parse', 'HEAD'), 'status': git(path, 'status', '--porcelain', '--untracked-files=no'), 'files_sha256': {name: sha(path / name) for name in paths if name}}
def routine_metadata():
    path = Path(sys.executable).parent.parent / 'conda-meta'
    return {p.name: sha(p) for p in path.glob('*.json')}
before = {'provider': source_snapshot(provider, ['depdigest']), 'consumer': source_snapshot(root, ['dockingmt', 'molsysviewer_dockingmt', 'tests/test_support_contracts.py', 'tests/test_bootstrap.py', 'pyproject.toml']), 'routine_metadata_observation': routine_metadata()}
assert before['provider']['head'] == '032d345becf8f8f574c24ede61ee62fcf0321de7' and not before['provider']['status']
assert before['consumer']['head'] == plan['source_commit'] and not before['consumer']['status']
for name, expected in plan['inputs'].items():
    assert sha(root / name) == expected
assert not os.environ.get('PYTEST_ADDOPTS'), 'Unregistered inherited pytest options'
versions = json.loads(subprocess.check_output([sys.executable, '-B', '-I', '-c', "import importlib.metadata as m, json; print(json.dumps({name:m.version(name) for name in ['depdigest','dockingmt','argdigest','smonitor','pyunitwizard','molsysmt','numpy','pytest','pytest-receptor','packaging']}))"], cwd=root, text=True))
assert versions['depdigest'] == '0.15.2+2.g032d345'
(attempt / 'before.json').write_text(json.dumps({'at_utc': datetime.now(timezone.utc).isoformat(), 'source': before, 'versions': versions}, indent=2) + '\n')
for name in ['original-control.py', 'audit_child.py']:
    shutil.copyfile(task / name, attempt / ('frozen-' + name))
with (attempt / 'audit.log').open('xb') as stream:
    result = subprocess.run([sys.executable, '-B', '-I', str(attempt / 'frozen-audit_child.py')], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
assert result.returncode == 0, (attempt / 'audit.log').read_text()[-4000:]
audit = json.loads((attempt / 'audit-receipt.json').read_text())
assert audit['passed'] == audit['total'] == 7
command = [sys.executable, '-B', '-I', '-m', 'pytest', '--receptor=llm', '--junitxml=' + str(attempt / 'pytest.xml'), *plan['pytest_selection']]
(attempt / 'pytest-command.json').write_text(json.dumps(command, indent=2) + '\n')
with (attempt / 'pytest.log').open('xb') as stream:
    result = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
junit = ET.parse(attempt / 'pytest.xml')
counts = {key: sum(int(suite.get(key, '0')) for suite in junit.getroot().iter('testsuite')) for key in ['tests', 'errors', 'failures', 'skipped']}
(attempt / 'pytest-counts.json').write_text(json.dumps({'exit_code': result.returncode, **counts}, indent=2) + '\n')
assert result.returncode == 0 and counts['tests'] > 0 and counts['errors'] == counts['failures'] == counts['skipped'] == 0, (attempt / 'pytest.log').read_text()[-4000:]
after = {'provider': source_snapshot(provider, ['depdigest']), 'consumer': source_snapshot(root, ['dockingmt', 'molsysviewer_dockingmt', 'tests/test_support_contracts.py', 'tests/test_bootstrap.py', 'pyproject.toml']), 'routine_metadata_observation': routine_metadata()}
assert before['provider'] == after['provider'] and before['consumer'] == after['consumer']
metadata_change = {'added': sorted(after['routine_metadata_observation'].keys() - before['routine_metadata_observation'].keys()), 'removed': sorted(before['routine_metadata_observation'].keys() - after['routine_metadata_observation'].keys()), 'modified': sorted(name for name in before['routine_metadata_observation'].keys() & after['routine_metadata_observation'].keys() if before['routine_metadata_observation'][name] != after['routine_metadata_observation'][name])}
(attempt / 'after.json').write_text(json.dumps({'at_utc': datetime.now(timezone.utc).isoformat(), 'source': after, 'metadata_change_observation': metadata_change}, indent=2) + '\n')
receipt = {'stage': 'receiving', 'source_commit': plan['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'provider_source': before['provider']['head'], 'provider_version': versions['depdigest'], 'original_audit_controls_passed': audit['passed'], 'original_audit_controls_total': audit['total'], 'pytest_counts': counts, 'metadata_change_observation': metadata_change, 'molecular_operations': 0, 'native_builds': 0, 'package_installs': 0, 'runtime_test_or_provider_pin_changes': False, 'scope': 'Current routine editable-source DepDigest47 audit and unchanged import/guard tests; hard MolSysMT import is allowed, no molecular operations; no public artifact/whole dependency closure or scientific receiving'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
