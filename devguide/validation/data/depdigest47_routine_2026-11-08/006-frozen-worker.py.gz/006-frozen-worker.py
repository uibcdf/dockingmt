"""Refresh only the two participating workspaces; preserve every worktree."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
script = root.parent / 'molsyssuite/devtools/scripts/suite_status.py'
before = {}
for name in ['dockingmt', 'depdigest']:
    path = root.parent / name
    before[name] = {'head': subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip(), 'worktree': subprocess.check_output(['git', '-C', str(path), 'status', '--porcelain'], text=True)}
result = subprocess.run([sys.executable, '-B', str(script), '--repository', 'dockingmt', '--repository', 'depdigest', '--format', 'json'], cwd=root, capture_output=True, text=True, check=False)
(attempt / 'suite-status.json').write_text(result.stdout)
(attempt / 'suite-status.stderr').write_text(result.stderr)
rows = json.loads(result.stdout)
assert len(rows) == 2 and all(not row['error'] for row in rows)
assert result.returncode in [0, 1]
for name in ['dockingmt', 'depdigest']:
    path = root.parent / name
    assert subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip() == before[name]['head']
    assert subprocess.check_output(['git', '-C', str(path), 'status', '--porcelain'], text=True) == before[name]['worktree']
assert before['depdigest']['head'] == '032d345becf8f8f574c24ede61ee62fcf0321de7' and not before['depdigest']['worktree']
assert before['dockingmt']['head'] == '75db240e9c0b3aefa64eae7258c1a513b664f9af'
assert before['dockingmt']['worktree'].strip() == '?? dockingmt-migration-2026-11-06/'
assert not any(row['ahead'] or row['behind'] for row in rows)
subprocess.run(['git', '-C', str(root.parent / 'depdigest'), 'merge-base', '--is-ancestor', '02339c2917588a91ba938575be44816d706b5e27', before['depdigest']['head']], check=True)
receipt = {'stage': 'workspace', 'source_commit': before['dockingmt']['head'], 'outcome': 'PASS', 'qualification_complete': True, 'suite_status_script_sha256': hashlib.sha256(script.read_bytes()).hexdigest(), 'snapshots': before, 'scope': 'Both selected remotes refreshed; provider clean/current, original migration preserved; no merge/reset/install', 'known_nonclean_disposition': 'DockingMT migration stays untouched/untracked/unstaged; suite-status exit1 is expected and retained'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'outcome': 'PASS', 'suite_status_exit': result.returncode, 'preserved_worktrees': True}))
