"""Receive geometry records through the owning quantity codec; no molecular replay."""
import hashlib
import json
import sys
import numpy as np
import pyunitwizard as puw
from pyunitwizard.record import QuantityRecord, RecordError

def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    def quantity(document,field):
        return puw.get_value(QuantityRecord.from_dict(document[field]).to_quantity(field=field,unit='nm',dimensionality={'[L]':1},form='pint'),to_unit='nm')
    worker=records['producer/worker.py.txt']
    assert hashlib.sha256(worker).hexdigest()=='65627af215163a9c012da536f4450df2892f04db2816d8c8fea6791fc2c49c5c'
    identities=obj('producer/provider-identities.json')
    for row in identities:
        assert hashlib.sha256(records['producer/'+row['frozen']]).hexdigest()==row['sha256']
    counts={'pairwise':18,'clusters':23,'maps':4,'convert':1,'append':1}
    chain=[[0,1,2],[1,0,1],[2,1,0]]
    fields_read=0
    for label in ['geometry-normal','geometry-pm_fs']:
        prefix='attempts/'+label+'/'
        registration=obj(prefix+'registration.json')
        outcome=obj(prefix+'resource-outcome.json')
        assert registration['direct_caps']==counts and registration['source_commit']=='3c5145c69367d15148ecb113501ed87dd6106ce1'
        assert records[prefix+'frozen-worker.py']==worker
        assert outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids']
        composition=obj(prefix+'frozen-composition.json')
        assert composition['provider_native_sha256']=='5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
        provider=obj(prefix+'producer-label.json')
        assert provider['actual_source_commit']=='8af8628e61ac28b519827802c39cf2e3eaa48b7e'
        assert provider['observed_version']==provider['metadata_version']=='0.23.0+687.g2325038e8'
        rows={}
        for path,raw in records.items():
            if not path.startswith(prefix) or not path.endswith('.json'):
                continue
            d=json.loads(raw)
            if not isinstance(d,dict) or 'quantity_fields' not in d:
                continue
            r=d['result']
            for field in d['quantity_fields']:
                q=quantity(r,field)
                assert np.isfinite(q).all()
                fields_read+=1
            rows[path[len(prefix):-5]]=d
            assert r['software']['molsysmt']==provider['observed_version']
        for name in ['translation','repeated','empty','singleton','ring-positional','ring-symmetry','ring-cached','ring-identity','ring-anchored']:
            r=rows[name]['result']
            assert r['alignment']==r['periodic_imaging']=='none'
            assert r['cartesian_axes']=='caller_declared_common'
            assert rows[name]['array_types']['pair_indices']['dtype']=='int64'
        np.testing.assert_allclose(quantity(rows['translation']['result'],'rmsd'),chain,rtol=0,atol=1e-12)
        np.testing.assert_allclose(quantity(rows['repeated']['result'],'rmsd'),[[0,2,1,0],[2,0,1,2],[1,1,0,1],[0,2,1,0]],rtol=0,atol=1e-12)
        assert rows['repeated']['result']['structure_indices']==[2,0,1,2]
        assert rows['empty']['array_types']['pair_indices']['shape']==[0,2]
        assert quantity(rows['empty']['result'],'rmsd').shape==(0,0)
        for name in ['ring-symmetry','ring-cached']:
            r=rows[name]['result']
            np.testing.assert_allclose(quantity(r,'rmsd'),[[0,0,.2],[0,0,.2],[.2,.2,0]],rtol=0,atol=1e-12)
            assert r['chemistry_checked'] and r['search_scope']=='all_chemical_correspondences'
        assert rows['ring-identity']['result']['search_scope']=='supplied_atom_correspondences'
        assert rows['ring-anchored']['result']['search_scope']=='anchored_chemical_correspondences'
        np.testing.assert_allclose(quantity(rows['ring-identity']['result'],'rmsd'),quantity(rows['ring-positional']['result'],'rmsd'),rtol=0,atol=1e-12)
        complete=rows['chain-complete']['result'];single=rows['chain-single']['result']
        assert complete['inequality']==single['inequality']=='<='
        if label=='geometry-normal':
            assert outcome['outcome']=='PASS' and outcome['exit_code']==0
            r=obj(prefix+'receipt.json')
            assert r['direct_counts']==counts and r['typed_refusals']==22 and r['successful_pairwise_records']==9 and r['successful_cluster_records']==10
            assert r['source_and_caller_preserved'] and r['provider_configuration_restored'] and not r['e3_accepted']
            assert complete['cluster_indices']==[0,0,1] and single['cluster_indices']==[0,0,0]
            assert rows['medoid']['result']['representative_indices']==[1] and rows['first']['result']['representative_indices']==[0]
            assert rows['exact-cutoff']['result']['cluster_indices']==[0,0]
            assert rows['below-cutoff']['result']['cluster_indices']==[0,1,2]
            assert obj(prefix+'ring-before.json')==obj(prefix+'ring-after.json')
            assert all(obj(prefix+'source-final.json').values())
            refusals=[json.loads(raw) for path,raw in records.items() if path.startswith(prefix) and path.endswith('-refusal.json')]
            assert len(refusals)==22 and {r['type'] for r in refusals}=={'ArgumentError','StructuralInconsistencyError','UnsupportedHeavyOperationError','MemoryBudgetExceededError'}
        else:
            assert outcome['outcome']=='FAIL' and outcome['exit_code']==1
            f=obj(prefix+'failure.json')
            assert f['stage']=='clusters' and f['exception_type']=='AssertionError'
            assert f['direct_counts']=={'pairwise':9,'clusters':2,'maps':3,'convert':1,'append':1}
            assert complete['cluster_indices']==single['cluster_indices']==[0,1,2]
            assert prefix+'receipt.json' not in records and prefix+'source-final.json' not in records
    diag=obj('attempts/cutoff-diagnostic-01/results.json')
    assert len(diag)==12
    for row in diag:
        for field in row['physical_records']:
            quantity(row['physical_records'],field)
            fields_read+=1
        if row['input'].startswith('nm-'):
            assert row['original_cutoff_nm']==1.0 and row['matrix_to_nm']==chain
            if row['policy']=='pm':
                assert row['cutoff_after_standardization_nm_hex']=='0x1.fffffffffffffp-1' and row['clusters']==[0,1,2]
            else:
                assert row['cutoff_after_standardization_nm_hex']=='0x1.0000000000000p+0'
                assert row['clusters']==([0,0,1] if row['method']=='complete_linkage' else [0,0,0])
        else:
            assert row['clusters']==([0,0,1] if row['method']=='complete_linkage' else [0,0,0])
    resource=obj('attempts/cutoff-diagnostic-01/resource-outcome.json')
    assert resource['outcome']=='PASS' and resource['group_terminal'] and not resource['remaining_live_owned_pids'] and resource['resource_interruption'] is None
    terminal=obj('producer/campaign-terminal.json')
    assert terminal['outcome']=='FAIL' and terminal['failed_attempt']=='geometry-pm_fs' and not terminal['further_molecular_work_permitted']
    # The owning codec also refuses incompatible receiver handshakes.
    q=obj('attempts/geometry-normal/translation.json')['result']['rmsd']
    for kwargs in [{'field':'wrong','unit':'nm'},{'field':'rmsd','unit':'ps'}]:
        try:
            QuantityRecord.from_dict(q).to_quantity(**kwargs)
        except RecordError:
            pass
        else:
            raise AssertionError('Invalid quantity handshake accepted')
    assert not any(n=='molsysmt' or n.startswith(('molsysmt.','rdkit')) for n in sys.modules)
    return {'complete_profiles':['normal'],'failed_profiles':['pm_fs'],'quantity_fields_received':fields_read,'invalid_quantity_handshakes_refused':2,'typed_refusals_received':22,'diagnostic_cluster_calls':12,'cutoff_defect':'uibcdf/molsysmt#659','final_pm_fs_live_checks':'unreached','molecular_replay':False,'reference_accepted':False,'e3_accepted':False,'native_searches':0}
