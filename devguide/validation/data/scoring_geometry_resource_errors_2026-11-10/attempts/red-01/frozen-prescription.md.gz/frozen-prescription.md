# Resource failures in fixed-pose geometry — 2026-11-10

Owner: [DockingMT #107](https://github.com/uibcdf/dockingmt/issues/107), with
#73/#47 qualification and #50 custody. Source basea0c184f. Status: registered.

The old installed helper diagnostic raises controlled MemoryError, OS ENOMEM
and ValueError through a fake provider facade. All three become ArgumentError;
the original resource objects remain causes. Its helper bytes match the source
base. Preserve that original observation separately from public red/green
receiving. No real allocation failure or molecular/native work is induced.

Add16 public `score` controls across conversion, coordinate/name/element reading
and four error families: MemoryError, OS ENOMEM, ValueError and OS ENOSPC. Check
exact exception/cause/field, stopping before the next provider/native operation,
original input/protocol and owned staging-file retirement. The real engine is
unavailable to these controls; explicit software availability/construction seams
are intentional and never native execution. Expected original red result:
eight allocation failures incorrectly translated, eight ordinary controls pass.

Then add only MemoryError and OS ENOMEM passthrough before the existing geometry
argument translator. No string matching, generic OSError passthrough, new schema,
scientific definition, dependency or provider change. Run complete unchanged
original139 input-resource cases plus16 new guards (155) and all48 pose-audit
cases,203 total per normal/pm-fs policy, without exclusions or changed assertions.
The two actual native score calls per complete profile retain the original tiny
four/two-record inputs,10-angstrom box, seed17 and CPU1. Existing bounded provider
geometry projection performs two conversions/six reads only in the fresh-score
node; all injected-error and remaining audit cases perform no actual molecular
or native calculation. Preserve generated labels separately from exact source
Git/overlay identity and observe real core origins before/after pytest.

Reuse the retained original Vina1.2.7/103-file prefix and same six-provider
source/native cohort. Check all788 frozen source/support inputs before/after;
606 support sources/declarations stay exact. No install, native build or source
refresh. Do not infer new artifact receiving from the old comparison wheel.

Each scientific cell remains serial CPU0/nice10/one worker,13GiB available-RAM
reserve,1GiB group RSS,2GiB address space,60/65 CPU seconds and180 wall seconds.
Estimate768MiB for complete profiles including the child process,256MiB for red;
the prior audit peak is below493MiB. Check reserve before launch, monitor owned
descendants during execution and retain every interruption. No automatic
headroom restart. No Slurm allocation; earlier applicability remains inconclusive.

Retain original diagnostic, source overlays/red/green/native observations and
independent readers under `.molsyssuite/scoring-geometry-resources-20261110`,
owners#107/#50, review2026-11-14. Preserve earlier native/receiver/SDK custody and
human migration backup. Public/platform/hosted/interactive, SSH#100/#178 and
original provider-panel requirements remain separate; no remote CI is launched.
