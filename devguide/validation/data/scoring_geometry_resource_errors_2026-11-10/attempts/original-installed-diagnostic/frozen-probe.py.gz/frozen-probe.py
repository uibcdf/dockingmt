"""Controlled geometry-read exceptions; no native work or memory exhaustion."""
import errno
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

root = Path(os.environ['DMT_GATE_ROOT'])
attempt = Path(os.environ['DMT_GATE_ATTEMPT'])
installation = json.loads((root / '.molsyssuite/installed-reconstruction-20261109/installation.json').read_text())
site = Path(installation['site'])
assert Path(sys.prefix) == Path(installation['prefix'])
def verify():
    for group in ['consumer_sha256', 'tool_sha256', 'unit_sha256']:
        for name, digest in installation[group].items():
            assert hashlib.sha256((site / name).read_bytes()).hexdigest() == digest
verify()
module = importlib.import_module('dockingmt.engines._vina_scoring')
assert Path(module.__file__).resolve().is_relative_to(site)
assert hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() == hashlib.sha256((root / 'dockingmt/engines/_vina_scoring.py').read_bytes()).hexdigest()
original = module.msm
rows = []
for failure in [MemoryError('controlled'), OSError(errno.ENOMEM, 'controlled'), ValueError('controlled')]:
    calls = []
    def convert(*args, **kwargs):
        calls.append('convert')
        raise failure
    module.msm = SimpleNamespace(convert=convert)
    try:
        module._input_pose(None, b'CONTROL', {'partner': None, 'receptor': None}, None)
    except BaseException as caught:
        rows.append({'injected_type': type(failure).__name__, 'errno': getattr(failure, 'errno', None),
            'actual_type': type(caught).__name__, 'code': getattr(caught, 'code', None),
            'same_exception': caught is failure, 'same_cause': caught.__cause__ is failure,
            'calls': calls})
    else:
        raise AssertionError('The controlled exception disappeared')
    finally:
        module.msm = original
assert all(row['actual_type'] == 'ArgumentError' and row['code'] == 'DMT-E002' and row['same_cause'] and row['calls'] == ['convert'] for row in rows)
assert 'vina' not in sys.modules and 'molsysviewer' not in sys.modules
verify()
receipt = {'diagnostic_completed': True, 'installed_module': str(module.__file__),
    'source_module_bytes_match_installed': True, 'actual_memory_exhaustion': False,
    'actual_molecular_native_operations': 0, 'rows': rows}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
