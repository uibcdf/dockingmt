"""Prospective coordinate-free peptide reference receiving."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tomllib
import traceback
from dataclasses import asdict

root = Path(os.environ['DMT_RECEPTOR_ROOT'])
task = Path(os.environ['DMT_RECEPTOR_TASK'])
attempt = Path(os.environ['DMT_RECEPTOR_ATTEMPT'])
registration = json.loads((attempt / 'registration.json').read_text())
candidate = json.loads((attempt / 'frozen-candidate.json').read_text())
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')
prefix = Path(candidate['prefix'])
sdk = root / '.molsyssuite/publication-sdk/devtools/scripts'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def files(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}

def write(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

assert sys.flags.isolated and sys.flags.no_site
assert os.sched_getaffinity(0) == {0} and os.getpriority(os.PRIO_PROCESS, 0) >= 10
sys.path[:0] = [str(prefix), candidate['consumer_prefix'], candidate['viewer_prefix'], str(routine / 'lib/python3.14/site-packages'), str(sdk)]
blocked, allowed_subprocesses = [], []
declaration = tomllib.loads((attempt / 'frozen-resources.toml').read_text())['installed_tests']['support']
git_files = {str(root): (registration['source_commit'], {r['source'] for r in declaration['files']}), str(sdk.parents[1]): ('95f693be10c9205ab9b912cb53453710a207bf45', {'devtools/scripts/installed_test_support.py', 'devtools/scripts/installed_noarch.py', 'devtools/scripts/installed_imports.py', 'devtools/scripts/installed_test_dependencies.py'})}
git_read_count = 0
def audit(event, args):
    global git_read_count
    if event == 'subprocess.Popen':
        executable, argv = os.fsdecode(args[0]), args[1]
        if shutil.which(executable) == json.loads((attempt / 'frozen-plan.json').read_text())['git_executable'] and isinstance(argv, list) and len(argv) >= 4 and argv[:2] == ['git', '-C'] and argv[2] in git_files:
            commit, paths = git_files[argv[2]]
            if argv[3:] == ['rev-parse', 'HEAD'] or any(argv[3:] in (['rev-parse', commit + ':' + path], ['hash-object', '--no-filters', str(Path(argv[2]) / path)]) for path in paths):
                git_read_count += 1
                return
        if shutil.which(executable) == '/usr/bin/uname' and argv == ['uname', '-p']:
            allowed_subprocesses.append({'executable': '/usr/bin/uname', 'arguments': ['-p'], 'purpose': 'stdlib platform.processor during h5py import'})
            return
    if event == 'socket.connect' or event == 'subprocess.Popen' or event == 'import' and args[0].split('.')[0] == 'vina':
        blocked.append(event)
        raise AssertionError('Network, native search and non-platform subprocesses forbidden')
sys.addaudithook(audit)
from installed_test_support import staged_support
import numpy as np
import pyunitwizard as puw

def policy():
    return {k: puw.configure.report()[k] for k in ['default_form', 'default_parser', 'standard_units', 'provenance']}

counts = dict.fromkeys(registration['direct_caps'], 0)
stage = 'custody'
def call(key, function, *args, **kwargs):
    global stage
    stage = key
    counts[key] += 1
    assert counts[key] <= registration['direct_caps'][key], key
    with (attempt / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps({'operation': key, 'direct_counts': counts}) + '\n')
    return function(*args, **kwargs)

"""Receiving body appended to the retained exact-payload isolated preamble."""
support = None
try:
    assert files(prefix) == candidate['provider_files_sha256']
    assert files(Path(candidate['consumer_prefix'])) == candidate['consumer_files_sha256']
    assert files(Path(candidate['viewer_prefix'])) == candidate['viewer_files_sha256']
    assert {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')} == candidate['routine_metadata_sha256']
    hypothesis = json.loads((attempt / 'frozen-hypothesis.json').read_text())
    previous = policy()
    units = ['nm', 'ps', 'kelvin', 'mole', 'dalton', 'elementary_charge', 'kJ/mol', 'kJ/(mol*nm)', 'kJ/(mol*nm**2)', 'radians'] if registration['profile'] == 'normal' else ['pm', 'fs', 'kelvin', 'mole', 'dalton', 'coulomb', 'kJ/mol', 'kJ/(mol*pm)', 'kJ/(mol*pm**2)', 'radians']
    context = {'candidate_sha': registration['source_commit'], 'qualification_sha': registration['source_commit'], 'provider_sha': '95f693be10c9205ab9b912cb53453710a207bf45', 'sha256': candidate['consumer_wheel_sha256']}
    with puw.context(standard_units=units), staged_support(root, declaration, ('dockingmt', 'molsysviewer_dockingmt'), context=context) as support:
        caller = policy()
        import molsysmt as msm
        from dmt_test_support.qualify_chemical_templates import detached_record, snapshot
        assert policy() == caller and msm.__version__ == candidate['wheel']['version']
        forbidden = []
        def refuse(*args, **kwargs):
            forbidden.append('unexpected molecular preparation')
            raise AssertionError('Bound-source preparation, generation, assignment and numerical analysis forbidden')
        for owner, names in [(msm.build, ['add_missing_terminal_cappings', 'add_terminal_atoms', 'add_missing_heavy_atoms', 'add_missing_hydrogens', 'assign_partial_charges', 'assign_autodock_atom_types']), (msm.physchem, ['apply_chemical_template']), (msm.structure, ['get_rmsd', 'get_symmetry_corrected_rmsd'])]:
            for name in names:
                if hasattr(owner, name):
                    setattr(owner, name, refuse)
        write('installed-origins.json', {name: {'path': str(Path(module.__file__).resolve()), 'sha256': sha(module.__file__)} for name, module in tuple(sys.modules.items()) if name in ['molsysmt', 'pyunitwizard', 'dockingmt', 'argdigest', 'smonitor', 'depdigest']})
        for name, module in tuple(sys.modules.items()):
            if name.split('.')[0] in {'molsysmt', 'pyunitwizard', 'argdigest', 'smonitor', 'depdigest'} and getattr(module, '__file__', None):
                assert Path(module.__file__).resolve().is_relative_to(prefix), name
            if name.split('.')[0] == 'dockingmt' and getattr(module, '__file__', None):
                assert Path(module.__file__).resolve().is_relative_to(Path(candidate['consumer_prefix'])), name
        live_sources, live_templates, observations = [], [], []
        def reference_snapshot(system):
            return detached_record({'topology': msm.convert(system.topology, to_form='molsysmt.TopologyDict').data, 'chemical_states': msm.convert(system.chemical_states, to_form='molsysmt.ChemicalStatesDict').to_dict(), 'n_structures': msm.get(system, n_structures=True)})
        for case in hypothesis['cases']:
            entry = case['entry']
            source = call('pdb_conversions', msm.convert, str(attempt / (entry + '.pdb')), to_form='molsysmt.MolSys', get_missing_bonds=False)
            before = snapshot(source)
            write(entry + '-source-snapshot.json', before)
            live_sources.append((entry + '-source', source, before))
            assembly = call('assemblies', msm.build.make_bioassembly, source, bioassembly='1', structure_indices=0)
            before = snapshot(assembly)
            write(entry + '-assembly-snapshot.json', before)
            live_sources.append((entry + '-assembly', assembly, before))
            chains = call('chain_selectors', msm.select, assembly, selection='group_type=="amino acid"', element='chain')
            assert [int(x) for x in chains] == [r['chain_index'] for r in case['chains']]
            for chain in case['chains']:
                key = entry + '-chain-' + str(chain['chain_index'])
                selected = 'chain_index==' + str(chain['chain_index']) + ' and group_type=="amino acid"'
                groups = call('group_tables', msm.get, assembly, element='group', selection=selected, output_type='dictionary', group_index=True, group_name=True, group_id=True, chain_index=True, chain_id=True, chain_name=True, get_missing_bonds=False)
                groups = detached_record(groups)
                assert len(groups['group_index']) == case['n_groups']
                assert groups['group_id'] == [str(i) for i in range(case['first_author_residue'], case['last_author_residue'] + 1)]
                assert set(groups['chain_id']) == {chain['chain_id']} and set(groups['chain_name']) == {chain['chain_name']}
                assert groups['group_name'][0] == case['first_name'] and groups['group_name'][-1] == case['last_name']
                assert set(groups['group_name']).issubset(set(hypothesis['allowed_observed_residue_names']))
                states = ['HIE' if name == 'HIS' else name for name in groups['group_name']]
                if entry == '1HSG':
                    assert groups['group_id'][24] == '25' and groups['group_name'][24] == 'ASP'
                    if chain['chain_index'] == 0:
                        states[24] = 'ASH'
                states_before = list(states)
                result = call('factory_attempts', msm.physchem.get_peptide_chemical_template, states, n_terminal_state='ammonium', c_terminal_state='carboxylate', disulfide_group_pairs=None)
                assert states == states_before
                template = result['template']
                report = detached_record(result['report'])
                provenance = detached_record(result['template_provenance'])
                write(key + '-group-declaration.json', {'source_groups': groups, 'declared_residue_states': states, 'association': 'Source group list position -> synthetic template group; no atom map and no application'})
                write(key + '-factory-report.json', report)
                assert report['schema'] == 'molsysmt.peptide_template@1' and report['status'] == 'constructed'
                assert report['template_provenance'] == provenance
                assert provenance['residue_names'] == states and provenance['n_terminal_state'] == 'ammonium' and provenance['c_terminal_state'] == 'carboxylate'
                assert provenance['disulfide_group_pairs'] == [] and provenance['stereochemistry'] == 'unspecified'
                assert report['units'] == {'formal_charge': 'elementary_charge'}
                assert report['unassessed_checks'] == ['stereochemistry', 'environmental_protonation', 'geometry', 'force_field_coverage']
                assert report['n_groups'] == case['n_groups'] and len(report['peptide_bond_pairs']) == case['n_groups'] - 1 and report['disulfide_bond_pairs'] == []
                summary = call('template_summaries', msm.get, template, output_type='dictionary', n_atoms=True, n_groups=True, n_bonds=True, n_structures=True)
                summary = detached_record(summary)
                write(key + '-template-summary.json', summary)
                assert template.structures is None and summary['n_structures'] is None and summary['n_groups'] == case['n_groups'] and summary['n_atoms'] == report['n_atoms'] and report['n_indexed_hydrogens'] == 0
                atoms = call('formal_charge_reads', msm.get, template, element='atom', output_type='dictionary', formal_charge=True, atom_name=True, atom_type=True, group_index=True)
                atoms = detached_record(atoms)
                expected_charge = states.count('LYS') + states.count('ARG') - states.count('ASP') - states.count('GLU')
                actual_charge = sum(int(value) for value in atoms['formal_charge'])
                assert actual_charge == expected_charge and 'H' not in atoms['atom_type']
                assert [(int(group), name) for group, name in zip(atoms['group_index'], atoms['atom_name']) if name == 'OXT'] == [(case['n_groups'] - 1, 'OXT')]
                inventory = call('hydrogen_inventories', msm.physchem.get_hydrogen_inventory, template)
                inventory = detached_record(inventory)
                write(key + '-hydrogen-inventory.json', inventory)
                assert sum(inventory['indexed_hydrogen_counts']) == 0 and sum(inventory['total_hydrogen_counts']) == report['n_stored_hydrogens']
                history = call('history_reads', template.chemical_states.get_preparation_history)
                write(key + '-history.json', detached_record(history))
                before = reference_snapshot(template)
                write(key + '-template-snapshot.json', before)
                live_templates.append((key, template, before))
                path = attempt / (key + '.h5msm')
                call('h5_writes', msm.convert, template, to_form=str(path))
                restored = call('h5_reads', msm.convert, str(path), to_form='molsysmt.MolSys')
                after = reference_snapshot(restored)
                write(key + '-restored-template-snapshot.json', after)
                labels = call('component_comparisons', msm.compare, template, restored, component_name=True, component_type=True, include_none=True, output_type='dictionary')
                labels = detached_record(labels)
                assert labels == {'component_name': True, 'component_type': True}
                assert before['topology'] == after['topology'] and before['n_structures'] is after['n_structures'] is None
                bc, ac = before['chemical_states'], after['chemical_states']
                assert {k: v for k, v in bc.items() if k != 'states'} == {k: v for k, v in ac.items() if k != 'states'}
                assert len(bc['states']) == len(ac['states']) == 1
                bs, ass = bc['states'][0], ac['states'][0]
                assert {k: v for k, v in bs.items() if k != 'components'} == {k: v for k, v in ass.items() if k != 'components'}
                bt, at = bs['components'], ass['components']
                assert bt.keys() == at.keys() and bt['n_rows'] == at['n_rows'] and bt['columns'].keys() == at['columns'].keys()
                dtype_audit = []
                for column in bt['columns']:
                    original, recovered = bt['columns'][column], at['columns'][column]
                    if column in ('component_name', 'component_type'):
                        assert original['dtype'] in ('str', 'string') and recovered['dtype'] == 'string'
                        assert {k: v for k, v in original.items() if k != 'dtype'} == {k: v for k, v in recovered.items() if k != 'dtype'}
                        dtype_audit.append({'column': column, 'original_dtype': original['dtype'], 'recovered_dtype': recovered['dtype'], 'values_and_null_mask_equal': True})
                    else:
                        assert original == recovered
                write(key + '-canonical-text-audit.json', {'provider_public_comparison': labels, 'storage_descriptors': dtype_audit, 'other_public_record_fields_exact': True, 'strict_snapshot_equal': before == after, 'native_objects_or_saved_records_normalized': False})
                assert detached_record(call('history_reads', restored.chemical_states.get_preparation_history)) == detached_record(history)
                observations.append({'entry': entry, 'chain_index': chain['chain_index'], 'chain_id': chain['chain_id'], 'author_chain_name': chain['chain_name'], 'n_residues': case['n_groups'], 'n_atoms': report['n_atoms'], 'n_bonds': summary['n_bonds'], 'n_stored_hydrogens': report['n_stored_hydrogens'], 'n_indexed_hydrogens': 0, 'n_structures': None, 'structural_domain_present': False, 'formal_charge': {'value': actual_charge, 'unit': 'elementary_charge'}, 'expected_formal_charge': {'value': expected_charge, 'unit': 'elementary_charge'}, 'template_graph_checksum': provenance['checksum'], 'template_h5msm_sha256': sha(path), 'history_roundtrip': True, 'canonical_text_storage_received': True, 'raw_dictionary_dtype_identity_claim': False, 'bound_source_applied': False})
                write(key + '-observation.json', observations[-1])
        typed = []
        for label, names, c_terminal in [('ambiguous-HIS', ['HIS'], 'carboxylate'), ('unsupported-terminus', ['GLY'], 'amide')]:
            try:
                call('factory_attempts', msm.physchem.get_peptide_chemical_template, names, n_terminal_state='ammonium', c_terminal_state=c_terminal)
            except msm.ArgumentError as error:
                typed.append({'control': label, 'type': type(error).__name__, 'message': str(error)})
            else:
                raise AssertionError('Required typed refusal missing: ' + label)
        write('typed-refusals.json', typed)
        stage = 'final-live-nonmutation-and-support'
        for name, system, before in live_sources:
            assert snapshot(system) == before, name
        for name, system, before in live_templates:
            assert reference_snapshot(system) == before, name
        assert len(observations) == 6 and len(typed) == 2 and policy() == caller and not forbidden
        support.check()
    assert policy() == previous and not blocked
    assert files(prefix) == candidate['provider_files_sha256']
    assert files(Path(candidate['consumer_prefix'])) == candidate['consumer_files_sha256']
    assert files(Path(candidate['viewer_prefix'])) == candidate['viewer_files_sha256']
    assert {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')} == candidate['routine_metadata_sha256']
    for basename, expected in registration['input_sha256'].items():
        assert sha(attempt / basename) == expected
    assert counts == registration['direct_caps']
    write('receipt.json', {'source_commit': registration['source_commit'], 'stage': 'templates', 'profile': registration['profile'], 'outcome': 'PASS', 'qualification_complete': True, 'direct_counts': counts, 'protein_reference_templates_received': 6, 'typed_refusals': typed, 'observations': observations, 'source_snapshot_scope': 'Public topology, chemical states/history, structures/coordinate and association values; not every experimental attribute', 'source_and_caller_preserved_in_observed_scope': True, 'reference_coordinate_structures': None, 'structural_domain_present': False, 'bound_receptors_admitted': 0, 'new_independent_docking_cases': 0, 'native_searches': 0, 'blocked': blocked, 'forbidden': forbidden, 'allowed_subprocesses': allowed_subprocesses, 'support_binding_git_reads': git_read_count})
except BaseException as error:
    write('failure.json', {'stage': stage, 'exception_type': type(error).__name__, 'exception_module': type(error).__module__, 'message': str(error), 'direct_counts': counts, 'bound_receptors_admitted': 0, 'whole_template_selection_accepted': False})
    traceback.print_exc()
    raise
finally:
    if support is not None:
        write('support-receipt.json', support.receipt)
