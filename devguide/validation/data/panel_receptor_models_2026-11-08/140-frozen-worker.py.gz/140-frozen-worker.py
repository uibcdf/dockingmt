"""Prospective synthetic public argument diagnostic."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tomllib
import traceback
from dataclasses import asdict

root = Path(os.environ['DMT_RECEPTOR_ROOT'])
task = Path(os.environ['DMT_RECEPTOR_TASK'])
attempt = Path(os.environ['DMT_RECEPTOR_ATTEMPT'])
registration = json.loads((attempt / 'registration.json').read_text())
candidate = json.loads((attempt / 'frozen-candidate.json').read_text())
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')
prefix = Path(candidate['prefix'])
sdk = root / '.molsyssuite/publication-sdk/devtools/scripts'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def files(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}

def write(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

assert sys.flags.isolated and sys.flags.no_site
assert os.sched_getaffinity(0) == {0} and os.getpriority(os.PRIO_PROCESS, 0) >= 10
sys.path[:0] = [str(prefix), candidate['consumer_prefix'], candidate['viewer_prefix'], str(routine / 'lib/python3.14/site-packages'), str(sdk)]
blocked, allowed_subprocesses = [], []
declaration = tomllib.loads((attempt / 'frozen-resources.toml').read_text())['installed_tests']['support']
git_files = {str(root): (registration['source_commit'], {r['source'] for r in declaration['files']}), str(sdk.parents[1]): ('95f693be10c9205ab9b912cb53453710a207bf45', {'devtools/scripts/installed_test_support.py', 'devtools/scripts/installed_noarch.py', 'devtools/scripts/installed_imports.py', 'devtools/scripts/installed_test_dependencies.py'})}
git_read_count = 0
def audit(event, args):
    global git_read_count
    if event == 'subprocess.Popen':
        executable, argv = os.fsdecode(args[0]), args[1]
        if shutil.which(executable) == json.loads((attempt / 'frozen-plan.json').read_text())['git_executable'] and isinstance(argv, list) and len(argv) >= 4 and argv[:2] == ['git', '-C'] and argv[2] in git_files:
            commit, paths = git_files[argv[2]]
            if argv[3:] == ['rev-parse', 'HEAD'] or any(argv[3:] in (['rev-parse', commit + ':' + path], ['hash-object', '--no-filters', str(Path(argv[2]) / path)]) for path in paths):
                git_read_count += 1
                return
        if shutil.which(executable) == '/usr/bin/uname' and argv == ['uname', '-p']:
            allowed_subprocesses.append({'executable': '/usr/bin/uname', 'arguments': ['-p'], 'purpose': 'stdlib platform.processor during h5py import'})
            return
    if event == 'socket.connect' or event == 'subprocess.Popen' or event == 'import' and args[0].split('.')[0] == 'vina':
        blocked.append(event)
        raise AssertionError('Network, native search and non-platform subprocesses forbidden')
sys.addaudithook(audit)
from installed_test_support import staged_support
import numpy as np
import pyunitwizard as puw

def policy():
    return {k: puw.configure.report()[k] for k in ['default_form', 'default_parser', 'standard_units', 'provenance']}

counts = dict.fromkeys(registration['direct_caps'], 0)
stage = 'custody'
def call(key, function, *args, **kwargs):
    global stage
    stage = key
    counts[key] += 1
    assert counts[key] <= registration['direct_caps'][key], key
    with (attempt / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps({'operation': key, 'direct_counts': counts}) + '\n')
    return function(*args, **kwargs)

"""Receiving body appended to the retained exact-payload isolated preamble."""
"""Minimal synthetic public comparison-flag reproduction, no protein input."""
try:
    assert files(prefix) == candidate['provider_files_sha256']
    previous = policy()
    observations = []
    for profile, length, time, charge in [('normal', 'nm', 'ps', 'elementary_charge'), ('pm_fs', 'pm', 'fs', 'coulomb')]:
        units = [length, time, 'kelvin', 'mole', 'dalton', charge, 'kJ/mol', 'kJ/(mol*' + length + ')', 'kJ/(mol*' + length + '**2)', 'radians']
        with puw.context(standard_units=units):
            caller = policy()
            import molsysmt as msm
            assert policy() == caller and msm.__version__ == candidate['wheel']['version']
            from molsysmt.native import MolSys
            source = call('constructors', MolSys, n_atoms=1)
            before = call('comparisons', msm.compare, source, source, n_atoms=True, include_none=True, output_type='dictionary')
            assert before == {'n_atoms': True}
            before = {key: bool(value) for key, value in before.items()}
            try:
                call('comparisons', msm.compare, source, source, component_type=True, include_none=True, output_type='dictionary')
            except msm.ArgumentError as error:
                observed = {'type': type(error).__name__, 'module': type(error).__module__, 'message': str(error), 'valid_component_type_flag_rejected': True}
            else:
                raise AssertionError('Reported flag rejection was not reproduced')
            after = call('comparisons', msm.compare, source, source, n_atoms=True, include_none=True, output_type='dictionary')
            assert before == after and policy() == caller
            after = {key: bool(value) for key, value in after.items()}
            observations.append({'profile': profile, 'control_before': before, 'control_after': after, 'observed_exception': observed, 'caller_preserved': True})
        assert policy() == previous
    assert counts == registration['direct_caps'] and not blocked
    assert files(prefix) == candidate['provider_files_sha256']
    assert files(Path(candidate['consumer_prefix'])) == candidate['consumer_files_sha256']
    assert files(Path(candidate['viewer_prefix'])) == candidate['viewer_files_sha256']
    assert {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')} == candidate['routine_metadata_sha256']
    write('receipt.json', {'source_commit': registration['source_commit'], 'stage': 'argument-diagnostic', 'profile': registration['profile'], 'outcome': 'PASS', 'qualification_complete': True, 'direct_counts': counts, 'observations': observations, 'provider_boundary_received': False, 'whole_reference_selection_accepted': False, 'interpretation': 'Minimal public comparison-flag rejection reproduced; original whole selection remains FAIL', 'synthetic_one_atom_systems': 2, 'new_protein_references': 0, 'native_searches': 0, 'blocked': blocked, 'allowed_subprocesses': allowed_subprocesses})
except BaseException as error:
    write('failure.json', {'stage': stage, 'exception_type': type(error).__name__, 'exception_module': type(error).__module__, 'message': str(error), 'direct_counts': counts, 'provider_boundary_received': False})
    traceback.print_exc()
    raise
