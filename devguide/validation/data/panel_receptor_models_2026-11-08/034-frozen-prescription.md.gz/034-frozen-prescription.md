# Panel receptor-state reference receiving — 2026-11-08

Owner: [DockingMT #33](../pending_proposals/validate_native_molsysmt_formats.md),
with [#49](../pending_proposals/retire_general_molecular_operations.md).
Starting consumer checkpoint: `b014b2598a1194eaee51c139e105e00ee259758a`.
Status: **prospectively registered; no receptor or docking case admitted**.

## Scientific choices and their limits

Keep both original complexes, their full protein dimer/tetramer, the selected
ligand instances and all original panel criteria. The unchanged
[ligand hypotheses](scientific_panel_ligand_models_2026-11-07.md) remain distinct
from the following protein reference hypotheses. Nominal pH7.4 is a model label,
not experimental pH or an environmental pKa calculation.

| Protein reference | Declared chemistry | Meaning and limits |
| --- | --- | --- |
| 1HSG biological assembly1, protein chains0/A and1/B | Observed PRO1–PHE99 on both chains; ammonium N and carboxylate C termini. Chain0/author A residue25 is ASH, with its stored H on OD2; chain1/author B residue25 is ASP. All other ASP/GLU are deprotonated, LYS/ARG charged, HIS explicitly HIE, CYS reduced neutral, ordinary remaining states unchanged. No declared disulfides or caps. | A fixed monoprotonated catalytic-dyad hypothesis. Choosing chainA/OD2 is explicit and occurs before docking; no crystal proton location or unique bound microstate is inferred. |
| 1STP biological assembly1, protein chains0/A,2/C,4/E,6/G, all author A | Each observed ALA13–VAL133 core is modelled as a separate linear peptide with ammonium N and carboxylate C termini. ASP/GLU deprotonated, LYS/ARG charged, HIS explicitly HIE, CYS reduced neutral, ordinary remaining states unchanged. No declared disulfides or caps. | Intended observed-core tetramer. These charges are a model of its boundaries, not measured experimental endpoint chemistry; residues outside13–133 are not reconstructed. |

The 2017 primary modelling study explicitly compares HIV-protease dyad states
and uses an OD2-protonated Asp25 in its monoprotonated ligand-bound model. Its
structure is 1SDT, not the retained 1HSG. The 2021 indinavir simulation explicitly
protonates chainA for another structure, 1K6C. These support a declared modelling
choice, not transfer of an experimental proton assignment.
[Kulp et al., 2017, Protein structures](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0183327),
[Sohraby and Aryapour, 2021, Methods](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0257916).
Primary NMR work on unliganded HIV protease supports a monoprotonated dyad while
also discussing different inhibitor-dependent states; it does not locate a
proton in 1HSG. [Torbeev and Kent, 2012](https://pmc.ncbi.nlm.nih.gov/articles/PMC3437676/).

HIE and reduced-CYS choices are explicit conventional reference hypotheses,
not residue-specific titration predictions or a disulfide search. The provider
template factory leaves stereochemistry, environmental protonation, geometry
and force-field coverage unassessed. Keep those limits. Before any application,
inspect actual source compatibility and all retained covalent connections;
incompatible source chemistry stops the selection rather than being overwritten.

The [prior environment evidence](scientific_panel_environment_2026-11-04.md)
retains ten/five observed water groups within5angstrom and the three non-target
BTN copies. Water-site literature prevents automatic dehydration; this increment
keeps their original bytes and leaves actual water/other-occupant modelling
unresolved. It neither silently deletes them nor adds an unqualified water model.
The original two-case panel and at-most24-search proposal stay unregistered.

## Prospective provider selection

This independently receives the **coordinate-free protein reference factory**,
before bound-source geometry completion or chemical-template application. No
terminal generation is needed to construct a reference; missing observed OXT
still requires MolSysMT #558's supported maps/history before application.
The failed anionic-BTN reference and provider #644 remain separate holds.

Use the two unchanged PDB inputs from the
[original input manifest](data/panel_admission_2026-11-04/manifest.json), with
explicit-only connectivity (`get_missing_bonds=False`) and public assembly1.
Public group/chain queries must recover all six previously observed chains,
their exact original chain IDs/names, contiguous author residue IDs, endpoint
identities and99/121 group counts. Query the observed sequences; do not parse
PDB atom tables or restore native molecular systems from inspection JSON.

For every observed chain, form the explicitly declared residue-state list and
call public `physchem.get_peptide_chemical_template` with ammonium/carboxylate,
no declared disulfides. Record source-group versus synthetic-template-group
indices as a declaration association, **not an atom map or applied correspondence**.
Check factory/provenance identities, zero coordinate structures, no indexed H,
stored-H inventory, complete peptide links and explicit unassessed checks.
Formal-charge counts use the provider's declared elementary-charge convention;
independently compare their total with the declared residue charges and the
cancelling +1/-1 termini. This elementary accounting is an analytic hypothesis
check, not a consumer charge-assignment implementation.

Save each of the six native coordinate-free templates through public H5MSM;
reopen them with the public provider reader and compare topology, chemical
assignments, preparation history and coordinate-free status. The synthetic
terminal OXT has no generated or experimental coordinate. Verify caller state
lists, public source/assembly snapshots and all original bytes remain unchanged.
Require two typed refusals: ambiguous HIS and an unsupported C-terminal state.
Neither rejection may mutate the already received templates or source records.

Two fresh complete processes: normal then pm/fs/coulomb, second only after
whole first PASS with identical worker/hypothesis/candidate/input bytes. Each
process selects both original cases and all six chains, without substituting
a smaller/easier case. Stop the whole selection on first failure and preserve
returned artifacts and unattempted members; no outcome-selected retry.

Direct caps per process: PDB conversions2, assemblies2, chain selectors2,
group-table queries6, valid/invalid factory attempts8, template summaries6,
formal-charge reads6, hydrogen inventories6, history reads12, H5 writes6 and
H5 reads6. Existing public snapshot-helper and provider-internal dispatches are
separate. No source mutation, template application, OXT/H generation, charge/type
assignment, energies, RMSD, detectors, browser or docking searches are allowed.

## Composition, resources and custody

Reuse the unchanged whole private faab727ca5b5c9078e2f2e505971fc0ea1cf1a8d provider
wheel SHA-256 c603fbde78a58fcec43d6d0fb8a6b27dabcbef706c19c35b4f5033c8a8dae9c6,
its qualified identical-input9e native, and consumer2ef82d2/private wheel
6db76835f4f3f9c41d06a163cb3a4fbc9e780597bfd89d2fc6a75d29cff31133.
Candidate manifest c7061d409bf59f8598027588f7dd8589edea16c36a58812436fad0c2adb5e76a
binds the whole provider/consumer/Viewer payloads and routine metadata. No
installation, native compilation or public dependency/candidate qualification.

Use Python3.14.10 with isolated/no-site imports, SDK95f693be10c9205ab9b912cb53453710a207bf45
and the unchanged declared unshipped test support. Allow only the exact current
Conda Git for bounded read-only SDK file verification and stdlib `uname -p`;
deny network, compiler, Vina and other subprocesses. Freeze actual producers,
prescription, candidate, hypothesis, inputs and resource declaration before work.

Run serial CPU0/nice10 with one native/build worker. Estimate512MiB group RSS;
cap1GiB group RSS,2GiB address space,CPU45s/wall60s per complete process.
Require at least13GiB available RAM plus1GiB before launch on this host; monitor
the13GiB reserve and owned group throughout. Availability is not a reservation.
No allocation is present; retain the prior bounded Slurm-query failure and fresh
RAM/CPU/swap/pressure observation. This is a finite small reference construction,
not a search campaign or permission to retry held native construction.
Stop only owned work and retain interruptions without automatic heavy restart.
Keep `.molsyssuite/panel-receptor-models-20261108` under #50 review2026-11-14.
