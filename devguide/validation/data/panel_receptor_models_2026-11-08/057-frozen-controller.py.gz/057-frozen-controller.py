"""Finite one-CPU receiver, reusing the retained measured resource monitor."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root = Path.cwd()
task = Path(__file__).resolve().parent
profile = sys.argv[1]
assert profile in ['normal', 'pm_fs'] and not (task / 'campaign-terminal.json').exists()
if profile == 'pm_fs':
    first = json.loads((task / 'templates-normal/resource-outcome.json').read_text())
    assert first['outcome'] == 'PASS' and first['group_terminal']
attempt = task / ('templates-' + profile)
attempt.mkdir(exist_ok=False)
guard = root / '.molsyssuite/e4-saved-carrier-20261107/pause-0650/launchers/e4_saved_carrier_guard.py'
assert hashlib.sha256(guard.read_bytes()).hexdigest() == '3663659769ae4cddabd4edc8e351558fe900b568f195496ffd0a07e6f0c65c2d'
functions = [n for n in ast.walk(ast.parse(guard.read_text())) if isinstance(n, ast.FunctionDef) and n.name in {'available', 'memory', 'limits', 'group_members', 'stop_owned_group', 'monitor'}]
assert len(functions) == 6
exec(compile(ast.Module(body=functions, type_ignores=[]), str(guard), 'exec'), globals())
mem = {line.split(':', 1)[0]: int(line.split(':', 1)[1].split()[0]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines()}
reserve = max(8 * 1024**3, ((mem['MemTotal'] + 5 * 1024**3 - 1) // (5 * 1024**3)) * 1024**3)
policy = {'cpu': 0, 'nice': 10, 'workers': 1, 'available_reserve_bytes': reserve, 'group_rss_limit_bytes': 1024**3, 'address_space_bytes': 2 * 1024**3, 'cpu_seconds': 45, 'wall_seconds': 60}
plan = json.loads((task / 'plan.json').read_text())
assert hashlib.sha256(Path(plan['git_executable']).read_bytes()).hexdigest() == plan['git_sha256']
assert available() >= reserve + policy['group_rss_limit_bytes']
frozen = {}
for source, name in [(guard, 'guard.py'), (task / 'template_worker.py', 'worker.py'), (Path(__file__), 'controller.py'), (task / 'plan.json', 'plan.json'), (task / 'hypothesis.json', 'hypothesis.json'), (Path(plan['candidate_path']), 'candidate.json'), (root / 'devtools/conda-build/resources.toml', 'resources.toml'), (root / 'devguide/validation/scientific_panel_receptor_models_2026-11-08.md', 'prescription.md')]:
    destination = attempt / ('frozen-' + name)
    shutil.copyfile(source, destination)
    frozen[destination.name] = hashlib.sha256(destination.read_bytes()).hexdigest()
for relative, expected in plan['inputs'].items():
    source = root / relative
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    shutil.copyfile(source, attempt / source.name)
if profile == 'pm_fs':
    assert frozen == json.loads((task / 'templates-normal/registration.json').read_text())['frozen_sha256']
registration = {'source_commit': plan['source_commit'], 'stage': 'templates', 'profile': profile, 'owner': 'uibcdf/dockingmt#33', 'registered_at_utc': datetime.now(timezone.utc).isoformat(), 'policy': policy, 'physical_ram_bytes': mem['MemTotal'], 'initial_available_bytes': available(), 'estimated_peak_group_rss_bytes': 512 * 1024**2, 'frozen_sha256': frozen, 'input_sha256': {Path(p).name: value for p, value in plan['inputs'].items()}, 'direct_caps': plan['direct_caps'], 'scope': plan['scope'], 'scheduler': plan['scheduler']}
(attempt / 'registration.json').write_text(json.dumps(registration, indent=2) + '\n')
env = os.environ.copy()
env.update(DMT_RECEPTOR_ROOT=str(root), DMT_RECEPTOR_TASK=str(task), DMT_RECEPTOR_ATTEMPT=str(attempt), PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', LD_LIBRARY_PATH='/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/lib')
for name in ['tmp', 'cache', 'numba-cache', 'mpl-cache']:
    (attempt / name).mkdir()
env.update(TMPDIR=str(attempt / 'tmp'), XDG_CACHE_HOME=str(attempt / 'cache'), NUMBA_CACHE_DIR=str(attempt / 'numba-cache'), MPLCONFIGDIR=str(attempt / 'mpl-cache'))
for key in ['OMP_NUM_THREADS', 'OMP_THREAD_LIMIT', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS', 'RAYON_NUM_THREADS', 'CARGO_BUILD_JOBS', 'MAX_JOBS']:
    env[key] = '1'
with (attempt / 'stdout.log').open('xb') as stdout, (attempt / 'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(['/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python', '-B', '-I', '-S', str(attempt / 'frozen-worker.py')], cwd=root, env=env, stdout=stdout, stderr=stderr, start_new_session=True, preexec_fn=limits)
    outcome = monitor(process, policy)
try:
    receipt = json.loads((attempt / 'receipt.json').read_text())
    semantic = receipt['outcome'] == 'PASS' and receipt['qualification_complete'] and receipt['profile'] == profile
except Exception as error:
    semantic = False
    outcome['qualification_diagnostic'] = type(error).__name__ + ': ' + str(error)
outcome['outcome'] = 'PASS' if semantic and outcome['exit_code'] == 0 and outcome['resource_interruption'] is None and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] else 'FAIL'
(attempt / 'resource-outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome), flush=True)
if outcome['outcome'] != 'PASS':
    (task / 'campaign-terminal.json').write_text(json.dumps({'outcome': 'FAIL', 'failed_attempt': attempt.name, 'further_molecular_work_permitted': False, 'unattempted': ['pm_fs'] if profile == 'normal' else []}, indent=2) + '\n')
    print((attempt / 'stderr.log').read_text()[-4500:])
    raise SystemExit(1)
print(json.dumps(receipt))
if profile == 'pm_fs':
    (task / 'campaign-terminal.json').write_text(json.dumps({'outcome': 'PASS', 'further_molecular_work_permitted': False, 'accepted_profiles': ['normal', 'pm_fs'], 'bound_receptors_admitted': 0}, indent=2) + '\n')
