"""Prospective public saved-template persistence diagnostic."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tomllib
import traceback
from dataclasses import asdict

root = Path(os.environ['DMT_RECEPTOR_ROOT'])
task = Path(os.environ['DMT_RECEPTOR_TASK'])
attempt = Path(os.environ['DMT_RECEPTOR_ATTEMPT'])
registration = json.loads((attempt / 'registration.json').read_text())
candidate = json.loads((attempt / 'frozen-candidate.json').read_text())
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')
prefix = Path(candidate['prefix'])
sdk = root / '.molsyssuite/publication-sdk/devtools/scripts'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def files(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}

def write(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

assert sys.flags.isolated and sys.flags.no_site
assert os.sched_getaffinity(0) == {0} and os.getpriority(os.PRIO_PROCESS, 0) >= 10
sys.path[:0] = [str(prefix), candidate['consumer_prefix'], candidate['viewer_prefix'], str(routine / 'lib/python3.14/site-packages'), str(sdk)]
blocked, allowed_subprocesses = [], []
declaration = tomllib.loads((attempt / 'frozen-resources.toml').read_text())['installed_tests']['support']
git_files = {str(root): (registration['source_commit'], {r['source'] for r in declaration['files']}), str(sdk.parents[1]): ('95f693be10c9205ab9b912cb53453710a207bf45', {'devtools/scripts/installed_test_support.py', 'devtools/scripts/installed_noarch.py', 'devtools/scripts/installed_imports.py', 'devtools/scripts/installed_test_dependencies.py'})}
git_read_count = 0
def audit(event, args):
    global git_read_count
    if event == 'subprocess.Popen':
        executable, argv = os.fsdecode(args[0]), args[1]
        if shutil.which(executable) == json.loads((attempt / 'frozen-plan.json').read_text())['git_executable'] and isinstance(argv, list) and len(argv) >= 4 and argv[:2] == ['git', '-C'] and argv[2] in git_files:
            commit, paths = git_files[argv[2]]
            if argv[3:] == ['rev-parse', 'HEAD'] or any(argv[3:] in (['rev-parse', commit + ':' + path], ['hash-object', '--no-filters', str(Path(argv[2]) / path)]) for path in paths):
                git_read_count += 1
                return
        if shutil.which(executable) == '/usr/bin/uname' and argv == ['uname', '-p']:
            allowed_subprocesses.append({'executable': '/usr/bin/uname', 'arguments': ['-p'], 'purpose': 'stdlib platform.processor during h5py import'})
            return
    if event == 'socket.connect' or event == 'subprocess.Popen' or event == 'import' and args[0].split('.')[0] == 'vina':
        blocked.append(event)
        raise AssertionError('Network, native search and non-platform subprocesses forbidden')
sys.addaudithook(audit)
from installed_test_support import staged_support
import numpy as np
import pyunitwizard as puw

def policy():
    return {k: puw.configure.report()[k] for k in ['default_form', 'default_parser', 'standard_units', 'provenance']}

counts = dict.fromkeys(registration['direct_caps'], 0)
stage = 'custody'
def call(key, function, *args, **kwargs):
    global stage
    stage = key
    counts[key] += 1
    assert counts[key] <= registration['direct_caps'][key], key
    with (attempt / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps({'operation': key, 'direct_counts': counts}) + '\n')
    return function(*args, **kwargs)

"""Receiving body appended to the retained exact-payload isolated preamble."""
"""Read the already written reference through public persistence, without repair."""
support = None
try:
    assert files(prefix) == candidate['provider_files_sha256']
    assert files(Path(candidate['consumer_prefix'])) == candidate['consumer_files_sha256']
    assert files(Path(candidate['viewer_prefix'])) == candidate['viewer_files_sha256']
    assert {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')} == candidate['routine_metadata_sha256']
    before = json.loads((attempt / '1HSG-chain-0-template-snapshot.json').read_text())
    previous = policy()
    context = {'candidate_sha': registration['source_commit'], 'qualification_sha': registration['source_commit'], 'provider_sha': '95f693be10c9205ab9b912cb53453710a207bf45', 'sha256': candidate['consumer_wheel_sha256']}
    observations = []
    with staged_support(root, declaration, ('dockingmt', 'molsysviewer_dockingmt'), context=context) as support:
        for profile, length, time, charge in [('normal', 'nm', 'ps', 'elementary_charge'), ('pm_fs', 'pm', 'fs', 'coulomb')]:
            units = [length, time, 'kelvin', 'mole', 'dalton', charge, 'kJ/mol', 'kJ/(mol*' + length + ')', 'kJ/(mol*' + length + '**2)', 'radians']
            with puw.context(standard_units=units):
                caller = policy()
                import molsysmt as msm
                from dmt_test_support.qualify_chemical_templates import detached_record
                assert policy() == caller and msm.__version__ == candidate['wheel']['version']
                restored = call('h5_reads', msm.convert, str(attempt / '1HSG-chain-0.h5msm'), to_form='molsysmt.MolSys')
                topology = call('domain_exports', msm.convert, restored.topology, to_form='molsysmt.TopologyDict').data
                chemical_states = call('domain_exports', msm.convert, restored.chemical_states, to_form='molsysmt.ChemicalStatesDict').to_dict()
                summary = call('summaries', msm.get, restored, output_type='dictionary', n_atoms=True, n_groups=True, n_bonds=True, n_structures=True)
                history = call('history_reads', restored.chemical_states.get_preparation_history)
                after = detached_record({'topology': topology, 'chemical_states': chemical_states, 'n_structures': summary['n_structures']})
                write(profile + '-restored-snapshot.json', after)
                write(profile + '-summary-history.json', detached_record({'summary': summary, 'history': history}))
                observations.append({'profile': profile, 'topology_equal': before['topology'] == after['topology'], 'chemical_states_history_equal': before['chemical_states'] == after['chemical_states'], 'n_structures_before': before['n_structures'], 'n_structures_after': after['n_structures'], 'structural_domain_present_after': restored.structures is not None, 'exact_snapshot_equal': before == after, 'source_native_sha256': sha(attempt / '1HSG-chain-0.h5msm'), 'caller_preserved': policy() == caller})
                assert policy() == caller
            assert policy() == previous
        support.check()
    assert counts == registration['direct_caps'] and not blocked and policy() == previous
    assert files(prefix) == candidate['provider_files_sha256']
    assert files(Path(candidate['consumer_prefix'])) == candidate['consumer_files_sha256']
    assert files(Path(candidate['viewer_prefix'])) == candidate['viewer_files_sha256']
    assert {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')} == candidate['routine_metadata_sha256']
    for basename, expected in registration['input_sha256'].items():
        assert sha(attempt / basename) == expected
    write('receipt.json', {'source_commit': registration['source_commit'], 'stage': 'diagnostic', 'profile': registration['profile'], 'outcome': 'PASS', 'qualification_complete': True, 'direct_counts': counts, 'observations': observations, 'interpretation': 'Public saved-artifact inspection completed; original exact persistence gate and whole reference selection remain FAIL/unreceived', 'provider_persistence_received': False, 'whole_reference_selection_accepted': False, 'new_template_constructors': 0, 'native_searches': 0, 'blocked': blocked, 'allowed_subprocesses': allowed_subprocesses, 'support_binding_git_reads': git_read_count})
except BaseException as error:
    write('failure.json', {'stage': stage, 'exception_type': type(error).__name__, 'exception_module': type(error).__module__, 'message': str(error), 'direct_counts': counts, 'provider_persistence_received': False})
    traceback.print_exc()
    raise
finally:
    if support is not None:
        write('support-receipt.json', support.receipt)
