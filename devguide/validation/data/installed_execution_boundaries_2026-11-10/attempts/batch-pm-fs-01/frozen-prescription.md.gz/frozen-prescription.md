# Installed batch execution and refusal boundaries — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with
resource custody #50 and complete functional delivery #73. Status: registered;
execution pending. Source checkpoint `958f16a15ebaaef8c641a6c77924d3b55de92456`.

## Question and coverage ledger

Receive the complete existing batch workflow and its backend-capability and
temporary-file failure boundaries through the genuine installed consumer. The
original isolated 2,593-node collection is a selection graph, not execution
evidence. Its 26-module offline selection received only 38 of the 41 batch cases:
the two Vina/Vinardo individual-versus-batch nodes and one missing-file isolation
node were explicitly excluded. Backend-contract and staging-lifecycle modules
were outside that offline selection. This is a focused three-module ledger,
not a retrospective whole-suite coverage certificate.

The registered `execution-ledger.json` authenticates that original collection
manifest, all 98 selected node identities, the prior offline selector and each
unchanged module digest against the original qualification input declaration.
Retain earlier evidence with its own runtime/provider producers; no old passing
population is relabelled as execution on the current wheel.

## Immutable composition and admitted work

Reuse the genuine aeae47d wheel, `0.0.0+351.gaeae47d`, 157821 bytes, SHA256
`0b303ae371466a6736e8d194a89a54048f8bc51de3cd293cdc68c06050ae042b`.
The actual ordinary receiver and independent source-free qualification root live
under `installed-reconstruction-20261109`. Verify all 67 runtime paths, private
tools/unit libraries, 305 qualification inputs and 606 support declarations before
and after each cell. There is no consumer source-path overlay or sibling refresh.

Keep MolSysMT 0c6f9c7, Viewer 1187fc18, ArgDigest 07126411, PyUnitWizard f82b618e,
SMonitor c1b6ce29 and DepDigest 032d345b exact, including native and Python hashes;
stale distribution labels remain separately recorded. Shared SDKs retain exact
738fe8dd/95f693be identities. Reuse the original authenticated 103-file Vina1.2.7
engine prefix under `e5-timed-replay-20261107/layouts-admission-01/producer/engine`.
Verify its bytes before/after and observe actual final loaded extension maps.
Do not rebuild, reinstall, change remotes or weaken source-context verification.

Use only the original synthetic four-record receptor and two-record partner,
origin-centred 10-angstrom box, original seed123, CPU1, exhaustiveness1 and at
most two requested poses. Preserve the exact native calls/assertions/tolerances.
No scientific reference, input preparation, force field or new accuracy case is
introduced. A software count is not a population of independent molecular cases.

1. Pilot: the real `test_batch.py` module plus 40 explicit node deselections,
   selecting only the original missing-file isolation case. Expected one pass,
   two actual native searches and a middle recorded failure before native setup.
2. If the pilot fits the registered bounds, the entire unchanged `test_batch.py`:
   41 cases without exclusions under normal then pm/fs caller unit policies.
   Expected ten actual searches per policy: two individual and two batch calls
   for each scoring method, plus the two successes surrounding the missing file.
3. Entire unchanged `test_backend_contracts.py` and
   `test_vina_staging_lifecycle.py`: 38+19=57 cases under each caller policy,
   without exclusions and with actual native construction forbidden.

Native wrappers preserve signatures/defaults and delegate actual calls unchanged.
Permit native construction only inside the three named original live batch nodes;
reject CPU0, larger inputs/grids and unregistered score/optimization/randomization
or viewer work. Preserve actual pose/energy outputs and record method/node/input
identities. Observe JSON exports used by the original live tests without wrapping
or retaining the streaming iterator/results; preserve its weak-reference and
traceback-lifetime controls. Intentional fake backends remain software controls,
never native observations.

The original comparisons retain each native result's complete record after
excluding only invocation-local elapsed time and temporary receptor path. The
missing-file case preserves failure identity and verifies the next successful
geometry/scores. Capability refusals precede preparation/provider execution;
staging failures preserve primary exceptions, caller-owned bytes and cleanup
warnings even under warning-as-error policy. Retain original warnings rather
than suppressing them.

## Resources, custody and limits

Initial host: 64,978,440,192 bytes physical RAM; 60,394,229,760 available; 20 logical
CPUs; load1.36/1.21/1.33; about90% interval CPU idle. Memory PSI is zero and measured
swap I/O is zero; existing swap allocation is not interpreted as current pressure.
Slurm commands exist but there is no allocation; the prior applicability check
was inconclusive. Free resources are not reserved.

Run serially on CPU0, nice10, one native/build worker, with a 13GiB available-RAM
reserve, 1GiB group RSS, 2GiB address space, 60/65 soft/hard CPU seconds and
180 wall seconds. Expected peak is768MiB for native batch/pilot and256MiB for
controls, conservatively above previous single-engine observations below553MiB.
Monitor owned descendants; stop only owned work if limits/headroom are threatened.
Preserve interruptions and never automatically restart after a headroom stop.

Retain registrations, exact programs/input/output identities, native observations,
all outcomes and independent readers under
`.molsyssuite/installed-execution-boundaries-20261110`, owners#47/#50/#73, review
2026-11-14. Keep the original receiver/harness/engine/SDK inputs; retire managed
support resources per cell. Preserve the untracked human migration backup.

Full #47/#30/#73, public Conda/closure/eight OS-minor lanes, SSH#100 under
MolSysSuite#178 and hosted#21/#28 remain separate. Actual kernel/browser/comm/
canvas and native-build holds remain in force. MolSysMT#521/#558 and #33/#49
scientific-panel admission retain their owners. No remote CI is dispatched;
`[skip ci]` supplies no hosted passing evidence.
