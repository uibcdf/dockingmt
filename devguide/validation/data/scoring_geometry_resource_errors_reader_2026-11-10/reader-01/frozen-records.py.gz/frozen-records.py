"""Seal and independently read finite actual-engine software controls."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/scoring-geometry-resources-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/scoring_geometry_resource_errors_2026-11-10';companion=root/'devguide/validation/data/scoring_geometry_resource_errors_reader_2026-11-10'
qualified=['dockingmt/engines/_vina_scoring.py','dockingmt/engines/vina.py','dockingmt/score.py','dockingmt/core/pose_audit.py','tests/test_input_resource_errors.py','tests/test_pose_audit.py']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.scoring_geometry_resource_errors@1','owner':'uibcdf/dockingmt#107','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'qualification_base':'a0c184f23c78c57c8259382dc46f77280002adfd','runtime_producer':'Explicit source overlay on base, bound by qualified hashes; old aeae47d artifact is comparison only','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored actual-engine software evidence; zero native/molecular replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 for name in qualified:paths.append((root/name,'qualified/'+name))
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 import ast
 from collections import Counter
 import xml.etree.ElementTree as ET
 cohort=d('producer/expected-cohort.json');refs=d('producer/reference-fixtures.json');measured={}
 for label,count,failed,code,native in [('red-01',16,8,1,0),('complete-normal-01',203,0,0,2),('complete-pm-fs-01',203,0,0,2)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['counts']=={'tests':count,'failures':failed,'errors':0,'skipped':0} and row['pytest_exit_code']==code and row['warnings']==0 and row['cohort_unchanged'] and not row['forbidden_operations'] and d(prefix+'cohort.json')==cohort and row['source_origins']['dockingmt'].endswith('/dockingmt/dockingmt/__init__.py')
  assert row['qualification_source']=='a0c184f23c78c57c8259382dc46f77280002adfd' and row['scope']=='source; no new installed artifact'
  counts=row['engine_call_counts'];assert counts.get('__init__',0)==counts.get('score',0)==native and not any(counts.get(k,0) for k in ['dock','optimize','randomize','poses','energies'])
  assert row['provider_call_counts']==({'convert':2,'get':6} if native else {})
  cases=[n for n in ET.fromstring(data[prefix+'junit.xml']).iter('testcase') if n.get('name','').startswith('test_scoring_geometry_preserves_resource_errors_and_cleans_staging[')];assert len(cases)==16
  for case in cases:
   expected_failure=label=='red-01' and any('['+kind+'-' in case.get('name','') for kind in ['memory','os_memory']);assert (case.find('failure') is not None)==expected_failure
  if native:
   calls=d(prefix+'engine-calls.json');assert calls==row['engine_calls'] and all(c['outcome']=='PASS' for c in calls);scores=[]
   for c in calls:
    q=c['parameters'];assert 'test_fresh_native_scoring_and_rescoring_produce_auditable_evidence' in c['test_node']
    if c['call']=='__init__':assert q['cpu']==1 and q['seed']==17 and q['sf_name'] in ['vina','vinardo']
    if c['call']=='compute_vina_maps':assert q['center']==[0.0]*3 and q['box_size']==[10.0]*3
    if c['call']=='score':assert q['unbound_energy'] is None and c['result_shape']==[8] and c['native_unit']=='kcal/mol';scores.append(c['native_components'])
    for role in ['receptor','partner']:
     if role not in c:continue
     info=c[role];raw=data[prefix+'inputs/backend/'+str(c['run'])+'/'+role+'.pdbqt'];assert len(raw)==info['bytes'] and hashlib.sha256(raw).hexdigest()==info['sha256']==refs['MINIMAL_REC_PDBQT' if role=='receptor' else 'MINIMAL_LIG_PDBQT']['sha256'];assert info['atom_records']==(4 if role=='receptor' else 2)
   exports=row['exports'];assert [e['kind'] for e in exports]==['score','score','audit_pose']
   for e in exports:assert hashlib.sha256(data[prefix+e['file']]).hexdigest()==e['sha256']
   first,second,report=[d(prefix+e['file']) for e in exports];assert len(first['scores'])==8 and len(second['scores'])==16 and list(first['scores'].values())==scores[0] and list(second['scores'].values())[8:]==scores[1]
   assert first['coordinates']==second['coordinates'] and first['metadata']['scoring_history'][0]==second['metadata']['scoring_history'][0] and len(second['metadata']['scoring_history'])==2 and report['status']=='consistent' and report['scope']=='saved_pose_internal_consistency'
   events=d(prefix+'provider-events.json');assert len(events)==8 and events==row['provider_events'] and all(e['outcome']=='PASS' for e in events) and [e['call'] for e in events]==['convert','get','get','get']*2
   for e in events:
    if e['call']=='convert':assert e['input_sha256']==refs['MINIMAL_LIG_PDBQT']['sha256'] and e['parameters']=={'to_form':'molsysmt.MolSys','discard_torsion_tree':True}
   native_name='lib/python3.14/site-packages/vina/_vina_wrapper.cpython-314-x86_64-linux-gnu.so';assert [v for k,v in d(prefix+'native-maps.json').items() if k.endswith('/'+native_name)]==[d(prefix+'frozen-engine-receipt.json')['paths'][native_name]]
  else:assert not row['engine_calls'] and not row['provider_events'] and not row['exports']
  measured[label]={'cases':count,'failed':failed,'pytest_exit':code,'actual_native_scores':native}
 assert data['attempts/complete-normal-01/frozen-worker.py']==data['attempts/complete-pm-fs-01/frozen-worker.py']
 green=d('attempts/complete-normal-01/frozen-qualification-inputs.json');assert len(green)==788 and green==d('attempts/complete-pm-fs-01/frozen-qualification-inputs.json')
 red=d('attempts/red-01/frozen-qualification-inputs.json');assert set(red)==set(green) and [k for k in red if red[k]!=green[k]]==['dockingmt/engines/_vina_scoring.py']
 baseline=d('producer/baseline-qualification-inputs.json');assert {k for k in baseline if baseline[k]!=green[k]}=={'dockingmt/engines/_vina_scoring.py','tests/test_input_resource_errors.py'}
 assert hashlib.sha256(data['producer/baseline-_vina_scoring.py.txt']).hexdigest()==baseline['dockingmt/engines/_vina_scoring.py']==red['dockingmt/engines/_vina_scoring.py']
 before=ast.parse(data['producer/baseline-_vina_scoring.py.txt']);after=ast.parse(data['qualified/dockingmt/engines/_vina_scoring.py']);after.body=[n for n in after.body if not(isinstance(n,ast.Import) and len(n.names)==1 and n.names[0].name=='errno')]
 function=next(n for n in after.body if isinstance(n,ast.FunctionDef) and n.name=='_input_pose');block=next(n for n in function.body if isinstance(n,ast.Try));assert len(block.handlers)==2 and isinstance(block.handlers[0].type,ast.Name) and block.handlers[0].type.id=='MemoryError' and len(block.handlers[0].body)==1 and isinstance(block.handlers[0].body[0],ast.Raise) and block.handlers[0].body[0].exc is None
 block.handlers.pop(0);handler=block.handlers[0];expected_if=ast.parse('if isinstance(exc, OSError) and exc.errno == errno.ENOMEM: raise').body[0];assert ast.dump(handler.body.pop(0),include_attributes=False)==ast.dump(expected_if,include_attributes=False)
 assert ast.dump(after,include_attributes=False)==ast.dump(before,include_attributes=False)
 old_test=data['producer/baseline-test_input_resource_errors.py.txt'];assert hashlib.sha256(old_test).hexdigest()==baseline['tests/test_input_resource_errors.py'];old_nodes=Counter(ast.dump(n,include_attributes=False) for n in ast.parse(old_test).body);new_nodes=Counter(ast.dump(n,include_attributes=False) for n in ast.parse(data['qualified/tests/test_input_resource_errors.py']).body);assert not old_nodes-new_nodes and sum((new_nodes-old_nodes).values())==5
 original=d('attempts/original-installed-diagnostic/receipt.json');assert original['diagnostic_completed'] and original['source_module_bytes_match_installed'] and not original['actual_memory_exhaustion'] and original['actual_molecular_native_operations']==0 and all(r['actual_type']=='ArgumentError' and r['code']=='DMT-E002' and r['same_cause'] and not r['same_exception'] for r in original['rows'])
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   r=json.loads(raw);assert r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids'] and r['minimum_available_bytes']>13*1024**3 and r['outcome']==('FAIL' if '/red-01/' in name else 'PASS')
 for name in qualified:assert (root/name).read_bytes()==data['qualified/'+name] and hashlib.sha256(data['qualified/'+name]).hexdigest()==green[name]
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),populations=measured,qualified_sources=6,original_test_nodes_preserved=True,only_runtime_resource_handlers_changed=True,actual_native_score_calls=4,new_installed_artifact_received=False,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json']);path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete and row['counts']==counts and row['receptor_final']==events.final.data
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':row['pytest_exit_code'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==3 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1600])
