"""Execute declared installed small-fixture tests through the shared runner."""
from collections import Counter
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib
import xml.etree.ElementTree as ET

root=Path(os.environ['DMT_SMALL_ROOT']);task=Path(os.environ['DMT_SMALL_TASK']);attempt=Path(os.environ['DMT_SMALL_ATTEMPT']);reg=json.loads((attempt/'registration.json').read_text())
def sha(p):
 with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
sdk=root/'.molsyssuite/publication-sdk';assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45';assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
old=root/'.molsyssuite/record-wheel-inputs-20261109';artifact=json.loads((old/'artifact.json').read_text());installation=json.loads((old/'installation.json').read_text());site=Path(installation['site']);assert sha(artifact['wheel'])==artifact['wheel_sha256']
assert artifact['wheel_sha256']=='0ed16b5a607a684be611b964b1996f56cc3273f7fcf012e6f86403551f3e91dd'
assert Path(sys.prefix)==Path(installation['prefix'])
def verify_receiver():
 for group in ['consumer_sha256','tool_sha256','unit_sha256']:
  for name,digest in installation[group].items():assert sha(site/name)==digest
verify_receiver();save(attempt/'wheel.json',artifact)
harness=root
inventory=tomllib.loads((root/'devtools/conda-build/resources.toml').read_text())
selection=json.loads((attempt/('frozen-'+reg['selection']+'.json')).read_text())
paths={r['source'] for r in inventory['installed_tests']['support']['files']}
paths.update(n.split('::')[0] for n in selection if not n.startswith('--'))
paths.update(str(p.relative_to(root)) for folder in ['dockingmt','molsysviewer_dockingmt'] for p in (root/folder).rglob('*.py'))
inputs={name:sha(root/name) for name in sorted(paths)}
def verify_inputs():
 for name,digest in inputs.items():assert sha(root/name)==digest
verify_inputs();save(attempt/'qualification-inputs.json',inputs)
shutil.copyfile(root/'devtools/conda-build/resources.toml',attempt/'frozen-resources.toml')
for name in sorted(paths):
 if name.endswith('.py'):
  destination=attempt/'inputs'/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,destination)
def cohort():
 return {name:{'commit':subprocess.check_output(['git','-C',str(root.parent/name),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(root.parent/name),'status','--porcelain'],text=True),'python_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.py')},'native_sha256':{str(p.relative_to(root.parent/name)):sha(p) for p in (root.parent/name/name).rglob('*.so')},'distribution_version':metadata.version(name)} for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']}
before=cohort();save(attempt/'cohort.json',before)
engine=root/'.molsyssuite/e5-timed-replay-20261107/layouts-admission-01/producer/engine';engine_receipt=root/'.molsyssuite/e1-public-composition-20261106/final_engine_byte_receipt.json';engine_hashes=json.loads(engine_receipt.read_text())['paths'];assert len(engine_hashes)==103
assert all(sha(engine/n)==digest for n,digest in engine_hashes.items());shutil.copyfile(engine_receipt,attempt/'frozen-engine-receipt.json')
sys.path[:0]=[str(root),str(engine/'lib/python3.14/site-packages')]
def check_installed_imports(roots,prefix,harness):
 import importlib
 result={}
 for name in roots:
  module=importlib.import_module(name);path=Path(module.__file__).resolve();assert path.is_relative_to(root/name);result[name]=str(path)
 return result
import pyunitwizard as puw
units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if reg['profile']=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
engine_attempts=[];provider_calls=Counter()
def forbidden(*args,**kwargs):engine_attempts.append('engine/viewer operation');raise AssertionError('Small-fixture receiving attempted engine/viewer work')
with puw.context(default_form='pint',default_parser='pint',standard_units=units):
 caller=puw.configure.report();origins=check_installed_imports(('dockingmt','molsysviewer_dockingmt'),Path(sys.prefix),harness)
 import dockingmt as dmt
 import molsysmt as msm
 import molsysviewer as msv
 import vina
 assert Path(dmt.__file__).resolve()==root/'dockingmt/__init__.py'
 assert json.loads(metadata.distribution('dockingmt').read_text('direct_url.json'))['archive_info']['hashes']['sha256']==artifact['wheel_sha256']
 assert Path(vina.__file__).resolve().is_relative_to(engine/'lib/python3.14/site-packages/vina')
 for name in ['molsysmt','molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']:assert Path(__import__(name).__file__).resolve().is_relative_to(root.parent/name/name)
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 for name in ['__init__','dock','score','optimize','compute_vina_maps','randomize']:setattr(vina.Vina,name,forbidden)
 msv.MolSysView=forbidden
 def observed(name,operation):
  def call(*args,**kwargs):provider_calls[name]+=1;return operation(*args,**kwargs)
  return call
 for name in ['convert','get','set','copy','select','extract','merge']:setattr(msm,name,observed(name,getattr(msm,name)))
 for name in ['assign_partial_charges','assign_autodock_atom_types','add_missing_hydrogens','merge_nonpolar_hydrogens']:setattr(msm.build,name,observed('build.'+name,getattr(msm.build,name)))
 inventory['import_name']='dockingmt';inventory['installed_tests']['paths']=[n for n in selection if not n.startswith('--')];inventory['installed_tests']['pytest_args']=['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'pytest-cache')]+[n for n in selection if n.startswith('--')]
 import pytest
 status=int(pytest.main(inventory['installed_tests']['pytest_args']+['--import-mode=importlib','-o','pythonpath=']+[str(root/n) for n in selection if not n.startswith('--')]))
 for key in ['default_form','default_parser','standard_units']:assert puw.configure.report()[key]==caller[key]
 final_origins=check_installed_imports(('dockingmt','molsysviewer_dockingmt'),Path(sys.prefix),harness)
counts={k:sum(int(row.get(k,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
from pytest_receptor import read_artifact
events=read_artifact(attempt/'events.jsonl');assert events.complete
verify_receiver();verify_inputs();assert cohort()==before and not engine_attempts and all(sha(engine/n)==digest for n,digest in engine_hashes.items())
native_maps={}
for line in Path('/proc/self/maps').read_text().splitlines():
 fields=line.split(None,5)
 if len(fields)==6 and fields[5].startswith('/') and '.so' in fields[5] and Path(fields[5]).is_file():native_maps[fields[5]]=sha(fields[5])
save(attempt/'native-maps.json',native_maps)
save(attempt/'receipt.json',{'profile':reg['profile'],'selection':selection,'pytest_exit_code':status,'counts':counts,'receptor_final':events.final.data,'warnings':events.final.data['counts']['warnings'],'provider_call_counts':dict(provider_calls),'engine_attempts':engine_attempts,'reference_old_wheel_sha256':artifact['wheel_sha256'],'source_runtime_version':dmt.__version__,'runtime_mode':'source working tree; exact frozen code/inputs','qualification_source':reg['qualification_source'],'installed_origins':final_origins,'cohort_unchanged':True,'caller_policy':caller,'support_inputs':606,'full_scientific_gate':False})
raise SystemExit(status)
