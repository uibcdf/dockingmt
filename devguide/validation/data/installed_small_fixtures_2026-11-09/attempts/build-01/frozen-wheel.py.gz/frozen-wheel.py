"""Build and normally install this exact private consumer wheel, without deps."""
import ast
import base64
import csv
from email.parser import BytesParser
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import tomllib
import venv
import zipfile

root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/installed-small-fixtures-20261109';stage=sys.argv[1]
producer='bba53f602c2e30a5817808bda303c0f736405651';old=root/'.molsyssuite/record-wheel-inputs-20261109'
def sha(p):
 with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def run(args,name,cwd=attempt):
 with (attempt/(name+'.log')).open('xb') as stream:subprocess.run(args,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,check=True)
inventory=tomllib.loads((root/'devtools/conda-build/resources.toml').read_text());required={n.removeprefix('site-packages/') for n in inventory['required_paths']};assert len(required)==67
if stage=='build':
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==producer and not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root)
 wheel_dir=task/'wheels';wheel_dir.mkdir()
 with tempfile.TemporaryDirectory(prefix='source-',dir=attempt) as tmp:
  source=Path(tmp)/'source';run(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(root),str(source)],'clone');run(['git','-c','core.hooksPath=/dev/null','checkout','--detach',producer],'checkout',source)
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
  hashes={n:sha(source/n) for n in required if n!='dockingmt/_version.py'}
  run([sys.executable,'-I','-B','-m','pip','--isolated','--disable-pip-version-check','wheel','--no-index','--no-cache-dir','--no-deps','--no-build-isolation','--wheel-dir',str(wheel_dir),str(source)],'build',source)
 wheels=list(wheel_dir.glob('*.whl'));assert len(wheels)==1;wheel=wheels[0]
 with zipfile.ZipFile(wheel) as z:
  names=z.namelist();assert len(set(names))==len(names) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
  assert {n for n in names if '.dist-info/' not in n}==required
  payload={n:hashlib.sha256(z.read(n)).hexdigest() for n in names}
  for n,digest in hashes.items():assert payload[n]==digest
  meta_name=next(n for n in names if n.endswith('.dist-info/METADATA'));meta=BytesParser().parsebytes(z.read(meta_name));version=meta['Version'];assert producer[:7] in version and meta['Name']=='dockingmt' and meta['License-Expression']=='MIT'
  assert any(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='__version__' for t in n.targets) and ast.literal_eval(n.value)==version for n in ast.parse(z.read('dockingmt/_version.py')).body)
  record=next(n for n in names if n.endswith('.dist-info/RECORD'))
  for name,digest,size in csv.reader(io.StringIO(z.read(record).decode())):
   raw=z.read(name)
   if name==record:assert not digest and not size
   else:assert digest=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode() and int(size)==len(raw)
  assert z.read(next(n for n in names if n.endswith('.dist-info/licenses/LICENSE')))==(root/'LICENSE').read_bytes()
  for name in [meta_name,record,next(n for n in names if n.endswith('.dist-info/WHEEL'))]:(attempt/Path(name).name).write_bytes(z.read(name))
 old_artifact=json.loads((old/'artifact.json').read_text());changed=[n for n in required if payload[n]!=old_artifact['payload_sha256'][n]];assert set(changed)=={'dockingmt/preparation/_export.py','dockingmt/_version.py'}
 artifact={'source_commit':producer,'version':version,'wheel':str(wheel),'wheel_sha256':sha(wheel),'wheel_bytes':wheel.stat().st_size,'payload_sha256':payload,'runtime_paths':67,'changed_runtime_paths_from_old':changed,'source_sha256':hashes,'build_context_retired':not Path(tmp).exists()};save(task/'artifact.json',artifact);save(attempt/'receipt.json',artifact)
elif stage=='install':
 artifact=json.loads((task/'artifact.json').read_text());assert sha(artifact['wheel'])==artifact['wheel_sha256'];prefix=task/'receiver';assert not prefix.exists();venv.EnvBuilder(system_site_packages=True,with_pip=False).create(prefix);py=str(prefix/'bin/python');site=prefix/'lib/python3.14/site-packages'
 unit=json.loads((old/'unit-support-receipt.json').read_text());wheel_dir=Path(unit['prefix']).parent/'wheels'
 for name,digest in unit['archives_sha256'].items():assert sha(wheel_dir/name)==digest
 run([py,'-I','-B','-m','pip','--isolated','--disable-pip-version-check','install','--no-index','--no-cache-dir','--no-deps','--no-compile','--ignore-installed',artifact['wheel']]+[str(wheel_dir/n) for n in unit['archives_sha256']],'install')
 tools=json.loads((old/'reporting-tools-receipt.json').read_text());tool=Path(tools['prefix'])
 for name,digest in tools['files_sha256'].items():
  assert sha(tool/name)==digest;target=site/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(tool/name,target)
 run([py,'-I','-B','-m','pip','--isolated','--disable-pip-version-check','check'],'pip-check')
 for name,digest in artifact['payload_sha256'].items():
  if not name.endswith('.dist-info/RECORD'):assert sha(site/name)==digest
 dist=next(site.glob('dockingmt-*.dist-info'));assert json.loads((dist/'direct_url.json').read_text())['archive_info']['hashes']['sha256']==artifact['wheel_sha256']
 harness=task/'harness';harness.mkdir();archive=attempt/'source.tar'
 with archive.open('wb') as stream:subprocess.run(['git','archive',producer],cwd=root,stdout=stream,check=True)
 with tarfile.open(archive) as stream:stream.extractall(harness,filter='data')
 archive.unlink()
 for name in ['dockingmt','molsysviewer_dockingmt']:shutil.rmtree(harness/name)
 inputs={str(p.relative_to(harness)):sha(p) for folder in ['tests','dmt_test_support'] for p in (harness/folder).rglob('*') if p.is_file()};save(task/'qualification-inputs.json',inputs)
 installed={'prefix':str(prefix),'site':str(site),'harness':str(harness),'consumer_sha256':{str(p.relative_to(site)):sha(p) for name in ['dockingmt','molsysviewer_dockingmt'] for p in (site/name).rglob('*') if p.is_file()},'tool_sha256':tools['files_sha256'],'unit_sha256':{str(p.relative_to(site)):sha(p) for p in site.rglob('*') if p.is_file() and p.relative_to(site).parts[0].split('-')[0] in ['unyt','sympy','mpmath']}}
 assert len(installed['consumer_sha256'])==67;save(task/'installation.json',installed);save(attempt/'receipt.json',{'prefix':str(prefix),'wheel_sha256':artifact['wheel_sha256'],'version':artifact['version'],'source_commit':producer,'runtime_paths':67,'unit_packages':unit['packages'],'ordinary_pip_check':True,'source_free_harness':True})
else:raise AssertionError(stage)
