"""Independent native test/source receiving without replay or molecular imports."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

_tool_receipt=Path(__file__).resolve().parents[1]/'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_receipt.read_bytes()).hexdigest()=='6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool=json.loads(_tool_receipt.read_text());_prefix=Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()}==_tool['files_sha256']
sys.path.insert(0,str(_prefix))
from pytest_receptor import read_artifact


def verify_records(records):
    def obj(name):return json.loads(records[name])
    expected={'red-normal':(1,139,37),'red-normal-02':(1,139,34),'green-normal':(1,549,4),'baseline-normal':(1,549,34),'green-normal-02':(0,549,0),'green-pm_fs':(0,549,0)}
    failures={}
    for label,(code,total,failed) in expected.items():
        p='attempts/'+label+'/'
        r=obj(p+'receipt.json');reg=obj(p+'registration.json');resource=obj(p+'resource-outcome.json')
        assert r['pytest_exit_code']==resource['exit_code']==code
        assert r['counts']=={'tests':total,'failures':failed,'errors':0,'skipped':0}
        assert r['outcome']==resource['outcome']==('PASS' if code==0 else 'FAIL') and r['qualification_complete']
        assert not r['molecular_calls_attempted'] and r['native_searches']==0
        assert resource['resource_interruption'] is None and resource['group_terminal'] and not resource['remaining_live_owned_pids']
        assert resource['minimum_available_bytes']>=13*1024**3 and resource['sampled_peak_group_rss_bytes']<1024**3 and resource['elapsed_seconds']<=60
        assert resource['policy']==reg['policy'] and reg['policy']['cpu']==0 and reg['policy']['nice']==10 and reg['policy']['workers']==1
        assert r['versions']['pytest-receptor']=='1.2.2'
        assert r['caller_policy_before']['standard_units'][:2]==(['pm','fs'] if r['profile']=='pm_fs' else ['nm','ps'])
        for name in ['default_form','default_parser','standard_units']:assert r['caller_policy_before'][name]==r['caller_policy_after'][name]
        for name,digest in reg['inputs_sha256'].items():assert hashlib.sha256(records[p+'frozen-'+name.replace('/','__')]).hexdigest()==digest
        for name,digest in reg['frozen_sha256'].items():assert hashlib.sha256(records[p+name]).hexdigest()==digest
        counts={k:0 for k in ['tests','failures','errors','skipped']};failures[label]=[]
        xml=ET.fromstring(records[p+'junit.xml'])
        for row in xml.iter('testsuite'):
            for k in counts:counts[k]+=int(row.get(k,'0'))
        assert counts==r['counts']
        for row in xml.iter('testcase'):
            f=row.find('failure')
            if f is not None:failures[label].append({'name':row.get('name'),'message':f.get('message')})
        with tempfile.TemporaryDirectory(prefix='dmt-resource-record-reader-',dir='/tmp') as tmp:
            path=Path(tmp)/'events.jsonl';path.write_bytes(records[p+'events.jsonl'])
            artifact=read_artifact(path);assert artifact.complete and artifact.final.data==r['receptor_final']
            final=artifact.final.data;c=final['counts'];assert final['exitstatus']==code
            assert c['collected']==c['executed']==total and c['failed']==failed and c['passed']==total-failed
            assert c['not_executed']==c['skipped']==c['deselected']==0
            assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
    initial=failures['red-normal'];red=failures['red-normal-02'];baseline=failures['baseline-normal']
    assert all('MemoryError' in row['name'] for row in red+baseline)
    assert {row['name'] for row in red}=={row['name'] for row in baseline}
    extras=[row for row in initial if row['name'] not in {x['name'] for x in red}]
    assert len(extras)==3 and all('AttributeError' in row['message'] and 'chemical_state_id' in row['message'] for row in extras)
    assert all('unyt' in row['name'] and 'ModuleNotFoundError' in row['message'] for row in failures['green-normal'])
    normal='attempts/green-normal-02/';pm='attempts/green-pm_fs/';base='attempts/baseline-normal/'
    for name in obj(normal+'registration.json')['inputs_sha256']:
        frozen='frozen-'+name.replace('/','__');assert records[normal+frozen]==records[pm+frozen]
        if name.startswith('tests/') or name=='pyproject.toml':assert records[base+frozen]==records[normal+frozen]
    assert obj(base+'registration.json')['selection']==obj(normal+'registration.json')['selection']==obj(pm+'registration.json')['selection']
    assert records[base+'frozen-test_child.py']==records[normal+'frozen-test_child.py']==records[pm+'frozen-test_child.py']
    added=0
    for name in ['dockingmt/core/problem.py','dockingmt/core/search_domain.py','dockingmt/core/_scores.py','dockingmt/_private/argdigest/registry.py']:
        filename='frozen-'+name.replace('/','__');old=ast.parse(records[base+filename]);new=ast.parse(records[normal+filename])
        before=[n for n in ast.walk(old) if isinstance(n,ast.Try)];after=[n for n in ast.walk(new) if isinstance(n,ast.Try)]
        assert len(before)==len(after)
        for a,b in zip(before,after):
            if len(b.handlers)==len(a.handlers)+1:
                extra=[n for n in b.handlers if ast.dump(n) not in [ast.dump(x) for x in a.handlers]]
                assert len(extra)==1 and isinstance(extra[0].type,ast.Name) and extra[0].type.id=='MemoryError'
                assert len(extra[0].body)==1 and isinstance(extra[0].body[0],ast.Raise) and extra[0].body[0].exc is None
                b.handlers.remove(extra[0]);added+=1
        assert ast.dump(old)==ast.dump(new)
    assert added==7
    support=obj('attempts/support-01/receipt.json');support_resource=obj('attempts/support-01/resource-outcome.json')
    assert support['outcome']==support_resource['outcome']=='PASS' and support_resource['group_terminal'] and not support_resource['remaining_live_owned_pids'] and support_resource['resource_interruption'] is None
    assert support['packages']=={'unyt':'3.2.0','sympy':'1.14.0','mpmath':'1.3.0'} and not support['shared_environment_modified']
    assert support==obj('producer/unit-support-receipt.json')
    assert records[normal+'frozen-unit-support-receipt.json']==records[pm+'frozen-unit-support-receipt.json']==records[base+'frozen-unit-support-receipt.json']==records['producer/unit-support-receipt.json']
    plan=obj('attempts/support-01/plan.json')
    assert {r['metadata']['name']:r['metadata']['version'] for r in plan['install']}==support['packages']
    for row in plan['install']:
        url=row['download_info']['url'];assert url.startswith('https://files.pythonhosted.org/') and url.endswith('.whl')
        assert support['archives_sha256'][url.rsplit('/',1)[1]]==row['download_info']['archive_info']['hashes']['sha256']
    for name,module in tuple(sys.modules.items()):
        if name=='pytest_receptor' or name.startswith('pytest_receptor.'):
            path=Path(module.__file__).resolve();assert path.is_relative_to(_prefix)
            assert hashlib.sha256(path.read_bytes()).hexdigest()==_tool['files_sha256'][str(path.relative_to(_prefix))]
    assert not any(n=='molsysmt' or n.startswith(('molsysmt.','dockingmt.','vina','rdkit','molsysviewer','unyt','sympy','mpmath')) for n in sys.modules)
    return {'complete_profiles':['normal','pm_fs'],'cases_per_profile':549,'new_guard_cases':139,'original_failures_preserved':34,'initial_fixture_failures_preserved':3,'initial_missing_dependency_failures_preserved':4,'full_old_runtime_failures_preserved':34,'only_memory_passthrough_handlers_added':7,'receptor_and_junit_agree':True,'all_existing_test_assertions_preserved':True,'published_unit_support_received':support['packages'],'molecular_replay':False,'source_only':True,'guard':'tests/test_input_resource_errors.py'}
