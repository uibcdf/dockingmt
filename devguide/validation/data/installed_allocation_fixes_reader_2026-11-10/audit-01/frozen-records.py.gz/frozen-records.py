"""Seal and independently read finite actual-engine software controls."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/installed-allocation-fixes-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/installed_allocation_fixes_2026-11-10';companion=root/'devguide/validation/data/installed_allocation_fixes_reader_2026-11-10'
qualified=['dockingmt/batch.py','dockingmt/engines/_vina_scoring.py','dockingmt/engines/vina.py','dockingmt/core/outcome.py','dockingmt/core/pose_audit.py','tests/test_batch.py','tests/test_input_resource_errors.py','tests/test_backend_contracts.py','tests/test_vina_staging_lifecycle.py','tests/test_pose_audit.py']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_allocation_fixes@1','owner':'uibcdf/dockingmt#47','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'qualification_base':'37a61e61db40f386a4ad031ecd14d578441f61ce','runtime_producer':'37a61e61db40f386a4ad031ecd14d578441f61ce','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored actual-engine software evidence; zero native/molecular replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 for name in qualified:paths.append((root/name,'qualified/'+name))
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 import ast,base64,csv,io
 from email.parser import BytesParser
 import xml.etree.ElementTree as ET
 artifact=d('producer/artifact.json');assert artifact['source_commit']=='37a61e61db40f386a4ad031ecd14d578441f61ce' and artifact['version']=='0.0.0+359.g37a61e6' and artifact['wheel_sha256']=='ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d' and artifact['wheel_bytes']==157933 and artifact['runtime_paths']==67 and artifact['build_context_retired']
 previous=d('producer/old-artifact.json');runtime={n for n in artifact['payload_sha256'] if n.startswith(('dockingmt/','molsysviewer_dockingmt/'))};assert len(runtime)==67 and {n for n in runtime if artifact['payload_sha256'][n]!=previous['payload_sha256'][n]}=={'dockingmt/batch.py','dockingmt/engines/_vina_scoring.py','dockingmt/_version.py'}
 meta=BytesParser().parsebytes(data['attempts/build-01/METADATA']);assert meta['Name']=='dockingmt' and meta['Version']==artifact['version'] and meta['License-Expression']=='MIT'
 for suffix in ['METADATA','WHEEL','RECORD']:
  name=next(n for n in artifact['payload_sha256'] if n.endswith('.dist-info/'+suffix));assert hashlib.sha256(data['attempts/build-01/'+suffix]).hexdigest()==artifact['payload_sha256'][name]
 record_rows=list(csv.reader(io.StringIO(data['attempts/build-01/RECORD'].decode())));assert len(record_rows)==len(artifact['payload_sha256'])
 for name,digest,size in record_rows:
  if name.endswith('.dist-info/RECORD'):assert not digest and not size
  else:assert digest=='sha256='+base64.urlsafe_b64encode(bytes.fromhex(artifact['payload_sha256'][name])).rstrip(b'=').decode() and int(size)>=0
 assert hashlib.sha256(data['producer/installed-version.py.txt']).hexdigest()==artifact['payload_sha256']['dockingmt/_version.py']
 assert any(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='__version__' for t in n.targets) and ast.literal_eval(n.value)==artifact['version'] for n in ast.parse(data['producer/installed-version.py.txt']).body)
 assert d('producer/installed-direct-url.json')['archive_info']['hashes']['sha256']==artifact['wheel_sha256']
 installed=d('producer/installation.json');assert len(installed['consumer_sha256'])==67 and installed['consumer_sha256']=={n:artifact['payload_sha256'][n] for n in runtime}
 admission=d('attempts/install-01/receipt.json');assert admission['ordinary_pip_check'] and admission['source_free_harness'] and admission['source_commit']==artifact['source_commit'] and admission['version']==artifact['version']
 cohort=d('producer/expected-cohort.json');refs=d('producer/reference-fixtures.json');baseline=d('attempts/pilot-normal-01/support-sidecar.json')['files'];assert len(baseline)==606;measured={};totals={'score':0,'dock':0}
 for label,count,deselected,scores,docks in [('pilot-normal-01',4,41,0,0),('resources-normal-01',212,0,0,0),('resources-pm-fs-01',212,0,0,0),('audit-normal-01',48,0,2,0),('audit-pm-fs-01',48,0,2,0),('batch-normal-01',45,0,0,10),('batch-pm-fs-01',45,0,0,10)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['counts']=={'tests':count,'failures':0,'errors':0,'skipped':0} and row['pytest_exit_code']==0 and row['warnings']==0 and row['cohort_unchanged'] and not row['forbidden_operations'] and row['receptor_final']['counts']['deselected']==deselected
  assert row['wheel_sha256']==artifact['wheel_sha256'] and row['runtime_version']==artifact['version'] and row['qualification_source']==artifact['source_commit'] and row['actual_engine_version']=='1.2.7' and d(prefix+'cohort.json')==cohort
  assert row['installed_origins']['state']=='verified-loaded-imports' and row['installed_origins']['roots']==['dockingmt','molsysviewer_dockingmt']
  support=d(prefix+'support-sidecar.json');assert support['files']==baseline and support['executed_tests']==count and support['imports_retired'] and support['resources_retired']
  counts=row['engine_call_counts'];assert counts.get('__init__',0)==scores+docks and counts.get('score',0)==scores and counts.get('dock',0)==docks and not any(counts.get(k,0) for k in ['optimize','randomize'])
  assert row['provider_call_counts']==({'convert':2,'get':6} if scores else {})
  calls=row['engine_calls'];assert all(c['outcome']=='PASS' for c in calls)
  if scores+docks:
   assert calls==d(prefix+'engine-calls.json')
   for c in calls:
    params=c['parameters'];node=c['test_node'];assert any(n in node for n in ['test_fresh_native_scoring_and_rescoring_produce_auditable_evidence','test_native_batch_matches_individual_seeded_docking','test_native_missing_file_failure_does_not_contaminate_next_execution'])
    if c['call']=='__init__':assert params['cpu']==1 and params['seed']==(17 if scores else 123) and params['sf_name'] in ['vina','vinardo']
    if c['call']=='compute_vina_maps':assert params['center']==[0.0]*3 and params['box_size']==[10.0]*3
    if c['call']=='score':assert params['unbound_energy'] is None and c['result_shape']==[8] and c['native_unit']=='kcal/mol'
    if c['call']=='dock':assert params['exhaustiveness']==1 and 1<=params['n_poses']<=2
    for role in ['receptor','partner']:
     if role not in c:continue
     info=c[role];blob=data[prefix+'inputs/backend/'+str(c['run'])+'/'+role+'.pdbqt'];assert len(blob)==info['bytes'] and hashlib.sha256(blob).hexdigest()==info['sha256']==refs['MINIMAL_REC_PDBQT' if role=='receptor' else 'MINIMAL_LIG_PDBQT']['sha256'] and info['atom_records']==(4 if role=='receptor' else 2)
   native='lib/python3.14/site-packages/vina/_vina_wrapper.cpython-314-x86_64-linux-gnu.so';assert [v for k,v in d(prefix+'native-maps.json').items() if k.endswith('/'+native)]==[d(prefix+'frozen-engine-receipt.json')['paths'][native]]
  exports=row['exports']
  for e in exports:assert hashlib.sha256(data[prefix+e['file']]).hexdigest()==e['sha256']
  if scores:
   assert [e['kind'] for e in exports]==['score','score','audit_pose'];first,second,report=[d(prefix+e['file']) for e in exports];assert len(first['scores'])==8 and len(second['scores'])==16 and first['coordinates']==second['coordinates'] and len(second['metadata']['scoring_history'])==2 and report['status']=='consistent'
   assert all(h['dockingmt_version']==artifact['version'] for h in second['metadata']['scoring_history'])
   observed=[c['native_components'] for c in calls if c['call']=='score'];assert list(first['scores'].values())==observed[0] and list(second['scores'].values())[8:]==observed[1]
   events=d(prefix+'provider-events.json');assert events==row['provider_events'] and [e['call'] for e in events]==['convert','get','get','get']*2
   for e in events:
    assert e['outcome']=='PASS'
    if e['call']=='convert':assert e['input_sha256']==refs['MINIMAL_LIG_PDBQT']['sha256'] and e['parameters']=={'to_form':'molsysmt.MolSys','discard_torsion_tree':True}
  elif docks:
   assert len(exports)==39;comparisons={};outcomes={};isolation={}
   for e in exports:
    received=d(prefix+e['file']);node=e['test_node']
    if e['kind']=='outcome':assert received['status']=='success' and received['error'] is None;outcomes.setdefault((node,received['index']),[]).append(received)
    else:
     assert received['provenance']['dockingmt_version']==artifact['version'];label_id=received['problem_info']['metadata']['ligand_id']
     if 'test_native_batch_matches_individual_seeded_docking' in node:
      received['provenance'].pop('elapsed_seconds');received['provenance']['backend_output']['engine_info'].pop('rigid_receptor');comparisons.setdefault((node,label_id),[]).append(received)
     else:isolation.setdefault(label_id,[]).append(received)
   assert len(comparisons)==len(outcomes)==4 and sum(map(len,outcomes.values()))==12
   for group in list(comparisons.values())+list(outcomes.values()):assert len(group)>=2 and all(r==group[0] for r in group)
   assert set(isolation)=={'first','third'};a=isolation['first'][0]['poses'][0];b=isolation['third'][0]['poses'][0];assert a['scores']==b['scores'] and a['coordinates']==b['coordinates']
  else:assert not exports and not row['provider_events'] and not calls
  if label.startswith('resources-'):
   nodes=[n for n in ET.fromstring(data[prefix+'junit.xml']).iter('testcase') if n.get('name','').startswith('test_scoring_geometry_preserves_resource_errors_and_cleans_staging[')];assert len(nodes)==16 and all(n.find('failure') is None for n in nodes)
  totals['score']+=scores;totals['dock']+=docks;measured[label]={'cases':count,'deselected':deselected,'actual_scores':scores,'actual_searches':docks}
 assert totals=={'score':4,'dock':20}
 for selection in ['resources','audit','batch']:assert data['attempts/'+selection+'-normal-01/frozen-worker.py']==data['attempts/'+selection+'-pm-fs-01/frozen-worker.py']
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   r=json.loads(raw);assert r['outcome']=='PASS' and r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids'] and r['minimum_available_bytes']>13*1024**3
 for name in qualified:
  raw=data['qualified/'+name];assert (root/name).read_bytes()==raw
  assert hashlib.sha256(raw).hexdigest()==(artifact['payload_sha256'][name] if name.startswith('dockingmt/') else d('producer/qualification-inputs.json')[name])
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),populations=measured,qualified_sources=10,support_records=606,new_installed_wheel_received=True,source_fixes_106_107_received=True,actual_native_calls=totals,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json']);path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete and row['counts']==counts and row['receptor_final']==events.final.data
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':row['pytest_exit_code'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==7 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1600])
