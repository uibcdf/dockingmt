"""Independent published Receptor/JUnit/source receiving, without test replay."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

_tool_receipt=Path(__file__).resolve().parents[1]/'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_receipt.read_bytes()).hexdigest()=='6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool=json.loads(_tool_receipt.read_text());_prefix=Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()}==_tool['files_sha256']
sys.path.insert(0,str(_prefix))
from pytest_receptor import read_artifact

def verify_records(records):
    def obj(name):return json.loads(records[name])
    expected={'red-normal':(1,103,73),'red-normal-02':(1,103,70),'green-normal':(0,562,0),'green-normal-02':(0,562,0),'green-pm_fs':(0,562,0)}
    for label,(code,total,failed) in expected.items():
        prefix='attempts/'+label+'/'
        r=obj(prefix+'receipt.json');resource=obj(prefix+'resource-outcome.json');reg=obj(prefix+'registration.json')
        assert r['pytest_exit_code']==resource['exit_code']==code
        assert r['counts']=={'tests':total,'failures':failed,'errors':0,'skipped':0}
        assert r['outcome']==resource['outcome']==('PASS' if code==0 else 'FAIL')
        assert resource['resource_interruption'] is None and resource['group_terminal'] and not resource['remaining_live_owned_pids']
        assert resource['sampled_peak_group_rss_bytes']<1024**3 and resource['minimum_available_bytes']>=13*1024**3 and resource['elapsed_seconds']<=60
        assert reg['policy']==resource['policy'] and r['qualification_complete']
        assert not r['molecular_calls_attempted'] and r['native_searches']==0
        assert r['versions']['pytest-receptor']=='1.2.2' and r['profile']==reg['profile']
        assert r['caller_policy_before']['standard_units'][:2]==(['pm','fs'] if r['profile']=='pm_fs' else ['nm','ps'])
        for key in ['default_form','default_parser','standard_units']:assert r['caller_policy_before'][key]==r['caller_policy_after'][key]
        for name,digest in reg['inputs_sha256'].items():assert hashlib.sha256(records[prefix+'frozen-'+name.replace('/','__')]).hexdigest()==digest
        counts={k:0 for k in ['tests','failures','errors','skipped']}
        for row in ET.fromstring(records[prefix+'junit.xml']).iter('testsuite'):
            for k in counts:counts[k]+=int(row.get(k,'0'))
        assert counts==r['counts']
        with tempfile.TemporaryDirectory(prefix='dmt-identity-record-reader-',dir='/tmp') as tmp:
            path=Path(tmp)/'events.jsonl';path.write_bytes(records[prefix+'events.jsonl'])
            artifact=read_artifact(path);assert artifact.complete and artifact.final.data==r['receptor_final']
            final=artifact.final.data;c=final['counts'];assert final['exitstatus']==code
            assert c['collected']==c['executed']==total and c['failed']==failed and c['passed']==total-failed
            assert c['not_executed']==c['skipped']==0 and c['deselected']==(1 if code==0 else 0)
            assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
    normal='attempts/green-normal-02/';pm='attempts/green-pm_fs/';red='attempts/red-normal-02/'
    for name in obj(normal+'registration.json')['inputs_sha256']:
        frozen='frozen-'+name.replace('/','__')
        assert records[normal+frozen]==records[pm+frozen]
        if name.startswith('tests/') or name.endswith('registry.py') or name=='pyproject.toml':assert records[red+frozen]==records[normal+frozen]
    filename='frozen-tests__test_audit_pose_identity_records.py'
    before=ast.parse(records['attempts/red-normal/'+filename]);after=ast.parse(records[normal+filename])
    assertions=lambda tree:[ast.dump(n) for n in ast.walk(tree) if isinstance(n,ast.Assert)]
    assert assertions(before)==assertions(after)
    assert records['attempts/red-normal/receptor-last-run.txt']
    for name in ['dockingmt/core/results.py','dockingmt/core/audit.py','dockingmt/core/_scores.py','dockingmt/core/pose_audit.py']:
        filename='frozen-'+name.replace('/','__');assert records[red+filename]!=records[normal+filename]
    probe=obj('attempts/probe-01/receipt.json');resource=obj('attempts/probe-01/resource-outcome.json')
    assert probe['outcome']==resource['outcome']=='PASS' and resource['group_terminal'] and not resource['remaining_live_owned_pids'] and resource['resource_interruption'] is None
    assert len(probe['observations'])==8 and not probe['forbidden_attempts'] and probe['molecular_operations']==0
    assert sum(row['observed'].get('status')!=row['expected_status'] for row in probe['observations'])==7
    for name,module in tuple(sys.modules.items()):
        if name=='pytest_receptor' or name.startswith('pytest_receptor.'):
            path=Path(module.__file__).resolve();assert path.is_relative_to(_prefix)
            assert hashlib.sha256(path.read_bytes()).hexdigest()==_tool['files_sha256'][str(path.relative_to(_prefix))]
    assert not any(n=='molsysmt' or n.startswith(('molsysmt.','dockingmt.','vina','rdkit','molsysviewer')) for n in sys.modules)
    return {'complete_profiles':['normal','pm_fs'],'cases_per_profile':562,'new_guard_cases':103,'original_failures_preserved':70,'initial_red_failures_preserved':73,'pre_refinement_pass_preserved':True,'all_test_assertions_preserved':True,'native_cases_deselected_per_profile':1,'receptor_and_junit_agree':True,'molecular_replay':False,'source_only':True,'guard':'tests/test_audit_pose_identity_records.py'}
