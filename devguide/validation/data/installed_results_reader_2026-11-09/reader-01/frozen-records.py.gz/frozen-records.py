"""Seal finite installed-result evidence and read it without molecular replay."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/installed-results-20261109';stage=sys.argv[1]
primary=root/'devguide/validation/data/installed_results_2026-11-09';companion=root/'devguide/validation/data/installed_results_reader_2026-11-09'
qualified=['dockingmt/core/results.py','dockingmt/engines/vina.py','devguide/validation/installed_result_inspection.ipynb']+['tests/'+n for n in ['test_results.py','test_result_restore_contracts.py','test_known_source_pose_consumption.py','test_prepared_pose_reading.py','test_result_contracts.py','test_pose_coordinates.py','test_pose_record_admission.py','test_result_record_admission.py']]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_results@1','owner':'uibcdf/dockingmt#47','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'qualification_base':'ac459ca7ba4d029b317c653c9af17e258050e752','runtime_producer':'aeae47d50c5e90687c2558437cb22cf8f271ce85','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored software evidence; no molecular imports/replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names]
 labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  if (directory/'inputs').is_dir():paths.extend((p,'attempts/'+directory.name+'/inputs/'+str(p.relative_to(directory/'inputs'))) for p in sorted((directory/'inputs').rglob('*')) if p.is_file())
 for name in qualified:paths.append((root/name,'qualified/'+name))
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 artifact=d('producer/artifact.json');assert artifact['source_commit']=='aeae47d50c5e90687c2558437cb22cf8f271ce85' and artifact['wheel_sha256']=='0b303ae371466a6736e8d194a89a54048f8bc51de3cd293cdc68c06050ae042b' and artifact['runtime_paths']==67
 expected_cohort=d('producer/expected-cohort.json');assert expected_cohort['molsysmt']['commit']=='0c6f9c746dbd10b02dfe8474a5af280b857ace0d'
 baseline_files=d('attempts/pilot-normal-01/support-sidecar.json')['files'];assert len(baseline_files)==606
 measured={}
 for selection,count,deselected in [('pilot',16,0),('mapped',22,2),('staged',6,9),('records',None,0)]:
  pair=[]
  for suffix in ['normal','pm-fs']:
   label=selection+'-'+suffix+'-01';prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');counts=row['counts'];assert counts['failures']==counts['errors']==counts['skipped']==0 and row['pytest_exit_code']==0 and row['engine_attempts']==[] and row['cohort_unchanged'] and row['warnings']==0
   if count is not None:assert counts['tests']==count,(label,counts)
   assert row['receptor_final']['counts']['deselected']==deselected and row['wheel_sha256']==artifact['wheel_sha256'] and row['qualification_source']==artifact['source_commit']
   assert d(prefix+'cohort.json')==expected_cohort
   support=d(prefix+'support-sidecar.json');assert support['files']==baseline_files and support['executed_tests']==counts['tests'] and support['imports_retired'] and support['resources_retired']
   resource=d(prefix+'resource-outcome.json');assert resource['outcome']=='PASS' and resource['resource_interruption'] is None and resource['group_terminal'] and resource['remaining_live_owned_pids']==[] and resource['minimum_available_bytes']>13*1024**3 and resource['sampled_peak_group_rss_bytes']<1024**3
   provider_data=d(prefix+'provider-data.json');assert provider_data['sha256']=='77018feaaa65bb22dea47c784e8c059b0ccc09cd6dc7442b79cce83f3170985f' and provider_data['bytes']==149121 and provider_data['physical_atom_records']==1441
   assert hashlib.sha256(data[prefix+'inputs/provider/181l.pdb']).hexdigest()==provider_data['sha256']
   pair.append(counts['tests']);measured[label]={'cases':counts['tests'],'deselected':deselected,'warnings':row['warnings'],'provider_calls':row['provider_call_counts']}
  assert pair[0]==pair[1]
  assert data['attempts/'+selection+'-normal-01/frozen-worker.py']==data['attempts/'+selection+'-pm-fs-01/frozen-worker.py']
 for name in qualified:
  raw=data['qualified/'+name];assert (root/name).read_bytes()==raw
  if name.startswith('dockingmt/'):assert hashlib.sha256(raw).hexdigest()==artifact['payload_sha256'][name]
  elif name.startswith('tests/'):assert hashlib.sha256(raw).hexdigest()==d('producer/qualification-inputs.json')[name]
  else:assert hashlib.sha256(raw).hexdigest()==d('producer/notebook-original.json')['notebook_sha256']
 notebook_populations={}
 for selection,status in [('notebook-original','consistent'),('notebook-no-captures','incomplete')]:
  for suffix in ['normal','pm-fs']:
   label=selection+'-'+suffix+'-01';prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');r=row['notebook_receipt'];assert row['completed_cells']==8 and row['headless_python_not_real_kernel'] and row['no_sdk_harness_source_injection'] and row['no_molecular_operations'] and not row['engine_attempts'] and row['cohort_unchanged'] and not row['new_scientific_case']
   assert r['pose_count']==5 and r['record_audit_status']==status and r['recorded_producer']['dockingmt_version']=='0.0.0+180.g1decee5' and r['reader']['dockingmt_version']==artifact['version'] and r['reader']['archive_sha256_if_recorded']==artifact['wheel_sha256'] and r['captured_bytes_verified']==(status=='consistent')
   assert d(prefix+'cohort.json')==expected_cohort and d(prefix+'resource-outcome.json')['outcome']=='PASS'
   assert hashlib.sha256(data[prefix+'inputs/result.json.gz']).hexdigest()==row['input_sha256']
   nb=json.loads(data[prefix+'inputs/installed_result_inspection.ipynb']);sources=[''.join(c['source']) for c in nb['cells'] if c['cell_type']=='code'];assert len(sources)==8
   for i,source in enumerate(sources,1):assert source.encode()==data[prefix+'inputs/cell-'+str(i)+'.py'] and hashlib.sha256(source.encode()).hexdigest()==row['cells'][i-1]['source_sha256']
   notebook_populations[label]={'cells':8,'audit':status,'poses':5,'recorded_producer':r['recorded_producer']['dockingmt_version'],'current_reader':r['reader']['dockingmt_version']}
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   r=json.loads(raw);assert r['outcome']=='PASS' and r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids'] and r['minimum_available_bytes']>13*1024**3
 assert d('attempts/records-normal-01/receipt.json')['provider_call_counts']==d('attempts/records-pm-fs-01/receipt.json')['provider_call_counts']=={}
 receipt['notebook_populations']=notebook_populations
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),populations=measured,qualified_source_files=len(qualified),unchanged_wheel_and_providers=True,support_records=606,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json'])
   path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete
   if 'counts' in row:assert row['counts']==counts and row['receptor_final']==events.final.data
   totals=events.final.data['counts'];assert counts['tests']==totals['executed']+totals.get('subtests',{}).get('passed',0) and counts['failures']==totals['failed'] and counts['errors']==totals['errors'] and counts['skipped']==totals['skipped']
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==8 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1700])
