"""Execute sealed saved-carrier cells in an isolated private payload."""

import hashlib
import json
import os
import sys
import traceback
from pathlib import Path

root = Path(os.environ['DMT_E4_ROOT'])
output = Path(os.environ['DMT_E4_OUTPUT'])
attempt = output.parent
registration = json.loads((attempt / 'registration.json').read_text())
installation_path = (
    root / '.molsyssuite/e1-score-comparison-20261107/installation-02.json'
)
installation = json.loads(installation_path.read_text())
target = installation_path.parent / 'site-packages-02'
task = root / '.molsyssuite/e4-saved-carrier-20261107'
viewer = task / 'viewer-overlay'
viewer_receipt = json.loads((task / 'viewer-overlay-receipt.json').read_text())
assert len(installation['targethashes']) == 3867
assert (
    installation['consumer_source_commit'] == 'a7422dfb9f8c3b1c8ede3d852e202dc33e4beefe'
)
assert (
    installation['wheel']['sha256']
    == '93d76f898575fb64b39520f33ceded25708270c8042c2a53c9a451acd834bcdd'
)
assert len(viewer_receipt['files_sha256']) == 641
assert (
    viewer_receipt['wheel_sha256']
    == '3d31a4d9edb7ed0e72fadcd81b3952196795218f55776478a7625b79e47e9e2a'
)
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def payload(directory):
    return {
        str(p.relative_to(directory)): sha(p)
        for p in directory.rglob('*')
        if p.is_file()
    }


def native_libraries():
    paths = set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        parts = line.split(None, 5)
        if len(parts) == 6 and parts[5].startswith('/') and '.so' in parts[5]:
            path = Path(parts[5])
            if path.is_file():
                paths.add(path.resolve())
    return [{'path': str(path), 'sha256': sha(path)} for path in sorted(paths)]


assert sys.flags.isolated and sys.flags.no_site
sdk = root / '.molsyssuite/publication-sdk'
assert registration['sdk_source_sha256']
for relative, digest in registration['sdk_source_sha256'].items():
    assert sha(sdk / relative) == digest
assert os.sched_getaffinity(0) == {0} and os.getpriority(os.PRIO_PROCESS, 0) >= 10
assert (
    sha(installation_path) == registration['frozen']['installation-02.json']['sha256']
)
assert (
    sha(task / 'viewer-overlay-receipt.json')
    == registration['frozen']['viewer-overlay-receipt.json']['sha256']
)
assert (
    payload(target) == installation['targethashes']
    and payload(viewer) == viewer_receipt['files_sha256']
)
sys.path[:0] = [
    str(target),
    str(viewer),
    str(routine / 'lib/python3.14/site-packages'),
    str(root / '.molsyssuite/publication-sdk/devtools/scripts'),
]
assert not any('__editable__' in type(x).__module__ for x in sys.meta_path)
from installed_imports import check_installed_imports  # noqa: E402

metadata_before = {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')}
write('routine-metadata-before.json', metadata_before)
inputs = json.loads(Path(os.environ['DMT_E4_INPUTS']).read_text())
assert inputs['profile'] == registration['profile'] == os.environ['DMT_E4_PROFILE']
assert sha(Path(os.environ['DMT_E4_INPUTS'])) == registration['inputs_manifest_sha256']
input_hashes = {row['path']: row['decoded_sha256'] for row in inputs['inputs'].values()}
origins = []


def check(label):
    for relative, digest in registration['sdk_source_sha256'].items():
        assert sha(sdk / relative) == digest
    assert (
        payload(target) == installation['targethashes']
        and payload(viewer) == viewer_receipt['files_sha256']
    )
    for name, digest in input_hashes.items():
        assert sha(Path(name)) == digest, name
    rows = []
    sdk_origins = []
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename and Path(filename).resolve().is_relative_to(sdk):
            path = Path(filename).resolve()
            relative = str(path.relative_to(sdk))
            assert sha(path) == registration['sdk_source_sha256'][relative]
            sdk_origins.append({'module': name, 'path': str(path), 'sha256': sha(path)})
    prefixes = (
        'dockingmt',
        'molsysviewer_dockingmt',
        'molsysmt',
        'molsysviewer_molsysmt',
        'molsysviewer',
        'argdigest',
        'pyunitwizard',
        'depdigest',
        'smonitor',
        'ackredit',
    )
    for name, module in tuple(sys.modules.items()):
        if not any(name == p or name.startswith(p + '.') for p in prefixes):
            continue
        locations = list(getattr(module, '__path__', ()))
        filename = getattr(module, '__file__', None)
        if filename:
            locations.append(filename)
        if not locations:
            assert name == 'pyunitwizard.main', name
            initializer = sys.modules['pyunitwizard']
            expected = target / 'pyunitwizard/__init__.py'
            for function in (module.__getattr__, module.__dir__):
                assert (
                    function.__globals__ is vars(initializer)
                    and Path(function.__code__.co_filename).resolve() == expected
                )
            locations = [str(expected)]
        checked = []
        for value in sorted(set(locations)):
            path = Path(value).resolve()
            expected_root = (
                viewer
                if name == 'molsysviewer' or name.startswith('molsysviewer.')
                else target
            )
            assert path.is_relative_to(expected_root), (name, str(path))
            checked.append(
                {'path': str(path), 'sha256': sha(path) if path.is_file() else None}
            )
        rows.append({'module': name, 'locations': checked})
    assert not any(name == 'vina' or name.startswith('vina.') for name in sys.modules)
    origins.append(
        {
            'label': label,
            'private_files': len(installation['targethashes']),
            'viewer_files': len(viewer_receipt['files_sha256']),
            'runtime_origins': rows,
            'sdk_origins': sdk_origins,
            'python_path': list(sys.path),
            'native_libraries': native_libraries(),
            'consumer_import_check': check_installed_imports(
                ('dockingmt', 'molsysviewer_dockingmt'), target, root / 'dockingmt'
            ),
        }
    )


notebook_path = attempt / 'frozen-e4_saved_carrier_receiving.ipynb'
assert (
    sha(notebook_path)
    == registration['frozen']['e4_saved_carrier_receiving.ipynb']['sha256']
)
notebook = json.loads(notebook_path.read_text())
namespace = {'__name__': '__main__', 'registered_installed_check': check}
completed = []
try:
    for cell in notebook['cells']:
        if cell['cell_type'] != 'code':
            continue
        available = (
            int(
                next(
                    line.split()[1]
                    for line in Path('/proc/meminfo').read_text().splitlines()
                    if line.startswith('MemAvailable:')
                )
            )
            * 1024
        )
        assert available >= registration['policy']['available_reserve_bytes']
        body = ''.join(cell['source'])
        expected = next(
            row for row in registration['code_cells'] if row['id'] == cell['id']
        )
        assert hashlib.sha256(body.encode()).hexdigest() == expected['sha256']
        with (attempt / 'progress.jsonl').open('a') as stream:
            stream.write(json.dumps({'stage': 'started', 'cell_id': cell['id']}) + '\n')
        exec(compile(body, 'e4_saved_carrier.' + cell['id'], 'exec'), namespace)
        completed.append(cell['id'])
        with (attempt / 'progress.jsonl').open('a') as stream:
            stream.write(
                json.dumps(
                    {
                        'stage': 'completed',
                        'cell_id': cell['id'],
                        'counts': namespace.get('counts'),
                    }
                )
                + '\n'
            )
    assert completed == [row['id'] for row in registration['code_cells']]
    receipt = json.loads((output / 'receipt.json').read_text())
    assert receipt['outcome'] == 'PASS'
    check('after-complete-selection')
    assert {
        p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')
    } == metadata_before
    write(
        'worker-receipt.json',
        {
            'outcome': 'PASS',
            'qualification_complete': True,
            'profile': inputs['profile'],
            'completed_cells': completed,
            'counts': namespace.get('counts'),
            'consumer_source_commit': installation['consumer_source_commit'],
            'consumer_wheel_sha256': installation['wheel']['sha256'],
            'viewer_wheel_sha256': viewer_receipt['wheel_sha256'],
            'private_payload_unchanged': True,
            'viewer_payload_unchanged': True,
            'input_bytes_unchanged': True,
            'routine_metadata_unchanged': True,
            'vina_imported': False,
        },
    )
except BaseException as error:
    write(
        'failure.json',
        {
            'exception_type': type(error).__name__,
            'message': str(error),
            'stage': namespace.get('stage'),
            'completed_cells': completed,
            'counts': namespace.get('counts'),
        },
    )
    traceback.print_exc()
    raise
finally:
    write('installed-origins.json', origins)
    write(
        'routine-metadata-after.json',
        {p.name: sha(p) for p in (routine / 'conda-meta').glob('*.json')},
    )
