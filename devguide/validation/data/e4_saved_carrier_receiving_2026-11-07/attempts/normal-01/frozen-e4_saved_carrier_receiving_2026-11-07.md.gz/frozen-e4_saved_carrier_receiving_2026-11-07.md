# E4 saved-carrier receiving — registered 2026-11-07

Owner: [DockingMT #80](../pending_proposals/receive_docking_interaction_analysis.md).
Status before execution: **prospective; no result is claimed**. This new selection
follows the [admission route](e4_saved_analysis_admission_2026-11-07.md), receiving
saved analyses in a real headless Viewer through public provider operations.
The complete functional objective #73 and whole E4 remain unproven.

## Authorization and separate populations

The resumed complete maintainer objective authorizes this bounded receiving.
[AGENTS.md](../../AGENTS.md) requires serial scientific cells, CPU/worker 1, low
priority, monitored task reserve and no automatic heavy restart after headroom
interruption. The [original attempt](installed_3ptb_interactions.md) requires
resource review and a fresh execution identity/budget. It does not require
another human confirmation for every new saved-file receiving.

The preceding recipe's requirement for explicit maintainer review of every new
venue was an overbroad agent interpretation. Its maintained correction retains
the original heavy interruption, unknown final counters and diagnostics. That
preparation/detector selection remains suspended. Actual frontend/canvas acceptance
retains separate deferred scheduling; no manual remote CI is dispatched.
Reading, provider queries, index projection and persistence are molecular consumer
operations and must be counted; this is not zero-operation record-only reading.

## Fixed originals and selected destination

Original scientific producer is `5952053328aac6f737e22906e984c0f9eb938dd7`; the
[success receipt](data/interaction_hosted_success_2026-11-06.json) retains sources,
inputs, normal/pm-fs, stored/decoded hashes and earlier failures.

For each profile, receive exactly its `retained_pose.h5msm`,
`translated_geometry_control.h5msm`, original `association.json` and unchanged
five-pose original result. Verify compressed/decoded bytes before all imports.
Seal each decoded read-only input, original receipt, notebook, worker, launcher,
installation/overlay receipts, source hashes and runtime command. Each input
manifest entry keeps `path`, `repository_path`, `stored_sha256`, `stored_bytes`,
`decoded_sha256` and `decoded_bytes`.

The destination is the **same complete saved carrier**, one structure and 3238
atoms: receptor_h3220 plus ligand18. Compose the recorded original-to-ligand map
with recorded merged ligand indices, yielding the original thirteen pose atoms
at carrier indices 3220–3232. For the retained case verify original keys/states
and physical coordinates through public getters with absolute tolerance
`1e-12 angstrom`, zero relative tolerance. The translated control retains labels
but different geometry: it is not admitted as the original pose. Inspect its own
carrier/scene separately and preserve the original control provenance. No
correspondence is inferred from labels or counts. All carrier atoms
and the original frame remain. The five added ligand H retain provider-local
geometry and original provenance; no H is generated here.

Load a detached copy through public `msv.new_view`/`view.load`. Receive complete
named analyses and public queries, identity remaps, independent attachment/loading,
refusal controls and provider persistence. Full roundtrips use `InteractionsDict`
and H5MSM; diagnostic JSON is not a molecular restoration codec. Close every
owned view on success and failure. Any public addon-registry clearing used for
this isolated receiving process is explicit configuration, not a claim that the
DockingMT addon or an ordinary user's existing registry was received unchanged.

Original retained observations are 3 named H-bonds and 2 typed hydrophobic
proximities; translated control is 0/0. These are previously computed baseline
witnesses, not new detection. The other four docking poses remain unevaluated.
No map to another carrier or the prepared2024 scene follows from this identity
route; addon API and actual canvas acceptance remain separate.

## Identified private composition

Use routine Python 3.14 from `molsyssuite@uibcdf_3.14`, isolated `-I -S -B`.
Reuse the existing 3,867-file private consumer/provider payload:

- DockingMT source `a7422dfb9f8c3b1c8ede3d852e202dc33e4beefe`, wheel SHA-256
  `93d76f898575fb64b39520f33ceded25708270c8042c2a53c9a451acd834bcdd`.
- Identified borrowed MolSysMT `9e1f1b1ad8bf09446374ab6f04ca7208e2717936` and
  auxiliary provider artifacts retain their actual versions/origins.
- Original MolSysViewer `78ede79e2e345593db5bfe80d246d3f6c70bd005` wheel SHA-256
  `3d31a4d9edb7ed0e72fadcd81b3952196795218f55776478a7625b79e47e9e2a`, verified
  against [its prior receipt](data/addon_player/viewer_wheel_2026-11-03.json) and
  wheel RECORD. Its 641 exact files are transported into a task-owned overlay;
  no rebuild, dependency solve, pip/Conda operation or shared-prefix change occurs.

This differs from the original H5MSM producer's provider source; compatibility
is to be received. Verify both payloads, import origins/native libraries, original
inputs and routine Conda metadata before/after. Sibling worktrees/pins remain.
Public dependency/platform/minor and complete-environment closure remain separate.

## Finite selection and resource/failure policy

Run normal first, then pm/fs in a fresh process only when the complete normal
selection, worker qualification and resource receipt all pass. Both use the
[same notebook](e4_saved_carrier_receiving.ipynb), with sealed cell bodies and
operation caps. Read only two saved carrier cases per process. Loops are over
those two carriers and two named analyses; no runtime population discovery or
scheduler is added. The finalized notebook ledger supplies the direct-call caps
and separates observed provider internals before launch.

Per process: CPU affinity `{0}`, nice 10, one native/build worker, owned-group
RSS at most 1 GiB, address space 2 GiB, CPU 45 seconds and wall 60 seconds. Require
initial available RAM at least 8 GiB reserve plus the 1 GiB owned allowance.
Monitor available RAM and owned-process-group RSS every 0.1 seconds; check headroom
at every code cell. Descendants inherit affinity/limits. A limit/reserve breach
terminates only the owned group, records a resource interruption and stops;
there is no automatic retry. Preserve partial outputs and raw logs.

Register **zero** preparation, H generation, charge/type assignment, interaction
detection, searches, scoring, optimisation, alignment and RMSD calls. Vina remains
unimported. Count direct reads/queries/remaps/loads/attachments/persistence apart
from provider internals. Known input/API/dependency failures remain failures;
no empty-interaction disposition or fallback scene is substituted. Journal every
started/completed cell with observed counters. Missing final counters following
interruption remain unknown. A zero process exit alone cannot accept the
selection: every sealed cell and the final PASS receipt must qualify.

Review source and notebook AST/lint/format before launch. Record executed
receiving and independent follow-up here afterwards. The original heavy case,
E3 #604, other carriers/poses, addon API admission, independent science, public
delivery and deferred canvas retain their own requirements.

## Sealed direct-call ledger and launcher controls

Per profile, source review fixes the following maximum direct requests. The
completed selection must match each exact value except typed exports, whose
cap is 64 and expected actual count is 50. Observed nested provider dispatch
counts remain separate; no alias or persisted copy becomes a new observation.

| Direct request | Cap |
| --- | ---: |
| Registry clear / original result reconstruction | 1 / 1 |
| Carrier reads / detached copies | 2 / 2 |
| Viewer factory / load / close | 2 / 2 / 2 |
| Independent layer reads / persistence layer reads | 2 / 2 |
| Typed exports | 64 (expected 50) |
| Saved analysis queries / pages / query inspection projections | 4 / 4 / 4 |
| Get analysis / attachment attempts / independent Viewer layer loads | 16 / 12 / 4 |
| Wrong-axis remaps / invalid-axis remaps | 2 / 2 |
| Viewer persistence writes / native-state snapshots | 2 / 8 |
| Source selections / cross-carrier preflight refusal | 2 / 1 |

Eleven informative refusals are expected: eight attachment refusals, two invalid
remaps and one different-carrier preflight. Queries use public MolSysMT
`Interactions.between_selections`; new persistence is reread with public
`msm.h5msm.read_layers`. Loading those new files into a second View and using
`view.interactions.query` are outside this registered selection.

Before molecular execution, four standard-library control groups pass against
the actual launcher functions: a clean zero exit without complete qualification
is refused; positive completion and adverse cell/profile/failure records are
distinguished; an owned child ignoring SIGTERM is retired after its leader exits;
and preflight failure retains logs/diagnostics without starting a worker. The
launcher also matches normal/pm-fs frozen code/composition and verifies SDK source
hashes/origins before and after use. These are administrative process controls,
not extra molecular cases. Their source and raw records are retained with the
new receiving evidence.
