"""Receive reference/typed-quantity evidence without molecular replay."""
import ast
from copy import deepcopy
import hashlib
import io
import json
import re
import sys

import h5py
import pyunitwizard as puw


def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    def sha(raw):
        return hashlib.sha256(raw).hexdigest()
    original = records['producer/original-worker.py.txt'].decode()
    worker = records['producer/worker.py.txt'].decode()
    undone = re.sub(r'(?ms)^[ \t]*# MECHANICS_EVIDENCE_START\n.*?^[ \t]*# MECHANICS_EVIDENCE_END\n', '', worker)
    undone = undone.replace(", format_version='0.6')", ')').replace("'storage_format_version': '0.6', ", '')
    assert ast.dump(ast.parse(undone)) == ast.dump(ast.parse(original))
    initial = obj('attempts/reference-normal/setup-failure.json')
    assert initial['outcome'] == 'FAIL' and not initial['scientific_process_started'] and initial['scientific_calls'] == 0
    assert initial['missing_task_input'] == 'gate-replacement.json'
    legacy = 'ae0e9d3beb4d14363ea6edb1bff591c56d53b02295082bae8c281d9284d84b9e'
    assert sha(records['producer/original-source.pdbqt']) == legacy
    baseline = obj('producer/baseline-source-identity.json')
    manifest = records['producer/historical-e2-manifest.json']
    assert sha(manifest) == baseline['manifest_sha256']
    row = next(x for x in json.loads(manifest)['files'] if x['path'] == baseline['member'])
    assert row['decoded_sha256'] == legacy
    quantity_records = 0
    def quantities(node):
        nonlocal quantity_records
        if isinstance(node, dict):
            if node.get('kind') == 'quantity':
                assert node['field'].startswith('e3.mechanics.')
                q = puw.QuantityRecord.from_dict(node['record']).to_quantity(field=node['field'], unit=node['original_unit'])
                assert puw.are_compatible(q, node['original_unit'])
                quantity_records += 1
            else:
                for value in node.values():
                    quantities(value)
        elif isinstance(node, list):
            for value in node:
                quantities(value)
    for profile in ['normal', 'pm_fs']:
        p = 'attempts/reference-' + profile + '-02/'
        r = obj(p + 'receipt.json')
        reg = obj(p + 'registration.json')
        resource = obj(p + 'resource-outcome.json')
        assert r['outcome'] == resource['outcome'] == 'PASS' and r['qualification_complete'] and resource['exit_code'] == 0
        assert r['profile'] == profile and r['storage_format_version'] == '0.6'
        assert r['direct_counts'] == reg['direct_caps'] and r['direct_counts']['h5_write'] == 4 and r['direct_counts']['h5_read'] == 2
        assert r['direct_counts']['mechanical_copy'] == 4 and r['direct_counts']['format_inspection'] == 4
        assert r['provider_commit'] == 'efbe67e1c6042078144bce1db24aa80bb565dbd2'
        assert r['provider_native_sha256'] == '5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3'
        assert r['full39_heavy_maps'] == r['prepared25_maps'] == 2 and r['generated_hydrogens'] == 15
        assert r['source_and_caller_preserved'] and r['matched_current_source_control'] and r['legacy_source_authenticated']
        assert not r['common_receptor_frame_admitted'] and not r['e3_accepted'] and r['native_searches'] == r['rmsd_calls'] == r['clustering_calls'] == 0
        assert resource['group_terminal'] and not resource['remaining_live_owned_pids'] and resource['resource_interruption'] is None
        assert resource['policy'] == reg['policy'] and resource['policy']['cpu'] == 0 and resource['policy']['nice'] == 10
        assert resource['minimum_available_bytes'] >= 13 * 1024**3 and resource['sampled_peak_group_rss_bytes'] < 1024**3
        for name, digest in reg['frozen_sha256'].items():
            assert sha(records[p + name]) == digest
        for name, digest in reg['input_sha256'].items():
            assert sha(records[p + name]) == digest
        for name in ['experimental-heavy24', 'experimental-generated39', 'source-prepared25', 'experimental-prepared25']:
            with h5py.File(io.BytesIO(records[p + name + '.h5msm']), 'r') as stream:
                assert stream.attrs['version'] == '0.6'
        received = obj(p + 'mechanical-receiving.json')
        assert received['source_nonmutation'] and set(received['format_versions'].values()) == {'0.6'}
        assert len(received['readbacks']) == 2
        for row in received['readbacks']:
            name = row['name']
            assert row['complete_public_mechanics_equal']
            before = obj(p + name + '-mechanics-before-read.json')
            after = obj(p + name + '-mechanics-restored.json')
            assert before == after and after['native_partial_charge_unit'] == 'elementary_charge'
            quantities(after)
            if name == 'experimental-prepared25':
                assert after['present'] and after['atoms_ff'] is not None
                assert after['partial_charge_assignment'].get('kind') != 'none'
                assert after['atom_type_assignment'].get('kind') != 'none'
                assert row['adverse_controls'] == ['missing_partial_charge_assignment', 'missing_atom_type_assignment', 'changed_partial_charge_value', 'changed_partial_charge_dtype']
        identity = obj(p + 'source-identity.json')
        assert identity['matched_current_source_control']
        assert sha(records[p + 'source-prepared.pdbqt']) == sha(records[p + 'control-prepared.pdbqt']) == identity['control_sha256']
        for role in ['source', 'experimental']:
            report = obj(p + role + '-policy-report.json')
            fields = obj(p + role + '-policy-fields.json')
            history = obj(p + role + '-policy-history.json')
            assert report['atom_correspondence'] == {'indices': 'identity', 'n_atoms': 39}
            assert report['hydrogen_atom_indices'] == list(range(24, 39))
            expected = deepcopy(fields['before'])
            expected['allows_implicit_hydrogens'][24:] = [False] * 15
            assert fields['after'] == expected and history['after'][:-1] == history['before'] and history['after'][-1]['report'] == report
        for name in ['full39-correspondences', 'prepared25-correspondences']:
            assert obj(p + name + '.json')['search_complete']
        support = obj(p + 'support-receipt.json')
        assert support['state'] == 'verified-support' and support['resources_retired'] and support['imports_retired']
    for name in obj('attempts/reference-normal-02/registration.json')['frozen_sha256']:
        assert records['attempts/reference-normal-02/' + name] == records['attempts/reference-pm_fs-02/' + name]
    assert not any(name == 'molsysmt' or name.startswith(('molsysmt.', 'dockingmt', 'vina', 'rdkit', 'molsysviewer')) for name in sys.modules)
    return {'complete_profiles': ['normal', 'pm_fs'], 'reference_accepted': True, 'e3_accepted': False, 'mechanical_adverse_controls_per_profile': 4, 'format': '0.6', 'quantity_records_verified': quantity_records, 'setup_failures_preserved': 1, 'scientific_replays': 0}
