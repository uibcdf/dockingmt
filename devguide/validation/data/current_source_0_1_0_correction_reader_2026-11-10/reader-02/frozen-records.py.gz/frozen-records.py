"""Seal and independently read the separate consumer-correction population."""
import gzip
import hashlib
import importlib.abc
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/current-0.1.0-preparation-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/current_source_0_1_0_correction_2026-11-10';companion=root/'devguide/validation/data/current_source_0_1_0_correction_reader_2026-11-10'
base='7a757ab0b29f9da97a04224434c7a53ad91bcf5b'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for source,name in paths:
  raw=source.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);p=folder/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len(rows)==len({r['path'] for r in rows})
 save(folder/'manifest.json',{'schema':'dockingmt.current_source_0_1_0_correction@1','owner':'uibcdf/dockingmt#74','base_candidate':base,'scope':'Consumer qualification correction; original hosted attempt cancelled/unqualified; no new full/native gate pass','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder,expected):
 assert sha(folder/'manifest.json')==expected['manifest_sha256'];rows=json.loads((folder/'manifest.json').read_text())['files'];assert len(rows)==expected['members'];data={}
 for r in rows:
  assert not Path(r['path']).is_absolute() and '..' not in Path(r['path']).parts
  blob=(folder/r['path']).read_bytes();assert len(blob)==r['bytes'] and hashlib.sha256(blob).hexdigest()==r['sha256'];raw=gzip.decompress(blob);assert len(raw)==r['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==r['decoded_sha256'];assert r['original_path'] not in data;data[r['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Stored correction records only; no scientific/native/test/build replay'}
if stage=='audit':
 names=sorted(set(json.loads((task/'qualified-files.json').read_text()))|{'devtools/tests/test_3ptb_interaction_hosted.py'});assert len(names)==81
 snapshot={name:sha(root/name) for name in names};save(task/'correction-qualified.json',snapshot)
 paths=[(root/name,'qualified/'+name) for name in names]
 for name in ['correction-records.py','gates.py','correction-qualified.json','published-checkpoint.json','runtime-artifact.json']:paths.append((task/name,'producer/'+name+('.txt' if name.endswith('.py') else '')))
 for label in ['final-11','committed-01','final-12','final-13','final-14']:paths.extend((p,'attempts/'+label+'/'+p.name) for p in sorted((task/label).iterdir()) if p.is_file())
 hosted=task/'hosted-42956040456'
 for name in ['terminal-observation.json','build-receiving.json','build/evidence/build-receipt.json','unqualified-311-artifact.json','unqualified-311/evidence/source-admission.json']:
  paths.append((hosted/name,'hosted/'+name))
 receipt.update(seal(primary,paths));save(task/'correction-primary-receipt.json',receipt)
elif stage=='reader':
 data=read(primary,json.loads((task/'correction-primary-receipt.json').read_text()));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm','dmt_test_support']:blocked.append(fullname);raise AssertionError('Stored reader imported science')
 sys.meta_path.insert(0,Block())
 site=Path(json.loads((root/'.molsyssuite/installed-pose-audit-20261110/installation.json').read_text())['site']);reporter=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,value in reporter['files_sha256'].items():assert sha(site/name)==value
 sys.path.insert(0,str(site));from pytest_receptor import read_artifact
 observations={}
 with tempfile.TemporaryDirectory(dir=attempt,prefix='correction-events-') as tmp:
  for label in ['final-11','committed-01','final-12','final-13','final-14']:
   prefix='attempts/'+label+'/';resource=json.loads(data[prefix+'resource-outcome.json']);assert resource['group_terminal'] and not resource['remaining_live_owned_pids'] and resource['resource_interruption'] is None and resource['minimum_available_bytes']>13*1024**3
   if label=='committed-01':assert resource['exit_code']==0;continue
   path=Path(tmp)/'events.jsonl';path.write_bytes(data[prefix+'events.jsonl']);events=read_artifact(path);assert events.complete;admin=json.loads(data[prefix+'admin-receipt.json']);assert admin['receptor_final']==events.final.data and not admin['blocked']
   counts={k:sum(int(n.get(k,0)) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};assert counts==admin['counts'];c=events.final.data['counts'];assert counts['tests']==c['executed']+sum(c.get('subtests',{}).values());assert counts['failures']==c['failed'];assert resource['exit_code']==events.final.data['exitstatus']==(1 if label=='final-13' else 0);assert c['failed']==(3 if label=='final-13' else 0);observations[label]=c
 assert observations['final-14']['passed']==114 and observations['final-14']['subtests']=={'passed':26}
 snapshot=json.loads(data['producer/correction-qualified.json']);assert len(snapshot)==81
 for name,value in snapshot.items():assert sha(root/name)==value==hashlib.sha256(data['qualified/'+name]).hexdigest()
 artifact=json.loads(data['producer/runtime-artifact.json']);assert len(artifact['source_sha256'])==66
 for name,value in artifact['source_sha256'].items():assert snapshot[name]==value
 run=json.loads(data['hosted/terminal-observation.json']);assert run['candidate']==base and run['conclusion']=='cancelled' and not run['qualified'] and not run['product_or_storage_tests_executed'];assert len(run['jobs'])==7
 build=json.loads(data['hosted/build/evidence/build-receipt.json']);assert build['candidate']==base and build['version']=='0.1.0' and len(build['runtime_sha256'])==67 and build['private_lightweight_tag_only']
 assert build['wheel_sha256']=='3e7aec46f1733dc3a53d7ab90ec7bf5add5ac2562e37d8a5ddf1b727f8d24158'
 assert not blocked;receipt.update(members=len(data),qualified_sources=81,unchanged_runtime_sources=66,administrative_observations=observations,events_retired=not Path(tmp).exists(),scientific_imports=blocked,original_hosted_conclusion='cancelled',product_or_storage_tests_executed=False,full_candidate_gate=False)
 save(task/'correction-reader-observation.json',receipt)
elif stage=='reader-seal':
 paths=[(p,'reader-02/'+p.name) for p in sorted((task/'reader-02').iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'correction-reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1700])
