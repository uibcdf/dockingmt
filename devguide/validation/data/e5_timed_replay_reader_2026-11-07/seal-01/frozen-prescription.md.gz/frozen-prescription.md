# Timed installed 1IEP reconstruction — 2026-11-07

Owner: [DockingMT #83](../pending_proposals/qualify_independent_installed_reproduction.md).
Starting checkpoint: `51ed3dd39e169f0b59d48797788cddd37ec9f14d`.
Registered before execution. Current selection: **admission and zero-search
diagnostic only; unexecuted**. The full scientific objective remains unchanged.

## Previous turn and preserved limits

The preceding turn made progress: exact installed artifact/support admission
passed and four native entries/three returns were preserved as interrupted,
without accepting a whole scientific cell. Its
[native record](e5_native_replay_2026-11-07.md) remains immutable in its archives.
Producer02's support retirement passes; final custody/caller restoration does
not. Producer03 stops in its second native search. Wall observations alone do
not identify CPU pressure, native cost or a product regression.

Do not restart the previous terminal campaign, merge its results into a PASS,
or treat its four remaining entries as a complete six-search budget. No extra
native entry is registered here yet. The newer MolSysMT #642 construction and
actual browser/comm/canvas holds stay in force; no rebuild or remote CI.

## Exact admission and diagnostic selection

Make fresh independent producer/normal/pm-fs byte copies from the same immutable
artifact anchors: consumer `2ef82d2` / wheel `6db76835`, MolSysMT `9e1f1b1`, Viewer `78ede79e`,
and the exact 103-path Vina 1.2.7/Boost overlay. Export the 594 declared support
inputs from committed `08324fe` without runtime source/Git in their owner tree.
Verify original prefixes, all payload/link targets and distinct actual inodes;
copy regular native files before symlinks. Use exact shared SDK `95f693be`.
The later routine composition includes the separately inventoried
`sphinxcontrib-plantuml-0.30-pyhd8ed1ab_0.json`; verify all current metadata against
that exact postflight inventory, without installing or removing anything.

The diagnostic uses the actual copied normal receiver in a fresh `-B -I -S`
process, caller normal unit context entered before sibling imports, and the
actual shared `staged_support` mechanism. Import real installed providers/Vina
and the Viewer class without constructing any View or native engine. Stage,
authenticate, import, fingerprint, check and retire all 594 support resources.
Require unchanged code identity `2612b3e`, unknown Git/dirty and no source fallback.
Verify complete installed Python/native origins, relocated Boost and every
prefix/metadata byte before/after. Restore the original caller policy.

All public DockingMT dock/score/preparation/view/evaluation calls, Vina method
entries, molecular getters/conversions/copies/source maps/comparisons and
detectors are forbidden or capped at zero. No ligand/input read, graph
reconstruction, source-reference metric, native initialization/grid/search,
kernel/server/browser or build is part of this diagnostic. Bookkeeping may
authenticate the declared fixture bytes outside a molecular operation.

Record monotonic wall time, own process CPU and child user/system CPU at import,
origin/custody, support-staging/check/retirement and policy-restoration phases.
Flush each progress event immediately. A bounded Python traceback watchdog
records stacks every 15 seconds; it adds no scientific call. The same observer
draft also records native method entry/return clocks for a future separately
registered complete run, without replacing scientific returns or changing the
pinned helper/protocol/tolerances.

## Resources, interpretation and next decision

Run admission then diagnostic serially, CPU0/nice10, one native/build worker,
8 GiB available-RAM reserve, 1 GiB owned-group RSS, 2 GiB address space, 45 CPU/
60 wall seconds. Reuse the frozen shared monitor/owned-group shutdown functions;
the task-local limit function explicitly applies the registered CPU allowance.
Preserve every failed/interrupted attempt; no automatic heavy restart after
headroom/RSS interruption. Confirm terminal groups before continuing.

Diagnostic timings qualify only the measured administrative phases in this
composition and current workstation state. They cannot estimate a missing
native call, prove a machine-contention cause, or establish a benchmark.
Inspect actual clocks/stacks before choosing a finite whole-workflow budget.
Any future native campaign needs an explicit prospective amendment: one complete
producer pair, complete adverse matrix and normal/pm-fs receiver pairs with all
original source/map/software/input/protocol/physical tolerance checks. Include
all four previous entries and all future attempts in the total; preserve old
producers and external-preparation limits. Public/platform and independent
molecular-panel acceptance remain separate.

Task `.molsyssuite/e5-timed-replay-20261107` retains copies, exact prescriptions,
frozen workers/controllers, phase journals/stacks and receipts under #50,
review 2026-11-14. Original migration stays untouched. Keep #83 partial and the
complete Core C0–C6/Extended E1–E5/scientific/public/stabilization goal active.


## Passing zero-search diagnostic and prospective whole-cell amendment

Fresh admission01 passes in 9.107 s/142,139,392 sampled group-RSS bytes.
Diagnostic01 passes in 9.930 wall seconds/324,743,168 bytes, zero observed
DockingMT/helper/provider/native calls, no forbidden operation, complete origin/
prefix/metadata nonmutation, all 594 support inputs retired and caller policy
restored. Its last phase marker is 9.474 elapsed / 9.435 own CPU seconds; child
CPU totals 0.023 s. First custody takes 1.633 s, Viewer class import 1.005 s,
support staging 1.368 s, final support check 0.302 s, retirement 0.323 s and final
custody 2.966 s. No 15-second stack dump fires. These are single-cell observations,
not a native benchmark, prediction or proven explanation of prior interruptions.

Register `candidate-scientific.json` as an explicit child of the unchanged
zero-search admission candidate, and freeze `campaign-registration.json` before
any new search. The new complete selection permits **six searches**, or **ten
cumulative entries including the four previously interrupted entries**. Run one
new complete producer pair, twelve native-free adverse controls, normal receiver
pair, then pm/fs receiver pair only after complete passing normal receiving with
identical worker/candidate bytes. Original producer paths must have retired.
Keep the original CPU 90 cap from the preceding measured attempt; set finite
wall 360 for these three whole cells so per-call CPU/wall clocks and 15-second
stacks can distinguish progress from elapsed-time starvation. Administrative/
adverse/reader cells remain CPU 45 / wall 60. All affinity/nice/worker/RSS/reserve/AS
limits stay unchanged. This is a prospective finite allowance, not an automatic
retry or a resource/performance claim. If a scientific cell is interrupted, stop
this campaign and retain it; no partial outputs become passing evidence.

All unchanged native/helper/molecular operations, caps, input fingerprints,
source-map and software/protocol comparisons and physical tolerances remain
those in the preceding recipe. In particular no new scientific kernel,
preparation, alignment, score, output replacement or relaxed comparison is
introduced. Record actual new pose populations rather than forcing historical
counts. Software-version controls are post-run comparisons on genuine results,
never falsely described as pre-search checks. New scientific calls are limited
to the registered six entries; the zero-search diagnostic spent none.
