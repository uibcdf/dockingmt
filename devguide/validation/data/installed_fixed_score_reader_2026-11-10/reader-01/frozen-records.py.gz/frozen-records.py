"""Seal fixed-pose scoring, independent interpretation and portable-cell evidence."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/installed-fixed-score-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/installed_fixed_score_2026-11-10';companion=root/'devguide/validation/data/installed_fixed_score_reader_2026-11-10'
qualified=['dockingmt/score.py','dockingmt/engines/_vina_scoring.py','dockingmt/core/results.py','dockingmt/core/_scores.py','tests/test_scoring.py','tests/test_scoring_reference.py','tests/test_score_semantics.py','tests/test_scored_result_audit.py','devguide/validation/fixed_pose_scoring.ipynb']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.installed_fixed_score@1','owner':'uibcdf/dockingmt#47','portable_workflow_owner':'uibcdf/dockingmt#105','qualification_base':'4e30da511afa4181bbdbb63a3f53c31a19b4e5fa','runtime_producer':'aeae47d50c5e90687c2558437cb22cf8f271ce85','notebook_source':'New exact notebook overlay on qualification base; independent of runtime wheel producer','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored software evidence; no molecular/native execution replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.ipynb'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 for name in qualified:paths.append((root/name,'qualified/'+name))
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 artifact=d('producer/artifact.json');assert artifact['source_commit']=='aeae47d50c5e90687c2558437cb22cf8f271ce85' and artifact['wheel_sha256']=='0b303ae371466a6736e8d194a89a54048f8bc51de3cd293cdc68c06050ae042b' and artifact['runtime_paths']==67
 cohort=d('producer/expected-cohort.json');assert cohort['molsysmt']['commit']=='0c6f9c746dbd10b02dfe8474a5af280b857ace0d';baseline=d('attempts/pilot-normal-01/support-sidecar.json')['files'];assert len(baseline)==606;refs=d('producer/reference-fixtures.json');measured={};native_total=0
 for label,count,deselected,runs in [('pilot-normal-01',1,31,2),('scoring-normal-01',31,1,7),('scoring-pm-fs-01',31,1,7),('records-normal-01',89,0,0),('records-pm-fs-01',89,0,0)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['counts']=={'tests':count,'failures':0,'errors':0,'skipped':0} and row['pytest_exit_code']==0 and row['warnings']==0 and not row['forbidden_operations'] and row['cohort_unchanged'] and row['deliberate_stubs_are_not_native_calls']
  counts=row['engine_call_counts'];assert counts.get('__init__',0)==counts.get('score',0)==runs and not any(counts.get(n,0) for n in ['dock','optimize','randomize','poses','energies'])
  assert row['receptor_final']['counts']['deselected']==deselected and row['wheel_sha256']==artifact['wheel_sha256'] and row['actual_engine_version']=='1.2.7' and d(prefix+'cohort.json')==cohort
  support=d(prefix+'support-sidecar.json');assert support['files']==baseline and support['executed_tests']==count and support['imports_retired'] and support['resources_retired']
  if runs:
   calls=d(prefix+'engine-calls.json');assert calls==row['engine_calls'] and all(c['outcome']=='PASS' for c in calls);groups={}
   for call in calls:
    params=call['parameters']
    if call['call']=='__init__':assert params['cpu']==1 and params['sf_name'] in ['vina','vinardo']
    elif call['call']=='compute_vina_maps':assert params['center']==[0.0]*3 and all(0<float(n)<=10 for n in params['box_size'])
    elif call['call']=='score':
     assert params['unbound_energy'] is None and call['result_shape']==[8] and len(call['native_components'])==8 and call['native_unit']=='kcal/mol';groups.setdefault(call['test_node'],[]).append(call['native_components'])
    for role in ['receptor','partner']:
     if role not in call:continue
     info=call[role];blob=data[prefix+'inputs/backend/'+str(call['run'])+'/'+role+'.pdbqt'];assert len(blob)==info['bytes'] and hashlib.sha256(blob).hexdigest()==info['sha256']
     assert sum(line.startswith((b'ATOM  ',b'HETATM')) for line in blob.splitlines())==info['atom_records']==(4 if role=='receptor' else 2)
     if role=='receptor':assert info['sha256']==refs['MINIMAL_REC_PDBQT']['sha256']
   direct=[v for name,v in groups.items() if 'test_native_scoring_matches_direct_engine_and_preserves_pose' in name];assert len(direct)==(1 if label.startswith('pilot') else 2)
   for vectors in direct:assert len(vectors)==2 and vectors[0]==vectors[1]
  else:assert row['provider_call_counts']=={} and not row['engine_calls']
  native_total+=runs;measured[label]={'cases':count,'deselected':deselected,'actual_native_scores':runs,'warnings':0}
 for selection in ['scoring','records']:assert data['attempts/'+selection+'-normal-01/frozen-worker.py']==data['attempts/'+selection+'-pm-fs-01/frozen-worker.py']
 notebook_profiles={}
 for label,mode,cells,scores in [('notebook-original-01','original-refusal',0,0),('notebook-revised-normal-01','revised',4,2),('notebook-revised-pm-fs-01','revised',4,2),('notebook-bad-digest-01','bad-digest',0,0),('notebook-missing-captures-01','missing-captures',0,0)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['mode']==mode and row['completed_cells']==cells and row['engine_call_counts'].get('score',0)==scores and not row['forbidden_operations'] and row['cohort_unchanged'] and row['outside_source_execution_root_retired'] and row['no_sdk_harness_source_injection'] and row['headless_not_actual_kernel']
  assert row['wheel_sha256']==artifact['wheel_sha256'] and d(prefix+'cohort.json')==cohort and row['caller_policy_preserved']
  sources=[''.join(c['source']) for c in json.loads(data[prefix+'inputs/fixed_pose_scoring.ipynb'])['cells'] if c['cell_type']=='code'];assert len(sources)==4 and hashlib.sha256(data[prefix+'inputs/fixed_pose_scoring.ipynb']).hexdigest()==row['notebook_sha256']
  for i,source in enumerate(sources,1):assert source.encode()==data[prefix+'inputs/cell-'+str(i)+'.py']
  assert hashlib.sha256(data[prefix+'inputs/record.json']).hexdigest()==row['input_sha256']
  if mode=='revised':
   assert row['refusal'] is None and row['notebook_sha256']==d('producer/notebook-revised.json')['notebook_sha256'];records=d(prefix+'scoring-records.json')
   assert len(records['first']['scores'])==8 and len(records['second']['scores'])==16 and len(records['restored']['scores'])==17 and len(records['second']['metadata']['scoring_history'])==2 and len(records['restored']['metadata']['scoring_history'])==2
   assert records['first']['coordinates']==records['second']['coordinates']==records['restored']['coordinates']
   assert row['original_producer']=='0.0.0+14.g25b6e0b.dirty'
  else:assert row['refusal']['cell']==1 and not row['engine_calls']
  native_total+=scores;notebook_profiles[label]={'mode':mode,'completed_cells':cells,'actual_native_scores':scores,'refusal':row['refusal']}
 for label in ['pilot-normal-01','scoring-normal-01','scoring-pm-fs-01','notebook-revised-normal-01','notebook-revised-pm-fs-01']:
  prefix='attempts/'+label+'/';maps=d(prefix+'native-maps.json');engine=d(prefix+'frozen-engine-receipt.json')['paths'];native='lib/python3.14/site-packages/vina/_vina_wrapper.cpython-314-x86_64-linux-gnu.so';assert [value for name,value in maps.items() if name.endswith('/'+native)]==[engine[native]]
 assert d('attempts/notebook-original-01/receipt.json')['refusal']['type']=='AssertionError'
 assert d('attempts/notebook-bad-digest-01/receipt.json')['refusal']['type']=='ValueError'
 assert d('attempts/notebook-missing-captures-01/receipt.json')['refusal']['code']=='DMT-E002'
 original_record=json.loads(data['attempts/notebook-revised-normal-01/inputs/record.json']);control=json.loads(json.dumps(original_record))
 for item in control['provenance']['backend_artifacts'].values():item.pop('content_base64',None)
 assert control==json.loads(data['attempts/notebook-missing-captures-01/inputs/record.json'])
 assert native_total==20
 assert data['attempts/notebook-revised-normal-01/frozen-worker.py']==data['attempts/notebook-revised-pm-fs-01/frozen-worker.py']
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   r=json.loads(raw);assert r['outcome']=='PASS' and r['resource_interruption'] is None and r['group_terminal'] and not r['remaining_live_owned_pids'] and r['minimum_available_bytes']>13*1024**3
 for name in qualified:
  raw=data['qualified/'+name];assert (root/name).read_bytes()==raw
  if name.startswith('dockingmt/'):assert hashlib.sha256(raw).hexdigest()==artifact['payload_sha256'][name]
  elif name.startswith('tests/'):assert hashlib.sha256(raw).hexdigest()==d('producer/qualification-inputs.json')[name]
  else:assert hashlib.sha256(raw).hexdigest()==d('producer/notebook-revised.json')['notebook_sha256']
 original=data['producer/original-fixed_pose_scoring.ipynb'];assert hashlib.sha256(original).hexdigest()==d('producer/notebook-original.json')['notebook_sha256'] and original!=data['qualified/devguide/validation/fixed_pose_scoring.ipynb']
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),pytest_populations=measured,notebook_profiles=notebook_profiles,qualified_sources=9,support_records=606,actual_native_score_calls=native_total,no_actual_search_optimization=True,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json']);path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete and row['counts']==counts and row['receptor_final']==events.final.data
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':row['pytest_exit_code'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==5 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1700])
