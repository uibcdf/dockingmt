"""Offline interaction admission with guarded molecular providers."""
import importlib.abc
import importlib.machinery
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import hashlib
_tool_receipt=Path(__file__).resolve().parents[1]/'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_receipt.read_bytes()).hexdigest()=='6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool=json.loads(_tool_receipt.read_text());_prefix=Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()}==_tool['files_sha256']
sys.path.insert(0,str(_prefix))
_unit_receipt=Path(__file__).parent/'frozen-unit-support-receipt.json'
assert hashlib.sha256(_unit_receipt.read_bytes()).hexdigest()=='e037dab5e968c1eb3797637d12e585ad74c0a86e5ce7ec185b2136778b63546f'
_unit=json.loads(_unit_receipt.read_text());_unit_prefix=Path(_unit['prefix'])
assert {str(p.relative_to(_unit_prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in _unit_prefix.rglob('*') if p.is_file()}==_unit['files_sha256']
sys.path.insert(0,str(_unit_prefix))
import pytest_receptor
assert metadata.version('pytest-receptor')=='1.2.2'
import pytest
import pyunitwizard as puw

root=Path(os.environ['DMT_SOURCE_ROOT'])
attempt=Path(os.environ['DMT_SOURCE_ATTEMPT'])
registration=json.loads((attempt/'registration.json').read_text())
profile=registration['profile']
units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if profile=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
forbidden=[]
engine_probes=[]
class RejectEngineImport(importlib.abc.Loader):
    def create_module(self,spec):
        forbidden.append('optional engine import: '+spec.name)
        raise AssertionError('Offline admission imported an optional molecular engine')
    def exec_module(self,module):
        raise AssertionError('Unreachable engine execution')
class BlockEngines(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'vina','rdkit','openmm'}:
            engine_probes.append(fullname)
            spec=importlib.machinery.PathFinder.find_spec(fullname,path)
            if spec is not None:
                spec.loader=RejectEngineImport()
            return spec
sys.meta_path.insert(0,BlockEngines())
with puw.context(default_form='pint',standard_units=units):
    before=puw.configure.report()
    import dockingmt as dmt
    import molsysmt as msm
    import molsysviewer as msv
    assert Path(dmt.__file__).resolve()==root/'dockingmt/__init__.py'
    def blocked(*args,**kwargs):
        forbidden.append('real molecular/provider construction')
        raise AssertionError('Source admission requested a real molecular operation')
    for name in ['get','select','extract','convert','copy','set']:
        setattr(msm,name,blocked)
    msv.MolSysView=blocked
    args=['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'-o','cache_dir='+str(attempt/'cache')]+registration['selection']
    code=int(pytest.main(args))
    after=puw.configure.report()
    for key in ['default_form','default_parser','standard_units']:
        assert before[key]==after[key]
    assert not forbidden
    assert not any(name.split('.')[0] in {'vina','rdkit','openmm'} for name in sys.modules)
    for name,module in tuple(sys.modules.items()):
        if name=='pytest_receptor' or name.startswith('pytest_receptor.'):
            path=Path(module.__file__).resolve();assert path.is_relative_to(_prefix)
            assert hashlib.sha256(path.read_bytes()).hexdigest()==_tool['files_sha256'][str(path.relative_to(_prefix))]
    for name,module in tuple(sys.modules.items()):
        if name.split('.')[0] in {'unyt','sympy','mpmath'} and getattr(module,'__file__',None):
            path=Path(module.__file__).resolve();assert path.is_relative_to(_unit_prefix)
            assert hashlib.sha256(path.read_bytes()).hexdigest()==_unit['files_sha256'][str(path.relative_to(_unit_prefix))]
    from pytest_receptor import read_artifact
    artifact=read_artifact(attempt/'events.jsonl')
    assert artifact.complete
    counts={key:sum(int(row.get(key,'0')) for row in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for key in ['tests','failures','errors','skipped']}
    receipt={'outcome':'PASS' if code==0 else 'FAIL','qualification_complete':True,'stage':registration['stage'],'profile':profile,'pytest_exit_code':code,'counts':counts,'receptor_final':artifact.final.data,'caller_policy_before':before,'caller_policy_after':after,'consumer_origin':dmt.__file__,'provider_origin':msm.__file__,'versions':{name:metadata.version(name) for name in ['dockingmt','molsysmt','molsysviewer','argdigest','smonitor','pyunitwizard','pytest','pytest-receptor','unyt','sympy','mpmath']},'molecular_calls_attempted':forbidden,'native_searches':0,'optional_availability_probes':engine_probes,'scope':'Offline audit resource-exception source gates; guarded real molecular operations; separately verified test-only unit support; no scientific/visual/public acceptance'}
    (attempt/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(code)
