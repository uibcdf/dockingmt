"""Independent stdlib-only reader of frozen failed reference evidence."""
import gzip
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
folder = root / 'devguide/validation/data/e3_experimental_reference_2026-11-08'
expected = '000117998b96f611fb001df6f7f01da5fb7643507fcb286fb6582e2d749cf3d2'
assert hashlib.sha256((folder / 'manifest.json').read_bytes()).hexdigest() == expected
manifest = json.loads((folder / 'manifest.json').read_text())
assert manifest['owner'] == 'uibcdf/dockingmt#79' and len(manifest['files']) == 59
records = {}
for row in manifest['files']:
    path = folder / row['path']
    assert path.resolve().parent == folder.resolve()
    stored = path.read_bytes()
    assert len(stored) == row['bytes'] and hashlib.sha256(stored).hexdigest() == row['sha256']
    raw = gzip.decompress(stored)
    assert len(raw) == row['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == row['decoded_sha256']
    assert row['original_path'] not in records
    records[row['original_path']] = raw
def read(name):
    return json.loads(records[name])
first = read('reference-normal/failure.json')
second = read('receiving-02/reference-normal/failure.json')
assert first['stage'] == 'custody' and not any(first['direct_counts'].values())
assert second['stage'] == 'graph_witnesses'
assert second['direct_counts'] == {'sdf_native': 2, 'native_to_rdkit': 2, 'rdkit_to_native': 2, 'coordinates': 6, 'hydrogen_addition': 1, 'heavy_selections': 2, 'graph_witnesses': 1, 'cip': 0, 'charges': 0, 'types': 0, 'prepare': 0, 'pdbqt': 0, 'prepared_native': 0, 'hydrogen_inventory': 0, 'h5_write': 0, 'h5_read': 0}
for name in ['reference-normal', 'receiving-02/reference-normal']:
    failure = read(name + '/failure.json')
    assert failure['reference_accepted'] is False and failure['e3_accepted'] is False
    resource = read(name + '/resource-outcome.json')
    assert resource['outcome'] == 'FAIL' and resource['group_terminal'] and resource['resource_interruption'] is None and not resource['remaining_live_owned_pids']
    assert resource['policy']['available_reserve_bytes'] == 13 * 1024**3
    registration = read(name + '/registration.json')
    for relative, digest in registration['frozen_sha256'].items():
        assert hashlib.sha256(records[name + '/' + relative]).hexdigest() == digest
    for basename, digest in registration['input_sha256'].items():
        assert hashlib.sha256(records[name + '/' + basename]).hexdigest() == digest
    assert not any(path.startswith(name + '/') and path.endswith(('.h5msm', '.pdbqt')) for path in records)
witness = read('receiving-02/reference-normal/full39-correspondences.json')
assert witness['search_complete'] and witness['search_scope'] == 'all_chemical_correspondences'
assert witness['n_candidate_matches'] == 2 and witness['atom_correspondences'] == witness['context_atom_correspondences'] == []
assert witness['n_atoms'] == witness['reference_n_atoms'] == 39
assert witness['selection_atom_indices'] == witness['reference_selection_atom_indices'] == list(range(24))
addition = read('receiving-02/reference-normal/hydrogen-addition-report.json')
assert addition['n_added_hydrogens'] == 15 and addition['original_coordinates_preserved']
diagnosis = read('diagnosis.json')
assert diagnosis['atom_count'] == 39 and diagnosis['bond_count'] == 42 and diagnosis['stored_stereo_atom7'] == 'R'
assert diagnosis['differences']['atom_attributes'] == {'allows_implicit_hydrogens': [{'index': i, 'source': True, 'reference': False} for i in range(24,39)]}
assert set(diagnosis['differences']['bonds']) == {'bond_id', 'is_conjugated'}
for n in ['campaign-terminal.json', 'receiving-02/campaign-terminal.json']:
    terminal = read(n)
    assert terminal['outcome'] == 'FAIL' and terminal['further_molecular_work_permitted'] is False and terminal['unattempted'] == ['pm_fs']
custody = read('custody.json')
assert custody['private_provider_consumer_viewer_payloads_unchanged'] and custody['routine_metadata_unchanged']
receipt = {'stage': 'reader', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'primary_manifest_sha256': expected, 'members_verified': 59, 'scientific_imports': [], 'molecular_operations': 0, 'whole_reference_selections_accepted': 0, 'failed_selections': 2, 'unattempted_pm_fs_selections': 2, 'reference_accepted': False, 'e3_accepted': False, 'provider_normalization': 'uibcdf/molsysmt#645', 'pairwise_clustering': 'uibcdf/molsysmt#604'}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
