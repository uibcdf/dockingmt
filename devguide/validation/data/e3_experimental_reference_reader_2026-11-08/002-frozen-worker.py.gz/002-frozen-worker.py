"""Freeze complete failed E3 attempts, without molecular imports or repair."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
output = root / 'devguide/validation/data/e3_experimental_reference_2026-11-08'
output.mkdir(exist_ok=False)
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
selected = []
for name in ['plan.json', 'preflight.json', 'previous-goal-turn.json', 'campaign-terminal.json', 'provider-feedback.json', 'receiving-02/plan.json', 'receiving-02/campaign-terminal.json']:
    selected.append((name, task / name))
for label in ['reference-normal', 'receiving-02/reference-normal']:
    folder = task / label
    for path in sorted(folder.iterdir()):
        if path.is_file():
            selected.append((str(path.relative_to(task)), path))
source = root / '.molsyssuite/panel-receiving-20261107/provider-source-faab'
review = {}
for relative in ['molsysmt/chemical_states/get_atom_correspondences.py', 'molsysmt/chemical_states/_atom_correspondences.py', 'molsysmt/build/add_missing_hydrogens.py', 'molsysmt/_private/fixed_hydrogens.py', 'molsysmt/form/file_sdf/to_molsysmt_MolSys.py']:
    path = source / relative
    blob = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'faab727ca5b5c9078e2f2e505971fc0ea1cf1a8d:' + relative], text=True).strip()
    review[relative] = {'source': 'faab727ca5b5c9078e2f2e505971fc0ea1cf1a8d', 'blob': blob, 'sha256': sha(path)}
    selected.append(('provider-source/' + relative, path))
(task / 'source-review.json').write_text(json.dumps(review, indent=2) + '\n')
selected.append(('source-review.json', task / 'source-review.json'))
folder = task / 'receiving-02/reference-normal'
a = json.loads((folder / 'source-authority-snapshot.json').read_text())['chemical_states']['states'][0]
b = json.loads((folder / 'experimental-generated-snapshot.json').read_text())['chemical_states']['states'][0]
differences = {}
for table in ['atom_attributes', 'bonds']:
    ac, bc = a[table]['columns'], b[table]['columns']
    assert ac.keys() == bc.keys() and a[table]['n_rows'] == b[table]['n_rows']
    differences[table] = {}
    for key in ac:
        rows = [{'index': i, 'source': None if ac[key]['null_mask'][i] else ac[key]['values'][i], 'reference': None if bc[key]['null_mask'][i] else bc[key]['values'][i]} for i in range(a[table]['n_rows']) if (ac[key]['null_mask'][i], ac[key]['values'][i]) != (bc[key]['null_mask'][i], bc[key]['values'][i])]
        if rows:
            differences[table][key] = rows
assert list(differences['atom_attributes']) == ['allows_implicit_hydrogens']
assert differences['atom_attributes']['allows_implicit_hydrogens'] == [{'index': i, 'source': True, 'reference': False} for i in range(24, 39)]
assert set(differences['bonds']) == {'bond_id', 'is_conjugated'}
for state in [a, b]:
    cols = state['atom_attributes']['columns']
    assert cols['stereochemistry']['values'][7] == 'R' and not cols['stereochemistry']['null_mask'][7]
    for key in ['n_implicit_hydrogens', 'n_explicit_hydrogens']:
        assert cols[key]['values'][24:] == [0] * 15 and not any(cols[key]['null_mask'][24:])
diagnosis = {'scope': 'Literal comparison of provider-produced public snapshots on their saved axes, not atom matching or chemical equivalence', 'atom_count': 39, 'bond_count': 42, 'stored_stereo_atom7': 'R', 'differences': differences, 'strict_atom_label_contains': 'allows_implicit_hydrogens', 'normalization_received': False, 'provider_issue': 'uibcdf/molsysmt#645'}
(task / 'diagnosis.json').write_text(json.dumps(diagnosis, indent=2) + '\n')
selected.append(('diagnosis.json', task / 'diagnosis.json'))
candidate = json.loads((task / 'reference-normal/frozen-candidate.json').read_text())
for key, field in [('prefix', 'provider_files_sha256'), ('consumer_prefix', 'consumer_files_sha256'), ('viewer_prefix', 'viewer_files_sha256')]:
    prefix = Path(candidate[key])
    assert {str(p.relative_to(prefix)): sha(p) for p in prefix.rglob('*') if p.is_file()} == candidate[field]
routine = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/conda-meta')
assert {p.name: sha(p) for p in routine.glob('*.json')} == candidate['routine_metadata_sha256']
custody = {'private_provider_consumer_viewer_payloads_unchanged': True, 'routine_metadata_unchanged': True, 'check_scope': 'Post-process administrative file custody, not unreached final live molecular nonmutation', 'original_attempts': {}}
for label in ['reference-normal', 'receiving-02/reference-normal']:
    resource = json.loads((task / label / 'resource-outcome.json').read_text())
    assert resource['outcome'] == 'FAIL' and resource['group_terminal'] and resource['resource_interruption'] is None and not resource['remaining_live_owned_pids']
    custody['original_attempts'][label] = {k: resource[k] for k in ['outcome', 'elapsed_seconds', 'sampled_peak_group_rss_bytes', 'group_terminal', 'resource_interruption']}
(task / 'custody.json').write_text(json.dumps(custody, indent=2) + '\n')
selected.append(('custody.json', task / 'custody.json'))
rows = []
for number, (name, path) in enumerate(selected):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    destination = f'{number:03d}-{Path(name).name}.gz'
    (output / destination).write_bytes(stored)
    rows.append({'original_path': name, 'path': destination, 'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(), 'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'schema': 'dockingmt.e3_reference_evidence@1', 'owner': 'uibcdf/dockingmt#79', 'provider_issue': 'uibcdf/molsysmt#645', 'source_commit': 'dc060579b097643546cf38655aa262c596f4b68c', 'classification': 'Two failed whole selections; first task Git audit before science, second no graph correspondence; no accepted reference or E3', 'files': rows}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {'stage': 'seal', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members': len(rows), 'manifest_sha256': sha(output / 'manifest.json'), 'stored_bytes': sum(r['bytes'] for r in rows), 'molecular_operations': 0, 'reference_accepted': False}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
