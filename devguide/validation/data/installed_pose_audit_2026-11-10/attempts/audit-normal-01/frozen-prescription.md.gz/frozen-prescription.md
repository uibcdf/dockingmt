# Complete installed pose audit on the updated development cohort — 2026-11-10

Owner: [DockingMT #47](https://github.com/uibcdf/dockingmt/issues/47), with
#30/#73 qualification and #50 custody. Status: registered, not yet executed.
Starting documentation checkpoint: 03ed7676. Unchanged actual consumer producer
37a61e6, private wheel `0.0.0+359.g37a61e6`, SHA-256
`ca082ab77b5b9ec77bd1bb75bc865f5279cde9105fe401b989b2b9b13f348e1d`.

## Complete original selection

Receive all **48 original `tests/test_pose_audit.py` cases**, normal then pm/fs,
with no deselection or modified assertion. The module is byte-identical to its
source-qualified 02228c3 population and retained installed harness. Preserve
the historical saved record, all contradiction/incomplete/refusal controls,
strict JSON semantics, source nonmutation, detached results, explicit units and
the original fresh-process check without optional engines/viewer. Auditing a
saved record checks internal consistency, not producer authenticity or physical
ranking. The original record and earlier observations retain their identities.

The one existing fresh-score case evaluates the same tiny four-atom receptor/
two-atom partner fixture with Vina then Vinardo, CPU 1/seed 17, original 10 angstrom
box and capture settings. Permit exactly two score calls per policy, no docking,
search, optimize, randomize, pose output or new molecular preparation. Observe
actual inputs/results, two public score records and the final consistent audit;
retain all sixteen scores and original assertions. The same two public PDBQT
conversions and six geometry/name/type reads are allowed only in that case.

Use the actual maintainer-updated MolSysMT source 9df62445 and local native SHA
`2dbcf13d148cb3ae13a5908707fcdd61c75a2de5027e50c566ce07de81bdb038`, already
recorded in [explicit 1.0 receiving](h5msm_v10_client_receiving_2026-11-10.md).
Preload/guard the actual native module before provider import. Admit only two
two-atom/zero-bond component-index calls per policy, with int64 inputs and result
[0, 1], within the existing fresh-score case. Block other Rust kernels, chemical
assignment, correspondence, RMSD, detector and viewer work. This is additional
finite receiving of that actual binary, whose compilation provenance remains
unassessed; provider reference 4ffb82e4 is not claimed.

Reuse the genuine installed consumer, source-free harness and shared runner/
multi-root validator at 95f693be. Verify both installed runtime roots, all 67
payload paths, distribution/version/PEP 610, 305 qualification inputs, 103 frozen
engine files, six provider source/native identities and all 606 shared support
declarations before/after, including retirement. Clear inherited source paths.
Require complete paired collection/program/input identities, JUnit/Receptor and
native qualification exits. Do not build, install, modify tests/helpers/data or
substitute fake native results.

## Resource and closeout controls

Fresh shared-host inspection: ixtlilton, 64,978,440,192 B physical RAM and
58,596,343,808 B available, about 72% sampled CPU idle, zero sampled swap I/O,
memory PSI avg10/60/300 zero. Disk has 24,184,975,360 B available; no large build
is planned. Slurm tools exist without an allocation; the bounded configuration
probe cannot open its socket and times out. No allocation or exclusive capacity
is inferred. Direct execution stays conservative.

Run serial CPU 0/nice 10/one native worker with inherited descendant limits.
Estimate 768 MiB peak group RSS; preserve the unchanged 1 GiB group cap, 2 GiB
address space, 60/65 CPU seconds and 180 wall seconds. Monitor a 13 GiB available
reserve before/during each cell. Stop only owned work; preserve interruptions
and never automatically restart after a headroom interruption.

Retain `.molsyssuite/installed-pose-audit-20261110` under #47/#73/#50, review
2026-11-14. Preserve old consumer/provider/native populations, native-build and
interactive holds, and the human migration backup. Authenticate stored records
without molecular/test replay, then run applicable local and fresh committed-
export resource/archive checks. Update maintained checkpoints and owning issues
before direct publication with `[skip ci]`; missing remote evidence stays missing.
No tag, GitHub Release, package publication or automatic remote CI follows.

Full scientific, general native/format/default, public dependency/Conda,
eight OS-minor lanes and interactive acceptance keep their separate owners.
