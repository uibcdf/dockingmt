"""Seal completed routine dependency receiving, including the failed harness."""
import gzip
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
output = root / 'devguide/validation/data/depdigest47_routine_2026-11-08'
output.mkdir(exist_ok=False)
sources = [task / name for name in ['plan.json', 'owner-evidence.json', 'receiving-amendment.json', 'original-control.py']]
for label in ['workspace-01', 'receiving-01', 'receiving-02']:
    sources.extend(path for path in sorted((task / label).iterdir()) if path.is_file())
sources.append(Path(__file__))
rows = []
for index, path in enumerate(sources):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    relative = f'{index:03d}-{path.name}.gz'
    (output / relative).write_bytes(stored)
    rows.append({'original_path': str(path.relative_to(task)), 'path': relative, 'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(), 'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'schema': 'dockingmt.depdigest47_routine_receiving@1', 'owner': 'uibcdf/dockingmt#19', 'source_commit': '75db240e9c0b3aefa64eae7258c1a513b664f9af', 'scope': 'Accepted routine provider static-audit/import/optional guards, failed task harness and separately observed MolSysMT645 source notice; no molecular receiving/build/install or public closure', 'files': rows}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {'stage': 'seal', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members': len(rows), 'manifest_sha256': hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest(), 'stored_bytes': sum(row['bytes'] for row in rows), 'molecular_operations': 0}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
