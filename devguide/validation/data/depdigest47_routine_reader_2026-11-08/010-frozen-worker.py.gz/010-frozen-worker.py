"""Independently authenticate completed routine receiving and retained failure."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(os.environ['DMT_GUIDES_ROOT'])
task = Path(os.environ['DMT_GUIDES_TASK'])
attempt = Path(os.environ['DMT_GUIDES_ATTEMPT'])
folder = root / 'devguide/validation/data/depdigest47_routine_2026-11-08'
sealed = json.loads((task / 'seal-01/receipt.json').read_text())
assert hashlib.sha256((folder / 'manifest.json').read_bytes()).hexdigest() == sealed['manifest_sha256']
manifest = json.loads((folder / 'manifest.json').read_text())
records = {}
for row in manifest['files']:
    assert (folder / row['path']).resolve().parent == folder.resolve()
    raw_stored = (folder / row['path']).read_bytes()
    assert len(raw_stored) == row['bytes'] and hashlib.sha256(raw_stored).hexdigest() == row['sha256']
    raw = gzip.decompress(raw_stored)
    assert len(raw) == row['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == row['decoded_sha256']
    assert row['original_path'] not in records
    records[row['original_path']] = raw
def read(name):
    return json.loads(records[name])
assert len(records) == sealed['members']
control_sha = 'e16b04e90932724ee9c937967211c8b885227a9a46f10c7879c50d6328af08fe'
assert hashlib.sha256(records['original-control.py']).hexdigest() == control_sha
assert records['receiving-02/frozen-original-control.py'] == records['original-control.py']
for label, expected in [('workspace-01', 'PASS'), ('receiving-01', 'FAIL'), ('receiving-02', 'PASS')]:
    outcome = read(label + '/resource-outcome.json')
    assert outcome['outcome'] == expected and outcome['group_terminal'] and not outcome['remaining_live_owned_pids'] and outcome['resource_interruption'] is None
    assert outcome['policy']['available_reserve_bytes'] == 13 * 1024**3
    registration = read(label + '/registration.json')
    assert hashlib.sha256(records[label + '/frozen-worker.py']).hexdigest() == registration['worker_sha256']
assert 'receiving-01/receipt.json' not in records and 'receiving-01/audit.log' not in records
assert b'PackageNotFoundError' in records['receiving-01/stderr.log']
assert read('receiving-amendment.json')['original_audit_controls_executed'] == 0
audit = read('receiving-02/audit-receipt.json')
assert audit['passed'] == audit['total'] == 7 and audit['temporary_fixtures_retired']
cases = {row['case']: row for row in audit['cases']}
assert len(cases) == 7 and all(row['passed'] for row in cases.values())
assert cases['core']['violation_count'] == cases['relative_adapter']['violation_count'] == cases['lazy_engine']['violation_count'] == cases['addon_exact_widget_exception']['violation_count'] == 0
for name in ['addon_raw', 'absolute_engine', 'new_addon_leak']:
    assert cases[name]['violation_count'] == 1 and cases[name]['exit'] == 1
assert cases['addon_raw']['findings'][0]['path'] == 'panels/_base.py'
assert cases['new_addon_leak']['findings'][0]['path'] == 'new_leak.py'
counts = read('receiving-02/pytest-counts.json')
assert counts == {'exit_code': 0, 'tests': 36, 'errors': 0, 'failures': 0, 'skipped': 0}
junit = ET.fromstring(records['receiving-02/pytest.xml'])
assert len(list(junit.iter('testcase'))) == 36
assert not list(junit.iter('failure')) and not list(junit.iter('error')) and not list(junit.iter('skipped'))
receipt = read('receiving-02/receipt.json')
assert receipt['outcome'] == 'PASS' and receipt['provider_source'] == '032d345becf8f8f574c24ede61ee62fcf0321de7'
assert receipt['molecular_operations'] == receipt['native_builds'] == receipt['package_installs'] == 0
before = read('receiving-02/before.json')['source']
after = read('receiving-02/after.json')['source']
assert before['provider'] == after['provider'] and before['consumer'] == after['consumer']
owner = read('owner-evidence.json')
assert owner['depdigest47']['state'] == owner['molsysmt645']['state'] == 'closed'
doc = owner['molsysmt645']['reviewed_document']
raw = doc['content'].encode()
assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == doc['git_blob']
assert not owner['molsysmt645']['consumer_received']
result = {'stage': 'reader', 'source_commit': manifest['source_commit'], 'outcome': 'PASS', 'qualification_complete': True, 'members_verified': len(records), 'primary_manifest_sha256': sealed['manifest_sha256'], 'original_controls_verified': 7, 'pytest_cases_verified': 36, 'failed_precontrol_attempts_verified': 1, 'molecular_operations': 0, 'molsysmt645_received': False, 'scope': 'Independent stored/decoded record, original producer, raw JUnit and failure/resource authentication; no rerun, scientific or public artifact qualification'}
(attempt / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
