"""Seal and independently read finite actual-engine software controls."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
root=Path(os.environ['DMT_GATE_ROOT']);attempt=Path(os.environ['DMT_GATE_ATTEMPT']);task=root/'.molsyssuite/source-scoring-evidence-20261110';stage=sys.argv[1]
primary=root/'devguide/validation/data/source_scoring_evidence_2026-11-10';companion=root/'devguide/validation/data/source_scoring_evidence_reader_2026-11-10'
qualified=['dockingmt/core/pose_audit.py','dockingmt/engines/_vina_scoring.py','dockingmt/comparison.py','dockingmt/core/results.py','dockingmt/core/_scores.py','dockingmt/score.py','tests/test_pose_audit.py','tests/test_score_comparison.py']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def seal(folder,paths):
 folder.mkdir(exist_ok=False);rows=[]
 for path,name in paths:
  raw=path.read_bytes();blob=gzip.compress(raw,compresslevel=6,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob);rows.append({'path':name+'.gz','original_path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()})
 assert len({r['path'] for r in rows})==len(rows)
 save(folder/'manifest.json',{'schema':'dockingmt.source_scoring_evidence@1','owner':'uibcdf/dockingmt#73','co_owners':['uibcdf/dockingmt#49','uibcdf/dockingmt#73'],'qualification_base':'02228c3aa94a37c8d0219068ac77bef836dc2e2c','runtime_producer':'Explicit source overlay on base, bound by qualified hashes; old aeae47d artifact is comparison only','files':rows})
 return {'manifest_sha256':sha(folder/'manifest.json'),'members':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'decoded_bytes':sum(r['decoded_bytes'] for r in rows)}
def read(folder):
 data={}
 for row in json.loads((folder/'manifest.json').read_text())['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  blob=(folder/row['path']).read_bytes();assert len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'];raw=gzip.decompress(blob);assert len(raw)==row['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==row['decoded_sha256'];assert row['original_path'] not in data;data[row['original_path']]=raw
 return data
receipt={'stage':stage,'outcome':'PASS','scope':'Independent stored actual-engine software evidence; zero native/molecular replay'}
if stage=='seal':
 names=[p for p in sorted(task.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.txt'] and p.name not in ['primary-receipt.json','reader-receipt.json','published-checkpoint.json']];paths=[(p,'producer/'+p.name+('.txt' if p.suffix=='.py' else '')) for p in names];labels=[p for p in sorted(task.iterdir()) if p.is_dir() and (p/'resource-outcome.json').is_file()]
 for directory in labels:
  paths.extend((p,'attempts/'+directory.name+'/'+p.name) for p in sorted(directory.iterdir()) if p.is_file())
  for folder in ['inputs','outputs','pytest-work']:
   if (directory/folder).is_dir():paths.extend((p,'attempts/'+directory.name+'/'+folder+'/'+str(p.relative_to(directory/folder))) for p in sorted((directory/folder).rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='.lock')
 paths.extend((p,'producer/original-fixtures/'+str(p.relative_to(task/'original-fixtures'))) for p in sorted((task/'original-fixtures').rglob('*')) if p.is_file())
 for name in qualified:paths.append((root/name,'qualified/'+name))
 receipt.update(seal(primary,paths));receipt['attempts']=[p.name for p in labels];save(task/'primary-receipt.json',receipt)
elif stage=='reader':
 expected=json.loads((task/'primary-receipt.json').read_text());assert sha(primary/'manifest.json')==expected['manifest_sha256'];data=read(primary);assert len(data)==expected['members']
 def d(name):return json.loads(data[name])
 cohort=d('producer/expected-cohort.json');refs=d('producer/reference-fixtures.json');measured={};total_scores=0
 correction=d('producer/initial-scope-correction.json');assert not correction['initial_zero_provider_expectation_received'] and correction['observed_provider_calls']=={'convert':2,'get':6}
 for label,count,run_count,qualified_pair in [('audit-normal-01',48,2,False),('audit-normal-02',48,2,True),('audit-pm-fs-01',48,2,True),('comparison-normal-01',54,0,True),('comparison-pm-fs-01',54,0,True)]:
  prefix='attempts/'+label+'/';row=d(prefix+'receipt.json');assert row['counts']=={'tests':count,'failures':0,'errors':0,'skipped':0} and row['pytest_exit_code']==0 and row['warnings']==0 and row['cohort_unchanged'] and not row['forbidden_operations'] and row['scope']=='source; no new installed artifact'
  assert row['qualification_source']=='02228c3aa94a37c8d0219068ac77bef836dc2e2c' and row['source_origins']['dockingmt'].endswith('/dockingmt/dockingmt/__init__.py') and d(prefix+'cohort.json')==cohort
  counts=row['engine_call_counts'];assert counts.get('__init__',0)==counts.get('score',0)==run_count and not any(counts.get(n,0) for n in ['dock','optimize','randomize','poses','energies'])
  expected_calls={'convert':2,'get':6} if run_count else {};assert row['provider_call_counts']==expected_calls
  if run_count:
   calls=d(prefix+'engine-calls.json');assert calls==row['engine_calls'] and all(c['outcome']=='PASS' for c in calls)
   native_scores=[]
   for call in calls:
    params=call['parameters'];assert 'test_fresh_native_scoring_and_rescoring_produce_auditable_evidence' in call['test_node']
    if call['call']=='__init__':assert params['cpu']==1 and params['seed']==17 and params['sf_name'] in ['vina','vinardo']
    if call['call']=='compute_vina_maps':assert params['center']==[0.0]*3 and params['box_size']==[10.0]*3
    if call['call']=='score':assert params['unbound_energy'] is None and call['result_shape']==[8] and call['native_unit']=='kcal/mol';native_scores.append(call['native_components'])
    for role in ['receptor','partner']:
     if role not in call:continue
     info=call[role];raw=data[prefix+'inputs/backend/'+str(call['run'])+'/'+role+'.pdbqt'];assert len(raw)==info['bytes'] and hashlib.sha256(raw).hexdigest()==info['sha256']==refs['MINIMAL_REC_PDBQT' if role=='receptor' else 'MINIMAL_LIG_PDBQT']['sha256'];assert info['atom_records']==(4 if role=='receptor' else 2)
   exports=row['exports'];assert len(exports)==3 and [e['kind'] for e in exports]==['score','score','audit_pose']
   for e in exports:assert hashlib.sha256(data[prefix+e['file']]).hexdigest()==e['sha256']
   first,second,report=[d(prefix+e['file']) for e in exports];assert len(first['scores'])==8 and len(second['scores'])==16 and len(first['metadata']['scoring_history'])==1 and len(second['metadata']['scoring_history'])==2 and first['coordinates']==second['coordinates']
   assert list(first['scores'].values())==native_scores[0] and list(second['scores'].values())[8:]==native_scores[1]
   assert first['metadata']['scoring_history'][0]==second['metadata']['scoring_history'][0] and first['partner_state_id']==second['partner_state_id'] and first['receptor_state_id']==second['receptor_state_id']
   assert report['status']=='consistent' and report['scope']=='saved_pose_internal_consistency' and 'content_base64' not in __import__('json').dumps(report)
   if qualified_pair:
    events=d(prefix+'provider-events.json');assert events==row['provider_events'] and len(events)==8 and all(e['outcome']=='PASS' and 'test_fresh_native_scoring_and_rescoring_produce_auditable_evidence' in e['test_node'] for e in events)
    assert [e['call'] for e in events]==['convert','get','get','get']*2
    for e in events:
     if e['call']=='convert':assert e['input_sha256']==refs['MINIMAL_LIG_PDBQT']['sha256'] and e['parameters']=={'to_form':'molsysmt.MolSys','discard_torsion_tree':True}
     elif e['parameters'].get('coordinates'):assert e['coordinates']['unit']=='angstrom' and len(e['coordinates']['value'])==1 and len(e['coordinates']['value'][0])==2
     else:assert len(e['values'])==2
   maps=d(prefix+'native-maps.json');engine=d(prefix+'frozen-engine-receipt.json')['paths'];native='lib/python3.14/site-packages/vina/_vina_wrapper.cpython-314-x86_64-linux-gnu.so';assert [v for k,v in maps.items() if k.endswith('/'+native)]==[engine[native]]
  else:assert not row['exports'] and not row['engine_calls'] and not row['provider_events']
  total_scores+=run_count;measured[label]={'cases':count,'actual_native_scores':run_count,'main_qualified_pair':qualified_pair}
 assert total_scores==6
 for selection in ['audit','comparison']:
  normal=selection+'-normal-'+('02' if selection=='audit' else '01');other=selection+'-pm-fs-01';assert data['attempts/'+normal+'/frozen-worker.py']==data['attempts/'+other+'/frozen-worker.py'] and d('attempts/'+normal+'/frozen-qualification-inputs.json')==d('attempts/'+other+'/frozen-qualification-inputs.json')
 inputs=d('producer/qualification-inputs.json');assert len(inputs)==788
 for name,row in d('producer/fixture-identities.json').items():
  raw=data['producer/original-fixtures/'+name];assert hashlib.sha256(raw).hexdigest()==row['sha256']==inputs[name] and len(raw)==row['bytes']
 if 'producer/generated-version.py.txt' in data:assert hashlib.sha256(data['producer/generated-version.py.txt']).hexdigest()==inputs['dockingmt/_version.py']
 for name,raw in data.items():
  if name.endswith('/resource-outcome.json'):
   row=json.loads(raw);assert row['outcome']=='PASS' and row['resource_interruption'] is None and row['group_terminal'] and not row['remaining_live_owned_pids'] and row['minimum_available_bytes']>13*1024**3
 for name in qualified:assert (root/name).read_bytes()==data['qualified/'+name] and hashlib.sha256(data['qualified/'+name]).hexdigest()==inputs[name]
 receipt.update(primary_manifest_sha256=expected['manifest_sha256'],members=len(data),populations=measured,qualified_sources=8,actual_native_score_calls=6,initial_zero_call_expectation_received=False,source_origins_before_after_verified=True,full_scientific_public_platform_gate=False,source_context_accepted=False)
elif stage=='audit':
 import importlib.abc
 import tempfile
 import xml.etree.ElementTree as ET
 site=Path(json.loads((task/'installation.json').read_text())['site']);tools=json.loads((root/'.molsyssuite/record-wheel-inputs-20261109/reporting-tools-receipt.json').read_text())
 for name,digest in tools['files_sha256'].items():assert sha(site/name)==digest
 sys.path.insert(0,str(site));blocked=[]
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in ['dockingmt','molsysmt','molsysviewer','vina','rdkit','openmm']:blocked.append(fullname);raise AssertionError('Evidence audit imported scientific code')
 sys.meta_path.insert(0,Block())
 from pytest_receptor import read_artifact
 data=read(primary);crosschecked={}
 with tempfile.TemporaryDirectory(prefix='events-',dir=attempt) as tmp:
  for name,raw in data.items():
   if not name.endswith('/events.jsonl'):continue
   prefix=name.removesuffix('events.jsonl');counts={k:sum(int(n.get(k,'0')) for n in ET.fromstring(data[prefix+'junit.xml']).iter('testsuite')) for k in ['tests','failures','errors','skipped']};row=json.loads(data[prefix+'receipt.json']);path=Path(tmp)/'events.jsonl';path.write_bytes(raw);events=read_artifact(path);assert events.complete and row['counts']==counts and row['receptor_final']==events.final.data
   crosschecked[prefix]={'junit':counts,'receptor_outcome':events.final.data['outcome'],'native_pytest_exit':row['pytest_exit_code'],'qualification_outcome':json.loads(data[prefix+'resource-outcome.json'])['outcome']}
 assert len(crosschecked)==5 and not blocked
 receipt.update(crosschecked=crosschecked,scientific_imports=blocked,event_inputs_retired=not Path(tmp).exists())
elif stage=='reader-seal':
 paths=[(p,label+'/'+p.name) for label in ['reader-01','audit-01'] for p in sorted((task/label).iterdir()) if p.is_file()];receipt.update(seal(companion,paths));save(task/'reader-receipt.json',receipt)
else:raise AssertionError(stage)
save(attempt/'receipt.json',receipt);print(json.dumps(receipt)[:1600])
