"""Bounded client storage receiving with every native kernel forbidden."""
import functools
import numpy as np
import hashlib
import importlib.abc
import importlib.metadata as metadata
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import types
import xml.etree.ElementTree as ET

root=Path(os.environ['DMT_SMALL_ROOT']);task=Path(os.environ['DMT_SMALL_TASK']);attempt=Path(os.environ['DMT_SMALL_ATTEMPT'])
reg=json.loads((attempt/'registration.json').read_text())
def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
assert os.sched_getaffinity(0)=={0} and os.getpriority(os.PRIO_PROCESS,0)>=10
composition=json.loads((attempt/'frozen-composition.json').read_text());provider=Path(composition['provider_tree'])
artifact=json.loads((attempt/'frozen-artifact.json').read_text());installed=json.loads((attempt/'frozen-installation.json').read_text());site=Path(installed['site'])
assert Path(sys.prefix)==Path(installed['prefix'])
packet=task/'packet';manifest=json.loads((packet/'manifest.json').read_text());forbidden=[];calls=[];kernel_calls=[]
def verify():
 assert sha(artifact['wheel'])==artifact['wheel_sha256']
 for group in ['consumer_sha256','tool_sha256','unit_sha256']:
  for name,digest in installed[group].items():assert sha(site/name)==digest,name
 for name,digest in composition['python_source_files'].items():assert sha(provider/name)==digest,name
 assert sha(provider/'molsysmt/_rust.abi3.so')==composition['native_copy_sha256']
 assert subprocess.check_output(['git','-C',str(provider),'rev-parse','HEAD'],text=True).strip()==composition['provider_source']
 assert not subprocess.check_output(['git','-C',str(provider),'status','--porcelain'])
 for name,digest in composition['packet_files'].items():assert sha(packet/name)==digest,name
 for name,digest in json.loads((attempt/'frozen-qualification-inputs.json').read_text()).items():assert sha(root/name)==digest,name
def shared_cohort():
 expected=json.loads((attempt/'frozen-expected-cohort.json').read_text())
 for name,value in expected.items():
  source=root.parent/name
  assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==value['commit']
  assert subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)==value['status']
  for group in ['python_sha256','native_sha256']:
   for path,digest in value[group].items():assert sha(source/path)==digest
 return expected
verify();before=shared_cohort();save(attempt/'shared-cohort.json',before)
sdk=root/'.molsyssuite/publication-sdk';assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()=='95f693be10c9205ab9b912cb53453710a207bf45'
assert not subprocess.check_output(['git','-C',str(sdk),'status','--porcelain'])
sys.path[:0]=[str(provider),str(sdk)]
class BlockOptional(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='molsysmt._version' and not (provider/'molsysmt/_version.py').exists():
   raise ModuleNotFoundError('No package-local generated build stamp',name=fullname)
  if fullname.split('.')[0] in ['vina','rdkit','openmm','ackredit']:
   forbidden.append(fullname);raise AssertionError('P5 attempted forbidden optional import: '+fullname)
assert not {'vina','rdkit','openmm','ackredit','molsysmt'}.intersection(sys.modules)
sys.meta_path.insert(0,BlockOptional())
def reject(name):
 def call(*args,**kwargs):forbidden.append(name);raise AssertionError('P5 attempted unadmitted work: '+name)
 return call
native_path=provider/'molsysmt/_rust.abi3.so'
spec=importlib.util.spec_from_file_location('molsysmt._rust',native_path);native=importlib.util.module_from_spec(spec);sys.modules[spec.name]=native;spec.loader.exec_module(native)
native_names=[name for name in dir(native) if not name.startswith('_') and callable(getattr(native,name))]
assert 'neighbor_list_csr_multi' in native_names
topology_operation=native.get_component_index_from_bonded_atom_pairs
for name in native_names:setattr(native,name,reject('molsysmt._rust.'+name))
def topology_observed(bonded_atom_pairs,n_atoms):
 assert reg['selection']=='whole' and 'test_unknown_report_transports_but_refuses_use' in os.environ.get('PYTEST_CURRENT_TEST','')
 assert n_atoms==1 and bonded_atom_pairs.shape==(0,2) and bonded_atom_pairs.dtype==np.dtype('int64') and len(kernel_calls)<2
 event={'call':'get_component_index_from_bonded_atom_pairs','test_node':os.environ.get('PYTEST_CURRENT_TEST'),'n_atoms':n_atoms,'pairs':bonded_atom_pairs.tolist(),'pairs_shape':list(bonded_atom_pairs.shape),'pairs_dtype':str(bonded_atom_pairs.dtype),'outcome':'started'};kernel_calls.append(event)
 result=topology_operation(bonded_atom_pairs,n_atoms)
 assert result.tolist()==[0];event.update(outcome='PASS',result=result.tolist(),result_dtype=str(result.dtype));save(attempt/'native-calls.json',kernel_calls)
 return result
native.get_component_index_from_bonded_atom_pairs=topology_observed

import pyunitwizard as puw
units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if reg['profile']=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
with puw.context(default_form='pint',default_parser='pint',standard_units=units):
 caller=puw.configure.report()
 import molsysmt as msm
 assert Path(msm.__file__).resolve()==provider/'molsysmt/__init__.py'
 assert sys.modules['molsysmt._rust'] is native and sha(native.__file__)==composition['native_copy_sha256']
 import dockingmt as dmt
 import molsysviewer as msv
 import molsysviewer_dockingmt as addon
 assert dmt.__version__==artifact['version']==metadata.version('dockingmt')
 assert json.loads(metadata.distribution('dockingmt').read_text('direct_url.json'))['archive_info']['hashes']['sha256']==artifact['wheel_sha256']
 for name in ['molsysviewer','argdigest','pyunitwizard','smonitor','depdigest']:assert Path(__import__(name).__file__).resolve().is_relative_to(root.parent/name/name)
 from devtools.scripts.installed_imports import check_installed_imports
 origins_before=check_installed_imports(('dockingmt','molsysviewer_dockingmt'),Path(sys.prefix),Path(installed['harness']))
 for name in ['assign_partial_charges','assign_autodock_atom_types','add_missing_hydrogens','merge_nonpolar_hydrogens']:setattr(msm.build,name,reject('molsysmt.build.'+name))
 msm.chemical_states.normalize_indexed_hydrogen_policy=reject('molsysmt.chemical_states.normalize_indexed_hydrogen_policy')
 msv.MolSysView=reject('molsysviewer.MolSysView')
 # Observe actual public IO without replacing returned values or exceptions.
 for name in ['read','write']:
  operation=getattr(msm.h5msm,name)
  def observed(*args,__name=name,__operation=operation,**kwargs):
   event={'operation':'h5msm.'+__name,'test':os.environ.get('PYTEST_CURRENT_TEST'),'kwargs':{k:str(v) for k,v in kwargs.items()},'outcome':'started'};calls.append(event)
   try:value=__operation(*args,**kwargs)
   except BaseException as exc:event.update(outcome='raised',error_type=type(exc).__name__);raise
   else:event['outcome']='PASS';return value
   finally:save(attempt/'public-io.json',calls)
  setattr(msm.h5msm,name,functools.wraps(operation)(observed))
 oracle=types.ModuleType('dmt_test_support.h5msm_p5_oracle');oracle.__file__=str(attempt/'frozen-oracle.py');exec(compile((attempt/'frozen-oracle.py').read_text(),oracle.__file__,'exec'),oracle.__dict__)
 context=types.ModuleType('p5_case_context');context.msm=msm;context.puw=puw;context.oracle=oracle;context.packet=packet;context.output=attempt/'outputs';context.output.mkdir();context.save=save;context.sha=sha
 sys.modules['p5_case_context']=context
 casefile=attempt/'test_p5_client.py';shutil.copyfile(attempt/'frozen-client_cases.py',casefile)
 import pytest
 nodes=[]
 class Collect:
  @pytest.hookimpl(trylast=True)
  def pytest_collection_finish(self,session):
   nodes.extend(item.nodeid for item in session.items);save(attempt/'collection.json',nodes)
   assert len(nodes)==(1 if reg['selection']=='admit' else 7)
 args=['--receptor=llm','--receptor-events='+str(attempt/'events.jsonl'),'--junitxml='+str(attempt/'junit.xml'),'--import-mode=importlib','-o','pythonpath=','-o','cache_dir='+str(attempt/'pytest-cache'),'--basetemp='+str(attempt/'pytest-work'),str(casefile)+('::test_packet_readback[complete]' if reg['selection']=='admit' else '')]
 status=int(pytest.main(args,plugins=[Collect()]))
 after_policy=puw.configure.report()
 for key in ['default_form','default_parser','standard_units']:assert after_policy[key]==caller[key]
 origins_after=check_installed_imports(('dockingmt','molsysviewer_dockingmt'),Path(sys.prefix),Path(installed['harness']))
counts={k:sum(int(n.get(k,'0')) for n in ET.parse(attempt/'junit.xml').getroot().iter('testsuite')) for k in ['tests','failures','errors','skipped']}
from pytest_receptor import read_artifact
events=read_artifact(attempt/'events.jsonl');assert events.complete
verify();assert shared_cohort()==before
assert not {'vina','rdkit','openmm','ackredit'}.intersection(sys.modules)
modules={name:str(Path(module.__file__).resolve()) for name,module in sys.modules.items() if name.split('.')[0] in ['molsysmt','dockingmt','molsysviewer_dockingmt'] and getattr(module,'__file__',None)}
save(attempt/'import-origins.json',modules)
allowed_aliases={'molsysmt.pyunitwizard':'pyunitwizard'}
for name,path in modules.items():
 if name in allowed_aliases:
  owner=allowed_aliases[name];assert sys.modules[name] is sys.modules[owner] and Path(path).is_relative_to(root.parent/owner/owner)
 elif name.startswith('molsysmt.'):
  assert Path(path).is_relative_to(provider/'molsysmt'),(name,path)

save(attempt/'receipt.json',{'profile':reg['profile'],'selection':reg['selection'],'pytest_exit_code':status,'counts':counts,'receptor_final':events.final.data,'warnings':events.final.data['counts']['warnings'],'nodes':nodes,'consumer_version':dmt.__version__,'wheel_sha256':artifact['wheel_sha256'],'provider_source':composition['provider_source'],'provider_version':msm.__version__,'provider_distribution_label':metadata.version('molsysmt'),'native_sha256':sha(native.__file__),'native_kernels_guarded':native_names,'native_kernel_calls':len(kernel_calls),'native_calls':kernel_calls,'forbidden_operations':forbidden,'optional_imports':[],'public_io':calls,'installed_origins_before':origins_before,'installed_origins_after':origins_after,'caller_policy_before':caller,'caller_policy_after':after_policy,'shared_sources_unchanged':True,'packet_files':composition['packet_files'],'full_stable_public_installed_platform_gate':False})
native_maps={}
for line in Path('/proc/self/maps').read_text().splitlines():
 fields=line.split(None,5)
 if len(fields)==6 and fields[5].endswith('/_rust.abi3.so'):native_maps[fields[5]]=sha(fields[5])
save(attempt/'native-maps.json',native_maps)
assert native_maps=={str(native_path):composition['native_copy_sha256']} and not forbidden
assert len(kernel_calls)==(0 if reg['selection']=='admit' else 2)
raise SystemExit(status)
