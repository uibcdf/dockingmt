# Finite H5MSM P5 client receiving — 2026-11-10

Owners: [MolSysMT #256](https://github.com/uibcdf/molsysmt/issues/256),
[DockingMT #73](https://github.com/uibcdf/dockingmt/issues/73); #50 custody.
Status: registered before execution; composition admission and results pending.
Consumer documentation base `e90c0446b7d3cb89cdf3285516f23db1e058d801`;
actual private consumer wheel/runtime producer remains `37a61e6`, version
`0.0.0+359.g37a61e6`. The [scope review](h5msm_p5_client_scope_2026-11-10.md)
and accepted publication 9b077fab/#79/#88/#96 retain their original scope.

## Exact source and native admission

Bounded shared suite-status refresh preserves every worktree: DockingMT's human
migration directory, clean MolSysMT 0c6f9c7 (87 behind), clean Viewer 1187fc18
(75 behind), and unchanged current ArgDigest/PyUnitWizard/SMonitor/DepDigest.
Preserve the actual old shared environment and earlier frozen installed receipts.

Create an independent clean tracked MolSysMT clone at exact provider product
`5e7d65a665425fe6077f016dd95cbd65d424ee91`. Across its Rust/Cargo inputs, only
`rust/src/neighbors.rs` differs from received 0c6f9c7; the exported neighbor
function adds a memory-budget argument and changes allocation semantics. Do not
claim its compatibility or execute it with the old binary. Other Rust sources,
Cargo declarations and runtime dependency declarations remain unchanged; the
pyproject additions affect optional documentation/development requirements only.

Reuse an exact byte copy of qualified `_rust.abi3.so`, SHA-256
`5715bda28be19820e96c2b81e4734bf75e1a9f05dd660d9c7e2817bc6bcd79d3`, inside the
isolated source package. Load and guard all exposed callable kernels before
provider import; every attempted kernel call must stop this finite profile.
Admission first reads the existing complete fixture without any native kernel
execution. The existing public translation implementation uses NumPy/get/set;
no Rust geometry calculation is admitted either. This is an explicitly bounded
Python-storage composition, separate from the provider's 4ffb82e4 binary and
156-case receiving; it is not general qualification of the newer source/old binary.
No source overlay or binary replacement is applied to shared checkouts.

Use the already installed private consumer receiver, with explicit isolated
provider origin and ordinary untouched development sources for the five other
siblings. Retain all source/native/file/import identities and actual distribution
labels separately. Clear inherited PYTHONPATH/PYTHONHOME and keep runtime source
out of the consumer's imports. No reinstall or native compilation is performed.

## Fixed packet and observation scope

Acquire the exact eleven files from provider commit
`1ce072ae7d8489831ad28d222b60a3c29616e0c6`, under
`devtools/data/h5msm_p5_review_20261110`. Authenticate every manifest size/SHA-256.
The three H5MSM files are synthetic complete/projected/nonpolar-H-merged storage
controls, each at experimental 0.6, no more than six atoms/three structures.
The packet's explicit typed snapshots and original PDBQT `[2, 0, 2]` exports
remain the original producer oracles. Preserve all raw strings, units, dtypes,
reports, histories and producer fields; supplemental assignments are not a
validated production force field or a new preparation.

Reuse the frozen provider's `_plain`, `_snapshot` and `_hdf_snapshot` observation
functions for exact oracle comparison, recording that they are provider oracles,
not an independent codec/calculation. Remove only the local cross-test import
so the frozen functions share a task-local `dmt_test_support` observation module.
They never restore objects. Complement their snapshots with independent direct
atom/structure/coordinate/charge/name/state/map/coverage assertions. No runtime,
helper declaration or existing test/scientific input changes are required.
These are finite external-packet client cells, separate from the repository's
declared complete installed pytest selection and its historical 606 support rows.

## Admission and seven original client cases

First run one complete-fixture admission case: public `h5msm.read` and `convert`,
exact typed oracle and original three PDBQT exports, source protection and no
kernel/optional-engine call. If admission passes, run identical seven-case
selections normal then pm/fs in separate fresh processes:

1. Three packet readbacks, each through both public reader routes, complete typed
   snapshot equality and original `[2, 0, 2]` PDBQT parity. Keep file hashes exact.
2. Complete fixture explicit reversed atom permutation using `permute_atoms`
   with its returned correspondence report, then structures `[2, 0]` using public
   extraction. Independently check axes, coordinates, charges, names/state
   associations and named-analysis maps/coverage. Write/read an explicit 0.6 copy
   elsewhere; require the transformed complete snapshot to survive.
3. Fresh restored complete fixture, translate structure 2 by an explicit 1 nm
   vector through the public setter route. Preserve structures 0/1, topology,
   chemistry/history/mechanics and other geometry-independent data; require only
   affected named-analysis coverage/occurrences to invalidate. Persist/read the
   edited 0.6 copy and check exact snapshot fidelity without rerunning a detector.
4. Two adverse cases, charge and atom-type assignment separately: detached full
   copy, change only the report schema to the same base plus `@999`, explicit
   0.6 write/read, original report equality and full-copy transport. Require both
   atom projection and PDBQT export to raise StructuralInconsistencyError for
   report/schema admission before returning output; preserve both original valid
   input and controlled adverse file hashes. Do not reinterpret or repair it.

Require complete JUnit/Receptor/native pytest exit records and unchanged caller
unit policy. Keep failed admissions/attempts and their inputs. The first admission
overlaps the whole selection; counts are software/integration coverage, not new
scientific observations. Vina/RDKit/OpenMM/Ackredit imports, new assignments,
H-policy preparation, detectors and Viewer construction are forbidden. No search,
minimization, simulation, browser/kernel or old E3 calculation is run.

## Resources and closing boundary

Initial RAM 64,978,440,192 B physical/58,855,858,176 B available, 20 logical CPUs,
load 2.28/3.07/2.85, about 90.2% interval idle, zero sampled swap I/O/memory PSI
averages and 38,841,524,224 B free disk. Slurm exists without an allocation; prior
applicability was inconclusive. Free capacity is not reserved.

Run each cell serially on CPU 0/nice 10, one native/build worker, including owned
heavy descendants. Estimate 512 MiB group RSS; hard group cap 1 GiB/address space
2 GiB, CPU 60/65 seconds, wall 180 seconds and 13 GiB available-RAM reserve.
Administrative readers use 45 CPU/60 wall seconds. Monitor owned groups; preserve
interruptions and never automatically restart after headroom interruption.
Keep `.molsyssuite/h5msm-p5-client-20261110`, original packet/isolated source and
receipts under #73/#256/#50, review 2026-11-14. Preserve old shared environments,
native/build holds, historical records and the human migration backup.

Seal original packet, scripts/oracles, actual observations and refusals; verify
stored records independently without molecular/test replay. Update maintained
checkpoints and applicable local/fresh committed-export gates before direct
`[skip ci]` publication. Report genuine provider limitations in their owner.
These cells cannot close stable H5MSM 1.0/default/migration, full/public/platform,
interactive or broader #30/#47/#73 gates. No remote CI or package publication.


## Admission observer correction

Admission-01 executes its complete-fixture test successfully (one pass, no
pytest failures/errors/skips/warnings), then the qualification driver fails its
post-test all-MolSysMT-name origin assertion. Preserve actual process exit 1,
JUnit/events, typed outputs, exact program and missing later receipt/origin
serialization. A passing pytest test is not a passing admission.

The provider deliberately exposes `molsysmt.pyunitwizard` as the actual shared
PyUnitWizard module. For admission-02, serialize the complete observed module
paths before validating them, accept only that declared alias when object identity
and the exact shared provider path agree, and require every other MolSysMT module
to originate in the isolated package. Do not exempt arbitrary foreign paths or
reconstruct the lost first-attempt map. Keep every molecular assertion and hard
resource/native prohibition unchanged. This is an observer correction, not a
provider fix, new native build or resource/headroom restart.


Admission-02 also passes its actual complete-fixture test, then fails qualification.
Its newly retained map locates the foreign module as `molsysmt._version` from the
old editable checkout. The earlier alias explanation was provisional and does
not identify this observed path. The provider's bootstrap already rejects the
foreign stamp and returns `0+unknown`; scientific implementation modules are
not shown to be foreign by this particular failure. Preserve both failures and
the second actual map rather than replacing their verdicts with pytest PASS.

For admission-03, the import guard enforces the isolated package's actual absence
of its Git-ignored `_version.py`: raise ModuleNotFoundError for that exact absent
module before the old editable finder can supply an unrelated stamp. The owning
bootstrap retains its normal unknown-version fallback. No stamp is fabricated,
no build label or source is rewritten, and all other MolSysMT origins remain
strict. Keep the same public molecular assertions/native prohibition. Use a
native pandas typed-frame comparison for mechanical columns rather than NumPy
object-array comparison; no acceptance value, dtype or correspondence changes.


## Whole-01 native-boundary observation and prospective amendment

Whole-normal-01 retains five pytest passes/two failures. Both adverse projection
cases reach `get_component_index_from_bonded_atom_pairs` before report refusal;
the registered blanket native prohibition correctly stops them. The complete
qualification remains FAIL, actual process exit 1, and pm/fs is unattempted for
this first population. No actual blocked kernel runs and no resource interruption
occurs. This is a previously unadmitted graph operation, not evidence that the
provider accepts an unknown report or that a scientific preparation ran.

Register whole-02 normal then pm/fs with exactly one native allowance. The
existing `rust/src/topology.rs` bytes are identical between old 0c6f9c7 and exact
5e7d65a6. Permit its original real connected-component binding only inside the two
adverse test nodes, with n_atoms=1, int64 pairs shape (0,2), at most two calls per
whole profile and exact real output [0]. Record arguments, result, node and actual
loaded binary mapping. No fabricated return, changed neighbor routine, additional
atom/structure/interaction calculation or build is admitted. All other native
callables remain forbidden. This supersedes the original zero-kernel expectation
only for that explicit one-atom bookkeeping; the earlier failure stays intact.

Strengthen direct client assertions before this new whole population: every
chemical state's public bond table must retain dtypes and the independently
inverse-remapped edge/order set; the complete post-edit analysis must equal the
original public query restricted to unaffected structure 0. The original
seven cases, input oracles, physical values, maps and refusal requirements remain.
Main registration identifies the exact private frozen program hashes and context
rather than attributing new client scripts to consumer runtime source 37a61e6;
earlier admission metadata retains its inherited field and frozen hashes.


Whole-normal-02 retains five passes/two failures and actual driver exit 1: its
observer reaches the admitted topology binding but cannot serialize NumPy int64
`n_atoms` into JSON. The callback exception prevents the projection from reaching
its own refusal, and the final receipt also fails serialization. Its complete
native call record/count and final loaded-map receipt are unavailable; preserve
that absence and do not infer a passing native admission from the expected code.
No semantic provider failure or resource interruption is established.

For whole-03, serialize only that observer scalar as a builtin integer with its
actual type name retained, and save the bounded started event before delegation.
All native arguments are passed unchanged to the original real function. Every
molecular assertion, source input, guard bound, expected refusal and seven-case
selection stays exact. Require full whole-03 normal then pm/fs and complete
actual native events/maps. This corrects event serialization without changing a
scientific input, source, backend, physical value or acceptance criterion.
