"""Finite client assertions on the exact public provider packet."""
from copy import deepcopy
import json
import numpy as np
import pandas as pd
import pytest
from p5_case_context import msm, puw, oracle, packet, output, save, sha

def snapshot(source):
    return oracle._hdf_snapshot(source)

def observe(name, source):
    data=snapshot(source);save(output/(name+'.json'),data);return data

def load(scope='complete'):
    source=msm.h5msm.read(packet/(scope+'.h5msm'))
    assert 0<source.get_n_atoms()<=6 and source.structures.n_structures==3
    return source

def xyz(source):
    return np.asarray(puw.get_value(source.structures.coordinates,to_unit='nm'))

def assert_source_hash(scope, original):
    assert sha(packet/(scope+'.h5msm'))==original

@pytest.mark.parametrize('scope',['complete','projected','merged'])
def test_packet_readback(scope):
    original=sha(packet/(scope+'.h5msm'));source=load(scope)
    expected=json.loads((packet/(scope+'-expected.json')).read_text())
    actual=observe(scope+'-read',source);assert actual==expected
    converted=msm.convert(packet/(scope+'.h5msm'))
    assert observe(scope+'-convert',converted)==expected
    texts=[msm.convert(source,to_form='string:pdbqt_text',typing_scheme='autodock4',structure_indices=[i]) for i in [2,0,2]]
    assert texts==json.loads((packet/(scope+'-pdbqt.json')).read_text())
    save(output/(scope+'-exports.json'),texts)
    assert snapshot(source)==actual
    assert_source_hash(scope,original)

def test_explicit_atom_and_structure_order_roundtrip():
    original=sha(packet/'complete.h5msm');source=load();baseline=observe('axis-source',source)
    order=np.arange(source.get_n_atoms()-1,-1,-1);inverse=np.argsort(order)
    transformed=msm.permute_atoms(source,atom_indices=order,return_report=True)
    permuted=transformed['molecular_system'];report=transformed['report']
    np.testing.assert_array_equal(report['output_to_source_atom_indices'],order)
    np.testing.assert_array_equal(report['source_to_output_atom_indices'],inverse)
    selected=msm.extract(permuted,structure_indices=[2,0])
    np.testing.assert_array_equal(xyz(selected),xyz(source)[[2,0]][:,order,:])
    np.testing.assert_array_equal(selected.topology.atoms['atom_name'].to_numpy(),source.topology.atoms['atom_name'].to_numpy()[order])
    np.testing.assert_array_equal(selected.molecular_mechanics.partial_charge,source.molecular_mechanics.partial_charge[order])
    assert selected.molecular_mechanics.atoms_ff.dtypes.equals(source.molecular_mechanics.atoms_ff.dtypes)
    pd.testing.assert_frame_equal(selected.molecular_mechanics.atoms_ff,source.molecular_mechanics.atoms_ff.iloc[order].reset_index(drop=True))
    assert selected.chemical_states.n_chemical_states==source.chemical_states.n_chemical_states
    assert selected.chemical_states.reference_chemical_state_index==source.chemical_states.reference_chemical_state_index
    np.testing.assert_array_equal(selected.get(structure_chemical_state_index=True),np.asarray(source.get(structure_chemical_state_index=True))[[2,0]])
    original_analysis=source.interactions['synthetic'];analysis=selected.interactions['synthetic']
    assert set(selected.interactions)==set(source.interactions)
    np.testing.assert_array_equal(analysis.atom_source_indices,original_analysis.atom_source_indices[order])
    np.testing.assert_array_equal(analysis.structure_source_indices,original_analysis.structure_source_indices[[2,0]])
    np.testing.assert_array_equal(analysis.evaluated_structure_indices,[0,1])
    np.testing.assert_array_equal(analysis.participant_atoms,inverse[original_analysis.participant_atoms])
    assert analysis.to_dict()['software']==original_analysis.to_dict()['software']
    assert analysis.measure_units==original_analysis.measure_units and analysis.source_id==original_analysis.source_id
    before=observe('axis-transformed',selected)
    save(output/'axis-map.json',oracle._plain(report))
    destination=output/'reordered.h5msm';msm.h5msm.write(selected,destination,format_version='0.6')
    restored=msm.h5msm.read(destination);assert observe('axis-restored',restored)==before
    assert snapshot(source)==baseline
    assert_source_hash('complete',original)

def test_restored_coordinate_edit_invalidates_only_covered_structure():
    original=sha(packet/'complete.h5msm');source=load();before=observe('edit-source',source);coordinates=xyz(source).copy()
    analysis=source.interactions['synthetic'];analysis_before=oracle._plain(analysis.to_dict())
    np.testing.assert_array_equal(analysis.evaluated_structure_indices,[0,2])
    old_units=deepcopy(analysis.measure_units);old_software=deepcopy(analysis.software);old_source=analysis.source_id
    msm.structure.translate(source,translation=puw.quantity([1.,0.,0.],'nm'),structure_indices=[2],in_place=True)
    np.testing.assert_array_equal(xyz(source)[:2],coordinates[:2])
    np.testing.assert_allclose(xyz(source)[2],coordinates[2]+[1.,0.,0.],rtol=0,atol=1e-15)
    after=observe('edit-changed',source)
    for key in ['topology','chemical_states','state_associations','mechanics','mechanical_columns','charge_assignment','type_assignment','history']:assert after[key]==before[key],key
    changed=source.interactions['synthetic'];np.testing.assert_array_equal(changed.evaluated_structure_indices,[0]);assert changed.n_interactions==0
    assert changed.measure_units==old_units and changed.software==old_software and changed.source_id==old_source
    assert set(source.interactions)==set(before['interactions'])
    save(output/'edit-analysis-before.json',analysis_before);save(output/'edit-analysis-after.json',oracle._plain(changed.to_dict()))
    destination=output/'edited.h5msm';msm.h5msm.write(source,destination,format_version='0.6')
    restored=msm.h5msm.read(destination);assert observe('edit-restored',restored)==after
    assert_source_hash('complete',original)

@pytest.mark.parametrize('field',['partial_charge_assignment','atom_type_assignment'])
def test_unknown_report_transports_but_refuses_use(field):
    original=sha(packet/'complete.h5msm');source=load();baseline=snapshot(source)
    controlled=msm.copy(source);report=deepcopy(getattr(controlled.molecular_mechanics,field));report['schema']=report['schema'].split('@')[0]+'@999'
    setattr(controlled.molecular_mechanics,field,report)
    destination=output/(field+'-unknown.h5msm');msm.h5msm.write(controlled,destination,format_version='0.6');unknown_hash=sha(destination)
    restored=msm.h5msm.read(destination)
    assert oracle._plain(getattr(restored.molecular_mechanics,field))==oracle._plain(report)
    copied=msm.copy(restored);assert oracle._plain(getattr(copied.molecular_mechanics,field))==oracle._plain(report)
    observe(field+'-transported',restored)
    dispositions=[]
    for operation in ['project','export']:
        try:
            if operation=='project':msm.extract(restored,selection=[1])
            else:msm.convert(restored,to_form='string:pdbqt_text',typing_scheme='autodock4',structure_indices=[0])
        except Exception as error:
            assert type(error).__name__=='StructuralInconsistencyError'
            assert 'report' in str(error).lower() or 'schema' in str(error).lower()
            dispositions.append({'operation':operation,'error_type':type(error).__name__,'error_module':type(error).__module__,'message':str(error),'output_returned':False})
        else:pytest.fail('Unknown assignment unexpectedly admitted '+operation)
        assert sha(destination)==unknown_hash
        assert oracle._plain(getattr(restored.molecular_mechanics,field))==oracle._plain(report)
    save(output/(field+'-refusals.json'),{'original_file_sha256':original,'unknown_file_sha256':unknown_hash,'report':oracle._plain(report),'refusals':dispositions})
    assert snapshot(source)==baseline
    assert_source_hash('complete',original)
