# Installed pose interaction binding — registered 2026-11-07

Owner: [DockingMT #80](../pending_proposals/receive_docking_interaction_analysis.md).
Status before execution: **prospective; no installed result is claimed**.
This receives the [new public binding](pose_interaction_binding.md) at source
`cfff3866d511e7f1d202e3e03dd8c54a38963dc2`, separately from its 190 source controls
and the earlier `a7422df` saved-carrier consumer. Whole E4, addon/canvas, public
delivery, independent science and full #73 remain unproven.

## Candidate and composition

Create one task-owned detached worktree at that exact commit. Build its pure
Python wheel using routine Python 3.14 and native `pip wheel --no-index --no-deps
--no-build-isolation`, retaining the actual VCS-derived version, source tree,
builder versions, raw logs, wheel metadata/RECORD and SHA-256. Install that exact
wheel into a new private prefix with `--no-index --no-deps --no-compile`; no shared
Conda/pip prefix, dependency solve or public package route changes.

Transport the 3867-file existing private payload through its exact installation
receipt, excluding its 73 historical DockingMT/addon/distribution files. Preserve
the remaining 3794 provider files byte-for-byte in a new task prefix. The source
receipt is anchored to the frozen original saved-carrier archive. Borrowed
MolSysMT remains `9e1f1b1ad8bf09446374ab6f04ca7208e2717936`; auxiliary providers
retain their real identities. Reuse the 641-file Viewer overlay from `78ede79e`
only for the existing import composition; no View is created or addon received.
Verify every source/transport/installed byte and loaded Python/native origin.
Routine host libraries and Conda metadata keep their separate authority; this
does not certify complete public/environment closure.

The candidate step and each scientific profile run serially with CPU0 affinity,
nice10, one native/build worker, 1 GiB owned-group RSS, 2 GiB address space,
45 CPU seconds/60 wall seconds and an 8 GiB available-RAM reserve. Start only
with reserve plus allowance available, monitor the entire owned group, and
retire surviving descendants. Preserve preflight/process/semantic failures and
resource interruptions separately; no automatic restart after a headroom stop.
Retain task resources under #50, review 2026-11-14. Shared guard support remains
MolSysSuite #173; reuse the already controlled guard functions by exact hash.

## Fixed population and scientific boundaries

Receive **normal first, then pm/fs in a fresh process**. Freeze the scripts,
candidate/composition manifests, SDK revision and files, original compressed/
decoded inputs, operation caps and command before each profile. The pm/fs
selection requires a complete passing normal receipt with identical executable
sources and actual composition. Use isolated Python `-B -I -S`; activate the
caller unit policy before importing DockingMT/MolSysMT and preserve/restore it.

Original producer `5952053`, its [success receipt](data/interaction_hosted_success_2026-11-06.json),
the five-pose result and each profile's original `association.json`,
`retained_pose.h5msm` and `translated_geometry_control.h5msm` remain unchanged.
The original carrier has 3238 atoms/one structure, receptor_h3220 plus ligand18.
The recorded thirteen original pose atoms map to 3220–3232. Preserve keys, state
IDs, original rank/scores, full analysis payloads and exact source identities.
Four other original poses remain unevaluated.

Two accepted bindings are prescribed per profile:

1. Use `dmt.bind_interactions` on original collection position 1 and its retained
   carrier. Its complete result still contains five original poses.
2. Use `dmt.PoseInteractions` on a **separate derived control record** whose
   coordinates come directly from the translated saved carrier through public
   MolSysMT getters and the existing declared map. Give it an explicit control
   ID, no original scores/rank/history, and derivation provenance. It is not an
   original docking pose or additional independent case. Its two original
   analyses are evaluated-empty (0/0); the retained carrier keeps 3/2.

No chemical state, molecular equivalence, receptor geometry outside the mapped
pose or producer authenticity is inferred from declarations. No H generation,
preparation, charge/type assignment, detector, alignment, RMSD, energy or native
search is admitted. Queries, reads, copies, extraction and persistence **are
molecular consumer operations** and are counted.

## Receiving and adverse controls

For each accepted binding, receive detached complete result/pose/association,
all named full analysis copies, public `between_selections` filtering and pages,
mutable metadata detachment and complete carrier copy/nonmutation. Persist with
public `msm.h5msm.write` (0.5), then reread with `msm.h5msm.read`. Compare full
topology, chemical states, coordinates, box/time/structure associations, original
analysis payloads and molecular-mechanics absence before/after. The preserved
original mechanical fields are all absent; do not remove data to force codec
acceptance. Nonempty-mechanics profiles retain the provider's codec limits.
Diagnostic JSON is never used as a molecular restoration codec.

Prescribe twelve refused binding attempts: missing common-frame declaration;
wrong partner state; wrong receptor state; missing verified pose atom map;
out-of-bounds map; duplicate map; noninteger map; reversed/wrong identities;
translated carrier associated with the original pose; two-frame carrier; missing
named analyses; another original pose associated with the retained carrier.
Also refuse an unknown analysis name and a query assigned as a full carrier
analysis. The latter is a separate provider admission refusal. No rejected
association changes the input/result/carrier or becomes evaluated-empty.
The two-frame adverse carrier is one public extraction of repeated existing
frame 0; it is not accepted as a replicated original-pose analysis.

Freeze finite caps before launch: fourteen explicit binding attempts, two result
accessors, two pose accessors, nine analysis accessors, four carrier accessors,
four queries/pages/inspection exports, eight complete native snapshots, one
adverse extraction and one accepted empty-analysis-store control. Provider API
entry counters (including calls inside the new binding/nested aliases) are
bounded by convert 96, copy 32, get 512, has_attribute 128, extract 1,
H5MSM read 4/write 2, Interactions.copy 128 and remap 8; typed exports cap 96.
All other scientific operation budgets above are zero. Wrapper counts and
explicit receiver counts keep their different scopes. Record actual counters,
every refusal and final completion; exit zero alone is insufficient.

After both profiles, seal original source/code/records and preserved failures
without rewriting their producers. A separate bounded standard-library reader
must verify every sealed stored/decoded hash, completion/cap/refusal evidence,
declared units/numeric witnesses and original versus derived-control identities.
It performs no molecular parsing/restoration, metrics or new calculations.
Source controls, installed receiving, saved-record verification, addon/scene
admission, real comm/canvas and public/platform gates remain separate outcomes.
