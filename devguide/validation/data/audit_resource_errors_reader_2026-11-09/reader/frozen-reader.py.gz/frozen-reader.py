"""Receive frozen pytest/native/AST evidence without importing molecular code."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

_tool_receipt = Path(__file__).resolve().parents[1] / 'reporting-tools-receipt.json'
assert hashlib.sha256(_tool_receipt.read_bytes()).hexdigest() == '6deb72abe10fbc706aa57052c98a07c58d7b716d8a7678fe8d27796773fb25f1'
_tool = json.loads(_tool_receipt.read_text())
_prefix = Path(_tool['prefix'])
assert {str(p.relative_to(_prefix)): hashlib.sha256(p.read_bytes()).hexdigest() for p in _prefix.rglob('*') if p.is_file()} == _tool['files_sha256']
sys.path.insert(0, str(_prefix))
from pytest_receptor import read_artifact


def verify_records(records):
    def obj(name):
        return json.loads(records[name])
    expected = {'red-normal': (1, 60, 15, 0), 'green-normal': (0, 464, 0, 1), 'green-pm_fs': (0, 464, 0, 1)}
    for label, (code, total, failed, deselected) in expected.items():
        prefix = 'attempts/' + label + '/'
        r = obj(prefix + 'receipt.json')
        reg = obj(prefix + 'registration.json')
        resource = obj(prefix + 'resource-outcome.json')
        assert r['pytest_exit_code'] == resource['exit_code'] == code
        assert r['counts'] == {'tests': total, 'failures': failed, 'errors': 0, 'skipped': 0}
        assert r['outcome'] == resource['outcome'] == ('PASS' if code == 0 else 'FAIL')
        assert r['qualification_complete'] and resource['group_terminal'] and resource['resource_interruption'] is None
        assert not resource['remaining_live_owned_pids'] and not r['molecular_calls_attempted'] and r['native_searches'] == 0
        assert resource['policy'] == reg['policy'] and reg['policy']['cpu'] == 0 and reg['policy']['nice'] == 10 and reg['policy']['workers'] == 1
        assert resource['minimum_available_bytes'] >= 13 * 1024**3 and resource['sampled_peak_group_rss_bytes'] < 1024**3 and resource['elapsed_seconds'] <= 60
        assert r['versions']['pytest-receptor'] == '1.2.2'
        for name in ['default_form', 'default_parser', 'standard_units']:
            assert r['caller_policy_before'][name] == r['caller_policy_after'][name]
        assert r['caller_policy_before']['standard_units'][:2] == (['pm', 'fs'] if r['profile'] == 'pm_fs' else ['nm', 'ps'])
        for name, digest in reg['inputs_sha256'].items():
            assert hashlib.sha256(records[prefix + 'frozen-' + name.replace('/', '__')]).hexdigest() == digest
        for name, digest in reg['frozen_sha256'].items():
            assert hashlib.sha256(records[prefix + name]).hexdigest() == digest
        xml = ET.fromstring(records[prefix + 'junit.xml'])
        native = {key: sum(int(row.get(key, '0')) for row in xml.iter('testsuite')) for key in ['tests', 'failures', 'errors', 'skipped']}
        assert native == r['counts']
        rows = list(xml.iter('testcase'))
        assert len(rows) == total
        if label == 'red-normal':
            bad = [row for row in rows if row.find('failure') is not None]
            assert len(bad) == 15 and all('MemoryError' in row.get('name') for row in bad)
            assert all(row.find('failure').get('message') == 'Failed: DID NOT RAISE MemoryError' for row in bad)
        else:
            assert not any('test_fresh_native_scoring_and_rescoring_produce_auditable_evidence' in row.get('name') for row in rows)
            assert reg['selection'][-2:] == ['-k', 'not test_fresh_native_scoring_and_rescoring_produce_auditable_evidence']
        with tempfile.TemporaryDirectory(prefix='dmt-audit-memory-reader-', dir='/tmp') as tmp:
            path = Path(tmp) / 'events.jsonl'
            path.write_bytes(records[prefix + 'events.jsonl'])
            artifact = read_artifact(path)
            assert artifact.complete and artifact.final.data == r['receptor_final']
            final = artifact.final.data
            c = final['counts']
            assert final['exitstatus'] == code and c['collected'] == c['executed'] == total
            assert c['failed'] == failed and c['passed'] == total - failed and c['deselected'] == deselected
            assert c['not_executed'] == c['skipped'] == c['errors'] == 0
            assert not final['artifact_policy']['truncated'] and not final['extensions']['incomplete']
    normal = 'attempts/green-normal/'
    pm = 'attempts/green-pm_fs/'
    red = 'attempts/red-normal/'
    changed = {'dockingmt/core/audit.py', 'dockingmt/core/pose_audit.py'}
    assert obj(normal + 'registration.json')['selection'] == obj(pm + 'registration.json')['selection']
    for name in obj(normal + 'registration.json')['inputs_sha256']:
        frozen = 'frozen-' + name.replace('/', '__')
        assert records[normal + frozen] == records[pm + frozen]
        if name not in changed:
            assert records[red + frozen] == records[normal + frozen]
    assert records[red + 'frozen-test_child.py'] == records[normal + 'frozen-test_child.py'] == records[pm + 'frozen-test_child.py']
    added = 0
    for name in changed:
        frozen = 'frozen-' + name.replace('/', '__')
        before = ast.parse(records[red + frozen])
        after = ast.parse(records[normal + frozen])
        old_tries = [n for n in ast.walk(before) if isinstance(n, ast.Try)]
        new_tries = [n for n in ast.walk(after) if isinstance(n, ast.Try)]
        assert len(old_tries) == len(new_tries)
        for old, new in zip(old_tries, new_tries):
            if len(new.handlers) == len(old.handlers) + 1:
                extra = [n for n in new.handlers if ast.dump(n) not in [ast.dump(h) for h in old.handlers]]
                assert len(extra) == 1 and isinstance(extra[0].type, ast.Name) and extra[0].type.id == 'MemoryError'
                assert len(extra[0].body) == 1 and isinstance(extra[0].body[0], ast.Raise) and extra[0].body[0].exc is None
                new.handlers.remove(extra[0])
                added += 1
        assert ast.dump(before) == ast.dump(after)
    assert added == 3
    for name in sys.modules:
        assert name.split('.')[0] not in {'dockingmt', 'molsysmt', 'molsysviewer', 'vina', 'rdkit', 'openmm'}
    return {'complete_profiles': ['normal', 'pm_fs'], 'cases_per_profile': 464, 'original_failures_preserved': 15, 'new_guard_cases': 60, 'native_case_deselected_per_profile': 1, 'memory_passthrough_handlers': 3, 'test_replays': 0, 'molecular_imports': 0}
